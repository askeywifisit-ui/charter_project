from __future__ import annotations

import os
from contextlib import contextmanager
from datetime import datetime

from sqlalchemy import (
    create_engine, MetaData, Table, Column,
    Integer, String, DateTime, ForeignKey, Index,
    UniqueConstraint, func, text, select, update, insert
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import sessionmaker

# ---- DB 連線 ----
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql+psycopg2://rg:rg@localhost:5432/rg")
engine = create_engine(DATABASE_URL, pool_pre_ping=True, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
metadata = MetaData()

# ---- 資料表 ----
scripts = Table(
    "scripts", metadata,
    Column("id", Integer, primary_key=True),
    Column("name", String(255), nullable=False),
    Column("suite", String(50), nullable=False),            # stability / sanity / regression
    Column("entrypoint", String(255), nullable=False),      # e.g. "main.py:run"
    Column("req_caps", JSONB, nullable=True),
    Column("metadata", JSONB, nullable=True),
    Column("created_at", DateTime(timezone=False), server_default=func.now(), nullable=False),
    Column("updated_at", DateTime(timezone=False), server_default=func.now(), onupdate=func.now(), nullable=False),
    Column("zip_path", String(512), nullable=True),
    UniqueConstraint("name", "suite", name="uq_scripts_name_suite"),
)
Index("ix_scripts_suite", scripts.c.suite)

runs = Table(
    "runs", metadata,
    Column("id", Integer, primary_key=True),
    Column("script_id", Integer, ForeignKey("scripts.id", ondelete="CASCADE"), nullable=False),
    Column("status", String(32), nullable=False, server_default=text("'queued'")),  # queued/starting/running/passed/failed/error/stopped
    Column("created_at", DateTime(timezone=False), server_default=func.now(), nullable=False),
    Column("started_at", DateTime(timezone=False), nullable=True),
    Column("finished_at", DateTime(timezone=False), nullable=True),
    Column("result", JSONB, nullable=True),
    Column("log", JSONB, nullable=True),
)
Index("ix_runs_status", runs.c.status)
Index("ix_runs_script_id", runs.c.script_id)

def init_schema() -> None:
    metadata.create_all(engine, tables=[scripts, runs])
    # 單例執行索引：同時間只允許 1 筆 running/starting
    with engine.begin() as conn:
        conn.execute(text("""
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM pg_indexes WHERE schemaname='public' AND indexname='ux_runs_singleton'
            ) THEN
                CREATE UNIQUE INDEX ux_runs_singleton
                ON runs ((1)) WHERE status IN ('starting','running');
            END IF;
        END$$;
        """))

@contextmanager
def session_scope():
    s = SessionLocal()
    try:
        yield s
        if s.in_transaction():
            s.commit()
    except Exception:
        if s.in_transaction():
            s.rollback()
        raise
    finally:
        s.close()

def now() -> datetime:
    return datetime.utcnow()
