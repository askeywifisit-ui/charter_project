from app.routers.cpe_status import router as cpe_status_router
from app.routers.cpe_cached import router as cpe_cached_router
from fastapi import FastAPI, HTTPException
from app.routes.scripts_v2 import router as scripts_v2_router
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import create_engine, text, select, and_
import os
from datetime import datetime
from app.routers import event_log  # clear event log

# 內部路由
from . import work as work_api
from .routes import scripts as scripts_router
from .routes import runs as runs_router
from .routes import worker as worker_router
# DISABLED: from app.routes import dashboard  # 原本就有
from .routes import runs_files as runs_files_router

app = FastAPI(title="RG Test Platform API")
app.include_router(cpe_status_router)

# CORS 設定
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/health")
def health():
    return {"ok": True}

# 掛上所有既有路由
app.include_router(scripts_router.router)
app.include_router(runs_router.router)
app.include_router(work_api.router)
app.include_router(worker_router.router)
app.include_router(event_log.router)
# DISABLED: app.include_router(dashboard.router)
#from routes import metrics_debug
#app.include_router(metrics_debug.router)
app.include_router(runs_files_router.router)

# === Stop run API（沿用你現有實作） ===
if 'engine' not in globals():
    DB_URL = os.getenv("DATABASE_URL", "postgresql+psycopg2://rg:rg@localhost:5432/rg")
    engine = create_engine(DB_URL, future=True)

def _stop_impl(rid: int):
    with engine.begin() as conn:
        row = conn.execute(text("SELECT status FROM runs WHERE id=:id"), {"id": rid}).first()
        if not row:
            raise HTTPException(status_code=404, detail="run not found")
        st = row[0]
        now_iso = datetime.now().isoformat(timespec="seconds")

        if st == "queued":
            conn.execute(text("""
                UPDATE runs
                   SET status='error',
                       summary='stopped by user',
                       finished_at=now(),
                       updated_at=now()
                 WHERE id=:id
            """), {"id": rid})
            return {"ok": True, "mode": "stop_queued", "at": now_iso}

        if st in ("starting", "running"):
            conn.execute(text("""
                UPDATE runs
                   SET status='stopping',
                       updated_at=now()
                 WHERE id=:id
            """), {"id": rid})
            return {"ok": True, "mode": "mark_stopping", "at": now_iso}

        return {"ok": True, "mode": "noop", "status": st, "at": now_iso}

@app.post("/api/runs/{rid}/stop")
def api_stop_run(rid: int):
    return _stop_impl(rid)

@app.post("/api/runs/stop")
def api_stop_run_query(id: int):
    return _stop_impl(id)

# --- mount CPE info routes（如存在） ---
try:
    from .routes import cpe as cpe_router  # type: ignore
    app.include_router(cpe_router.router, prefix="/api")
except Exception as e:
    print(f"[api] warn: cpe routes not mounted: {e}")


import importlib as _imp
app.include_router(_imp.import_module("app.routes.dashboard_v3").router)

# ---- override /api/dashboard/metrics to v3 ----
try:
    from starlette.routing import Route
    # 移除任何已存在的 GET /api/dashboard/metrics（避免與 metrics.py / dashboard.py / hotfix 衝突）
    app.router.routes[:] = [
        r for r in app.router.routes
        if not (isinstance(r, Route) and r.path == "/api/dashboard/metrics" and "GET" in getattr(r, "methods", set()))
    ]
except Exception as _e:
    # 忽略移除失敗（例如 Route 型別不同），讓後面的 v3 照常掛上
    pass

# 以最後順序掛上 v3（operationId: dashboard_metrics_v3_api_dashboard_metrics_get）
import importlib as _imp
app.include_router(_imp.import_module("app.routes.dashboard_v3").router)
# ---- end override ----

# ---- override /api/dashboard/metrics to v3 ----
try:
    from starlette.routing import Route
    # 移除任何已存在的 GET /api/dashboard/metrics（避免與 metrics.py / dashboard.py / hotfix 衝突）
    app.router.routes[:] = [
        r for r in app.router.routes
        if not (isinstance(r, Route) and r.path == "/api/dashboard/metrics" and "GET" in getattr(r, "methods", set()))
    ]
except Exception as _e:
    # 忽略移除失敗（例如 Route 型別不同），讓後面的 v3 照常掛上
    pass

# 以最後順序掛上 v3（operationId: dashboard_metrics_v3_api_dashboard_metrics_get）
import importlib as _imp
app.include_router(_imp.import_module("app.routes.dashboard_v3").router)
# ---- end override ----
app.include_router(scripts_v2_router)
