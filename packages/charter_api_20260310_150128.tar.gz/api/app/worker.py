#!/usr/bin/env python3
import os, re, json, time, shutil, zipfile, subprocess, traceback, signal
from pathlib import Path
from datetime import datetime, timezone
from sqlalchemy import create_engine, text
from sqlalchemy.exc import ProgrammingError

# --- DB 連線 ---
DB_URL = os.environ.get("DATABASE_URL", "postgresql+psycopg2://rg:rg@localhost:5432/rg")
engine = create_engine(DB_URL, isolation_level="AUTOCOMMIT", future=True)

# --- 路徑設定 ---
BASE = Path("/home/da40/charter/data")
WORK_ROOT = BASE / "work"
VENV_ROOT = BASE / "venv"
WORK_ROOT.mkdir(parents=True, exist_ok=True)
VENV_ROOT.mkdir(parents=True, exist_ok=True)

# --- 參數 ---
STARTING_MAX_AGE_SEC = int(os.environ.get("STARTING_MAX_AGE_SEC", "120"))
IDLE_SLEEP = float(os.environ.get("WORKER_IDLE_SLEEP", "1"))
BUSY_SLEEP = float(os.environ.get("WORKER_BUSY_SLEEP", "1.5"))

# --- ANSI 顏色碼過濾 ---
ANSI_RE = re.compile(r"\x1B\[[0-9;]*[A-Za-z]")
def _sanitize(s: str) -> str: return "" if not s else ANSI_RE.sub("", s)

# ---------- log 追加（支援 jsonb / text 欄位） ----------
def _log_append_with_conn(conn, rid: int, msg: str):
    msg = _sanitize(msg)
    entry = {"time": datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S'), "msg": msg}
    arr = json.dumps([entry])
    try:
        conn.execute(text("""
            UPDATE runs
               SET log = COALESCE(log, '[]'::jsonb) || :arr::jsonb,
                   updated_at = now()
             WHERE id = :rid
        """), {"rid": rid, "arr": arr})
    except ProgrammingError:
        conn.execute(text("""
            UPDATE runs
               SET log = CASE
                           WHEN log IS NULL OR log = '' THEN :line
                           ELSE log || E'\n' || :line
                         END,
                   updated_at = now()
             WHERE id = :rid
        """), {"rid": rid, "line": f"[{entry['time']}] {msg}"})

def log_append(rid: int, msg: str, conn=None):
    if conn is not None: _log_append_with_conn(conn, rid, msg); return
    with engine.begin() as c: _log_append_with_conn(c, rid, msg)

# ---------- 讀/改狀態 ----------
def get_status(conn, rid: int) -> str | None:
    row = conn.execute(text("SELECT status FROM runs WHERE id=:id"), {"id": rid}).first()
    return None if not row else row[0]

def mark_status(conn, rid: int, status: str, *, started=False, finished=False, summary: str | None=None):
    cols = ["status=:st", "updated_at=now()"]; params = {"rid": rid, "st": status}
    if started: cols.append("started_at=now()")
    if finished: cols.append("finished_at=now()")
    if summary is not None: cols.append("summary=:sm"); params["sm"] = summary
    conn.execute(text(f"UPDATE runs SET {', '.join(cols)} WHERE id=:rid"), params)

# ---------- 撿工作 & 卡住的 starting 復原 ----------
def revive_stuck_starting():
    with engine.begin() as conn:
        conn.execute(text(f"""
            UPDATE runs
               SET status='queued', updated_at=now()
             WHERE status='starting'
               AND (started_at IS NULL OR started_at < now() - interval '{STARTING_MAX_AGE_SEC} seconds')
        """))

def pick_one():
    revive_stuck_starting()
    with engine.begin() as conn:
        row = conn.execute(text("""
            SELECT r.id, r.script_id, s.zip_path, s.entrypoint, s.name
              FROM runs r
              JOIN scripts s ON s.id = r.script_id
             WHERE r.status = 'queued'
             ORDER BY r.id
             FOR UPDATE SKIP LOCKED
             LIMIT 1
        """)).mappings().first()
        if not row: return None
        mark_status(conn, row["id"], "starting", started=True)
        return row

# ---------- venv ----------
def ensure_venv(script_id: int):
    venv = VENV_ROOT / f"script_{script_id}"
    py = venv / "bin" / "python3"
    pip = venv / "bin" / "pip"
    if not py.exists():
        subprocess.run(["python3", "-m", "venv", str(venv)], check=True)
    return str(venv), str(py), str(pip)

# ---------- 輔助：嘗試殺掉整棵 process tree（可無 psutil） ----------
def kill_tree(pid: int, rid: int):
    try:
        import psutil  # 可選
        parent = psutil.Process(pid)
        children = parent.children(recursive=True)
        for c in children:
            try: c.kill()
            except Exception: pass
        try: parent.kill()
        except Exception: pass
        log_append(rid, f"[runner] force-killed {len(children)} subprocess(es) (pid={pid})")
    except Exception:
        # 沒有 psutil 就退而求其次，用 SIGKILL 整個 group
        try:
            os.killpg(os.getpgid(pid), signal.SIGKILL)
        except Exception:
            pass

# ---------- 子程序串流 + 可中止（強化版） ----------
def stream_with_cancel(cmd, *, rid: int, cwd: str | None = None, env: dict | None = None) -> int:
    # 用 setsid 讓子程有獨立 process group，方便整組 kill
    p = subprocess.Popen(
        cmd, cwd=cwd, env=env,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, bufsize=1, universal_newlines=True,
        preexec_fn=os.setsid
    )
    try:
        assert p.stdout is not None
        while True:
            line = p.stdout.readline()
            if line: log_append(rid, line.rstrip("\n"))
            if p.poll() is not None: break

            # 偵測停止要求
            with engine.begin() as c:
                if get_status(c, rid) == "stopping":
                    log_append(rid, "[runner] stop requested — terminating process group ...")
                    # 先溫和關閉整個 group
                    try: os.killpg(os.getpgid(p.pid), signal.SIGTERM)
                    except Exception: pass
                    # 最多等 3 秒
                    for _ in range(30):
                        if p.poll() is not None: break
                        time.sleep(0.1)
                    # 還活著就強制殺整棵
                    if p.poll() is None:
                        log_append(rid, "[runner] group still alive — killing tree ...")
                        kill_tree(p.pid, rid)
                    break
            time.sleep(0.2)
    finally:
        try:
            if p.stdout: p.stdout.close()
        except Exception:
            pass
    return p.wait() if p.returncode is not None else 1

# ---------- worker 主流程 ----------
def run_once():
    job = pick_one()
    if not job: return False

    rid = job["id"]; sid = job["script_id"]
    zip_path = job["zip_path"]
    entry = (job["entrypoint"] or "main.py:run").strip()

    workdir = WORK_ROOT / f"run_{rid}"
    if workdir.exists(): shutil.rmtree(workdir, ignore_errors=True)
    workdir.mkdir(parents=True, exist_ok=True)

    status = "error"; summary = None
    try:
        log_append(rid, f"[worker] picked run #{rid} (script {sid}) zip={zip_path}")
        with zipfile.ZipFile(zip_path, "r") as z: z.extractall(workdir)
        log_append(rid, f"[worker] unzipped → {workdir}")

        with engine.begin() as conn: mark_status(conn, rid, "running")

        venv, py, pip = ensure_venv(sid)

        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"
        env["FORCE_COLOR"] = "0"; env["NO_COLOR"] = "1"
        env["PYTHONWARNINGS"] = "ignore"
        env["RUN_ID"] = str(rid)  # 讓腳本可自我偵測停止

        # requirements
        req = workdir / "requirements.txt"
        if req.exists():
            log_append(rid, f"[worker] pip install -r requirements.txt (venv={venv})")
            rc_pip = stream_with_cancel([pip, "install", "-r", str(req)], rid=rid, env=env)
            log_append(rid, f"[worker] pip exit_code={rc_pip}")
            if rc_pip != 0:
                status = "failed"; raise RuntimeError(f"pip failed with rc={rc_pip}")

        # 嘗試 <module>:<func>；失敗(回 111)改直跑檔案
        code = 1
        if ":" in entry:
            mod, func = entry.split(":", 1)
            if mod.endswith(".py"): mod = mod[:-3]
            code_str = (
                "import sys,importlib,inspect,traceback\n"
                f"sys.path.insert(0,r'{workdir}')\n"
                f"mod='{mod}'; func='{func}'\n"
                "try:\n"
                "    m=importlib.import_module(mod)\n"
                "    f=getattr(m,func,None)\n"
                "    print('[runner] entry:', m.__name__, getattr(f,'__name__',None))\n"
                "    rc = f() if callable(f) and len(inspect.signature(f).parameters)==0 else (f({}) if callable(f) else 0)\n"
                "    sys.exit(int(rc) if rc is not None else 0)\n"
                "except Exception:\n"
                "    traceback.print_exc(); sys.exit(111)\n"
            )
            code = stream_with_cancel([py, "-u", "-c", code_str], rid=rid, env=env)
            if code == 111:
                log_append(rid, "[runner] import path failed → fallback to file exec")
                entry = entry.split(":")[0]

        if ":" not in entry:
            file_path = workdir / entry
            if not file_path.exists(): file_path = workdir / "main.py"
            log_append(rid, f"[runner] exec file: {file_path}")
            code = stream_with_cancel([py, "-u", str(file_path)], rid=rid, cwd=str(workdir), env=env)

        # 如果中途被標記 stopping，視為使用者中止
        with engine.begin() as c: st = get_status(c, rid)
        if st == "stopping":
            status = "error"; summary = "stopped by user"
            log_append(rid, "[runner] stopped by user")
        else:
            status = "passed" if code == 0 else "failed"
        log_append(rid, f"[runner] exit_code={code}")

    except Exception as e:
        status = "error" if status not in ("failed", "passed") else status
        tb = "".join(traceback.format_exception(type(e), e, e.__traceback__))
        log_append(rid, f"[worker] exception: {type(e).__name__}: {e}\n{tb}")
    finally:
        with engine.begin() as conn:
            mark_status(conn, rid, status, finished=True, summary=summary)
    return True

def main():
    print("[worker] start polling queue...")
    while True:
        did = run_once()
        time.sleep(BUSY_SLEEP if did else IDLE_SLEEP)

if __name__ == "__main__":
    main()
