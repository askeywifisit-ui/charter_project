#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CPE Metrics API (FastAPI) — router 版（供 app.main include），同時也提供 app 直接啟動。
- 啟動時一次性初始化 Schema（用 advisory lock 防止多進程競態/死鎖）
- /api/metrics/push        : 收 agent 單筆 metrics（含 wifi_clients 與 radio 陣列）
- /api/metrics/latest      : 取最新 N 筆（wifi_clients 向前填值、rx/tx NULL→0）
- /api/wifi/stations/count : 回 DB 最新一筆 wifi_clients（只讀 DB）
- /api/wifi/radio/state    : 回 DB 最新時間戳的一組 radio 狀態
- /api/dashboard/metrics   : 儀表板匯總（表不存在時回安全預設）
"""
from fastapi import FastAPI, APIRouter, Body, HTTPException
from starlette.middleware.cors import CORSMiddleware
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List
import os
import json

# -------------------- DB 連線 --------------------
DATABASE_URL = os.environ.get(
    "DATABASE_URL",
    "postgresql+psycopg2://rg:rg@localhost:5432/rg"
)
engine = create_engine(DATABASE_URL, future=True)

# -------------------- router（給 main.py include） --------------------
router = APIRouter(prefix="/api", tags=["metrics", "wifi", "dashboard"])

# -------------------- 一次性 Schema 初始化（避免死鎖） --------------------
_INIT_DONE = False
def init_schema_once() -> None:
    """僅在載入時做一次 DDL，使用 advisory lock 避免多進程死鎖。"""
    global _INIT_DONE
    if _INIT_DONE:
        return
    with engine.begin() as conn:
        conn.execute(text("SELECT pg_advisory_lock(9137501)"))
        try:
            conn.execute(text("""
                CREATE TABLE IF NOT EXISTS cpe_metrics(
                    ts           timestamptz NOT NULL DEFAULT now(),
                    cpu_pct      real,
                    mem_pct      real,
                    temp_c       real,
                    rx_mbps      real,
                    tx_mbps      real,
                    latency_ms   real,
                    run_id       integer,
                    wifi_clients integer
                );
            """))
            conn.execute(text("""
                CREATE INDEX IF NOT EXISTS idx_cpe_metrics_ts
                  ON cpe_metrics(ts);
            """))
            conn.execute(text("""
                CREATE TABLE IF NOT EXISTS wifi_radio_state(
                    ts        timestamptz NOT NULL DEFAULT now(),
                    if_name   text,
                    channel   text,
                    ht_mode   text,
                    tx_power  text,
                    country   text
                );
            """))
            conn.execute(text("""
                CREATE INDEX IF NOT EXISTS idx_wifi_radio_state_ts
                  ON wifi_radio_state(ts);
            """))
            _INIT_DONE = True
        finally:
            conn.execute(text("SELECT pg_advisory_unlock(9137501)"))

# 模組載入就初始化（不要在請求裡做任何 DDL）
init_schema_once()

# -------------------- 小工具 --------------------
def table_exists(conn, tbl_name: str) -> bool:
    return bool(conn.execute(text("SELECT to_regclass(:t) IS NOT NULL"), {"t": tbl_name}).scalar())

def utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

# -------------------- 健康檢查 --------------------
@router.get("/health")
def api_health():
    return {"ok": True, "time": utcnow_iso()}

# -------------------- 推送 Metrics（含 wifi/radio/bands） --------------------
@router.post("/metrics/push")
def api_metrics_push(payload: Dict[str, Any] = Body(...)):
    """
    接收 agent 的單筆 metrics：
      必填（任一鍵名）：cpu_pct/cpu, mem_pct/mem, temp_c/tmp, rx_mbps/rx, tx_mbps/tx, latency_ms/lat
      選填：run_id/rid, wifi_clients, wifi_bands(=wifi_clients_per_band), radio: [{if_name,channel,ht_mode,tx_power,country}, ...]
    """
    # 相容舊鍵名
    cpu = payload.get("cpu_pct")    or payload.get("cpu")
    mem = payload.get("mem_pct")    or payload.get("mem")
    tmp = payload.get("temp_c")     or payload.get("tmp")
    rx  = payload.get("rx_mbps")    or payload.get("rx")
    tx  = payload.get("tx_mbps")    or payload.get("tx")
    lat = payload.get("latency_ms") or payload.get("lat")
    rid = payload.get("run_id")     or payload.get("rid")
    wif = payload.get("wifi_clients")
    bands = payload.get("wifi_bands") or payload.get("wifi_clients_per_band")  # ★ 新增：拿每頻段連線數
    radios = payload.get("radio") or []

    # 若沒帶 wifi_clients，但 bands 有 total/可加總，幫忙補 total
    if wif is None and isinstance(bands, dict):
        total = bands.get("total")
        if total is None:
            total = sum(v for k, v in bands.items() if isinstance(v, (int, float)))
        wif = int(total) if total is not None else None

    with engine.begin() as conn:
        # ★ INSERT 新增 wifi_clients_per_band 欄位（jsonb）
        conn.execute(text("""
            INSERT INTO cpe_metrics (
                cpu_pct, mem_pct, temp_c, rx_mbps, tx_mbps, latency_ms,
                run_id, wifi_clients, wifi_clients_per_band
            ) VALUES (
                :cpu, :mem, :tmp, :rx, :tx, :lat,
                :rid, :wifi, :bands
            )
        """), {
            "cpu": cpu, "mem": mem, "tmp": tmp,
            "rx": rx, "tx": tx, "lat": lat,
            "rid": rid, "wifi": wif,
            "bands": json.dumps(bands) if bands is not None else None,
        })

        if isinstance(radios, list) and radios:
            conn.execute(text("""
                INSERT INTO wifi_radio_state (if_name, channel, ht_mode, tx_power, country)
                VALUES (:if_name, :channel, :ht_mode, :tx_power, :country)
            """), [
                {
                    "if_name": str(r.get("if_name", "")),
                    "channel": str(r.get("channel", "")),
                    "ht_mode": str(r.get("ht_mode", "")),
                    "tx_power": str(r.get("tx_power", "")),
                    "country": str(r.get("country", "")),
                }
                for r in radios if isinstance(r, dict)
            ])

    return {"ok": True}

# -------------------- 最新 N 筆（wifi 向前填值，帶出 bands） --------------------
@router.get("/metrics/latest")
def api_metrics_latest(n: int = 60, limit: int | None = None):
    """
    回傳最新 n 筆（舊→新排序）：
      - 支援 query 參數 limit（若有則覆蓋 n）
      - wifi_clients 使用最近一筆非空值向前填（forward-fill）
      - rx/tx 的 NULL 以 0 補齊
      - 帶出 wifi_clients_per_band 為 wifi_bands（給 GUI 用）
    """
    if limit is not None:
        n = limit
    n = max(1, min(int(n), 600))

    with engine.begin() as conn:
        rows = conn.execute(text("""
            WITH chunk AS (
                SELECT *
                  FROM cpe_metrics
              ORDER BY ts DESC
                 LIMIT :n
            )
            SELECT
                c.ts,
                c.cpu_pct,
                c.mem_pct,
                c.temp_c,
                COALESCE(c.rx_mbps, 0)::float AS rx_mbps,
                COALESCE(c.tx_mbps, 0)::float AS tx_mbps,
                c.latency_ms,
                COALESCE(c.wifi_clients, w.wifi_clients) AS wifi_clients,
                c.wifi_clients_per_band AS wifi_bands               -- ★ 新增：把欄位帶出
            FROM chunk c
            LEFT JOIN LATERAL (
                SELECT x.wifi_clients
                  FROM cpe_metrics x
                 WHERE x.ts <= c.ts
                   AND x.wifi_clients IS NOT NULL
              ORDER BY x.ts DESC
                 LIMIT 1
            ) w ON TRUE
            ORDER BY c.ts ASC
        """), {"n": n}).mappings().all()

    return {"ok": True, "data": [
        {
            "ts": r["ts"].strftime("%Y-%m-%d %H:%M:%S"),
            "cpu_pct": r["cpu_pct"],
            "mem_pct": r["mem_pct"],
            "temp_c": r["temp_c"],
            "rx_mbps": r["rx_mbps"],
            "tx_mbps": r["tx_mbps"],
            "latency_ms": r["latency_ms"],
            "wifi_clients": r["wifi_clients"],
            "wifi_bands": r["wifi_bands"],                           # ★ 新增：回前端沿用舊鍵名
        } for r in rows
    ]}

# -------------------- Wi-Fi Stations（只讀 DB 最新） --------------------
@router.get("/wifi/stations/count")
def api_wifi_stations_count():
    with engine.begin() as conn:
        row = conn.execute(text("""
            SELECT wifi_clients, ts
              FROM cpe_metrics
             WHERE wifi_clients IS NOT NULL
          ORDER BY ts DESC
             LIMIT 1
        """)).first()
    if not row:
        return {"ok": False, "count": None, "error": "no db value yet"}
    count, ts = row
    return {
        "ok": True,
        "count": int(count),
        "source": "db",
        "ts": ts.isoformat() if hasattr(ts, "isoformat") else str(ts),
    }

# -------------------- Wi-Fi Radio（最新一組） --------------------
@router.get("/wifi/radio/state")
def api_wifi_radio_state():
    with engine.begin() as conn:
        latest_ts = conn.execute(text("SELECT max(ts) FROM wifi_radio_state")).scalar()
        if not latest_ts:
            return {"ok": True, "ts": None, "data": []}
        rows = conn.execute(text("""
            SELECT if_name, channel, ht_mode, tx_power, country
              FROM wifi_radio_state
             WHERE ts = :ts
             ORDER BY if_name
        """), {"ts": latest_ts}).mappings().all()
    return {"ok": True, "ts": latest_ts.isoformat(), "data": [dict(r) for r in rows]}

# -------------------- Dashboard 匯總（表不存在時回安全預設） --------------------
@router.get("/dashboard/metrics")
def api_dashboard_metrics():
    since = datetime.utcnow() - timedelta(hours=24)
    suites = ["stability", "sanity", "regression"]
    pass_rate: Dict[str, float] = {}
    events: List[Dict[str, Any]] = []

    with engine.begin() as conn:
        # pass rate（若沒有表，回 0）
        try:
            if table_exists(conn, "runs") and table_exists(conn, "scripts"):
                for s in suites:
                    row = conn.execute(text("""
                        SELECT COUNT(*) AS total,
                               COUNT(*) FILTER (WHERE r.status='passed') AS passed
                          FROM runs r
                          JOIN scripts sc ON sc.id = r.script_id
                         WHERE sc.suite = :suite
                           AND r.created_at >= :since
                    """), {"suite": s, "since": since}).mappings().first()
                    total = int(row["total"] or 0)
                    passed = int(row["passed"] or 0)
                    rate = round(passed / total * 100.0, 1) if total else 0.0
                    pass_rate[s] = rate
            else:
                pass_rate = {s: 0.0 for s in suites}
        except SQLAlchemyError:
            pass_rate = {s: 0.0 for s in suites}

        # events（最新 10 筆失敗；若沒有表，回空）
        try:
            if table_exists(conn, "runs") and table_exists(conn, "scripts"):
                rows = conn.execute(text("""
                    SELECT r.finished_at, sc.name AS script_name, sc.suite, r.summary
                      FROM runs r
                      JOIN scripts sc ON sc.id = r.script_id
                     WHERE r.status='failed'
                  ORDER BY r.finished_at DESC NULLS LAST, r.id DESC
                     LIMIT 10
                """)).mappings().all()
                for x in rows:
                    ts = x["finished_at"].strftime("%Y-%m-%d %H:%M:%S") if x["finished_at"] else ""
                    msg = f"{x['script_name']} ({x['suite']}) → Fail: {x['summary'] or 'unknown cause'}"
                    events.append({"ts": ts, "msg": msg})
        except SQLAlchemyError:
            events = []

        # metrics series（最近 60 筆，2 小時內）
        mrows = conn.execute(text("""
            SELECT ts, cpu_pct, mem_pct, temp_c,
                   COALESCE(rx_mbps,0)::float AS rx_mbps,
                   COALESCE(tx_mbps,0)::float AS tx_mbps,
                   latency_ms
              FROM cpe_metrics
             WHERE ts >= now() - interval '2 hours'
          ORDER BY ts DESC
             LIMIT 60
        """)).mappings().all()

    series = list(reversed(mrows))
    cpu  = [{"value": (r["cpu_pct"] or 0.0)} for r in series]
    mem  = [{"value": (r["mem_pct"] or 0.0)} for r in series]
    temp = [{"value": (r["temp_c"]   or 0.0)} for r in series]
    thr  = [{"value": ((r["rx_mbps"] or 0.0) + (r["tx_mbps"] or 0.0))} for r in series]
    lat  = [{"value": (r["latency_ms"] or 0.0)} for r in series]

    return {
        "pass_rate": pass_rate,
        "cpu": cpu, "mem": mem, "temp": temp, "throughput": thr, "latency": lat,
        "events": events
    }

# -------------------- 可直接啟動的 app（選擇性用法） --------------------
app = FastAPI(title="CPE Metrics API (with router)", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True,
    allow_methods=["*"], allow_headers=["*"],
)
app.include_router(router)

