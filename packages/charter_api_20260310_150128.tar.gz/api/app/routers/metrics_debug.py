# /home/da40/charter/apps/api/routes/metrics_debug.py
from fastapi import APIRouter
import time, json

router = APIRouter(prefix="/api/metrics", tags=["metrics-debug"])

@router.get("/debug")
def metrics_debug(iface: str = "eth0", interval: float = 1.2):
    """
    直接從 /proc/net/dev 讀取速率，計算 RX/TX Mbps。
    用來比對 cpe_console_serial 的 throughput 計算是否一致。
    """
    def read_counters(iface):
        with open("/proc/net/dev") as f:
            for line in f:
                if f"{iface}:" in line:
                    parts = line.split(":")[1].split()
                    return int(parts[0]), int(parts[8])
        raise ValueError(f"Interface {iface} not found")

    rx1, tx1 = read_counters(iface)
    time.sleep(interval)
    rx2, tx2 = read_counters(iface)

    dr = rx2 - rx1
    dt = tx2 - tx1
    if dr < 0: dr += 2**32
    if dt < 0: dt += 2**32
    rx_mbps = dr * 8 / interval / 1e6
    tx_mbps = dt * 8 / interval / 1e6

    return {
        "iface": iface,
        "interval": interval,
        "rx_mbps": round(rx_mbps, 3),
        "tx_mbps": round(tx_mbps, 3),
        "source": "/proc/net/dev"
    }

