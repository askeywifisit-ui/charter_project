from fastapi import APIRouter, Depends
from sqlalchemy import text
from datetime import datetime, timezone
from cachetools import TTLCache
from importlib import import_module

def _resolve_get_db():
    for modpath in ("app.db", "app.database", "db", "database"):
        try:
            mod = import_module(modpath)
            fn = getattr(mod, "get_db", None)
            if fn: return fn
        except Exception:
            continue
    raise ImportError("get_db not found in app.db / app.database / db / database")

get_db = _resolve_get_db()

router = APIRouter()
_cache = TTLCache(maxsize=64, ttl=5)  # 5 秒微快取

@router.get("/api/metrics/age")
def metrics_age(db=Depends(get_db)):
    if "age" in _cache:
        return _cache["age"]

    # 兼容 Session.scalar(...) 與 Session.execute(...).scalar()
    try:
        last_ts = db.scalar(text("SELECT MAX(ts) FROM cpe_metrics"))
    except Exception:
        last_ts = db.execute(text("SELECT MAX(ts) FROM cpe_metrics")).scalar()

    if not last_ts:
        res = {"ok": True, "last_ts": None, "age_sec": None, "stale": True}
        _cache["age"] = res
        return res

    now = datetime.now(timezone.utc)
    age = int((now - last_ts).total_seconds())
    # agent 每 5s 上報，>15s 視為 stale
    res = {"ok": True, "last_ts": last_ts, "age_sec": age, "stale": age > 15}
    _cache["age"] = res
    return res
