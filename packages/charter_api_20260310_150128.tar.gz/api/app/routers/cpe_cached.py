import json
from urllib.request import urlopen
from fastapi import APIRouter
from app.utils.microcache import cache10, key

router = APIRouter()

@router.get("/api/cpe/info_cached")
def cpe_info_cached():
    k = key("cpe_info_cached")
    if k in cache10:
        return cache10[k]
    with urlopen("http://127.0.0.1:8080/api/cpe/info", timeout=2) as r:
        data = json.loads(r.read().decode("utf-8"))
    cache10[k] = data
    return data
