from fastapi import APIRouter
from sqlalchemy import text, create_engine
from app.utils.microcache import cache10, key
from datetime import datetime, timezone, timedelta
import os

router = APIRouter()
try:
    from app.main import db_engine
except Exception:
    db_engine = create_engine(os.environ.get("DATABASE_URL","postgresql+psycopg2://rg:rg@localhost:5432/rg"))

FRESH_SEC = int(os.environ.get("CPE_STATUS_FRESH_SEC", "20"))  # GUI 5s → 給 12s 緩衝


def _parse_to_aware_dt(ts):
    if ts is None:
        return None
    if isinstance(ts, datetime):
        return ts if ts.tzinfo else ts.replace(tzinfo=timezone.utc)
    try:
        s = str(ts).strip()
        if s.endswith('Z'): s = s[:-1] + '+00:00'
        dt = datetime.fromisoformat(s)
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except Exception:
        return None



@router.get("/api/cpe/status/latest")
def cpe_status_latest(device_id: str | None = None):
    k = key("cpe_status_latest_v2", device_id=device_id or "")
    # if k in cache10:
    #     return cache10[k]

    sql_any = '''
      SELECT ts, device_id, internet_ok, cloud_ok, ipv4, mac, serial, model, fw, probe_ms, error
      FROM cpe_status
      WHERE (:dev IS NULL OR device_id IS NOT DISTINCT FROM :dev)
      ORDER BY ts DESC
      LIMIT 1
    '''
    sql_ok = '''
      SELECT ts, device_id, internet_ok, cloud_ok, ipv4, mac, serial, model, fw, probe_ms, error
      FROM cpe_status
      WHERE error IS NULL AND (:dev IS NULL OR device_id IS NOT DISTINCT FROM :dev)
      ORDER BY ts DESC
      LIMIT 1
    '''
    with db_engine.begin() as conn:
        last_any = conn.execute(text(sql_any), {"dev": device_id}).mappings().first()
        last_ok  = conn.execute(text(sql_ok),  {"dev": device_id}).mappings().first()

    now = datetime.now(timezone.utc)

    # --- 方便轉 ISO 字串（安全，不會因 ts 是字串而崩潰） ---
    def ts_to_iso(x):
        if x is None:
            return None
        dt = _parse_to_aware_dt(x)
        return dt.isoformat() if dt is not None else str(x)

    # === 舊行為（保留）：用「最新一筆」來算 age_sec / stale / source ===
    probe_ok = bool(last_any and last_any.get("error") is None)
    age_sec = None
    if last_any and last_any.get("ts") is not None:
        ts_any = _parse_to_aware_dt(last_any["ts"])
        if ts_any is not None:
            age_sec = max(0, int((now - ts_any).total_seconds()))

    stale = True
    data = None
    source = "none"
    if last_any:
        if probe_ok and age_sec is not None and age_sec <= FRESH_SEC:
            data = dict(last_any)
            stale = False
            source = "latest_ok"
        else:
            source = "error_or_stale"

    # === 修正：Heartbeat 年齡優先用 last_ok，沒有就退回 last_any（解決剛開機不更新） ===
    last_ok_ts_iso = None
    hb_age_sec = None
    if last_ok and last_ok.get("ts"):
        ts_ok = _parse_to_aware_dt(last_ok["ts"])
        if ts_ok is not None:
            last_ok_ts_iso = ts_ok.isoformat()
            hb_age_sec = max(0, int((now - ts_ok).total_seconds()))
    if hb_age_sec is None and last_any and last_any.get("ts"):
        ts_any = _parse_to_aware_dt(last_any["ts"])
        if ts_any is not None:
            # 沒有成功樣本時，用最新樣本的時間當心跳年齡
            hb_age_sec = max(0, int((now - ts_any).total_seconds()))
            if last_ok_ts_iso is None:
                last_ok_ts_iso = ts_any.isoformat()

    # === 正規化 internet/cloud（維持你原本預設 False 的邏輯） ===
    def yn(v, fallback=False):
        if isinstance(v, bool): return v
        if v in (1, "1", "true", "True", "connected", "Connected"): return True
        if v in (0, "0", "false", "False", "disconnected", "Disconnected"): return False
        return fallback

    pick = None
    for r in (data, last_ok, last_any):
        if r:
            pick = r
            break

    internet_ok = yn(pick.get("internet_ok") if pick else None, fallback=False)
    cloud_ok    = yn(pick.get("cloud_ok")    if pick else None, fallback=False)

    def label(ok: bool) -> str:
        return "Connected" if ok else "Disconnected"

    res = {
        # === 原欄位（保留） ===
        "ok": bool(last_any),
        "source": source,
        "probe_ok": probe_ok,
        "age_sec": age_sec,
        "stale": stale,
        "ts": ts_to_iso(last_any.get("ts") if last_any else None),
        "data": data,
        "last_ok": (dict(last_ok) if last_ok else None),

        # === Heartbeat & 時間戳（修正版） ===
        "last_ok_ts": last_ok_ts_iso,
        "last_ok_compact": ({"ts": last_ok_ts_iso} if last_ok_ts_iso else None),
        "hb_age_sec": hb_age_sec,
        "heartbeat_age_sec": hb_age_sec,

        # === 小膠囊 ===
        "internet_ok": internet_ok,
        "cloud_ok": cloud_ok,
        "internet": label(internet_ok),
        "cloud":    label(cloud_ok),

        # === 其他資訊（取最可信來源 pick） ===
        "ipv4":   (pick.get("ipv4")   if pick else None),
        "mac":    (pick.get("mac")    if pick else None),
        "serial": (pick.get("serial") if pick else None),
        "model":  (pick.get("model")  if pick else None),
        "fw":     (pick.get("fw")     if pick else None),
        "probe_ms": (pick.get("probe_ms") if pick else None),
        "error":    (pick.get("error")    if pick else None),
        "device_id": (pick.get("device_id") if pick else (device_id or None)),
    }

    cache10[k] = res
    return res

