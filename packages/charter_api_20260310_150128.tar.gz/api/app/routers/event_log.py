# app/routers/event_log.py
from fastapi import APIRouter, Query, HTTPException
from sqlalchemy import create_engine, text
import os

# 1) 連線字串 — 先吃環境變數 DATABASE_URL，否則 fallback 你給的 DSN
DB_URL = os.getenv("DATABASE_URL") or "postgresql+psycopg2://rg:rg@127.0.0.1:5432/rg"
engine = create_engine(DB_URL, pool_pre_ping=True, future=True)

router = APIRouter()

@router.post("/api/event-log/clear")
def clear_event_log(hours: int | None = Query(default=None, ge=0, le=720)):
    """
    刪除 event_log：
    - hours 未提供或 =0  => 刪除全部
    - hours = 24/48/72  => 刪除「最近 N 小時內」的資料
    回傳刪除筆數（若 rowcount 無法取得，回傳 -1）
    """
    try:
        with engine.begin() as conn:
            if not hours:
                res = conn.execute(text("DELETE FROM event_log"))
            else:
                res = conn.execute(
                    text("DELETE FROM event_log WHERE ts >= now() - (:h || ' hours')::interval"),
                    {"h": hours},
                )
            deleted = res.rowcount if res.rowcount is not None else -1
        return {"ok": True, "deleted": deleted, "hours": hours}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

