from fastapi import APIRouter, Depends
from sqlalchemy import text
from datetime import datetime, timezone
try:
    from app.db import get_db
except Exception:
    from app.database import get_db  # type: ignore

router = APIRouter()

def _age_sec(db):
    last_ts = db.scalar(text("SELECT MAX(ts) FROM cpe_metrics"))
    if not last_ts: return None, None, True
    age = int((datetime.now(timezone.utc) - last_ts).total_seconds())
    return last_ts, age, age > 15

@router.get("/api/metrics/latest_sanitized")
def latest_sanitized(db=Depends(get_db)):
    # 先沿用你既有 latest 結果
    row = db.execute(text("""
      SELECT
        MAX(ts)                              AS ts,
        AVG(cpu_pct) FILTER (WHERE ts = (SELECT MAX(ts) FROM cpe_metrics)) AS cpu,
        AVG(mem_pct) FILTER (WHERE ts = (SELECT MAX(ts) FROM cpe_metrics)) AS mem,
        AVG(temp_c)  FILTER (WHERE ts = (SELECT MAX(ts) FROM cpe_metrics)) AS temp,
        AVG(dl_mbps) FILTER (WHERE ts = (SELECT MAX(ts) FROM cpe_metrics)) AS dl,
        AVG(ul_mbps) FILTER (WHERE ts = (SELECT MAX(ts) FROM cpe_metrics)) AS ul,
        AVG(lat_ms)  FILTER (WHERE ts = (SELECT MAX(ts) FROM cpe_metrics)) AS lat
      FROM cpe_metrics
    """)).mappings().first()

    last_ts, age, stale = _age_sec(db)

    # 在 stale 時，把最新值設成 None（前端就會顯示 "—"）
    def mask(v): return None if stale else v
    data = {
      "ts": last_ts or row.get("ts"),
      "cpu": mask(row.get("cpu")),
      "mem": mask(row.get("mem")),
      "temp": mask(row.get("temp")),
      "dl": mask(row.get("dl")),
      "ul": mask(row.get("ul")),
      "lat": mask(row.get("lat")),
    }
    return {"ok": True, "stale": stale, "age_sec": age, "data": data}
