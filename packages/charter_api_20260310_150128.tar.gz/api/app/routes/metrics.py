from __future__ import annotations
import datetime as dt, math, random
from fastapi import APIRouter
from sqlalchemy import select, and_
from ..db import session_scope, runs, telemetry, event_log, scripts  # <— add scripts

router = APIRouter(prefix="/api/metrics", tags=["metrics"])

@router.get("/suite_pass_rate")
def suite_pass_rate(window_hours: int=24):
    since = dt.datetime.utcnow() - dt.timedelta(hours=window_hours)
    out={}
    with session_scope() as s:
        for st in ("stability","sanity","regression"):
            a = s.execute(
                """
                SELECT r.status
                FROM runs r
                JOIN scripts s ON s.id=r.script_id
                WHERE s.suite=:suite AND r.created_at >= :since
                """, {"suite": st, "since": since}
            ).all()
            total=len(a); passed=sum(1 for x in a if x[0]=="passed"); failed=sum(1 for x in a if x[0] in ("failed","error"))
            rate = (passed/total)*100 if total else 0.0
            out[st] = {"passed":passed,"failed":failed,"total":total,"pass_rate":round(rate,2),"window_hours":window_hours}
    return out

@router.get("/dashboard")
def dashboard(window_hours:int=24, label:str="RG-01"):
    since = dt.datetime.utcnow() - dt.timedelta(hours=window_hours)
    with session_scope() as s:
        rates = suite_pass_rate(window_hours)

        # ---- series ----
        series_out = {}
        for m in ("cpu","mem","temp","throughput","latency"):
            rows = s.execute(
                select(telemetry.c.ts, telemetry.c.value)
                .where(and_(telemetry.c.metric==m, telemetry.c.ts>=since, telemetry.c.label==label))
                .order_by(telemetry.c.ts.asc())
            ).all()
            if not rows:
                # generate placeholder data when empty, so UI has lines
                pts=[]
                for i in range(96):
                    ts = dt.datetime.utcnow()-dt.timedelta(minutes=(95-i)*15)
                    base={"cpu":40,"mem":55,"temp":60,"throughput":300,"latency":20}[m]
                    amp ={"cpu":15,"mem":10,"temp":8,"throughput":120,"latency":10}[m]
                    val = base + amp*math.sin(i/8)+random.uniform(-2,2)
                    pts.append({"ts": ts.isoformat(), "value": round(val,2)})
                series_out[m]=pts
            else:
                series_out[m]=[{"ts": r[0].isoformat(), "value": float(r[1])} for r in rows]

        # ---- events from event_log ----
        events1 = s.execute(
            select(event_log.c.ts, event_log.c.level, event_log.c.message)
            .where(event_log.c.ts>=since)
            .order_by(event_log.c.ts.desc()).limit(200)
        ).all()
        ev1 = [{"ts": r[0].isoformat(), "level": r[1], "message": r[2]} for r in events1]

        # ---- runs -> events (Pass/Fail/Error), map Error/Timeout as fail level for stats
        runs_rows = s.execute(
            select(runs.c.created_at, scripts.c.name, scripts.c.suite, runs.c.status)
            .join(scripts, scripts.c.id == runs.c.script_id)
            .where(runs.c.created_at >= since)
            .order_by(runs.c.created_at.desc())
            .limit(200)
        ).all()

        def _norm(st: str) -> str:
            st = (st or "").lower()
            if st.startswith("pass"):    return "Pass"
            if st.startswith("fail"):    return "Fail"
            if st.startswith("error"):   return "Error"
            if st.startswith("timeout"): return "Timeout"
            return st.title() or "Unknown"

        ev2 = [{
            "ts": row[0].isoformat(),
            # Error/Timeout 一律當成 fail 等級，方便前端 FAIL 統計與顏色
            "level": "fail" if _norm(row[3]) in ("Fail","Error","Timeout") else "pass",
            "message": f"{row[1]} ({row[2]}) → {_norm(row[3])}",
        } for row in runs_rows]

        # 合併後依時間排序，最多 200 筆
        events = sorted(ev1 + ev2, key=lambda x: x["ts"], reverse=True)[:200]

        return {"rates": rates, "series": series_out, "events": events}

# ---- CPE info endpoint -------------------------------------------------------
import os, re, subprocess
from typing import Dict, Any

# 嘗試沿用本檔已存在的 router；若沒有就自建（避免破壞原結構）
try:
    router  # type: ignore[name-defined]
except NameError:  # pragma: no cover
    from fastapi import APIRouter
    router = APIRouter()

def _strip_ansi(s: str) -> str:
    return re.sub(r"\x1b\[[0-9;]*m", "", s)

def _parse_cpe_info(txt: str) -> Dict[str, Any]:
    txt = _strip_ansi(txt)
    def g(rx):
        m = re.search(rx, txt, flags=re.M)
        return m.group(1).strip() if m else None
    return {
        "internet": g(r"Internet Status:\s*([A-Za-z]+)"),
        "cloud":    g(r"Cloud Status:\s*([A-Za-z]+)"),
        "ipv4":     g(r"IPv4:\s*([0-9\.]+)"),
        "mac":      g(r"MAC:\s*([0-9A-Fa-f:]{17})"),
        "serial":   g(r"Serial Number:\s*([^\s]+)"),
        "model":    g(r"Model:\s*(.+)"),
        "fw":       g(r"FW Version:\s*(.+)"),
        "pods":     g(r"Connected Pods S/N:\s*(.+)"),
    }

@router.get("/cpe/info")
def api_cpe_info():
    """
    執行 /home/da40/charter/tools/cpe_info 並回傳解析結果。
    也可用環境變數 CPE_INFO_CMD 指定其他路徑。
    """
    cmd = os.environ.get("CPE_INFO_CMD", "/home/da40/charter/tools/cpe_info")
    try:
        p = subprocess.run([cmd], text=True, capture_output=True, timeout=15)
        out = (p.stdout or "") + (("\n"+p.stderr) if p.stderr else "")
        return {"ok": True, "data": _parse_cpe_info(out), "raw": out, "code": p.returncode}
    except FileNotFoundError:
        return {"ok": False, "error": f"not found: {cmd}"}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "timeout"}
