from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
from sqlalchemy import select, func, and_
from ..db import session_scope, runs, scripts
import os, shutil
from pathlib import Path
from datetime import datetime, date, timedelta

router = APIRouter(prefix="/api/runs", tags=["runs"])

WORK_BASE = os.getenv("WORK_BASE", "/home/da40/charter/data/work")

def _run_dir(run_id: int) -> Path:
    return Path(WORK_BASE) / f"run_{run_id}"


def _dt(v):
    return v.isoformat() if v else None

@router.get("", summary="List runs")
def list_runs(limit: int = 200):
    with session_scope() as s:
        rows = s.execute(
            select(
                runs.c.id,
                runs.c.status,
                runs.c.created_at,
                runs.c.started_at,
                runs.c.finished_at,
                scripts.c.name.label("script"),
                scripts.c.suite.label("suite"),
            )
            .join(scripts, scripts.c.id == runs.c.script_id)
            .order_by(runs.c.id.desc())
            .limit(limit)
        ).mappings().all()

    # 轉成可序列化的乾淨 JSON
    return [
        {
            "id": r["id"],
            "status": r["status"],
            "script": r["script"],
            "suite": r["suite"],
            "created_at": _dt(r.get("created_at")),
            "started_at": _dt(r.get("started_at")),
            "finished_at": _dt(r.get("finished_at")),
        }
        for r in rows
    ]

@router.get("/worker/status", summary="Worker status")
def worker_status():
    with session_scope() as s:
        queued = s.execute(
            select(func.count()).select_from(runs).where(runs.c.status == "queued")
        ).scalar_one()
        running = s.execute(
            select(func.count()).select_from(runs).where(runs.c.status == "running")
        ).scalar_one()
    return {"idle": running == 0, "queue": queued}

@router.delete("/purge", summary="Purge runs older than given date")
def purge_runs(
    before: date | None = None,          # 指定某「日期之前」
    older_than_days: int | None = None,  # 或者：早於 N 天（0 表示不看時間）
    status: str | None = None,           # 可選：只清某一種狀態，例如 'passed'
    dry_run: bool = False,               # dry_run=1 只看不真的刪
):
    """
    刪除「指定日期以前」或「早於 N 天」的 run + 對應的工作目錄。

    範例：
      - DELETE /api/runs/purge?older_than_days=30&status=passed
      - DELETE /api/runs/purge?before=2025-01-01
      - DELETE /api/runs/purge?older_than_days=90&dry_run=1
      - DELETE /api/runs/purge?older_than_days=0      # 清所有已結束 run
    """

    # 1) 算 cutoff 時間
    cutoff: datetime | None = None

    if before is not None:
        # before 這天的 00:00 以前都算舊資料
        cutoff = datetime.combine(before, datetime.min.time())
    elif older_than_days is not None:
        if older_than_days > 0:
            # >0 天：finished_at 早於 (現在 - N 天)
            cutoff = datetime.utcnow() - timedelta(days=older_than_days)
        else:
            # older_than_days <= 0：不套時間條件，表示「所有已結束」
            cutoff = None
    else:
        raise HTTPException(
            status_code=400,
            detail="must provide either 'before' or 'older_than_days'",
        )

    ids: list[int] = []
    with session_scope() as s:
        # 一律只清「已經結束」的 run，比較安全
        cond = [runs.c.finished_at.isnot(None)]

        # 如果有 cutoff，再加時間條件
        if cutoff is not None:
            cond.append(runs.c.finished_at < cutoff)

        if status:
            cond.append(runs.c.status == status)

        q = select(runs.c.id).where(and_(*cond))
        rows = s.execute(q).all()
        ids = [r.id for r in rows]

        if dry_run:
            # dry_run 模式：只回報會刪多少，不真的砍
            return {"ok": True, "would_delete": len(ids), "ids": ids}

        if ids:
            s.execute(runs.delete().where(runs.c.id.in_(ids)))

    # 2) 刪除對應工作目錄
    for rid in ids:
        rdir = _run_dir(rid)
        shutil.rmtree(rdir, ignore_errors=True)

    return {"ok": True, "deleted": len(ids), "ids": ids}


@router.delete("/{rid}", summary="Delete a run and its logs")
def delete_run(rid: int):
    # 1) 刪除 DB 裡的 run 記錄（包含 result / log JSON）
    with session_scope() as s:
        exists = s.execute(
            select(runs.c.id).where(runs.c.id == rid)
        ).scalar_one_or_none()
        if exists is None:
            raise HTTPException(status_code=404, detail="run not found")

        s.execute(runs.delete().where(runs.c.id == rid))

    # 2) 刪除對應的工作目錄（底下的 log / cpe_log / 壓縮檔都會一起刪）
    rdir = _run_dir(rid)
    shutil.rmtree(rdir, ignore_errors=True)

    return {"ok": True}



@router.get("/{rid}/log", summary="Get a run's log")
def get_run_log(rid: int):
    with session_scope() as s:
        row = s.execute(select(runs.c.log).where(runs.c.id == rid)).first()
        log = row[0] if row and row[0] is not None else []
        return JSONResponse(log)
