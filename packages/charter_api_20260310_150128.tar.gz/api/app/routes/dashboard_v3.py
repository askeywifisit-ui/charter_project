from __future__ import annotations
import datetime as dt
from typing import List, Dict, Any

from fastapi import APIRouter, Query
from sqlalchemy import text, select
from app import db as dbmod

router = APIRouter(prefix="/api/dashboard", tags=["dashboard-final-v3"])

def _fmt_ts(x) -> str:
    try:
        return x.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return str(x)

def _norm_status(st: str) -> str:
    s = (st or "").lower()
    if s.startswith("pass"):    return "Pass"
    if s.startswith("fail"):    return "Fail"
    if s.startswith("error"):   return "Error"
    if s.startswith("timeout"): return "Timeout"
    return s.title() or "Unknown"

@router.get("/metrics")
def dashboard_metrics_v3(
    window_hours: int = Query(24, ge=1, le=720),
    limit_events: int = Query(200, ge=1, le=1000),
    # 重點：預設 eventlog = 只顯示 event_log；可改 runs / both 做測試
    events: str = Query("eventlog", pattern="^(eventlog|runs|both)$"),
):
    since = dt.datetime.utcnow() - dt.timedelta(hours=window_hours)

    # ---------- 時序：cpe_metrics ----------
    cpu: List[Dict[str, Any]] = []
    mem: List[Dict[str, Any]] = []
    temp: List[Dict[str, Any]] = []
    tp_total: List[Dict[str, Any]] = []
    tp_dl: List[Dict[str, Any]] = []
    tp_ul: List[Dict[str, Any]] = []
    latency: List[Dict[str, Any]] = []

    with dbmod.session_scope() as s:
        rows = s.execute(text("""
            SELECT ts, cpu_pct, mem_pct, temp_c, rx_mbps, tx_mbps, latency_ms
            FROM cpe_metrics
            WHERE ts >= :since
            ORDER BY ts ASC
        """), {"since": since}).all()

    for ts, cpu_pct, mem_pct, temp_c, rx, tx, lat in rows:
        ts_s = _fmt_ts(ts)
        if cpu_pct is not None: cpu.append({"ts": ts_s, "value": float(cpu_pct)})
        if mem_pct is not None: mem.append({"ts": ts_s, "value": float(mem_pct)})
        if temp_c is not None:  temp.append({"ts": ts_s, "value": float(temp_c)})
        if rx is not None:      tp_dl.append({"ts": ts_s, "value": float(rx)})
        if tx is not None:      tp_ul.append({"ts": ts_s, "value": float(tx)})
        if (rx is not None) or (tx is not None):
            tp_total.append({"ts": ts_s, "value": float(rx or 0)+float(tx or 0)})
        if lat is not None:     latency.append({"ts": ts_s, "value": float(lat)})

    # ---------- pass rate：仍用 runs（跟事件是否只顯示 event_log 無關）----------
    pass_rate = {"stability": 0.0, "sanity": 0.0, "regression": 0.0}
    runs_tbl    = getattr(dbmod, "runs", None)
    scripts_tbl = getattr(dbmod, "scripts", None)
    if runs_tbl is not None and scripts_tbl is not None:
        with dbmod.session_scope() as s:
            for suite in ("stability","sanity","regression"):
                rws = s.execute(
                    select(runs_tbl.c.status)
                    .join(scripts_tbl, scripts_tbl.c.id == runs_tbl.c.script_id)
                    .where((scripts_tbl.c.suite == suite) & (runs_tbl.c.created_at >= since))
                ).all()
                total = len(rws)
                passed = sum(1 for (st,) in rws if str(st or "").lower().startswith("pass"))
                pass_rate[suite] = round((passed/total)*100, 2) if total else 0.0

    # ---------- events：ev1 from event_log ----------
    with dbmod.session_scope() as s:
        ev1_rows = s.execute(text("""
            SELECT ts, message
            FROM event_log
            WHERE ts >= :since
            ORDER BY ts DESC
            LIMIT :lim
        """).bindparams(since=since, lim=limit_events)).all()
    ev1 = [{"ts": _fmt_ts(ts), "msg": msg} for ts, msg in ev1_rows]
    ev1_count = len(ev1)

    # ---------- events：ev2 from runs（只有在 events!=eventlog 時才抓） ----------
    ev2 = []
    ev2_fallback_used = False
    if events in ("runs", "both") and runs_tbl is not None and scripts_tbl is not None:
        with dbmod.session_scope() as s:
            rws = s.execute(
                select(runs_tbl.c.created_at, scripts_tbl.c.name, scripts_tbl.c.suite, runs_tbl.c.status)
                .join(scripts_tbl, scripts_tbl.c.id == runs_tbl.c.script_id)
                .where(runs_tbl.c.created_at >= since)
                .order_by(runs_tbl.c.created_at.desc())
                .limit(limit_events)
            ).all()
            ev2 = [{"ts": _fmt_ts(r[0]), "msg": f"{r[1]} ({r[2]}) → {_norm_status(r[3])}"} for r in rws]
        if events != "eventlog" and not ev2:
            ev2_fallback_used = True
            with dbmod.session_scope() as s:
                rows2 = s.execute(text("""
                    SELECT r.created_at, s.name, s.suite, r.status
                    FROM runs r
                    JOIN scripts s ON s.id = r.script_id
                    WHERE r.created_at >= :since
                    ORDER BY r.created_at DESC
                    LIMIT :lim
                """), {"since": since, "lim": limit_events}).all()
            ev2 = [{"ts": _fmt_ts(ts), "msg": f"{name} ({suite}) → {_norm_status(status)}"}
                   for ts, name, suite, status in rows2]

    ev2_count = len(ev2)

    # ---------- 合併 ----------
    if events == "eventlog":
        merged = ev1
    elif events == "runs":
        merged = ev2
    else:
        merged = ev1 + ev2

    events_out = sorted(merged, key=lambda x: x["ts"], reverse=True)[:limit_events]

    return {
        "source": f"dashboard-final-v3[{events}]",
        "pass_rate": pass_rate,
        "cpu": cpu, "mem": mem, "temp": temp,
        "throughput": tp_total,
        "throughput_dl": tp_dl, "throughput_ul": tp_ul,
        "latency": latency,
        "events": events_out,
        # debug
        "ev1_count": ev1_count, "ev2_count": ev2_count,
        "ev2_fallback_used": ev2_fallback_used,
        "dl_count": len(tp_dl), "ul_count": len(tp_ul),
    }
