from fastapi import APIRouter, UploadFile, File, Form
from fastapi.responses import JSONResponse
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from ..db import session_scope, scripts
from pathlib import Path
import zipfile, shutil
from datetime import datetime
import os

router = APIRouter(prefix="/api/scripts", tags=["scripts"])

DATA_DIR = Path("/home/da40/charter/data/scripts")
DATA_DIR.mkdir(parents=True, exist_ok=True)

VALID_SUITES = {"stability", "sanity", "regression"}

# === 檔案檢查策略 ===
# 最少需要這三個；若不想強制 requirements.txt，把 REQUIRED_FILES 改為 {"main.py","manifest.yaml"}
REQUIRED_FILES = {"main.py", "manifest.yaml", "requirements.txt"}

def _slugify(s: str) -> str:
    import re as _re
    return _re.sub(r"[^A-Za-z0-9._-]+", "_", s).strip("_")

def _pick_name_entry(zf: zipfile.ZipFile, fallback_name: str):
    name = fallback_name.replace(".zip","")
    entry = "main.py:run"
    try:
        if "manifest.yaml" in (os.path.basename(n) for n in zf.namelist()):
            import yaml
            # 找到真正的 manifest.yaml 路徑（可能在子目錄）
            mpath = _find_member(zf, "manifest.yaml")
            meta = yaml.safe_load(zf.read(mpath).decode("utf-8"))
            name = meta.get("name", name)
            entry = meta.get("entry", entry)
    except Exception:
        pass
    return name, entry

def _exists(suite: str, name: str) -> bool:
    with session_scope() as s:
        q = select(scripts.c.id).where(scripts.c.suite==suite, scripts.c.name==name)
        return s.execute(q).first() is not None

def _register(suite: str, zip_path: Path, name: str, entry: str):
    with session_scope() as s:
        rid = s.execute(scripts.insert().values(
            name=name, suite=suite, entrypoint=entry, zip_path=str(zip_path)
        ).returning(scripts.c.id)).scalar_one()
        return rid

def _basename_set(zf: zipfile.ZipFile):
    return {os.path.basename(n.rstrip("/")) for n in zf.namelist() if not n.endswith("/")}

def _find_member(zf: zipfile.ZipFile, target: str):
    # 在 zip 裡找出結尾為 target 的檔案（允許在子資料夾）
    for n in zf.namelist():
        if n.endswith("/"): 
            continue
        if os.path.basename(n) == target:
            return n
    return None

@router.post("/import2")
async def import_scripts_v2(suite: str = Form(...), file: UploadFile = File(...)):
    if suite not in VALID_SUITES:
        return JSONResponse({"ok": False, "error": f"invalid suite: {suite}"}, status_code=400)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S%f")
    save_as = DATA_DIR / f"upload_{ts}_{_slugify(file.filename or 'script.zip')}"
    with save_as.open("wb") as f:
        shutil.copyfileobj(file.file, f)

    results = []
    stats = {"total": 0, "created": 0, "skipped": 0, "failed": 0}

    def handle_one(path: Path, disp_name: str):
        nonlocal results, stats
        stats["total"] += 1
        try:
            with zipfile.ZipFile(path, "r") as zf:
                # 1) 檔案齊備性檢查（basename 方式，允許在子目錄）
                bases = _basename_set(zf)
                missing = sorted(list(REQUIRED_FILES - bases))
                if missing:
                    results.append({
                        "name": disp_name, "action": "failed",
                        "reason": "MISSING_FILES", "missing": missing
                    })
                    stats["failed"] += 1
                    return

                # 2) 解析名稱/entry
                name, entry = _pick_name_entry(zf, disp_name)

                # 3) entry 的檔要存在（若 manifest.yaml 指到其它 py）
                try:
                    entry_file = entry.split(":")[0] if ":" in entry else entry
                    if _find_member(zf, entry_file) is None:
                        results.append({
                            "name": name, "action": "failed",
                            "reason": "BAD_ENTRY", "detail": f"missing entry file {entry_file}"
                        })
                        stats["failed"] += 1
                        return
                except Exception:
                    pass

        except zipfile.BadZipFile:
            results.append({"name": disp_name, "action": "failed", "reason": "INVALID_ZIP"})
            stats["failed"] += 1
            return

        if _exists(suite, name):
            results.append({"name": name, "action": "skipped", "reason": "DUPLICATE"})
            stats["skipped"] += 1
            return

        try:
            rid = _register(suite, path, name, entry)
            results.append({"name": name, "action": "created", "id": rid})
            stats["created"] += 1
        except IntegrityError:
            results.append({"name": name, "action": "skipped", "reason": "DUPLICATE"})
            stats["skipped"] += 1
        except Exception as e:
            results.append({"name": name, "action": "failed", "reason": str(e)[:200]})
            stats["failed"] += 1

    # 單包 vs 大包
    try:
        with zipfile.ZipFile(save_as, "r") as big:
            inner = [n for n in big.namelist() if n.lower().endswith(".zip")]
            if inner:
                tmp = DATA_DIR / f"{save_as.stem}_unpack"
                tmp.mkdir(parents=True, exist_ok=True)
                for n in inner:
                    sub = tmp / Path(n).name
                    with big.open(n) as src, sub.open("wb") as out:
                        shutil.copyfileobj(src, out)
                    handle_one(sub, sub.name)
            else:
                handle_one(save_as, file.filename or "script.zip")
    except zipfile.BadZipFile:
        stats["total"] += 1
        results.append({"name": file.filename or "script.zip", "action": "failed", "reason": "INVALID_ZIP"})
        stats["failed"] += 1

    return {"ok": True, "stats": stats, "results": results}
