from fastapi import APIRouter, Body, File, Form, UploadFile
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel
from sqlalchemy import select, update
from sqlalchemy.exc import IntegrityError
from ..db import session_scope, scripts, runs
from datetime import datetime
from pathlib import Path
import shutil
import io
import zipfile
import re
import json
import os

DATA_DIR = Path("/home/da40/charter/data/scripts")
DATA_DIR.mkdir(parents=True, exist_ok=True)

# worker.py creates per-script python virtualenvs under /home/da40/charter/data/venv/script_{id}
BASE_DIR = DATA_DIR.parent
VENV_DIR = BASE_DIR / "venv"
VENV_DIR.mkdir(parents=True, exist_ok=True)

VALID_SUITES = {"stability", "sanity", "regression"}

# ---- Helpers for naming ----
def _slugify(s: str) -> str:
    import re
    return re.sub(r"[^A-Za-z0-9._-]+", "_", s).strip("_")

def _extract_prd_id(name: str) -> str:
    """
    Try to extract PRD/Test ID from a filename, e.g., A2435635_..., T4625121_..., C15807060_...
    Falls back to the leading token before '_' or empty string.
    """
    import re
    base = Path(name).name
    m = re.match(r"([A-Za-z]?\d{6,})[_-]", base)
    if m:
        return m.group(1)
    head = base.split("_", 1)[0]
    head = re.sub(r"[^A-Za-z0-9-]+", "", head)
    return head

def _unique_name(suite: str, orig_filename: str) -> str:
    """
    Compose a unique zip filename under DATA_DIR using:
    YYYYMMDD_%f_suite_PRDID_slug_shortuuid.zip
    """
    from datetime import datetime
    import uuid
    dt = datetime.now().strftime("%Y%m%d_%H%M%S%f")
    prd = _extract_prd_id(orig_filename) or "NA"
    base = Path(orig_filename).stem
    tail = _slugify(base)[:40]
    short = uuid.uuid4().hex[:6]
    return f"{dt}_{suite}_{prd}_{tail}_{short}.zip"

router = APIRouter(prefix="/api/scripts", tags=["scripts"])

# ---------- Helpers ----------
def _row_script(r):
    return {
        "id": r["id"],
        "name": r["name"],
        "suite": r["suite"],
        "entrypoint": r["entrypoint"],
        "created_at": r.get("created_at"),
        "updated_at": r.get("updated_at"),
        "zip_path": r.get("zip_path"),
    }

# ---------- List ----------
@router.get("")
def list_scripts(suite: str | None = None, q: str | None = None):
    """Return scripts. If suite is 'all' or None -> no suite filter."""
    with session_scope() as s:
        stmt = select(
            scripts.c.id,
            scripts.c.name,
            scripts.c.suite,
            scripts.c.entrypoint,
            scripts.c.created_at,
            scripts.c.updated_at,
            scripts.c.zip_path,
        ).order_by(scripts.c.id.desc())

        if suite and suite in VALID_SUITES:
            stmt = stmt.where(scripts.c.suite == suite)

        if q:
            stmt = stmt.where(scripts.c.name.ilike(f"%{q}%"))

        rows = s.execute(stmt).mappings().all()
        return [_row_script(r) for r in rows]

# ---------- Import (single zip, or big-zip containing many zips) ----------
@router.post("/import")
async def import_script(
    suite: str = Form(...),
    file: UploadFile = File(...),
):
    if suite not in VALID_SUITES:
        return JSONResponse({"ok": False, "error": f"invalid suite: {suite}"}, status_code=400)

    # Save the uploaded zip with a unique name
    out_name = _unique_name(suite, file.filename or "script.zip")
    dst = DATA_DIR / out_name
    with dst.open("wb") as f:
        shutil.copyfileobj(file.file, f)

    created = []
    errors = []

    def _register_one(zip_path: Path, fallback_name: str):
        name = re.sub(r"\.zip$", "", fallback_name)
        entry = "main.py:run"  # default, will be overridden by manifest if present

        # Read manifest.yaml (if present)
        try:
            with zipfile.ZipFile(zip_path, "r") as zf:
                if "manifest.yaml" in zf.namelist():
                    import yaml
                    meta = yaml.safe_load(zf.read("manifest.yaml").decode("utf-8")) or {}
                    name = meta.get("name", name)
                    # NEW: accept both keys (entry / entrypoint)
                    entry = meta.get("entry") or meta.get("entrypoint") or entry
        except Exception:
            pass

        with session_scope() as s:
            attempt = 0
            base_name = name
            while True:
                try:
                    rid = s.execute(
                        scripts.insert().values(
                            name=name,
                            suite=suite,
                            entrypoint=entry,
                            zip_path=str(zip_path),
                        ).returning(scripts.c.id)
                    ).scalar_one()
                    created.append({"id": rid, "name": name})
                    break
                except IntegrityError as e:
                    attempt += 1
                    if attempt > 9:
                        errors.append(f"{name}: {str(e).splitlines()[-1]}")
                        break
                    from uuid import uuid4
                    suffix = uuid4().hex[:4]
                    name = f"{base_name}_{suffix}"

    # Detect “big zip” (contains many *.zip), otherwise treat as single script zip
    try:
        with zipfile.ZipFile(dst, "r") as big:
            inner_zips = [n for n in big.namelist() if n.lower().endswith(".zip")]
            if inner_zips:
                tmpdir = DATA_DIR / f"{Path(dst).stem}_unpack"
                tmpdir.mkdir(parents=True, exist_ok=True)
                for n in inner_zips:
                    sub_p = tmpdir / Path(n).name
                    with big.open(n) as src, sub_p.open("wb") as out:
                        shutil.copyfileobj(src, out)
                    _register_one(sub_p, sub_p.name)
            else:
                _register_one(dst, file.filename or "script.zip")
    except zipfile.BadZipFile:
        _register_one(dst, file.filename or "script.zip")

    return {"ok": True, "created": created, "errors": errors}

# ---------- Run one ----------
@router.post("/{script_id}/run")
def run_script(script_id: int):
    with session_scope() as s:
        row = s.execute(
            select(
                scripts.c.id, scripts.c.name, scripts.c.suite, scripts.c.entrypoint, scripts.c.zip_path
            ).where(scripts.c.id == script_id)
        ).mappings().first()
        if not row:
            return JSONResponse({"ok": False, "error": "script not found"}, status_code=404)

        rid = s.execute(
            runs.insert().values(
                script_id=script_id,
                status="queued",
                created_at=datetime.now(),
            ).returning(runs.c.id)
        ).scalar_one()

    return {"ok": True, "run_id": rid}

# ---------- Delete one ----------
@router.delete("/{script_id}")
def delete_script(script_id: int):
    """Delete script record + its runs, and best-effort delete the backing zip on disk."""

    # --- helper: safe resolve within DATA_DIR ---
    data_root = DATA_DIR.resolve()
    venv_root = VENV_DIR.resolve()

    def _is_under_root(p: Path, root: Path) -> bool:
        try:
            rp = p.resolve()
        except Exception:
            return False
        # Python 3.10 has Path.is_relative_to
        try:
            return rp.is_relative_to(root)
        except Exception:
            rp_s = str(rp)
            root_s = str(root)
            return rp_s == root_s or rp_s.startswith(root_s + os.sep)

    def _is_under_data_dir(p: Path) -> bool:
        return _is_under_root(p, data_root)

    def _is_under_venv_dir(p: Path) -> bool:
        return _is_under_root(p, venv_root)

    def _candidate_paths(zip_path: str | None, name: str | None) -> list[Path]:
        cands: list[Path] = []
        if zip_path:
            p = Path(zip_path)
            if not p.is_absolute():
                p = (DATA_DIR / p)
            cands.append(p)
        # Conservative fallbacks (same as export): name.zip / id.zip
        if name:
            base = re.sub(r"\.zip$", "", name, flags=re.IGNORECASE)
            slug = re.sub(r"[^A-Za-z0-9._-]+", "_", base)
            slug = re.sub(r"_+", "_", slug).strip("_") or "script"
            cands.append(DATA_DIR / f"{slug}.zip")
        cands.append(DATA_DIR / f"{script_id}.zip")
        return cands

    file_deleted = False
    file_path: Path | None = None
    file_error: str | None = None
    parent_to_prune: Path | None = None

    venv_deleted = False
    venv_path: Path | None = None
    venv_error: str | None = None

    # 1) Read row first (outside of delete)
    with session_scope() as s:
        row = s.execute(
            select(scripts.c.id, scripts.c.name, scripts.c.zip_path).where(scripts.c.id == script_id)
        ).mappings().first()
        if not row:
            return JSONResponse({"ok": False, "error": "script not found"}, status_code=404)

        # 2) Delete DB rows
        s.execute(runs.delete().where(runs.c.script_id == script_id))
        s.execute(scripts.delete().where(scripts.c.id == script_id))

    # 3) Best-effort delete file on disk (do not block DB deletion)
    try:
        zip_path = row.get("zip_path")
        name = row.get("name")
        for cand in _candidate_paths(zip_path, name):
            if not cand:
                continue
            try:
                if cand.exists() and cand.is_file() and _is_under_data_dir(cand):
                    file_path = cand.resolve()
                    parent_to_prune = file_path.parent
                    file_path.unlink(missing_ok=True)
                    file_deleted = True
                    break
            except Exception as e:
                # keep trying other candidates, remember last error
                file_error = str(e)
                continue
    except Exception as e:
        file_error = str(e)

    # 4) Prune empty *_unpack dir if applicable
    try:
        if file_deleted and parent_to_prune and parent_to_prune.name.endswith("_unpack") and _is_under_data_dir(parent_to_prune):
            # remove if empty
            if parent_to_prune.exists() and parent_to_prune.is_dir() and not any(parent_to_prune.iterdir()):
                parent_to_prune.rmdir()
    except Exception:
        pass

    # 5) Best-effort delete per-script venv (/home/da40/charter/data/venv/script_{id})
    try:
        vp = (VENV_DIR / f"script_{script_id}")
        if vp.exists() and vp.is_dir() and _is_under_venv_dir(vp):
            venv_path = vp.resolve()
            shutil.rmtree(venv_path)
            venv_deleted = True
    except Exception as e:
        venv_error = str(e)

    resp = {"ok": True, "file_deleted": file_deleted, "venv_deleted": venv_deleted}
    if file_path:
        resp["file_path"] = str(file_path)
    if file_error and not file_deleted:
        resp["file_error"] = file_error
    if venv_path:
        resp["venv_path"] = str(venv_path)
    if venv_error and not venv_deleted:
        resp["venv_error"] = venv_error
    return resp

# ---------- Export one (download zip) ----------
@router.get("/{script_id}/export")
def export_script(script_id: int):
    def _slugify2(s: str) -> str:
        s = re.sub(r"\.zip$", "", s or "", flags=re.IGNORECASE)
        s = re.sub(r"[^A-Za-z0-9._-]+", "_", s)
        s = re.sub(r"_+", "_", s).strip("_")
        return s or "script"

    with session_scope() as s:
        row = s.execute(
            select(
                scripts.c.id,
                scripts.c.name,
                scripts.c.zip_path,
                scripts.c.created_at,
            ).where(scripts.c.id == script_id)
        ).mappings().first()

    if not row:
        return JSONResponse({"ok": False, "error": "script not found"}, status_code=404)

    name = row.get("name") or f"{script_id}"
    zip_path = row.get("zip_path")

    candidates = []
    if zip_path:
        p = Path(zip_path)
        if not p.is_absolute():
            p = (DATA_DIR / p).resolve()
        candidates.append(p)
    candidates.append((DATA_DIR / f"{_slugify2(name)}.zip").resolve())
    candidates.append((DATA_DIR / f"{script_id}.zip").resolve())

    file_path = next((p for p in candidates if p.exists()), None)
    if not file_path:
        return JSONResponse({"ok": False, "error": "zip not found"}, status_code=404)

    dt = row.get("created_at")
    if not dt:
        try:
            dt = datetime.fromtimestamp(file_path.stat().st_mtime)
        except Exception:
            dt = datetime.now()

    slug = _slugify2(name)
    if re.match(r"^\d{8}_", slug):
        out_name = f"{slug}.zip"
    else:
        date_tag = dt.strftime("%Y%m%d_%H%M%S")
        out_name = f"{date_tag}_{slug}.zip"

    def _iter():
        with open(file_path, "rb") as f:
            while True:
                chunk = f.read(1024 * 1024)
                if not chunk:
                    break
                yield chunk

    headers = {"Content-Disposition": f'attachment; filename="{out_name}"'}
    return StreamingResponse(_iter(), media_type="application/zip", headers=headers)

# ---------- Manifest read / update ----------
import zipfile as _zipfile
import re as _re
from pathlib import Path as _P

class ManifestPayload(BaseModel):
    content: str

SCRIPTS_DIR = DATA_DIR

def _slug_for_match(s: str) -> str:
    s = (s or "").replace(" wrapper", "").replace("_wrapper", "")
    return _re.sub(r"[^A-Za-z0-9]+", "_", s).strip("_").lower()

def _resolve_zip_path_for_manifest(row, *, allow_fallback: bool = False):
    """Resolve the exact zip file to read/write manifest.

    IMPORTANT:
      - If DB zip_path is present but missing on disk, we DO NOT silently fall back unless allow_fallback=True.
      - PUT manifest MUST call with allow_fallback=False to avoid editing the wrong zip when multiple versions exist.
    """
    zip_path = (row.get("zip_path") or "").strip()
    if zip_path:
        p = _P(zip_path)
        if not p.is_absolute():
            p = (SCRIPTS_DIR / zip_path).resolve()
        # extra-safe exists checks (debugging rare false negatives)
        try:
            if p.exists() or os.path.isfile(str(p)):
                return p
            rp = p.resolve()
            if rp.exists() or os.path.isfile(str(rp)):
                return rp
        except Exception:
            pass

        # zip_path is set but missing → do not guess a different zip
        if not allow_fallback:
            return None

    if not allow_fallback:
        return None

    name = (row.get("name") or f"{row.get('id')}").strip()
    name_slug = _slug_for_match(name)

    best = None
    best_mtime = -1.0
    if SCRIPTS_DIR.exists():
        # also consider big-zip unpacked artifacts
        for p in SCRIPTS_DIR.glob("upload_*_unpack/*.zip"):
            stem_slug = _slug_for_match(p.stem)
            if name_slug and (name_slug in stem_slug):
                mt = p.stat().st_mtime
                if mt > best_mtime:
                    best, best_mtime = p, mt
        for p in SCRIPTS_DIR.glob("upload_*.zip"):
            stem_slug = _slug_for_match(p.stem)
            if name_slug and (name_slug in stem_slug):
                mt = p.stat().st_mtime
                if mt > best_mtime:
                    best, best_mtime = p, mt
    if best:
        return best

    sid = int(row.get("id"))
    for c in [(SCRIPTS_DIR / f"{name}.zip").resolve(), (SCRIPTS_DIR / f"{sid}.zip").resolve()]:
        if c.exists():
            return c
    return None

@router.get("/{script_id}/manifest")
def get_manifest(script_id: int):
    with session_scope() as s:
        row = s.execute(
            select(scripts.c.id, scripts.c.name, scripts.c.zip_path)
            .where(scripts.c.id == script_id)
        ).mappings().first()
    if not row:
        return JSONResponse({"ok": False, "error": "script not found"}, status_code=404)

    # GET is allowed to fall back to help operators view legacy/misaligned records.
    # IMPORTANT: PUT must remain strict (no fallback) to avoid editing the wrong artifact.
    zpath = _resolve_zip_path_for_manifest(row, allow_fallback=True)
    if not zpath:
        return JSONResponse({"ok": False, "error": "zip not found"}, status_code=404)

    # Determine whether we had to fall back (DB zip_path missing or missing on disk)
    db_zip = (row.get("zip_path") or "").strip()
    dbp = None
    if db_zip:
        p = _P(db_zip)
        if not p.is_absolute():
            p = (SCRIPTS_DIR / db_zip).resolve()
        dbp = p
    fallback_used = not (dbp and dbp.exists() and dbp == zpath)

    content = ""
    try:
        with _zipfile.ZipFile(zpath, "r") as z:
            try:
                content = z.read("manifest.yaml").decode("utf-8", "ignore")
            except KeyError:
                try:
                    content = z.read("manifest.yml").decode("utf-8", "ignore")
                except KeyError:
                    content = ""
    except Exception as e:
        return JSONResponse({"ok": False, "error": f"zip read error: {e}"}, status_code=500)
    return {"ok": True, "content": content, "zip_used": str(zpath), "fallback_used": fallback_used}

@router.put("/{script_id}/manifest")
def put_manifest(script_id: int, payload: ManifestPayload = Body(...)):
    with session_scope() as s:
        row = s.execute(
            select(scripts.c.id, scripts.c.name, scripts.c.zip_path)
            .where(scripts.c.id == script_id)
        ).mappings().first()
    if not row:
        return JSONResponse({"ok": False, "error": "script not found"}, status_code=404)

    # GET is allowed to fall back to help operators view legacy/misaligned records.
    # IMPORTANT: PUT must remain strict (no fallback) to avoid editing the wrong artifact.
    zpath = _resolve_zip_path_for_manifest(row, allow_fallback=False)
    if not zpath:
        # STRICT fallback: only accept the DB zip_path itself if it exists (no guessing).
        db_zip = (row.get("zip_path") or "").strip()
        if db_zip:
            try:
                p2 = Path(db_zip)
                if p2.exists() and p2.is_file():
                    zpath = p2
            except Exception:
                zpath = None

    if not zpath:
        return JSONResponse({"ok": False, "error": "zip not found"}, status_code=404)

    tmp = zpath.with_suffix(".tmp.zip")
    try:
        with _zipfile.ZipFile(zpath, "r") as zin, _zipfile.ZipFile(tmp, "w", _zipfile.ZIP_DEFLATED) as zout:
            names = {it.filename for it in zin.infolist()}
            target = "manifest.yaml" if "manifest.yaml" in names else ("manifest.yml" if "manifest.yml" in names else "manifest.yaml")
            replaced = False
            for it in zin.infolist():
                if it.filename == target:
                    zout.writestr(target, payload.content.encode("utf-8"))
                    replaced = True
                else:
                    zout.writestr(it, zin.read(it.filename))
            if not replaced:
                zout.writestr("manifest.yaml", payload.content.encode("utf-8"))
        tmp.replace(zpath)
    except Exception as e:
        try:
            if tmp.exists(): tmp.unlink()
        except Exception:
            pass
        return JSONResponse({"ok": False, "error": f"zip write error: {e}"}, status_code=500)

    # If the saved manifest declares entry/entrypoint, sync DB.entrypoint
    new_ep = None
    try:
        import yaml  # type: ignore
        y = yaml.safe_load(payload.content) or {}
        new_ep = (y.get("entry") or y.get("entrypoint"))
        if new_ep:
            with session_scope() as s:
                s.execute(update(scripts).where(scripts.c.id == script_id).values(entrypoint=str(new_ep)))
                s.commit()
    except Exception:
        pass
    return {"ok": True, "updated_entrypoint": new_ep, "zip_used": str(zpath)}



