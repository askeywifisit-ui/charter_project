from fastapi import APIRouter, UploadFile, File, Form
from fastapi.responses import JSONResponse, StreamingResponse
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from ..db import session_scope, scripts, runs
from datetime import datetime
from pathlib import Path
import shutil
import io
import zipfile
import re
import json

DATA_DIR = Path("/home/da40/charter/data/scripts")
DATA_DIR.mkdir(parents=True, exist_ok=True)

router = APIRouter(prefix="/api/scripts", tags=["scripts"])

# ---------- Helpers ----------
VALID_SUITES = {"stability", "sanity", "regression"}

def _row_script(r):
    return {
        "id": r["id"],
        "name": r["name"],
        "suite": r["suite"],
        "entrypoint": r["entrypoint"],
        "created_at": r.get("created_at"),
        "updated_at": r.get("updated_at"),
        "zip_path": r.get("zip_path"),
    }

# ---------- List ----------
@router.get("")
def list_scripts(suite: str | None = None, q: str | None = None):
    """Return scripts. If suite is 'all' or None -> no suite filter."""
    with session_scope() as s:
        stmt = select(
            scripts.c.id,
            scripts.c.name,
            scripts.c.suite,
            scripts.c.entrypoint,
            scripts.c.created_at,
            scripts.c.updated_at,
            scripts.c.zip_path,
        ).order_by(scripts.c.id.desc())

        if suite and suite in VALID_SUITES:
            stmt = stmt.where(scripts.c.suite == suite)
        # 忽略 'all' 或未知 suite

        if q:
            stmt = stmt.where(scripts.c.name.ilike(f"%{q}%"))

        rows = s.execute(stmt).mappings().all()
        return [_row_script(r) for r in rows]

# ---------- Import (single zip, or big-zip containing many zips) ----------
@router.post("/import")
async def import_script(
    suite: str = Form(...),
    file: UploadFile = File(...),
):
    if suite not in VALID_SUITES:
        return JSONResponse({"ok": False, "error": f"invalid suite: {suite}"}, status_code=400)

    # 存成隨機檔名
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    dst = DATA_DIR / f"{ts}_script.zip"
    with dst.open("wb") as f:
        shutil.copyfileobj(file.file, f)

    created = []
    errors = []

    def _register_one(zip_path: Path, fallback_name: str):
        name = fallback_name
        entry = "main.py:run"

        # 從 zip 裡讀 manifest.yaml (若存在)
        try:
            with zipfile.ZipFile(zip_path, "r") as zf:
                if "manifest.yaml" in zf.namelist():
                    import yaml
                    meta = yaml.safe_load(zf.read("manifest.yaml").decode("utf-8"))
                    name = meta.get("name", name)
                    entry = meta.get("entry", entry)
        except Exception:
            pass

        # 防呆：把檔名裡的副檔名去掉當作預設名稱
        name = re.sub(r"\.zip$", "", name)

        with session_scope() as s:
            try:
                rid = s.execute(
                    scripts.insert().values(
                        name=name,
                        suite=suite,
                        entrypoint=entry,
                        zip_path=str(zip_path),
                    ).returning(scripts.c.id)
                ).scalar_one()
                created.append({"id": rid, "name": name})
            except IntegrityError as e:
                errors.append(f"{name}: {str(e).splitlines()[-1]}")

    # 判斷是否「大 zip」：裡面含多個 *.zip
    try:
        with zipfile.ZipFile(dst, "r") as big:
            inner_zips = [n for n in big.namelist() if n.lower().endswith(".zip")]
            if inner_zips:
                # 展開每個子 zip 再註冊
                tmpdir = DATA_DIR / f"{ts}_unpack"
                tmpdir.mkdir(parents=True, exist_ok=True)
                for n in inner_zips:
                    sub_p = tmpdir / Path(n).name
                    with big.open(n) as src, sub_p.open("wb") as out:
                        shutil.copyfileobj(src, out)
                    _register_one(sub_p, sub_p.name)
            else:
                _register_one(dst, file.filename or "script.zip")
    except zipfile.BadZipFile:
        # 不是 zip，直接拿單一 zip 註冊
        _register_one(dst, file.filename or "script.zip")

    return {"ok": True, "created": created, "errors": errors}

# ---------- Run one ----------
@router.post("/{script_id}/run")
def run_script(script_id: int):
    with session_scope() as s:
        row = s.execute(
            select(
                scripts.c.id, scripts.c.name, scripts.c.suite, scripts.c.entrypoint, scripts.c.zip_path
            ).where(scripts.c.id == script_id)
        ).mappings().first()
        if not row:
            return JSONResponse({"ok": False, "error": "script not found"}, status_code=404)

        rid = s.execute(
            runs.insert().values(
                script_id=script_id,
                status="queued",
                created_at=datetime.now(),
            ).returning(runs.c.id)
        ).scalar_one()

    return {"ok": True, "run_id": rid}

# ---------- Delete one ----------
@router.delete("/{script_id}")
def delete_script(script_id: int):
    with session_scope() as s:
        s.execute(runs.delete().where(runs.c.script_id == script_id))
        s.execute(scripts.delete().where(scripts.c.id == script_id))
    return {"ok": True}

# ---------- Export one (download zip) ----------
# ---------- Export one (download zip) ----------
@router.get("/{script_id}/export")
def export_script(script_id: int):
    from datetime import datetime
    import re

    def _slugify(s: str) -> str:
        # 只留英數與 ._-，其餘轉底線
        return re.sub(r"[^A-Za-z0-9._-]+", "_", s).strip("_")

    with session_scope() as s:
        row = s.execute(
            select(
                scripts.c.id,
                scripts.c.name,
                scripts.c.zip_path,
                scripts.c.created_at,
            ).where(scripts.c.id == script_id)
        ).mappings().first()

    if not row:
        return JSONResponse({"ok": False, "error": "script not found"}, status_code=404)

    name = row["name"] or f"{script_id}"
    zip_path = row.get("zip_path")

    # 可能的檔案路徑候選
    candidates = []
    if zip_path:
        p = Path(zip_path)
        if not p.is_absolute():
            p = (DATA_DIR / p).resolve()
        candidates.append(p)
    candidates.append((DATA_DIR / f"{name}.zip").resolve())
    candidates.append((DATA_DIR / f"{script_id}.zip").resolve())

    file_path = next((p for p in candidates if p.exists()), None)
    if not file_path:
        return JSONResponse({"ok": False, "error": "zip not found"}, status_code=404)

    # 日期標籤：優先用 DB 的 created_at，否則用檔案 mtime，再不然用現在時間
    dt = row.get("created_at")
    if not dt:
        try:
            dt = datetime.fromtimestamp(file_path.stat().st_mtime)
        except Exception:
            dt = datetime.now()
    date_tag = dt.strftime("%Y%m%d")

    slug = _slugify(name)
    # 若名稱本身已含 YYYYMMDD_ 前綴，就不要重複加
    if re.match(r"^\d{8}_", slug):
        out_name = f"{slug}.zip"
    else:
        out_name = f"{date_tag}_{slug}.zip"

    def _iter():
        with open(file_path, "rb") as f:
            while True:
                chunk = f.read(1024 * 1024)
                if not chunk:
                    break
                yield chunk

    headers = {
        "Content-Disposition": f'attachment; filename="{out_name}"'
    }
    return StreamingResponse(_iter(), media_type="application/zip", headers=headers)

