# /home/da40/charter/apps/api/app/routes/worker.py
from fastapi import APIRouter
from sqlalchemy import select, func
from ..db import session_scope, runs

router = APIRouter(prefix="/api/worker", tags=["worker"])

def _state_payload():
    with session_scope() as s:
        running = s.scalar(
            select(func.count()).select_from(runs).where(runs.c.status == "running")
        ) or 0
        queued = s.scalar(
            select(func.count()).select_from(runs).where(runs.c.status == "queued")
        ) or 0
    return {"idle": running == 0, "queue": queued}

@router.get("")  # 讓 /api/worker 也能回應（前端會同時打這條）
def worker_root():
    return _state_payload()

@router.get("/state")  # 既有的 /api/worker/state
def worker_state():
    return _state_payload()

