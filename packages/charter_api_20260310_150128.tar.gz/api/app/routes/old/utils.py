
from __future__ import annotations
import os, io, tempfile, shutil, zipfile
from typing import Optional

def zip_read_text(zip_path: str, path_in_zip: str="main.py") -> Optional[str]:
    if not os.path.exists(zip_path): return None
    with zipfile.ZipFile(zip_path, "r") as z:
        try:
            with z.open(path_in_zip, "r") as f:
                return f.read().decode("utf-8", "ignore")
        except KeyError:
            for info in z.infolist():
                if info.filename.endswith("/"+path_in_zip) or info.filename.endswith(path_in_zip):
                    with z.open(info, "r") as f:
                        return f.read().decode("utf-8", "ignore")
    return None

def zip_write_text(zip_path: str, path_in_zip: str, text: str) -> bool:
    if not os.path.exists(zip_path): return False
    tmp = zip_path + ".tmp"
    with zipfile.ZipFile(zip_path, "r") as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        replaced = False
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename.endswith(path_in_zip) or item.filename == path_in_zip:
                data = text.encode("utf-8")
                replaced = True
            zout.writestr(item, data)
        if not replaced:
            zout.writestr(path_in_zip, text.encode("utf-8"))
    shutil.move(tmp, zip_path)
    return True
