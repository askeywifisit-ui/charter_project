from fastapi import APIRouter
from fastapi.responses import JSONResponse
from sqlalchemy import select, func
from ..db import session_scope, runs, scripts

router = APIRouter(prefix="/api/runs", tags=["runs"])

def _dt(v):
    return v.isoformat() if v else None

@router.get("", summary="List runs")
def list_runs(limit: int = 200):
    with session_scope() as s:
        rows = s.execute(
            select(
                runs.c.id,
                runs.c.status,
                runs.c.created_at,
                runs.c.started_at,
                runs.c.finished_at,
                scripts.c.name.label("script"),
                scripts.c.suite.label("suite"),
            )
            .join(scripts, scripts.c.id == runs.c.script_id)
            .order_by(runs.c.id.desc())
            .limit(limit)
        ).mappings().all()

    # 轉成可序列化的乾淨 JSON
    return [
        {
            "id": r["id"],
            "status": r["status"],
            "script": r["script"],
            "suite": r["suite"],
            "created_at": _dt(r.get("created_at")),
            "started_at": _dt(r.get("started_at")),
            "finished_at": _dt(r.get("finished_at")),
        }
        for r in rows
    ]

@router.get("/worker/status", summary="Worker status")
def worker_status():
    with session_scope() as s:
        queued = s.execute(
            select(func.count()).select_from(runs).where(runs.c.status == "queued")
        ).scalar_one()
        running = s.execute(
            select(func.count()).select_from(runs).where(runs.c.status == "running")
        ).scalar_one()
    return {"idle": running == 0, "queue": queued}


@router.get("/{rid}/log", summary="Get a run's log")
def get_run_log(rid: int):
    with session_scope() as s:
        row = s.execute(select(runs.c.log).where(runs.c.id == rid)).first()
        log = row[0] if row and row[0] is not None else []
        return JSONResponse(log)
