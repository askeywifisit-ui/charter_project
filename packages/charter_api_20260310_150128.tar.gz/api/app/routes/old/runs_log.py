from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
from sqlalchemy import select
from ..db import session_scope, runs

router = APIRouter(prefix="/api/runs", tags=["runs"])

@router.get("/{run_id}/log", summary="Get run log (JSON array)")
def get_run_log(run_id: int):
    with session_scope() as s:
        log = s.execute(select(runs.c.log).where(runs.c.id == run_id)).scalar_one_or_none()
        if log is None:
            raise HTTPException(404, f"run {run_id} not found")
        return JSONResponse(log if isinstance(log, list) else [])
