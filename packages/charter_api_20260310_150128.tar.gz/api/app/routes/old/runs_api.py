from __future__ import annotations
import datetime as dt
from fastapi import APIRouter, Query
from sqlalchemy import select
from app import db as dbmod

router = APIRouter(prefix="/api/dashboard", tags=["runs"])

def _fmt_ts(x) -> str:
    try: return x.strftime("%Y-%m-%d %H:%M:%S")
    except Exception: return str(x)

def _norm(st: str) -> str:
    st = (st or "").lower()
    if st.startswith("pass"):    return "Pass"
    if st.startswith("fail"):    return "Fail"
    if st.startswith("error"):   return "Error"
    if st.startswith("timeout"): return "Timeout"
    return st.title() or "Unknown"

@router.get("/runs")
def list_runs(
    window_hours: int = Query(24, ge=1, le=720),
    limit: int = Query(200, ge=1, le=1000),
):
    since = dt.datetime.utcnow() - dt.timedelta(hours=window_hours)
    runs_tbl    = getattr(dbmod, "runs", None)
    scripts_tbl = getattr(dbmod, "scripts", None)
    if runs_tbl is None or scripts_tbl is None:
        return {"error": "tables 'runs' or 'scripts' not found"}

    with dbmod.session_scope() as s:
        # events（一定會同時含 → Pass / → Error / → Fail / → Timeout）
        rows = s.execute(
            select(runs_tbl.c.created_at, scripts_tbl.c.name, scripts_tbl.c.suite, runs_tbl.c.status)
            .join(scripts_tbl, scripts_tbl.c.id == runs_tbl.c.script_id)
            .where(runs_tbl.c.created_at >= since)
            .order_by(runs_tbl.c.created_at.desc())
            .limit(limit)
        ).all()

    # 統計
    p = f = e = t = 0
    events = []
    for ts, name, suite, status in rows:
        norm = _norm(status)
        if   norm == "Pass":    p += 1
        elif norm == "Fail":    f += 1
        elif norm == "Error":   e += 1
        elif norm == "Timeout": t += 1
        events.append({"ts": _fmt_ts(ts), "msg": f"{name} ({suite}) → {norm}"})

    # 各 suite 的 pass_rate（給你前端可用）
    pass_rate = {"stability": 0.0, "sanity": 0.0, "regression": 0.0}
    try:
        with dbmod.session_scope() as s2:
            for st in ("stability", "sanity", "regression"):
                w = s2.execute(
                    """
                    SELECT r.status
                    FROM runs r
                    JOIN scripts s ON s.id=r.script_id
                    WHERE s.suite=:suite AND r.created_at >= :since
                    """,
                    {"suite": st, "since": since},
                ).all()
                total = len(w)
                passed = sum(1 for (status,) in w if str(status or "").lower().startswith("pass"))
                pass_rate[st] = round((passed/total)*100, 2) if total else 0.0
    except Exception:
        pass  # 表或欄位異常就保持 0.0

    return {
        "source": "runs-endpoint",
        "window_hours": window_hours,
        "limit": limit,
        "summary": {
            "pass": p,
            "fail": f + e + t,   # Fail 含 Error/Timeout
            "error": e,
            "timeout": t,
            "total": len(rows)
        },
        "pass_rate": pass_rate,
        "events": events,
    }
