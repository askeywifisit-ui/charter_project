from fastapi import APIRouter
import os, re, subprocess
from typing import Dict, Any

router = APIRouter()  # 不要放 /api 前綴；由 app.main 統一加

ANSI = re.compile(r"\x1b\[[0-9;]*m")

def _parse_cpe_info(txt: str) -> Dict[str, Any]:
    txt = ANSI.sub("", txt or "")
    def g(rx):
        m = re.search(rx, txt, flags=re.M)
        return m.group(1).strip() if m else None
    return {
        "internet": g(r"Internet Status:\s*([A-Za-z]+)"),
        "cloud":    g(r"Cloud Status:\s*([A-Za-z]+)"),
        "ipv4":     g(r"IPv4:\s*([0-9\.]+)"),
        "mac":      g(r"MAC:\s*([0-9A-Fa-f:]{17})"),
        "serial":   g(r"Serial Number:\s*([^\s]+)"),
        "model":    g(r"Model:\s*(.+)"),
        "fw":       g(r"FW Version:\s*(.+)"),
        "pods":     g(r"Connected Pods S/N:\s*(.+)"),
    }

@router.get("/cpe/info")
def cpe_info_api():
    cmd = os.environ.get("CPE_INFO_CMD", "/home/da40/charter/tools/cpe_info")
    try:
        p = subprocess.run([cmd], text=True, capture_output=True, timeout=15)
        out = (p.stdout or "") + (("\n"+p.stderr) if p.stderr else "")
        return {"ok": True, "data": _parse_cpe_info(out), "raw": out, "code": p.returncode}
    except FileNotFoundError:
        return {"ok": False, "error": f"not found: {cmd}"}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "timeout"}
