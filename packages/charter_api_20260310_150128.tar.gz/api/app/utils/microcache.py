from cachetools import TTLCache
# 10 秒微快取（相同參數的請求 10s 內直接回快取）
cache10 = TTLCache(maxsize=256, ttl=10)
def key(name, **kw): return (name, tuple(sorted(kw.items())))
