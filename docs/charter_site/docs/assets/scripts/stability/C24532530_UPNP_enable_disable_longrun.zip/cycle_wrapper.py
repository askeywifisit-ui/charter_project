#!/usr/bin/env python3
"""cycle_wrapper.py

UPnP longrun wrapper with standardized precondition + per-cycle SSH readiness.

precondition()（只在 cycle #1 跑一次；PRECONDITION_FIRST_CYCLE=1）：
  cpe_info --cloud retry
    → still fail → PDU reset 1 次 → wait → 再 retry
    → scan port 22，若關閉就 NOC ssh-enable → wait → 再 scan + ssh uptime probe

每一個 cycle 開始前：
  scan port 22，若關閉就 NOC ssh-enable（同 A2435638 v7 的 ssh_enable_start/end/wait + attempt:2 log）
  → wait → 再 scan + ssh uptime probe

Reads env:
  - CYCLES / CYCLE_INTERVAL / STOP_ON_FAIL / ORIGINAL_ENTRY
  - PRECONDITION_FIRST_CYCLE
  - CPE_READY_MAX_RETRIES / CPE_READY_RETRY_INTERVAL_SEC / CPE_READY_CMD_TIMEOUT_SEC
  - PDU_SCRIPT / PDU_OUTLET_ID / PDU_RESET_ACTION / PDU_RESET_WAIT_SEC / PDU_RESET_TIMEOUT_SEC
  - SSH_HOST_LAN / SSH_USER / SSH_PASSWORD / SSH_TOOL_TIMEOUT
  - REQUIRE_SSH_READY / AUTO_SSH_ENABLE / SSH_ENABLE_RETRIES / WAIT_AFTER_SSH_ENABLE_SEC
  - SSH_PORT_MAX_RETRIES / SSH_PORT_INTERVAL_SEC / SSH_SCAN_TIMEOUT_SEC
  - NOC_PROFILE / PROFILES_FILE / NOC_BASE(or BASE) / NOC_EMAIL / NOC_PASSWORD / CUSTOMER_ID
"""

import importlib
import json
import os
import shlex
import socket
import subprocess
import sys
import time
from typing import Optional, Tuple


def _parse_bool(val, default: bool = False) -> bool:
    if val is None:
        return default
    s = str(val).strip().lower()
    return s in ("1", "true", "yes", "y")


def _jprint(obj) -> None:
    print(json.dumps(obj, ensure_ascii=False), flush=True)


def _resolve_entry(entry: str):
    if not entry or ":" not in entry:
        raise ValueError(f"Bad ORIGINAL_ENTRY: {entry!r}")
    mod_name, func_name = entry.split(":", 1)
    if mod_name.endswith(".py"):
        mod_name = mod_name[:-3]
    mod = importlib.import_module(mod_name)
    return getattr(mod, func_name)


def _run_cmd(cmd_list, timeout: int = 30) -> Tuple[int, str]:
    try:
        cp = subprocess.run(
            cmd_list,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=timeout,
        )
        return cp.returncode, (cp.stdout or "")
    except Exception as e:
        return 99, f"ERROR: {e}"


# ---------------- CPE ready (cpe_info --cloud) ----------------

def _parse_cloud_status(out: str) -> Optional[str]:
    for line in (out or "").splitlines():
        if ":" not in line:
            continue
        k, v = line.split(":", 1)
        if k.strip().lower() == "cloud status":
            return v.strip()
    return None


def _cloud_connected(val: Optional[str]) -> bool:
    return bool(val) and val.strip().lower() == "connected"


def _cpe_cloud_probe(tag: str) -> bool:
    cpe_info = os.environ.get("CPE_INFO_TOOL", "cpe_info")
    cmd = os.environ.get("CPE_CLOUD_CMD", f"{cpe_info} --cloud")
    retries = int(os.environ.get("CPE_READY_MAX_RETRIES", "5"))
    interval = float(os.environ.get("CPE_READY_RETRY_INTERVAL_SEC", "3"))
    timeout = int(os.environ.get("CPE_READY_CMD_TIMEOUT_SEC", "20"))

    for attempt in range(1, retries + 1):
        rc, out = _run_cmd(shlex.split(cmd), timeout=timeout)
        cloud = _parse_cloud_status(out)
        ok = _cloud_connected(cloud)
        _jprint({
            "event": tag,
            "attempt": attempt,
            "cmd": cmd,
            "cmd_rc": rc,
            "cloud": cloud,
            "ok": ok,
        })
        if ok:
            return True
        if attempt < retries and interval > 0:
            time.sleep(interval)

    return False


def _pdu_reset_once() -> bool:
    pybin = os.environ.get("PYTHON", "python3")
    pdu_script = os.environ.get("PDU_SCRIPT") or os.environ.get("PDU_RESET_SCRIPT") or "/home/da40/charter/tools/pdu_outlet1.py"
    pdu_outlet = os.environ.get("PDU_OUTLET_ID", "1")
    action = os.environ.get("PDU_RESET_ACTION", "reset")
    timeout = int(os.environ.get("PDU_RESET_TIMEOUT_SEC", "600"))
    wait_sec = int(os.environ.get("PDU_RESET_WAIT_SEC", "120"))

    os.environ["PDU_OUTLET_ID"] = str(pdu_outlet)

    _jprint({
        "event": "pdu_reset_start",
        "script": pdu_script,
        "outlet_id": str(pdu_outlet),
        "action": action,
    })

    rc, out = _run_cmd([pybin, pdu_script, action], timeout=timeout)

    _jprint({
        "event": "pdu_reset_end",
        "rc": rc,
        "output_tail": (out or "")[-2000:],
    })

    if wait_sec > 0:
        _jprint({"event": "pdu_reset_wait", "secs": wait_sec})
        time.sleep(wait_sec)

    return rc == 0


# ---------------- SSH ensure (scan 22 + NOC ssh-enable + uptime probe) ----------------

def _port_open(host: str, port: int = 22, timeout: float = 2.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except Exception:
        return False


def _scan_port22(host: str, phase: str) -> bool:
    # wrapper 的「scan」不要跟 main_impl_orig 的「wait port open」共用同一組 env，
    # 否則為了讓 main_impl 等久一點而把 SSH_PORT_MAX_RETRIES 調大，
    # 會導致 wrapper 在 NOC ssh-enable 前拖很久。
    #
    # wrapper 使用獨立變數（未設定時採用快速預設值）：
    #   SSH_SCAN_MAX_RETRIES (default=1)
    #   SSH_SCAN_INTERVAL_SEC (default=1)
    max_r = int(os.environ.get("SSH_SCAN_MAX_RETRIES", "1"))
    interval = float(os.environ.get("SSH_SCAN_INTERVAL_SEC", "1"))
    timeout = float(os.environ.get("SSH_SCAN_TIMEOUT_SEC", "2"))

    for attempt in range(1, max_r + 1):
        ok = _port_open(host, 22, timeout=timeout)
        _jprint({
            "event": "ssh_port",
            "phase": phase,
            "attempt": attempt,
            "host": host,
            "port": 22,
            "ok": ok,
        })
        if ok:
            return True
        if attempt < max_r and interval > 0:
            time.sleep(interval)

    return False


def _ssh_uptime_probe(host: str, phase: str) -> bool:
    pybin = os.environ.get("PYTHON", "python3")
    cpe_ssh = os.environ.get("CPE_SSH_TOOL", "/home/da40/charter/tools/cpe_ssh.py")
    user = os.environ.get("SSH_USER", "operator")
    pw = os.environ.get("SSH_PASSWORD", "")
    t = float(os.environ.get("SSH_TOOL_TIMEOUT", "15"))

    cmd = [
        pybin,
        cpe_ssh,
        "--host",
        host,
        "--user",
        user,
        "--password",
        pw,
        "--cmd",
        "uptime",
        "--timeout",
        str(t),
    ]
    rc, out = _run_cmd(cmd, timeout=int(t) + 10)

    meta = {}
    ok = False
    out_s = (out or "").strip()
    try:
        # cpe_ssh.py 通常會輸出 JSON；但部分環境/子指令可能只輸出純文字
        if out_s.startswith("{"):
            meta = json.loads(out_s)
            if isinstance(meta, dict) and ("ok" in meta):
                ok = bool(meta.get("ok"))
            else:
                ok = (rc == 0)
        else:
            meta = {"raw": (out or "")[-300:], "note": "non_json_output"}
            ok = (rc == 0)
    except Exception as e:
        meta = {"raw": (out or "")[-300:], "parse_error": str(e)}
        ok = (rc == 0)

    _jprint({
        "event": "ssh_probe",
        "phase": phase,
        "ok": ok,
        "rc": rc,
        "meta": meta,
    })
    return ok


def _apply_noc_profile_if_any() -> None:
    prof = os.environ.get("NOC_PROFILE")
    pf = os.environ.get("PROFILES_FILE")
    if not prof or not pf:
        return

    try:
        with open(pf, "r", encoding="utf-8") as f:
            data = json.load(f)
        p = data.get(prof) if isinstance(data, dict) else None
        if not isinstance(p, dict):
            return

        if p.get("base"):
            os.environ["NOC_BASE"] = p["base"]
        if p.get("email"):
            os.environ["NOC_EMAIL"] = p["email"]
        if p.get("password"):
            os.environ["NOC_PASSWORD"] = p["password"]
        if p.get("customer_id"):
            os.environ["CUSTOMER_ID"] = str(p["customer_id"])
    except Exception:
        return


def _import_noc_api_cli():
    tools = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
    if tools and tools not in sys.path:
        sys.path.insert(0, tools)
    import noc_api_cli  # type: ignore

    return noc_api_cli


def _get_node_id() -> Optional[str]:
    nid = os.environ.get("NODE_ID")
    if nid:
        return nid.strip().lower().replace(":", "")

    cpe_info = os.environ.get("CPE_INFO_TOOL", "cpe_info")
    cmd = os.environ.get("CPE_NODEID_CMD", f"{cpe_info} --node-id")
    retries = int(os.environ.get("NODE_ID_MAX_RETRIES", "5"))
    interval = float(os.environ.get("NODE_ID_RETRY_INTERVAL_SEC", "2"))

    for attempt in range(1, retries + 1):
        rc, out = _run_cmd(shlex.split(cmd), timeout=20)
        tok = (out or "").strip().split()
        val = tok[0].strip().lower().replace(":", "") if tok else ""
        ok = len(val) >= 12
        _jprint({
            "event": "node_id",
            "attempt": attempt,
            "cmd": cmd,
            "cmd_rc": rc,
            "node_id": val if ok else None,
            "ok": ok,
        })
        if ok:
            return val
        if attempt < retries and interval > 0:
            time.sleep(interval)

    return None


def _noc_ssh_enable(node_id: str, attempt: int, phase: str) -> bool:
    _apply_noc_profile_if_any()
    noc_api = _import_noc_api_cli()

    base = os.environ.get("NOC_BASE") or os.environ.get("BASE") or "https://piranha-int.tau.dev-charter.net"
    customer_id = os.environ.get("CUSTOMER_ID", "")
    email = os.environ.get("NOC_EMAIL", "")
    password = os.environ.get("NOC_PASSWORD", "")
    ssh_passwd = os.environ.get("SSH_PASSWORD", "")
    timeout_min = int(os.environ.get("SSH_TIMEOUT_MIN", "120"))

    bearer = _parse_bool(os.environ.get("NOC_BEARER", "0"), default=False)
    insecure = _parse_bool(os.environ.get("NOC_INSECURE", "0"), default=False)

    token = os.environ.get("NOC_TOKEN")
    if not token:
        token = noc_api.login(base, email, password, bearer=bearer, insecure=insecure)

    location_id = os.environ.get("LOCATION_ID") or os.environ.get("NOC_LOCATION_ID")
    if not location_id:
        location_id = noc_api.get_location_id(base, customer_id, node_id, token=token, bearer=bearer, insecure=insecure)

    _jprint({
        "event": "ssh_enable_start",
        "phase": phase,
        "attempt": attempt,
        "base": base,
        "customer_id": customer_id,
        "location_id": location_id,
        "node_id": node_id,
        "timeout_min": timeout_min,
    })

    try:
        resp = noc_api.ssh_enable(
            base,
            customer_id,
            location_id,
            node_id,
            passwd=ssh_passwd,
            timeout_min=timeout_min,
            token=token,
            bearer=bearer,
            insecure=insecure,
        )
        _jprint({
            "event": "ssh_enable_end",
            "phase": phase,
            "attempt": attempt,
            "ok": True,
            "resp_tail": str(resp)[-500:],
        })
        return True
    except Exception as e:
        _jprint({
            "event": "ssh_enable_end",
            "phase": phase,
            "attempt": attempt,
            "ok": False,
            "error": str(e),
        })
        return False


def _ensure_ssh_ready(phase: str) -> bool:
    if not _parse_bool(os.environ.get("REQUIRE_SSH_READY", "1"), default=True):
        return True

    host = os.environ.get("SSH_HOST_LAN", "192.168.1.1")
    auto_enable = _parse_bool(os.environ.get("AUTO_SSH_ENABLE", "1"), default=True)
    enable_retries = int(os.environ.get("SSH_ENABLE_RETRIES", "2"))
    wait_after = int(os.environ.get("WAIT_AFTER_SSH_ENABLE_SEC", "10"))

    # quick path
    if _scan_port22(host, phase) and _ssh_uptime_probe(host, phase):
        return True

    if not auto_enable:
        return False

    node_id = _get_node_id()
    if not node_id:
        _jprint({"event": "ssh_ready_fail", "phase": phase, "reason": "node_id_missing"})
        return False

    for a in range(1, enable_retries + 1):
        _noc_ssh_enable(node_id, attempt=a, phase=phase)

        if wait_after > 0:
            _jprint({"event": "ssh_enable_wait", "phase": phase, "attempt": a, "secs": wait_after})
            time.sleep(wait_after)

        if _scan_port22(host, phase) and _ssh_uptime_probe(host, phase):
            return True

    _jprint({"event": "ssh_ready_fail", "phase": phase, "reason": "port_or_probe_failed"})
    return False


# ---------------- main loop ----------------

def run() -> int:
    cycles = int(os.environ.get("CYCLES", "1"))
    interval = int(os.environ.get("CYCLE_INTERVAL", "30"))
    stop_on_fail = _parse_bool(os.environ.get("STOP_ON_FAIL", "1"), default=True)
    entry = os.environ.get("ORIGINAL_ENTRY", "main_impl_orig.py:run")

    try:
        func = _resolve_entry(entry)
    except Exception as e:
        _jprint({"event": "entry_resolve_error", "entry": entry, "error": str(e)})
        return 1

    precond_first = _parse_bool(os.environ.get("PRECONDITION_FIRST_CYCLE", "1"), default=True)

    # precondition (cycle #1 only)
    if precond_first:
        if not _cpe_cloud_probe("cpe_cloud_check"):
            _pdu_reset_once()
            if not _cpe_cloud_probe("cpe_cloud_recheck_after_pdu"):
                _jprint({"event": "precondition_fail", "cycle": 1, "reason": "cloud_not_ready"})
                return 2

        if not _ensure_ssh_ready("precondition"):
            _jprint({"event": "precondition_fail", "cycle": 1, "reason": "ssh_not_ready"})
            return 3

    overall_rc = 0
    for i in range(cycles):
        cycle_no = i + 1
        os.environ["CYCLE_INDEX"] = str(cycle_no)

        if not _ensure_ssh_ready(f"cycle_{cycle_no}"):
            _jprint({"event": "cycle_fail_before_entry", "cycle": cycle_no, "reason": "ssh_not_ready"})
            overall_rc = 3
            if stop_on_fail:
                break
            else:
                continue

        _jprint({"event": "cycle_start", "cycle": cycle_no, "total": cycles})

        try:
            rc = func()
        except SystemExit as se:
            rc = int(se.code or 0)
        except Exception as e:
            _jprint({"event": "cycle_exception", "cycle": cycle_no, "error": str(e)})
            rc = 1

        try:
            rc = int(rc)
        except Exception:
            rc = 1

        _jprint({"event": "cycle_end", "cycle": cycle_no, "rc": rc})
        if rc != 0:
            overall_rc = rc
            if stop_on_fail:
                break

        if i < cycles - 1 and interval > 0:
            time.sleep(interval)

    _jprint({"event": "all_cycles_done", "rc": overall_rc})
    return overall_rc


if __name__ == "__main__":
    sys.exit(run())
