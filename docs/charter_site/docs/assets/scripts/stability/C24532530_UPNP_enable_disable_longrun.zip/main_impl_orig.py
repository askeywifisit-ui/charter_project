#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
C001_SSH_api_test main implementation.

流程：
  1. 使用 NOC_EMAIL / NOC_PASSWORD login 取得 token
  2. 透過 serial (METRICS_TOOL) 取得 node_id
  3. 透過 NOC API 取得 location_id
  4. 跑一輪 NOC API 測試：
     - get-location 一致性確認
     - speedtest-run + speedtest-result (輪詢等待結果)
     - wifi-status / wifi-enable / wifi-disable（最後會還原）
     - lte-status
  5. 根據 SSH_ACTION (enable / disable / both) 做 ssh-enable / ssh-disable

依賴：
  - /home/da40/charter/tools/noc_api_cli.py (用 import noc_api_cli as api)
"""


import os
import sys
import json
import time
import subprocess
import socket
from pathlib import Path
from typing import Dict, Optional

import requests  # 用來抓 HTTPError status code
from cpe_health_helper import run_cpe_health_check

# -------------------------------------------------
# serial mute helpers (stale cleanup + safe clear)
# -------------------------------------------------

try:
    import serial_mute  # type: ignore
except Exception:
    serial_mute = None  # type: ignore

_SERIAL_MUTE_PATH = Path(os.environ.get("SERIAL_MUTE_FILE", "/home/da40/charter/var/serial.mute"))


def _read_mute_until_ts() -> int:
    """Return mute-until unix ts from file, or 0 if missing/invalid."""
    try:
        s = _SERIAL_MUTE_PATH.read_text().strip()
        if not s:
            return 0
        return int(float(s))
    except FileNotFoundError:
        return 0
    except Exception:
        return 0

def _serial_mute_clear_stale(*, reason: str) -> bool:
    """Clear serial mute only when it is stale/invalid (safe for other scripts)."""
    now = int(time.time())
    until_ts = _read_mute_until_ts()
    if until_ts <= 0:
        print(json.dumps({"event": "serial_mute_clear", "ok": True, "via": "noop", "reason": reason, "path": str(_SERIAL_MUTE_PATH)}))
        return True
    if until_ts > now:
        print(json.dumps({"event": "serial_mute_clear", "ok": True, "via": "skip_active", "reason": reason, "path": str(_SERIAL_MUTE_PATH), "until_ts": until_ts, "left": max(0, until_ts - now)}))
        return True
    # stale
    try:
        if serial_mute and hasattr(serial_mute, "clear"):
            serial_mute.clear()
            via = "serial_mute.clear"
        else:
            _SERIAL_MUTE_PATH.unlink(missing_ok=True)
            via = "unlink"
        print(json.dumps({"event": "serial_mute_clear", "ok": True, "via": via, "reason": reason, "path": str(_SERIAL_MUTE_PATH), "until_ts": until_ts}))
        return True
    except Exception as e:
        print(json.dumps({"event": "serial_mute_clear", "ok": False, "via": "exception", "reason": reason, "path": str(_SERIAL_MUTE_PATH), "until_ts": until_ts, "error": str(e)}))
        return False


def _serial_mute_clear_if_match(*, expected_until_ts: int, reason: str) -> bool:
    """Clear serial mute only if file equals expected_until_ts (avoid clobber others)."""
    if expected_until_ts <= 0:
        return True
    try:
        cur = _read_mute_until_ts()
        if cur != int(expected_until_ts):
            print(json.dumps({"event": "serial_mute_clear", "ok": True, "via": "skip_mismatch", "reason": reason, "path": str(_SERIAL_MUTE_PATH), "expected_until_ts": int(expected_until_ts), "current_until_ts": int(cur)}))
            return True
        if serial_mute and hasattr(serial_mute, "clear"):
            serial_mute.clear()
            via = "serial_mute.clear"
        else:
            _SERIAL_MUTE_PATH.unlink(missing_ok=True)
            via = "unlink"
        print(json.dumps({"event": "serial_mute_clear", "ok": True, "via": via, "reason": reason, "path": str(_SERIAL_MUTE_PATH), "until_ts": int(expected_until_ts)}))
        return True
    except Exception as e:
        print(json.dumps({"event": "serial_mute_clear", "ok": False, "via": "exception", "reason": reason, "path": str(_SERIAL_MUTE_PATH), "expected_until_ts": int(expected_until_ts), "error": str(e)}))
        return False


def _serial_mute_set(*, secs: int, use_lock: bool, lock_timeout: int = 5, reason: str = "") -> int:
    """Set serial mute and return until_ts. Best-effort.

    Priority:
    1) cpe_ssh.set_console_mute (supports lock)
    2) serial_mute.mute_for
    3) write SERIAL_MUTE_FILE directly
    """
    try:
        secs_i = int(secs)
    except Exception:
        secs_i = 0
    if secs_i <= 0:
        return 0

    now = int(time.time())
    until_ts = now + secs_i

    # best-effort stale cleanup before setting
    _serial_mute_clear_stale(reason=reason or "before_set")

    # prefer cpe_ssh integration
    try:
        if "cpe_ssh" in globals() and cpe_ssh is not None and hasattr(cpe_ssh, "set_console_mute"):
            return int(cpe_ssh.set_console_mute(secs_i, use_lock=bool(use_lock), lock_timeout=int(lock_timeout)))
    except Exception:
        pass

    # fallback to serial_mute
    try:
        if serial_mute and hasattr(serial_mute, "mute_for"):
            return int(serial_mute.mute_for(secs_i))
    except Exception:
        pass

    # last resort: direct file write
    try:
        _SERIAL_MUTE_PATH.parent.mkdir(parents=True, exist_ok=True)
        _SERIAL_MUTE_PATH.write_text(str(until_ts))
        try:
            os.chmod(_SERIAL_MUTE_PATH, 0o664)
        except Exception:
            pass
        return int(until_ts)
    except Exception:
        return 0



# 用來讓 cycle_wrapper 讀取本次 speedtest 的結果
_last_speedtest_metrics: Optional[Dict[str, float]] = None


def get_last_speedtest_metrics() -> Optional[Dict[str, float]]:
    """
    給 cycle_wrapper 用：
    回傳本次 run() 內最後一次 speedtest 的 DL / UL / latency。
    如果這次 run 沒有成功拿到數值，回傳 None。
    """
    return _last_speedtest_metrics


def _first_numeric_key(obj: object, candidates) -> Optional[float]:
    """
    在巢狀 JSON 裡面找第一個符合 key 且是數字的值。
    candidates: 依序嘗試的欄位名稱。
    """
    if isinstance(obj, dict):
        for k in candidates:
            if k in obj and isinstance(obj[k], (int, float)):
                return float(obj[k])
        for v in obj.values():
            val = _first_numeric_key(v, candidates)
            if val is not None:
                return val
    elif isinstance(obj, list):
        for v in obj:
            val = _first_numeric_key(v, candidates)
            if val is not None:
                return val
    return None


def _extract_speedtest_metrics(resp: object) -> Optional[Dict[str, float]]:
    """
    嘗試從 speedtest-result 的 JSON 裡面抽出 download / upload / latency。

    這裡先假設 NOC 回傳的欄位名稱類似：
      - downloadSpeed  (吞吐 / DL)
      - uploadSpeed    (吞吐 / UL)
      - latency        (延遲)

    如果你實際看到的 JSON 不同，只要把下面 KEY 清單換成實際的 key 即可。
    """
    dl = _first_numeric_key(resp, ["downloadSpeed", "download", "downstream", "dlMbps"])
    ul = _first_numeric_key(resp, ["uploadSpeed", "upload", "upstream", "ulMbps"])
    lat = _first_numeric_key(resp, ["latency", "ping", "rtt"])

    if dl is None and ul is None and lat is None:
        return None

    return {
        "downloadSpeed": dl,
        "uploadSpeed": ul,
        "latency": lat,
    }


# -------------------------------------------------
# 載入 tools 目錄底下的 noc_api_cli
# -------------------------------------------------
TOOLS_PATH = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
TOOLS_PATH = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
if TOOLS_PATH and TOOLS_PATH not in sys.path:
    sys.path.insert(0, TOOLS_PATH)

try:
    import noc_api_cli as api  # type: ignore
except Exception as e:  # 在 ChatGPT sandbox 會失敗，在實機應該 OK
    api = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "noc_api_cli", "error": str(e)}))

try:
    import cpe_ssh  # type: ignore
except Exception as e:
    cpe_ssh = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "cpe_ssh", "error": str(e)}))

_CACHE: Dict[str, object] = {}


# -------------------------------------------------
# Precondition-style cached context (like A2435637)
# -------------------------------------------------
def _ensure_noc_context(
    base: str,
    email: str,
    password: str,
    bearer: bool,
    insecure: bool,
    customer_id: str,
    metrics_tool: str,
    dev: str,
    baud: int,
    cpe_user: str,
    cpe_password: str,
) -> tuple[str, str, str]:
    """Ensure token/node_id/location_id are cached.

    Runs login/node-id/location-id only when cache is missing.
    Emits a JSON event showing which parts were newly resolved.
    """
    had_token = "token" in _CACHE
    had_node = "node_id" in _CACHE
    had_loc = "location_id" in _CACHE

    token = _login(base, email, password, bearer, insecure)
    node_id = _node_id(metrics_tool, dev, baud, cpe_user, cpe_password)
    location_id = _location_id(base, customer_id, node_id, token, bearer, insecure)

    print(json.dumps({
        "event": "precondition_noc_ctx",
        "token_cached": had_token,
        "node_id_cached": had_node,
        "location_id_cached": had_loc,
        "node_id": node_id,
        "location_id": location_id,
    }))
    return token, node_id, location_id


def _cloud_ssh_enable_with_relogin(
    *,
    base: str,
    customer_id: str,
    location_id: str,
    node_id: str,
    ssh_pass: str,
    ssh_timeout_min: int,
    bearer: bool,
    insecure: bool,
    reason: str,
) -> bool:
    """Best-effort enable SSH via NOC; retry once with re-login if token is stale."""
    if api is None:
        return False
    email = _getenv("NOC_EMAIL")
    password = _getenv("NOC_PASSWORD")
    if not email or not password:
        return False

    def _try_once() -> bool:
        tok = _login(base, email, password, bearer, insecure)
        try:
            _ssh_enable(
                base,
                customer_id,
                location_id,
                node_id,
                ssh_pass,
                ssh_timeout_min,
                tok,
                bearer,
                insecure,
            )
            return True
        except Exception as e:
            print(json.dumps({
                "event": "cloud_ssh_enable_error",
                "reason": reason,
                "error": str(e),
            }))
            return False

    print(json.dumps({
        "event": "cloud_ssh_enable_try",
        "reason": reason,
        "base": base,
        "customer_id": customer_id,
        "location_id": location_id,
        "node_id": node_id,
    }))

    if _try_once():
        print(json.dumps({"event": "cloud_ssh_enable_ok", "reason": reason}))
        return True

    # Clear token and retry once
    try:
        _CACHE.pop("token", None)
    except Exception:
        pass

    ok2 = _try_once()
    print(json.dumps({
        "event": "cloud_ssh_enable_retry_done",
        "reason": reason,
        "ok": bool(ok2),
    }))
    return bool(ok2)



# -------------------------------------------------
# 小工具
# -------------------------------------------------
def _getenv(name: str, default: str = "") -> str:
    v = os.environ.get(name)
    return default if v is None else str(v)


def _bool_env(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return str(v).strip().lower() in ("1", "true", "yes", "y")


# -------------------------------------------------
# login / node / location
# -------------------------------------------------
def _login(base: str, email: str, password: str, bearer: bool, insecure: bool) -> str:
    if "token" in _CACHE:
        return _CACHE["token"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot login to NOC")

    tok = api.login(base, email, password, bearer=bearer, insecure=insecure)
    _CACHE["token"] = tok
    print(json.dumps({"step": "login", "ok": True}))
    return tok


def _node_id(metrics_tool: str, dev: str, baud: int, user: str, password: str) -> str:
    """Resolve node_id via `cpe_info --node-id` only (no console/serial)."""
    if "node_id" in _CACHE:
        try:
            print(json.dumps({"step": "node-id", "cached": True, "node_id": _CACHE["node_id"]}))
        except Exception:
            pass
        return _CACHE["node_id"]  # type: ignore[return-value]

    try:
        max_retries = int(os.environ.get("NODE_ID_MAX_RETRIES", "3"))
    except Exception:
        max_retries = 3
    try:
        retry_interval = float(os.environ.get("NODE_ID_RETRY_INTERVAL_SEC", "2"))
    except Exception:
        retry_interval = 2.0

    def _norm_node_id(raw: str) -> str:
        s = (raw or "").strip()
        if not s:
            return ""
        for ln in s.splitlines():
            ln = ln.strip()
            if ln:
                s = ln
                break
        s = s.replace(":", "").strip().lower()
        if len(s) == 12 and all(c in "0123456789abcdef" for c in s):
            return s
        return ""

    cpe_info_tool = os.environ.get("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
    last_raw = ""

    for attempt in range(1, max_retries + 1):
        for extra_args in (["--node-id"], ["--node-id", "--value"]):
            cmd = ([cpe_info_tool] if os.path.exists(cpe_info_tool) else ["cpe_info"]) + extra_args
            try:
                proc = subprocess.run(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    timeout=20,
                )
                last_raw = (proc.stdout or "").strip()
            except Exception as e:
                last_raw = str(e)
                print(json.dumps({
                    "step": "node-id-cpe_info-exception",
                    "attempt": attempt,
                    "cmd": cmd,
                    "error": str(e),
                }))
                continue

            nid = _norm_node_id(last_raw)
            ok = (proc.returncode == 0 and bool(nid))
            print(json.dumps({
                "step": "node-id-cpe_info",
                "attempt": attempt,
                "cmd": cmd,
                "rc": proc.returncode,
                "raw": last_raw,
                "node_id": nid if ok else "",
                "ok": ok,
            }))
            if ok:
                _CACHE["node_id"] = nid
                return nid

        if attempt < max_retries:
            print(json.dumps({
                "step": "node-id-retry",
                "attempt": attempt,
                "next_wait_sec": retry_interval,
            }))
            time.sleep(retry_interval)

    raise RuntimeError(f"cpe_info --node-id failed after {max_retries} retries; last_output={last_raw!r}")


def _location_id(base: str, customer_id: str, node_id: str,
                 token: str, bearer: bool, insecure: bool) -> str:
    if "location_id" in _CACHE:
        return _CACHE["location_id"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot query location_id")

    loc = api.get_location_id(base, customer_id, node_id,
                              token=token, bearer=bearer, insecure=insecure)
    _CACHE["location_id"] = loc
    print(json.dumps({"step": "location-id", "location_id": loc}))
    return loc


# -------------------------------------------------
# CPE console password fallback
# -------------------------------------------------
def _console_password(cpe_info_tool: str) -> str:
    """
    若 CPE_PASSWORD 未設定或為 null，嘗試透過 cpe_info 撈 console 密碼。
    """
    try:
        proc = subprocess.run(
            [cpe_info_tool, "--password"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=15,
        )
        out = (proc.stdout or "").strip()
        for line in out.splitlines():
            line = line.strip()
            if line:
                return line
    except Exception:
        pass
    return ""



# -------------------------------------------------
# Internet status wait using cpe_info --status
# -------------------------------------------------
def _wait_internet_connected_status(*, unmute_expected_until_ts: int = 0) -> None:
    """等待 cpe_info --internet 顯示 Internet Status: Connected。

    使用以下環境變數控制行為：
      UPNP_REBOOT_WAIT_SEC: 先 sleep 的秒數（預設 0，不等）
      INTERNET_STATUS_MAX_RETRIES: 狀態輪詢最多次數（預設 10）
      INTERNET_STATUS_INTERVAL_SEC: 輪詢間隔秒數（預設 1）
    """
    cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")

    try:
        first_wait = float(_getenv("UPNP_REBOOT_WAIT_SEC", "0"))
    except Exception:
        first_wait = 0.0

    try:
        max_retries = int(_getenv("INTERNET_STATUS_MAX_RETRIES", "10"))
    except Exception:
        max_retries = 10

    try:
        interval_sec = float(_getenv("INTERNET_STATUS_INTERVAL_SEC", "1"))
    except Exception:
        interval_sec = 1.0

    # 先等 reboot / 網路恢復的時間（此段期間保留 mute，避免其他工具誤用 serial）
    if first_wait > 0:
        print(json.dumps({
            "event": "upnp-reboot-wait",
            "wait_sec": first_wait,
        }))
        time.sleep(first_wait)

    # reboot window 結束後再解除 mute（只解除本次 iteration 設定的那個 until_ts）
    if unmute_expected_until_ts:
        _serial_mute_clear_if_match(
            expected_until_ts=int(unmute_expected_until_ts),
            reason="upnp_reboot_window_end",
        )

    last_output: str = ""

    for attempt in range(1, max_retries + 1):
        cmd = [cpe_info_tool, "--internet"]
        print(json.dumps({
            "step": "status-check",
            "attempt": attempt,
            "max_retries": max_retries,
            "cmd": cmd,
        }))

        try:
            proc = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=30,
            )
            out = (proc.stdout or "").strip()
            last_output = out
        except Exception as e:
            print(json.dumps({
                "step": "status-check-exception",
                "attempt": attempt,
                "error": str(e),
            }))
        else:
            print(json.dumps({
                "step": "status-check-raw",
                "attempt": attempt,
                "rc": proc.returncode,
                "out": out,
            }))
            if proc.returncode == 0 and "Internet Status: Connected" in out:
                print(json.dumps({
                    "step": "status-check-ok",
                    "attempt": attempt,
                }))
                return

        if attempt < max_retries:
            time.sleep(interval_sec)

    print(json.dumps({
        "step": "status-check-failed",
        "max_retries": max_retries,
        "last_output": last_output[-200:],
    }))
    raise RuntimeError(
        f"internet not connected after {max_retries} checks via cpe_info --status"
    )



# -------------------------------------------------

def _wait_ssh_port_open(host: str, port: int) -> None:
    """
    等待 SSH TCP port 開啟。

    使用環境變數控制：
      SSH_PORT_MAX_RETRIES:   重試次數（預設 10）
      SSH_PORT_INTERVAL_SEC:  每次重試間隔秒數（預設 3）
      SSH_PORT_CHECK_TIMEOUT: 單次 connect timeout 秒數（預設 3）
    """
    try:
        max_retries = int(os.environ.get("SSH_PORT_MAX_RETRIES", "10"))
    except Exception:
        max_retries = 10
    try:
        interval_sec = float(os.environ.get("SSH_PORT_INTERVAL_SEC", "3"))
    except Exception:
        interval_sec = 3.0
    try:
        ssh_port_timeout = float(os.environ.get("SSH_PORT_CHECK_TIMEOUT", "3"))
    except Exception:
        ssh_port_timeout = 3.0

    last_error: str = ""

    for attempt in range(1, max_retries + 1):
        print(json.dumps({
            "event": "ssh-port-wait",
            "host": host,
            "port": port,
            "attempt": attempt,
            "max_retries": max_retries,
            "timeout": ssh_port_timeout,
        }))
        try:
            with socket.create_connection((host, port), timeout=ssh_port_timeout):
                print(json.dumps({
                    "event": "ssh-port-wait-ok",
                    "host": host,
                    "port": port,
                    "attempt": attempt,
                }))
                return
        except Exception as e:
            last_error = str(e)

        if attempt < max_retries:
            time.sleep(interval_sec)

    print(json.dumps({
        "event": "ssh-port-wait-failed",
        "host": host,
        "port": port,
        "max_retries": max_retries,
        "last_error": last_error,
    }))
    raise RuntimeError(
        f"ssh port {host}:{port} not open after {max_retries} attempts"
    )


# SSH enable / disable
# -------------------------------------------------
def _ssh_enable(base: str, customer_id: str, location_id: str, node_id: str,
                ssh_pass: str, timeout_min: int,
                token: str, bearer: bool, insecure: bool) -> None:
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot enable SSH")

    resp = api.ssh_enable(
        base,
        customer_id,
        location_id,
        node_id,
        ssh_pass,
        timeout_min,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({"step": "ssh-enable", "resp": resp}))


def _ssh_disable(base: str, customer_id: str, location_id: str, node_id: str,
                 token: str, bearer: bool, insecure: bool) -> None:
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot disable SSH")

    resp = api.ssh_disable(
        base,
        customer_id,
        location_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({"step": "ssh-disable", "resp": resp}))


# -------------------------------------------------
# NOC API 測試 helpers
# -------------------------------------------------
def _run_speedtest_tests(base: str, customer_id: str, location_id: str, node_id: str,
                         token: str, bearer: bool, insecure: bool) -> None:
    """
    SpeedTest 測試流程：

      1) POST /speedTest 觸發一次測速 → 拿到 requestId
      2) 先等 SPEEDTEST_WAIT_SEC 秒（預設 60）
      3) 最多重試 SPEEDTEST_MAX_TRIES 次，每次間隔 SPEEDTEST_INTERVAL_SEC 秒
         呼叫 GET /speedTestResults/{requestId} 查單筆結果

    三個參數都用 env 控制：
      SPEEDTEST_WAIT_SEC
      SPEEDTEST_MAX_TRIES
      SPEEDTEST_INTERVAL_SEC
    """
    global _last_speedtest_metrics
    _last_speedtest_metrics = None

    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run speedtest tests")

    # 1) 觸發一次 speed test
    resp_run = api.speedtest_run(
        base,
        customer_id,
        location_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )

    request_id: Optional[str] = None
    if isinstance(resp_run, dict):
        request_id = (
            resp_run.get("requestId")
            or resp_run.get("request_id")
            or resp_run.get("id")
        )

    print(json.dumps({
        "step": "speedtest-run",
        "resp": resp_run,
        "request_id": request_id,
    }))

    if not request_id:
        raise RuntimeError("speedtest-run did not return requestId")

    # 2) 先等一段時間再開始查結果
    wait_sec = int(_getenv("SPEEDTEST_WAIT_SEC", "60"))
    print(json.dumps({
        "step": "speedtest-wait",
        "request_id": request_id,
        "seconds": wait_sec,
    }))
    time.sleep(wait_sec)

    # 3) 開始少量輪詢
    max_tries = int(_getenv("SPEEDTEST_MAX_TRIES", "3"))
    interval_sec = int(_getenv("SPEEDTEST_INTERVAL_SEC", "10"))

    last_error: Optional[str] = None
    resp_one: Optional[object] = None

    for attempt in range(1, max_tries + 1):
        try:
            resp_one = api.speedtest_result_by_id(
                base,
                customer_id,
                location_id,
                node_id,
                request_id,
                token=token,
                bearer=bearer,
                insecure=insecure,
            )
            # 呼叫成功（沒有丟 HTTPError）
            print(json.dumps({
                "step": "speedtest-result",
                "attempt": attempt,
                "request_id": request_id,
                "resp": resp_one,
            }))

            # 解析本次 speedtest 的 throughput / latency，存成全域給 cycle_wrapper 用
            metrics = _extract_speedtest_metrics(resp_one)
            if metrics is not None:
                _last_speedtest_metrics = metrics
                print(json.dumps({
                    "event": "speedtest_metrics",
                    **metrics,
                }))
            else:
                # 沒有找到 DL / UL / latency 欄位
                _last_speedtest_metrics = None
                print(json.dumps({
                    "event": "speedtest_metrics_missing",
                    "reason": "no_dl_ul_latency_found_in_response",
                }))

            break

        except requests.HTTPError as e:
            status = e.response.status_code if e.response is not None else None
            body = e.response.text[:200] if e.response is not None else ""
            last_error = f"HTTP {status}: {body}"

            print(json.dumps({
                "step": "speedtest-result-retry",
                "attempt": attempt,
                "request_id": request_id,
                "status": status,
                "error": last_error,
            }))

            # 如果還有下一次機會，且是 400/404，就睡 interval_sec 秒再試
            if attempt < max_tries and status in (400, 404):
                time.sleep(interval_sec)
                continue

            # 其他情況（沒下一次或不是 400/404），直接丟出去
            raise

    if resp_one is None:
        # 全部嘗試完還失敗，就讓整個腳本 FAIL
        raise RuntimeError(f"speedtest-result failed after {max_tries} tries: {last_error}")


def _wifi_enabled_flag(status: object) -> Optional[bool]:
    """從 wifi-status 回傳的 JSON 抽出 enabled 狀態."""
    if isinstance(status, dict):
        # 1) 先看頂層有沒有 enabled
        if "enabled" in status:
            return bool(status.get("enabled"))

        # 2) 再看 wifiNetwork.enabled
        wn = status.get("wifiNetwork")
        if isinstance(wn, dict) and "enabled" in wn:
            return bool(wn.get("enabled"))

        # 3) 如果是 wifiNetworks 陣列，也處理一下（預留擴充）
        wns = status.get("wifiNetworks")
        if isinstance(wns, list) and wns and isinstance(wns[0], dict) and "enabled" in wns[0]:
            return bool(wns[0].get("enabled"))

    return None


def _run_wifi_tests(base: str, customer_id: str, location_id: str,
                    token: str, bearer: bool, insecure: bool) -> None:
    """wifi-status / wifi-enable / wifi-disable 功能測試，最後會盡量恢復原本狀態。"""
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run wifi tests")

    # 先查目前狀態
    status_before = api.wifi_status(
        base,
        customer_id,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    enabled_before = _wifi_enabled_flag(status_before)
    print(json.dumps({
        "step": "wifi-status-before",
        "enabled": enabled_before,
        "resp": status_before,
    }))

    target_state = not bool(enabled_before) if enabled_before is not None else True

    # 切換一次
    resp_toggle = api.wifi_set_enabled(
        base,
        customer_id,
        location_id,
        target_state,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    status_mid = api.wifi_status(
        base,
        customer_id,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    enabled_mid = _wifi_enabled_flag(status_mid)
    print(json.dumps({
        "step": "wifi-toggle",
        "target": target_state,
        "enabled_mid": enabled_mid,
        "resp_toggle": resp_toggle,
        "status_mid": status_mid,
    }))

    # 盡量恢復原本狀態
    if enabled_before is not None and enabled_before != enabled_mid:
        resp_restore = api.wifi_set_enabled(
            base,
            customer_id,
            location_id,
            enabled_before,
            token=token,
            bearer=bearer,
            insecure=insecure,
        )
        status_after = api.wifi_status(
            base,
            customer_id,
            location_id,
            token=token,
            bearer=bearer,
            insecure=insecure,
        )
        enabled_after = _wifi_enabled_flag(status_after)
        ok = (enabled_after == enabled_before)
        print(json.dumps({
            "step": "wifi-restore",
            "enabled_before": enabled_before,
            "enabled_after": enabled_after,
            "ok": ok,
            "resp_restore": resp_restore,
            "status_after": status_after,
        }))
        if not ok:
            raise RuntimeError("wifi enabled state mismatch after restore")


def _run_lte_test(base: str, location_id: str,
                  token: str, bearer: bool, insecure: bool) -> None:
    """lte-status 測試（僅查詢）。"""
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run LTE tests")

    resp = api.lte_status(
        base,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({
        "step": "lte-status",
        "resp": resp,
    }))


def _run_get_location_test(base: str, customer_id: str, node_id: str,
                           location_id: str,
                           token: str, bearer: bool, insecure: bool) -> None:
    """get-location 功能測試，確認回傳的 locationId 與前面取得的一致。"""
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run get-location test")

    loc2 = api.get_location_id(
        base,
        customer_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    ok = (loc2 == location_id)
    print(json.dumps({
        "step": "get-location-check",
        "location_id": location_id,
        "location_id_refetched": loc2,
        "ok": ok,
    }))
    if not ok:
        raise RuntimeError("location_id from get_location_id() mismatch")

def _run_noc_api_tests(base: str, customer_id: str, node_id: str, location_id: str,
                       token: str, bearer: bool, insecure: bool,
                       ssh_pass: str, ssh_timeout_min: int) -> None:
    """
    統一執行 NOC API 測試，並可透過環境變數決定是否啟用各項測試：

      ENABLE_SPEEDTEST  (預設 1)
      ENABLE_WIFI_TEST  (預設 1)
      ENABLE_LTE_TEST   (預設 1)
    """
    # 讀 env 開關
    enable_speedtest = _bool_env("ENABLE_SPEEDTEST", True)
    enable_wifi = _bool_env("ENABLE_WIFI_TEST", True)
    enable_lte = _bool_env("ENABLE_LTE_TEST", True)

    print(json.dumps({
        "event": "noc-api-tests-start",
        "enable_speedtest": enable_speedtest,
        "enable_wifi": enable_wifi,
        "enable_lte": enable_lte,
    }))

    # 一律先做 get-location 一致性檢查
    _run_get_location_test(base, customer_id, node_id, location_id,
                           token, bearer, insecure)

    # speedtest

    if enable_speedtest:
        _run_speedtest_tests(base, customer_id, location_id, node_id,
                             token, bearer, insecure)
        # 在 health 之前先檢查 SSH port 是否開啟，如未開則透過 NOC API 重新 enable SSH
        host = os.environ.get("CPE_HEALTH_HOST", "192.168.1.1")
        try:
            port = int(os.environ.get("CPE_HEALTH_PORT", "22"))
        except Exception:
            port = 22
        try:
            ssh_port_timeout = float(os.environ.get("SSH_PORT_CHECK_TIMEOUT", "3"))
        except Exception:
            ssh_port_timeout = 3.0
        ssh_open = False
        try:
            with socket.create_connection((host, port), timeout=ssh_port_timeout):
                ssh_open = True
        except Exception:
            ssh_open = False
        print(json.dumps({
            "event": "ssh-port-check",
            "host": host,
            "port": port,
            "open": ssh_open,
        }))
        if not ssh_open:
            # 透過 NOC API 再次 enable SSH（延長 / 重新打開 SSH 視後端實作而定）
            _ssh_enable(base, customer_id, location_id, node_id,
                        ssh_pass, ssh_timeout_min, token, bearer, insecure)
            # 簡單等待一下再給 health 使用
            time.sleep(2.0)
        # CPE health check after speedtest metrics
        health_ok = run_cpe_health_check(TOOLS_PATH, timeout=180)
        if not health_ok:
            raise RuntimeError("CPE health check failed after speedtest")
    else:
        print(json.dumps({
            "event": "speedtest-skip",
            "reason": "env_disabled",
        }))



    # wifi
    if enable_wifi:
        _run_wifi_tests(base, customer_id, location_id,
                        token, bearer, insecure)
    else:
        print(json.dumps({
            "event": "wifi-skip",
            "reason": "env_disabled",
        }))

    # lte
    if enable_lte:
        _run_lte_test(base, location_id,
                      token, bearer, insecure)
    else:
        print(json.dumps({
            "event": "lte-skip",
            "reason": "env_disabled",
        }))

    print(json.dumps({"event": "noc-api-tests-done"}))


# -------------------------------------------------
# main entrypoint for cycle_wrapper
# -------------------------------------------------
# -------------------------------------------------
# main entrypoint for cycle_wrapper
# -------------------------------------------------
def run() -> int:
    """
    entrypoint: ORIGINAL_ENTRY = main_impl_orig.py:run
    """
    # --- NOC 相關 ---
    base = _getenv("NOC_BASE", "https://piranha-int.tau.dev-charter.net")
    email = _getenv("NOC_EMAIL")
    password = _getenv("NOC_PASSWORD")
    bearer = _bool_env("BEARER", False)
    insecure = _bool_env("INSECURE", False)
    customer_id = _getenv("CUSTOMER_ID")

    if not email or not password:
        print(json.dumps({
            "event": "missing_credentials",
            "email": bool(email),
            "password": bool(password),
        }))
        return 2

    # --- CPE / Serial ---
    metrics_tool = _getenv("METRICS_TOOL", "/home/da40/charter/tools/cpe_metrics_agent_serial.py")
    dev = _getenv("CPE_DEV", "/dev/ttyUSB0")
    baud = int(_getenv("CPE_BAUD", "115200"))
    cpe_user = _getenv("CPE_USER", "root")
    cpe_password = _getenv("CPE_PASSWORD", "")
    if str(cpe_password).strip().lower() in ("none", "null", "nil"):
        cpe_password = ""

    cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
    if not cpe_password:
        cpe_password = _console_password(cpe_info_tool)
        print(json.dumps({"step": "console-password-fallback", "len": len(cpe_password)}))

    # --- SSH 動作 ---
    ssh_user = _getenv("SSH_USER", "operator")
    ssh_pass = _getenv("SSH_PASSWORD", "")
    ssh_timeout_min = int(_getenv("SSH_TIMEOUT_MIN", "120"))
    ssh_action = _getenv("SSH_ACTION", "enable").strip().lower()

    # SSH flow 開關（預設啟用）
    enable_ssh_flow = _bool_env("ENABLE_SSH_FLOW", True)

    if ssh_action not in ("enable", "disable", "both"):
        print(json.dumps({"event": "bad_ssh_action", "ssh_action": ssh_action}))
        return 1

    print(json.dumps({
        "event": "params",
        "base": base,
        "customer_id": customer_id,
        "ssh_action": ssh_action,
        "ssh_user": ssh_user,
        "enable_ssh_flow": enable_ssh_flow,
    }))

    try:
        # 1) login + node/location (cached like precondition)
        token, node_id, location_id = _ensure_noc_context(
            base, email, password, bearer, insecure,
            customer_id,
            metrics_tool, dev, baud, cpe_user, cpe_password,
        )

        # 2) NOC API 測試（內部再依 env 判斷 speedtest / wifi / lte）

        _run_noc_api_tests(base, customer_id, node_id, location_id,
                           token, bearer, insecure, ssh_pass, ssh_timeout_min)
        # 3) SSH enable / disable（可整個關掉）
        if enable_ssh_flow:
            if ssh_action in ("enable", "both"):
                _ssh_enable(base, customer_id, location_id, node_id,
                            ssh_pass, ssh_timeout_min, token, bearer, insecure)
            if ssh_action in ("disable", "both"):
                _ssh_disable(base, customer_id, location_id, node_id,
                             token, bearer, insecure)
        else:
            print(json.dumps({
                "event": "ssh-flow-skip",
                "reason": "env_disabled",
            }))

        return 0

    except Exception as e:
        print(json.dumps({"event": "exception", "error": str(e)}))
        return 1

if __name__ == "__main__":
    sys.exit(run())

# -------------------------------------------------
# C24532530: UPNP enable/disable long-run helpers
# -------------------------------------------------
def _run_upnp_longrun(
    base: str,
    customer_id: str,
    node_id: str,
    location_id: str,
    token: str,
    bearer: bool,
    insecure: bool,
    ssh_pass: str,
    ssh_timeout_min: int,
    iterations: int,
    apply_wait_sec: float,
    enable_ssh_flow: bool,
    mute_secs: int,
    mute_with_lock: bool,
) -> None:
    """C24532530: Enable/disable UPNP multiple times and verify CPE health.

    iterations:
      每次 run 要跑幾個 iteration。
      一次 iteration 會做：
        1. 將 UPNP 從 *目前狀態* 切成相反狀態（enable → disable 或 disable → enable）。
        2. 做一次 status 驗證 +（可選的）health 檢查。

    apply_wait_sec:
      每次切換後等待幾秒，讓設定生效再做檢查。
    """
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run UPNP tests")

    if iterations <= 0:
        print(json.dumps({
            "event": "upnp-tests-skip",
            "reason": "non_positive_iterations",
            "iterations": iterations,
        }))
        return

    enable_health = _bool_env("ENABLE_UPNP_HEALTH", True)
    print(json.dumps({
        "event": "upnp-health-config",
        "enable_health": enable_health,
    }))

    restore_baseline = _bool_env("UPNP_RESTORE_BASELINE", False)

    # 先讀 baseline（目前 UPNP 狀態），並做 normalize
    baseline = api.upnp_status(
        base,
        customer_id,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    baseline_mode = str(baseline.get("mode") or "").lower()
    baseline_enabled = bool(baseline.get("enabled"))
    # 如果 API 沒有回 mode，就依 enabled 推一個
    if not baseline_mode:
        baseline_mode = "enable" if baseline_enabled else "disable"
    baseline["mode"] = baseline_mode
    baseline["enabled"] = baseline_enabled

    print(json.dumps({
        "event": "upnp-baseline",
        "baseline": baseline,
    }))

    # 預期的「另一個」狀態（只做紀錄用，實際切換以 current_enabled 為主）
    if baseline_enabled:
        other_mode = "disable"
        other_enabled = False
    else:
        other_mode = "enable"
        other_enabled = True

    apply_wait = apply_wait_sec if apply_wait_sec > 0 else 0.0

    print(json.dumps({
        "event": "upnp-tests-start",
        "iterations": iterations,
        "apply_wait_sec": apply_wait,
        "baseline_mode": baseline_mode,
        "baseline_enabled": baseline_enabled,
        "other_mode": other_mode,
        "other_enabled": other_enabled,
        "restore_baseline": restore_baseline,
    }))

    # current_* 會隨著每次成功切換而更新，下一個 iteration 就會反向操作
    current_mode = baseline_mode
    current_enabled = baseline_enabled
    last_mute_until_ts = 0

    try:
        for i in range(1, iterations + 1):
            print(json.dumps({
                "event": "upnp-iteration-start",
                "iteration": i,
                "current_mode": current_mode,
                "current_enabled": current_enabled,
            }))

            # 根據「目前狀態」決定下一步要切成什麼
            if current_enabled:
                target_mode = "disable"
                target_enabled = False
            else:
                target_mode = "enable"
                target_enabled = True

            print(json.dumps({
                "event": "upnp-set-start",
                "iteration": i,
                "mode": target_mode,
                "enabled": target_enabled,
            }))

            # UPNP set 可能觸發 CPE reboot：在送 API 前先 mute console（每次 iteration 獨立 scope）
            cur_until_ts = 0
            if mute_secs > 0:
                cur_until_ts = int(_serial_mute_set(
                    secs=int(mute_secs),
                    use_lock=bool(mute_with_lock),
                    lock_timeout=5,
                    reason=f"upnp_iteration_{i}",
                ))
                last_mute_until_ts = cur_until_ts
                if cur_until_ts > 0:
                    print(json.dumps({
                        "step": "reboot-mute-console",
                        "iteration": i,
                        "mute_secs": int(mute_secs),
                        "until_ts": cur_until_ts,
                        "use_lock": bool(mute_with_lock),
                    }))
                else:
                    print(json.dumps({
                        "step": "reboot-mute-console-fail",
                        "iteration": i,
                        "mute_secs": int(mute_secs),
                        "use_lock": bool(mute_with_lock),
                        "error": "unable_to_set_mute",
                    }))

            resp = api.upnp_set(
                base,
                customer_id,
                location_id,
                enabled=target_enabled,
                mode=target_mode,
                token=token,
                bearer=bearer,
                insecure=insecure,
            )
            print(json.dumps({
                "event": "upnp-set-done",
                "iteration": i,
                "mode": target_mode,
                "enabled": target_enabled,
                "resp": resp,
            }))

            if apply_wait > 0:
                try:
                    print(json.dumps({
                        "event": "upnp-apply-wait",
                        "iteration": i,
                        "mode": target_mode,
                        "enabled": target_enabled,
                        "wait_sec": apply_wait,
                    }))
                except Exception:
                    pass
                time.sleep(apply_wait)

            # 讀回狀態確認
            st2 = api.upnp_status(
                base,
                customer_id,
                location_id,
                token=token,
                bearer=bearer,
                insecure=insecure,
            )
            actual_mode = str(st2.get("mode") or "").lower()
            actual_enabled = bool(st2.get("enabled"))
            print(json.dumps({
                "event": "upnp-status-after",
                "iteration": i,
                "expected_mode": target_mode,
                "expected_enabled": target_enabled,
                "status": st2,
            }))
            if actual_mode != target_mode or actual_enabled != target_enabled:
                raise RuntimeError(
                    f"UPNP state mismatch at iteration {i}: "
                    f"expected (mode={target_mode}, enabled={target_enabled}) "
                    f"got (mode={actual_mode}, enabled={actual_enabled})"
                )

            # UPNP 可能觸發 reboot / 影響 Internet：
            # - 先等 UPNP_REBOOT_WAIT_SEC（期間保留 mute）
            # - reboot window 結束後再解除 mute（只解除本次 iteration 設定的 until_ts）
            # - 再開始跑 cpe_info / ssh health
            _wait_internet_connected_status(unmute_expected_until_ts=int(cur_until_ts))

            # CPE health check（參考 speedtest 腳本的作法）
            if not enable_health:
                print(json.dumps({
                    "event": "upnp-health-skip",
                    "reason": "env_disabled",
                    "iteration": i,
                    "mode": target_mode,
                    "enabled": target_enabled,
                }))
            else:
                host = os.environ.get("CPE_HEALTH_HOST", "192.168.1.1")
                try:
                    port = int(os.environ.get("CPE_HEALTH_PORT", "22"))
                except Exception:
                    port = 22
                try:
                    ssh_port_timeout = float(os.environ.get("SSH_PORT_CHECK_TIMEOUT", "3"))
                except Exception:
                    ssh_port_timeout = 3.0

                ssh_open = False
                try:
                    with socket.create_connection((host, port), timeout=ssh_port_timeout):
                        ssh_open = True
                except Exception:
                    ssh_open = False

                print(json.dumps({
                    "event": "ssh-port-check",
                    "host": host,
                    "port": port,
                    "open": ssh_open,
                }))

                # 如果 SSH port 尚未打開且允許自動 enable，先呼叫 NOC API 開啟 SSH
                if not ssh_open and enable_ssh_flow:
                    _ssh_enable(
                        base,
                        customer_id,
                        location_id,
                        node_id,
                        ssh_pass,
                        ssh_timeout_min,
                        token,
                        bearer,
                        insecure,
                    )
                    # 簡單等待一下再給 health 使用
                    time.sleep(2.0)


                # Wait for SSH port; if it won't open, try enable SSH via NOC and retry once.
                try:
                    _wait_ssh_port_open(host, port)
                except Exception as e:
                    print(json.dumps({
                        "event": "ssh-port-wait-exception",
                        "host": host,
                        "port": port,
                        "error": str(e),
                    }))
                    if enable_ssh_flow and _bool_env("SSH_RECOVER_ON_FAIL", True):
                        _cloud_ssh_enable_with_relogin(
                            base=base,
                            customer_id=customer_id,
                            location_id=location_id,
                            node_id=node_id,
                            ssh_pass=ssh_pass,
                            ssh_timeout_min=ssh_timeout_min,
                            bearer=bearer,
                            insecure=insecure,
                            reason="ssh_port_wait_fail",
                        )
                        # retry wait once
                        _wait_ssh_port_open(host, port)
                    else:
                        raise

                # Run health; on timeout/failure, immediately re-enable SSH via NOC and retry once.
                health_timeout = int(_getenv("UPNP_HEALTH_TIMEOUT_SEC", "180"))
                health_ok = run_cpe_health_check(TOOLS_PATH, timeout=health_timeout)

                if (not health_ok) and enable_ssh_flow and _bool_env("SSH_RECOVER_ON_FAIL", True):
                    print(json.dumps({
                        "event": "upnp-health-recover",
                        "iteration": i,
                        "mode": target_mode,
                        "enabled": target_enabled,
                        "action": "cloud_ssh_enable_then_retry_health",
                    }))
                    _cloud_ssh_enable_with_relogin(
                        base=base,
                        customer_id=customer_id,
                        location_id=location_id,
                        node_id=node_id,
                        ssh_pass=ssh_pass,
                        ssh_timeout_min=ssh_timeout_min,
                        bearer=bearer,
                        insecure=insecure,
                        reason="health_fail_or_timeout",
                    )
                    # small wait then retry port+health once
                    try:
                        time.sleep(float(_getenv("SSH_RECOVER_WAIT_SEC", "2")))
                    except Exception:
                        time.sleep(2.0)
                    _wait_ssh_port_open(host, port)
                    health_ok = run_cpe_health_check(TOOLS_PATH, timeout=health_timeout)

                print(json.dumps({
                    "event": "upnp-health-result",
                    "iteration": i,
                    "mode": target_mode,
                    "enabled": target_enabled,
                    "health_ok": bool(health_ok),
                }))
                if not health_ok:
                    # Best-effort: keep SSH enabled for post-fail logpull.
                    if enable_ssh_flow and _bool_env("SSH_RECOVER_ON_FAIL", True):
                        _cloud_ssh_enable_with_relogin(
                            base=base,
                            customer_id=customer_id,
                            location_id=location_id,
                            node_id=node_id,
                            ssh_pass=ssh_pass,
                            ssh_timeout_min=ssh_timeout_min,
                            bearer=bearer,
                            insecure=insecure,
                            reason="final_fail_keep_ssh_enabled",
                        )
                        # optional grace period so external fail-hook can pull logs
                        try:
                            grace = float(_getenv("SSH_RECOVER_GRACE_SEC", "5"))
                        except Exception:
                            grace = 5.0
                        if grace > 0:
                            print(json.dumps({"event": "ssh-recover-grace", "sec": grace}))
                            time.sleep(grace)
                    raise RuntimeError(
                        f"CPE health check failed after UPNP change "
                        f"(iteration={i}, mode={target_mode}, enabled={target_enabled})"
                    )

            # 這次成功切換完成後，把 current_* 更新為新的狀態
            current_mode = target_mode
            current_enabled = target_enabled

            print(json.dumps({
                "event": "upnp-iteration-end",
                "iteration": i,
                "mode": current_mode,
                "enabled": current_enabled,
            }))

        print(json.dumps({
            "event": "upnp-tests-done",
        }))
    finally:
        # Safety: 任何例外都不要把 serial.mute 留在系統上（避免後續 DNS / node-id 被擋）
        if last_mute_until_ts:
            _serial_mute_clear_if_match(
                expected_until_ts=int(last_mute_until_ts),
                reason="upnp_longrun_finally",
            )
        else:
            _serial_mute_clear_stale(reason="upnp_longrun_finally")

        # 可選：測完後把 UPNP 還原成 baseline（預設關閉）
        if restore_baseline and (current_mode != baseline_mode or current_enabled != baseline_enabled):
            try:
                restore_until_ts = 0
                if mute_secs > 0:
                    restore_until_ts = int(_serial_mute_set(
                        secs=int(mute_secs),
                        use_lock=bool(mute_with_lock),
                        lock_timeout=5,
                        reason="upnp_restore",
                    ))
                    last_mute_until_ts = restore_until_ts
                    if restore_until_ts > 0:
                        print(json.dumps({
                            "step": "reboot-mute-console",
                            "iteration": "restore",
                            "mute_secs": int(mute_secs),
                            "until_ts": restore_until_ts,
                            "use_lock": bool(mute_with_lock),
                        }))

                restore_resp = api.upnp_set(
                    base,
                    customer_id,
                    location_id,
                    enabled=baseline_enabled,
                    mode=baseline_mode,
                    token=token,
                    bearer=bearer,
                    insecure=insecure,
                )
                if apply_wait > 0:
                    time.sleep(apply_wait)

                # 若 restore 也觸發 reboot，等待並在 reboot window 結束後解除 mute
                _wait_internet_connected_status(unmute_expected_until_ts=int(restore_until_ts))
                st3 = api.upnp_status(
                    base,
                    customer_id,
                    location_id,
                    token=token,
                    bearer=bearer,
                    insecure=insecure,
                )
                restore_ok = (
                    str(st3.get("mode") or "").lower() == baseline_mode
                    and bool(st3.get("enabled")) == baseline_enabled
                )
                print(json.dumps({
                    "event": "upnp-restore",
                    "ok": restore_ok,
                    "baseline": baseline,
                    "current": st3,
                    "resp": restore_resp,
                }))
            except Exception as e:
                print(json.dumps({
                    "event": "upnp-restore-error",
                    "error": str(e),
                }))

            # restore 結束後再保險一次清理（只清我們自己的 until_ts）
            if 'restore_until_ts' in locals() and int(locals().get('restore_until_ts') or 0) > 0:
                _serial_mute_clear_if_match(
                    expected_until_ts=int(locals().get('restore_until_ts') or 0),
                    reason="upnp_restore_finally",
                )
def run_upnp() -> int:
    """Entrypoint for C24532530_UPNP_enable_disable_longrun.

    ORIGINAL_ENTRY = main_impl_orig.py:run_upnp
    """
    # --- NOC 相關 ---
    base = _getenv("NOC_BASE", "https://piranha-int.tau.dev-charter.net")
    email = _getenv("NOC_EMAIL")
    password = _getenv("NOC_PASSWORD")
    bearer = _bool_env("BEARER", False)
    insecure = _bool_env("INSECURE", False)
    customer_id = _getenv("CUSTOMER_ID")

    if not email or not password:
        print(json.dumps({
            "event": "missing_credentials",
            "email": bool(email),
            "password": bool(password),
        }))
        return 2

    # --- CPE / Serial ---
    metrics_tool = _getenv("METRICS_TOOL", "/home/da40/charter/tools/cpe_metrics_agent_serial.py")
    dev = _getenv("CPE_DEV", "/dev/ttyUSB0")
    baud = int(_getenv("CPE_BAUD", "115200"))
    cpe_user = _getenv("CPE_USER", "root")
    cpe_password = _getenv("CPE_PASSWORD", "")
    if str(cpe_password).strip().lower() in ("none", "null", "nil"):
        cpe_password = ""

    cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
    if not cpe_password:
        cpe_password = _console_password(cpe_info_tool)
        print(json.dumps({
            "step": "console-password-fallback",
            "len": len(cpe_password),
        }))

    # --- SSH 動作 ---
    ssh_user = _getenv("SSH_USER", "operator")
    ssh_pass = _getenv("SSH_PASSWORD", "")
    ssh_timeout_min = int(_getenv("SSH_TIMEOUT_MIN", "120"))
    ssh_action = _getenv("SSH_ACTION", "enable").strip().lower()

    # SSH flow 開關（預設啟用）
    enable_ssh_flow = _bool_env("ENABLE_SSH_FLOW", True)

    if ssh_action not in ("enable", "disable", "both"):
        print(json.dumps({
            "event": "bad_ssh_action",
            "ssh_action": ssh_action,
        }))
        return 1

    # UPNP 專用 env
    try:
        upnp_iterations = int(_getenv("UPNP_ITERATIONS", "100"))
    except Exception:
        upnp_iterations = 100
    try:
        upnp_apply_wait_sec = float(_getenv("UPNP_APPLY_WAIT_SEC", "10"))
    except Exception:
        upnp_apply_wait_sec = 10.0
    mute_secs_str = _getenv("REBOOT_MUTE_SECS", "").strip()
    mute_with_lock = _bool_env("REBOOT_MUTE_WITH_LOCK", False)
    mute_secs = 0
    if mute_secs_str:
        try:
            mute_secs = int(mute_secs_str)
        except ValueError:
            print(json.dumps({
                "step": "reboot-mute-console",
                "event": "invalid_mute_secs",
                "mute_raw": mute_secs_str,
            }))


    print(json.dumps({
        "event": "params",
        "base": base,
        "customer_id": customer_id,
        "ssh_action": ssh_action,
        "ssh_user": ssh_user,
        "enable_ssh_flow": enable_ssh_flow,
        "upnp_iterations": upnp_iterations,
        "upnp_apply_wait_sec": upnp_apply_wait_sec,
        "upnp_mute_console_secs": mute_secs,
    }))

    # Precondition: clear stale/expired serial.mute (avoid node-id blocked)
    _serial_mute_clear_stale(reason="precondition")



    try:
        # 1) login + node/location (cached like precondition)
        token, node_id, location_id = _ensure_noc_context(
            base, email, password, bearer, insecure,
            customer_id,
            metrics_tool, dev, baud, cpe_user, cpe_password,
        )

        # 2) UPNP long-run 測試
        _run_upnp_longrun(
            base,
            customer_id,
            node_id,
            location_id,
            token,
            bearer,
            insecure,
            ssh_pass,
            ssh_timeout_min,
            upnp_iterations,
            upnp_apply_wait_sec,
            enable_ssh_flow,
            mute_secs,
            mute_with_lock,
        )

        return 0

    except Exception as e:
        print(json.dumps({
            "event": "exception",
            "error": str(e),
        }))
        return 1

    finally:
        # Postcondition: 保險清一次（即便中途例外），避免留下 active mute
        _serial_mute_clear_stale(reason="postcondition")