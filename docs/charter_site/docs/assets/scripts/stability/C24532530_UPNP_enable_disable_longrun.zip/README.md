# C24532530_UPNP_enable_disable_longrun

## 1) 目的 / 覆蓋範圍
- 驗證 UPnP enable/disable 狀態切換與 SSDP/IGD 行為。

## 2) 前置條件 / 環境
- LAN client 需可發 SSDP M-SEARCH（常用介面 `eno2`）。
- 若流程可能觸發 reboot：建議 serial mute + retry。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`stability`
- suite（manifest）：`sanity`（注意：與資料夾不同，建議後續統一）
- entrypoint：`cycle_wrapper.py:run`
- （manifest 未包含常見 env 或解析不到；可直接查看 zip 內 manifest.yaml）

## 5) PASS/FAIL 判定
- ON：SSDP/IGD discovery present=true。
- OFF：SSDP M-SEARCH present=false。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C24532530_UPNP_enable_disable_longrun

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`stability`
- suite（manifest）：`sanity`（注意：與資料夾不同，建議後續統一）
- entrypoint：`cycle_wrapper.py:run`

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C24532530_UPNP_enable_disable_longrun

## 目的 / Purpose

這支腳本用來做 **UPNP enable/disable long‑run 測試**，對應 test case：

- **PRD / Test case**：C24532530 – *Enable/disable UPNP multiple times*
- 目標：在多次切換 UPNP（enable / disable）過程中：
  - UPNP 狀態必須正確生效（NOC `upnp-status` 回傳與預期一致）。
  - CPE 不應出現 crash / panic（由 `cpe_ssh.py --cmd health` 判斷）。
  - 如果有 reboot，也要能正常回到線上，health 檢查為 GOOD。

## 高階流程

每次執行 `run_upnp()`（由 `cycle_wrapper.py` 呼叫）會做：

1. 讀取 NOC 帳號 (`NOC_EMAIL` / `NOC_PASSWORD`) 與 `NOC_BASE`。
2. 透過 `cpe_info --node-id` 取得 CPE 的 `node_id`。
3. 透過 NOC API 取得對應的 `location_id`。
4. 讀取目前 **baseline UPNP 狀態**（`upnp-status`）並記錄下來：
   - `baseline.mode`
   - `baseline.enabled`
5. 依照 `UPNP_ITERATIONS` 迴圈多次：
   - 將 UPNP 切到 **baseline 的反向狀態**（enable ↔ disable）。
   - 等待 `UPNP_APPLY_WAIT_SEC` 秒。
   - 再呼叫 `upnp-status` 驗證實際狀態是否符合預期。
   - 做一次 `CPE health`：
     - 呼叫 `cpe_ssh.py --cmd health`（透過 `run_cpe_health_check()`）。
     - 若 SSH port 關閉，會依照 `ENABLE_SSH_FLOW` 決定是否自動透過 NOC API `ssh-enable`。
   - 接著再把 UPNP 切回 **baseline 狀態**，同樣做一次 status 驗證 + health 檢查。
6. 迴圈完成後，透過 `upnp_set` + `upnp_status` **確認 UPNP 狀態已恢復成最一開始的 baseline**。
7. 任一階段出現：
   - UPNP 狀態與預期不符，或
   - health 檢查失敗（overall != GOOD / rc != 0）
   → 本次 run 視為 FAIL，`cycle_wrapper` 依 `STOP_ON_FAIL` 判斷是否停止後續 cycles。

## 檔案結構

這個 zip 內容與其他腳本一致：

- `cycle_wrapper.py`：通用的 cycle 控制器。
- `main_impl.py`：PBR-free wrapper，載入 `main_impl_orig.py` 並呼叫 `run_upnp()`。
- `main_impl_orig.py`：
  - 共用 helper：NOC login / node-id / location-id / SSH enable 等。
  - 新增 `_run_upnp_longrun()` + `run_upnp()`，實作 UPNP long‑run 流程。
- `cpe_health_helper.py`：封裝 `cpe_ssh.py --cmd health` 的呼叫與解析。
- `manifest.yaml`：
  - `name: C24532530_UPNP_enable_disable_longrun`
  - `entrypoint: cycle_wrapper.py:run`
  - `env.ORIGINAL_ENTRY: main_impl_orig.py:run_upnp`
  - 新增 `UPNP_ITERATIONS`, `UPNP_APPLY_WAIT_SEC` 等參數。
- `requirements.txt`：列出需要的 Python 套件（`requests`, `PyYAML`, `paramiko`…）。

## 執行方式（實機）

環境變數設定範例：

```bash
export NOC_BASE="https://piranha-int.tau.dev-charter.net"
export NOC_EMAIL="your_account@charter.com"
export NOC_PASSWORD=<REDACTED>
export CUSTOMER_ID="..."

export TOOLS_PATH="/home/da40/charter/tools"

# CPE / serial
export CPE_DEV="/dev/ttyUSB0"
export CPE_BAUD="115200"
export CPE_USER="root"
export CPE_PASSWORD=""   # 若留空會自動透過 cpe_info 取得

# SSH / health
export SSH_USER="operator"
export SSH_PASSWORD=<REDACTED>
export ENABLE_SSH_FLOW=1
export CPE_HEALTH_HOST="192.168.1.1"
export CPE_HEALTH_PORT="22"

# UPNP long-run 參數
export UPNP_ITERATIONS=100        # 要跑幾個 iteration
export UPNP_APPLY_WAIT_SEC=10     # 每次切換後的等待秒數

# cycle_wrapper 相關
export CYCLES=1
export CYCLE_INTERVAL=0
export STOP_ON_FAIL=1
```

執行：

```bash
python3 cycle_wrapper.py
```

```
