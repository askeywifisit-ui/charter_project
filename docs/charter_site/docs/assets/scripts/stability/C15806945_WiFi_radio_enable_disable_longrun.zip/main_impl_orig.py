#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
C001_SSH_api_test main implementation.

流程：
  1. 使用 NOC_EMAIL / NOC_PASSWORD login 取得 token
  2. 透過 serial (METRICS_TOOL) 取得 node_id
  3. 透過 NOC API 取得 location_id
  4. 跑一輪 NOC API 測試：
     - get-location 一致性確認
     - speedtest-run + speedtest-result (輪詢等待結果)
     - wifi-status / wifi-enable / wifi-disable（最後會還原）
     - lte-status
  5. 根據 SSH_ACTION (enable / disable / both) 做 ssh-enable / ssh-disable

依賴：
  - /home/da40/charter/tools/noc_api_cli.py (用 import noc_api_cli as api)
"""

import os
import sys
import json
import time
import subprocess
import socket
import re
from typing import Dict, Optional

import requests  # 用來抓 HTTPError status code
from cpe_health_helper import run_cpe_health_check_ex


# -------------------------------------------------
# 載入 tools 目錄底下的 noc_api_cli
# -------------------------------------------------
TOOLS_PATH = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
if TOOLS_PATH and TOOLS_PATH not in sys.path:
    sys.path.insert(0, TOOLS_PATH)

try:
    import noc_api_cli as api  # type: ignore
except Exception as e:  # 在 ChatGPT sandbox 會失敗，在實機應該 OK
    api = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "noc_api_cli", "error": str(e)}))

_CACHE: Dict[str, object] = {}

# -------------------------------------------------
# NOC profile loader (align with C00000001 style)
# -------------------------------------------------

def _load_noc_profile(profiles_file: str, profile_name: str) -> Optional[dict]:
    try:
        with open(profiles_file, 'r', encoding='utf-8') as f:
            j = json.load(f)
        if isinstance(j, dict):
            if profile_name in j and isinstance(j.get(profile_name), dict):
                return j.get(profile_name)
            pj = j.get('profiles')
            if isinstance(pj, dict) and profile_name in pj and isinstance(pj.get(profile_name), dict):
                return pj.get(profile_name)
    except Exception as e:
        print(json.dumps({"event": "noc_profile_error", "profile": profile_name, "file": profiles_file, "error": str(e)}))
    return None


def _resolve_noc_settings() -> tuple[str, str, str, bool, bool, str]:
    """Resolve NOC settings from (1) NOC_PROFILE/PROFILES_FILE, then env fallbacks.

    Compatible with noc_api_cli.py defaults:
      - DEFAULT_BASE reads env BASE (or fallback URL)
      - DEFAULT_CUSTOMER_ID reads env CUSTOMER_ID (or fallback customer id)

    Returns: (base, email, password, bearer, insecure, customer_id)
    """
    # Defaults from env / noc_api_cli
    default_base = _getenv('NOC_BASE', '') or _getenv('BASE', '')
    if not default_base:
        default_base = getattr(api, 'DEFAULT_BASE', 'https://piranha-int.tau.dev-charter.net') if api is not None else 'https://piranha-int.tau.dev-charter.net'

    default_customer_id = _getenv('CUSTOMER_ID', '') or _getenv('NOC_CUSTOMER_ID', '')
    if not default_customer_id:
        default_customer_id = getattr(api, 'DEFAULT_CUSTOMER_ID', '') if api is not None else ''

    base = default_base
    email = _getenv('NOC_EMAIL', '')
    password = _getenv('NOC_PASSWORD', '')
    bearer = _bool_env('BEARER', False)
    insecure = _bool_env('INSECURE', False)
    customer_id = default_customer_id

    profile_name = _getenv('NOC_PROFILE', '').strip()
    profiles_file = _getenv('PROFILES_FILE', '').strip()
    if profile_name and profiles_file:
        prof = _load_noc_profile(profiles_file, profile_name)
        if isinstance(prof, dict):
            base = str(prof.get('base') or prof.get('NOC_BASE') or base)
            customer_id = str(
                prof.get('customer_id') or prof.get('customerId') or prof.get('NOC_CUSTOMER_ID') or customer_id
            )
            email = str(prof.get('email') or prof.get('NOC_EMAIL') or email)
            password = str(prof.get('password') or prof.get('NOC_PASSWORD') or password)
            # allow profile override
            try:
                bearer = bool(prof.get('bearer')) if 'bearer' in prof else bearer
            except Exception:
                pass
            try:
                insecure = bool(prof.get('insecure')) if 'insecure' in prof else insecure
            except Exception:
                pass
            print(json.dumps({
                "event": "noc_profile_loaded",
                "profile": profile_name,
                "base": base,
                "has_customer_id": bool(customer_id),
                "has_email": bool(email),
                "bearer": bearer,
                "insecure": insecure,
            }))

    return base, email, password, bearer, insecure, customer_id


# -------------------------------------------------
# 小工具
# -------------------------------------------------
def _getenv(name: str, default: str = "") -> str:
    v = os.environ.get(name)
    return default if v is None else str(v)


def _bool_env(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return str(v).strip().lower() in ("1", "true", "yes", "y")


def _tcp_open(host: str, port: int = 22, timeout: float = 3.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except Exception:
        return False


def _wait_port_open(host: str, port: int = 22, *, total_wait_sec: int = 30, interval_sec: float = 2.0, timeout_each: float = 3.0) -> bool:
    t0 = time.time()
    while time.time() - t0 < float(total_wait_sec):
        if _tcp_open(host, port, timeout_each):
            return True
        time.sleep(interval_sec)
    return False



def _cpe_ssh_json(tools_path: str, *, host: str, cmd_name: str, extra: Optional[list] = None, timeout_sec: int = 30) -> Dict[str, object]:
    """Run tools/cpe_ssh.py.

    Most commands print JSON, but some (notably `uptime`) print a short plain-text
    string on success. This helper returns a dict in all cases:
      - If stdout is valid JSON dict -> return that dict (plus rc/stderr_tail)
      - Otherwise -> return {ok, rc, raw, stdout_tail, stderr_tail}
    """
    cpe_ssh = os.environ.get("CPE_SSH_TOOL") or os.path.join(tools_path, "cpe_ssh.py")
    cmd = ["python3", cpe_ssh, "--host", host, "--cmd", cmd_name, "--timeout", str(timeout_sec)]
    if extra:
        cmd += list(extra)
    print(json.dumps({"event": "cpe_ssh_start", "cmd": cmd_name, "argv": cmd}))
    try:
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout_sec + 15)
    except Exception as e:
        return {"ok": False, "cmd": cmd_name, "error": str(e)}
    out = (proc.stdout or "").strip()
    err = (proc.stderr or "").strip()

    # Try JSON first
    data: object
    try:
        data = json.loads(out) if out else {}
    except Exception:
        data = None

    # Non-JSON success path (e.g. uptime prints "27 min")
    if not isinstance(data, dict):
        return {
            "ok": (proc.returncode == 0),
            "cmd": cmd_name,
            "rc": proc.returncode,
            "raw": out or "",
            "stdout_tail": (out or "")[-300:],
            "stderr_tail": (err or "")[-300:],
        }

    # Normalize JSON dict
    d = data
    d.setdefault("ok", proc.returncode == 0)
    d.setdefault("cmd", cmd_name)
    d.setdefault("rc", proc.returncode)
    # Always keep a raw tail for troubleshooting (without flooding logs)
    if out and "_stdout_tail" not in d and "stdout_tail" not in d:
        d.setdefault("stdout_tail", out[-300:])
    if err:
        d.setdefault("stderr_tail", err[-300:])
    return d


def _attempt_pull_log(tools_path: str, *, host: str, node_id: str, logpull_timeout: int = 240, attempts: int = 3, sleep_sec: int = 10) -> bool:
    """Best-effort pull-log with retry. Returns True if any attempt succeeds."""
    cpe_ssh = os.environ.get("CPE_SSH_TOOL") or os.path.join(tools_path, "cpe_ssh.py")
    for i in range(1, attempts + 1):
        cmd = [
            "python3", cpe_ssh,
            "--host", host,
            "--cmd", "pull-log",
            "--pre-logpull",
            "--logpull-timeout", str(logpull_timeout),
            "--rename-with-node-id",
        ]
        print(json.dumps({"event": "logpull_start", "attempt": i, "cmd": " ".join(cmd)}))
        try:
            proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=logpull_timeout + 30)
            ok = (proc.returncode == 0)
        except Exception as e:
            ok = False
            proc = None  # type: ignore
            print(json.dumps({"event": "logpull_exception", "attempt": i, "error": str(e)}))

        if proc is not None:
            out = (proc.stdout or "").strip()
            err = (proc.stderr or "").strip()
            print(json.dumps({
                "event": "logpull_end",
                "attempt": i,
                "ok": ok,
                "rc": proc.returncode,
                "stdout_tail": out[-400:],
                "stderr_tail": err[-400:],
            }))

        if ok:
            return True
        if i < attempts and sleep_sec > 0:
            time.sleep(float(sleep_sec))
    return False


def _parse_uptime_seconds(text: str) -> Optional[int]:
    """Parse uptime into seconds.

    Supported inputs:
      - cpe_ssh.py --cmd uptime success output: "27 min", "13:38", "2 hrs 3 min", "1 day"
      - full Linux uptime output (meta["raw"]): " 11:23:01 up 1 day,  3:22,  2 users,  load average: ..."
      - JSON meta printed by cpe_ssh.py on failure: {"raw": "...", "uptime": null, ...}

    Returns seconds, or None if cannot parse.
    """

    s = " ".join((text or "").replace("\t", " ").split())
    if not s:
        return None

    # If caller accidentally passed JSON text, try extract "raw" / "uptime"
    if s.startswith("{") and s.endswith("}"):
        try:
            j = json.loads(s)
            if isinstance(j, dict):
                s = " ".join(str(j.get("uptime") or j.get("raw") or "").split())
        except Exception:
            pass

    # 1) Full `uptime` output: extract the "up ..." segment
    up_seg = None
    if " up " in f" {s} " or s.startswith("up "):
        m = re.search(r"\bup\s+(.+?)(?:,\s+\d+\s+user|\s+users\b|,\s+load average:)", s)
        if not m:
            m = re.search(r"\bup\s+(.+?),\s+load average:", s)
        if m:
            up_seg = m.group(1).strip()

    # If we found up segment, parse that; else parse the whole string (short form)
    target = up_seg or s
    target = target.strip().lstrip("up ").strip()

    # Normalize commas to spaces
    target = target.replace(",", " ")
    target = " ".join(target.split())
    if not target:
        return None

    total = 0

    # days / weeks
    m = re.search(r"(\d+)\s*(?:weeks?|w)\b", target, re.IGNORECASE)
    if m:
        total += int(m.group(1)) * 7 * 86400
        target = re.sub(r"\b\d+\s*(?:weeks?|w)\b", " ", target, flags=re.IGNORECASE)
    m = re.search(r"(\d+)\s*(?:days?|d)\b", target, re.IGNORECASE)
    if m:
        total += int(m.group(1)) * 86400
        target = re.sub(r"\b\d+\s*(?:days?|d)\b", " ", target, flags=re.IGNORECASE)

    target = " ".join(target.split())

    # HH:MM or H:MM (common after "up")
    m = re.search(r"\b(\d+):(\d{2})\b", target)
    if m:
        total += int(m.group(1)) * 3600 + int(m.group(2)) * 60
        target = re.sub(r"\b\d+:\d{2}\b", " ", target)

    # hours / minutes / seconds tokens (order-agnostic)
    m = re.search(r"(\d+)\s*(?:hrs?|hours?|h)\b", target, re.IGNORECASE)
    if m:
        total += int(m.group(1)) * 3600
    m = re.search(r"(\d+)\s*(?:mins?|minutes?|m)\b", target, re.IGNORECASE)
    if m:
        total += int(m.group(1)) * 60
    m = re.search(r"(\d+)\s*(?:secs?|seconds?|s)\b", target, re.IGNORECASE)
    if m:
        total += int(m.group(1))

    return int(total) if total > 0 else None


def _run_cpe_ssh_json(tools_path: str, args: list[str], *, timeout: int = 60) -> Dict[str, object]:
    """Run cpe_ssh.py with given argv (excluding python/cpe_ssh.py) and parse JSON stdout."""
    cpe_ssh = os.environ.get("CPE_SSH_TOOL") or os.path.join(tools_path, "cpe_ssh.py")
    cmd = ["python3", cpe_ssh] + args
    print(json.dumps({"event": "cpe_ssh_cmd", "argv": cmd}))
    try:
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return {"ok": False, "reason": "timeout", "timeout": timeout}
    out = (p.stdout or "").strip()
    err = (p.stderr or "").strip()
    try:
        data = json.loads(out) if out else {}
    except Exception:
        # Some cpe_ssh.py commands (e.g. uptime) print plain text on success.
        data = {"ok": (p.returncode == 0), "raw": out}
    if not isinstance(data, dict):
        data = {"ok": (p.returncode == 0), "raw": out}
    # Keep tails for debug without huge logs
    data.update({
        "_rc": p.returncode,
        "_stdout_tail": out[-400:],
        "_stderr_tail": err[-400:],
    })
    return data


def _uptime_probe(tools_path: str, host: str, *, timeout: int = 20) -> Dict[str, object]:
    data = _run_cpe_ssh_json(tools_path, ["--host", host, "--cmd", "uptime", "--timeout", str(timeout)], timeout=timeout + 10)
    raw = str(data.get("raw") or "")
    sec = _parse_uptime_seconds(raw)
    data["uptime_sec"] = sec
    return data


def _logpull_probe(tools_path: str, host: str, *, timeout_sec: int = 240) -> Dict[str, object]:
    args = [
        "--host", host,
        "--cmd", "pull-log",
        "--pre-logpull",
        "--logpull-timeout", str(timeout_sec),
        "--rename-with-node-id",
    ]
    return _run_cpe_ssh_json(tools_path, args, timeout=timeout_sec + 30)


# -------------------------------------------------
# login / node / location
# -------------------------------------------------
def _login(base: str, email: str, password: str, bearer: bool, insecure: bool) -> str:
    if "token" in _CACHE:
        return _CACHE["token"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot login to NOC")

    tok = api.login(base, email, password, bearer=bearer, insecure=insecure)
    _CACHE["token"] = tok
    print(json.dumps({"step": "login", "ok": True}))
    return tok


def _node_id(metrics_tool: str, dev: str, baud: int, user: str, password: str) -> str:
    """Get node-id.

    Preferred backend: cpe_info --node-id (no serial dependency)
    Fallback: metrics_tool via serial (kept for compatibility)
    """
    if "node_id" in _CACHE:
        return _CACHE["node_id"]  # type: ignore[return-value]

    # 0) Prefer cpe_info --node-id
    cpe_info_tool = os.environ.get("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
    try:
        proc = subprocess.run(
            [cpe_info_tool, "--node-id"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=15,
        )
        out = (proc.stdout or "").strip()
        print(json.dumps({
            "step": "node-id-cpe_info-raw",
            "rc": proc.returncode,
            "out": out,
        }))
        if proc.returncode == 0:
            m = re.search(r"([0-9a-fA-F]{12})", out)
            if m:
                node_id = m.group(1).lower()
                _CACHE["node_id"] = node_id
                print(json.dumps({"step": "node-id", "backend": "cpe_info", "node_id": node_id}))
                return node_id
        print(json.dumps({
            "step": "node-id-cpe_info-failed",
            "reason": "no_match_or_nonzero_rc",
        }))
    except Exception as e:
        print(json.dumps({
            "step": "node-id-cpe_info-exception",
            "error": str(e),
        }))

    # 1) Fallback: serial metrics tool
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot parse node-id")

    # 允許因為 console lock 等情況多重嘗試取得 node-id
    try:
        max_retries = int(os.environ.get("NODE_ID_MAX_RETRIES", "3"))
    except Exception:
        max_retries = 3
    try:
        retry_interval = float(os.environ.get("NODE_ID_RETRY_INTERVAL_SEC", "2"))
    except Exception:
        retry_interval = 2.0

    last_error: Optional[Exception] = None

    # sanitize password like 'null   # comment'
    pw = (password or "").strip()
    if re.match(r"^(none|null|nil)\b", pw, re.IGNORECASE):
        pw = ""

    for attempt in range(1, max_retries + 1):
        cmd = [
            metrics_tool,
            "--device",
            dev,
            "--baud",
            str(baud),
            "--user",
            user,
            "--cmd",
            "node-id",
        ]
        if pw:
            cmd += ["--password", pw]

        print(json.dumps({
            "step": "node-id-cmd",
            "attempt": attempt,
            "max_retries": max_retries,
            "cmd": cmd,
        }))

        try:
            proc = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=60,
            )
        except Exception as e:
            last_error = e
            print(json.dumps({
                "step": "node-id-run-exception",
                "attempt": attempt,
                "error": str(e),
            }))
        else:
            out = (proc.stdout or "").strip()
            print(json.dumps({
                "step": "node-id-raw",
                "attempt": attempt,
                "out": out,
                "rc": proc.returncode,
            }))

            if proc.returncode != 0:
                msg = f"metrics_tool node-id failed rc={proc.returncode}"
                last_error = RuntimeError(msg)
                print(json.dumps({
                    "step": "node-id-attempt-failed",
                    "attempt": attempt,
                    "error": msg,
                }))
            else:
                try:
                    node_id = api.parse_node_id_from_text(out)
                except Exception as e:
                    last_error = e
                    print(json.dumps({
                        "step": "node-id-parse-error",
                        "attempt": attempt,
                        "error": str(e),
                    }))
                else:
                    _CACHE["node_id"] = node_id
                    print(json.dumps({
                        "step": "node-id",
                        "backend": "serial",
                        "attempt": attempt,
                        "node_id": node_id,
                    }))
                    return node_id

        if attempt < max_retries:
            print(json.dumps({
                "step": "node-id-retry",
                "attempt": attempt,
                "next_wait_sec": retry_interval,
            }))
            time.sleep(retry_interval)

    if last_error is not None:
        raise last_error
    raise RuntimeError("node-id not found in serial output after retries")

def _location_id(base: str, customer_id: str, node_id: str,
                 token: str, bearer: bool, insecure: bool) -> str:
    if "location_id" in _CACHE:
        return _CACHE["location_id"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot query location_id")

    loc = api.get_location_id(base, customer_id, node_id,
                              token=token, bearer=bearer, insecure=insecure)
    _CACHE["location_id"] = loc
    print(json.dumps({"step": "location-id", "location_id": loc}))
    return loc


# -------------------------------------------------
# CPE console password fallback
# -------------------------------------------------
def _console_password(cpe_info_tool: str) -> str:
    """
    若 CPE_PASSWORD 未設定或為 null，嘗試透過 cpe_info 撈 console 密碼。
    """
    try:
        proc = subprocess.run(
            [cpe_info_tool, "--password"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=15,
        )
        out = (proc.stdout or "").strip()
        for line in out.splitlines():
            line = line.strip()
            if line:
                return line
    except Exception:
        pass
    return ""


# -------------------------------------------------
# SSH enable / disable
# -------------------------------------------------
def _ssh_enable(base: str, customer_id: str, location_id: str, node_id: str,
                ssh_pass: str, timeout_min: int,
                token: str, bearer: bool, insecure: bool) -> None:
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot enable SSH")

    resp = api.ssh_enable(
        base,
        customer_id,
        location_id,
        node_id,
        ssh_pass,
        timeout_min,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({"step": "ssh-enable", "resp": resp}))


def _ssh_disable(base: str, customer_id: str, location_id: str, node_id: str,
                 token: str, bearer: bool, insecure: bool) -> None:
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot disable SSH")

    resp = api.ssh_disable(
        base,
        customer_id,
        location_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({"step": "ssh-disable", "resp": resp}))


# -------------------------------------------------
# NOC API 測試 helpers
# -------------------------------------------------
def _run_speedtest_tests(base: str, customer_id: str, location_id: str, node_id: str,
                         token: str, bearer: bool, insecure: bool) -> None:
    """
    SpeedTest 測試流程：

      1) POST /speedTest 觸發一次測速 → 拿到 requestId
      2) 先等 SPEEDTEST_WAIT_SEC 秒（預設 60）
      3) 最多重試 SPEEDTEST_MAX_TRIES 次，每次間隔 SPEEDTEST_INTERVAL_SEC 秒
         呼叫 GET /speedTestResults/{requestId} 查單筆結果

    三個參數都用 env 控制：
      SPEEDTEST_WAIT_SEC
      SPEEDTEST_MAX_TRIES
      SPEEDTEST_INTERVAL_SEC
    """
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run speedtest tests")

    # 1) 觸發一次 speed test
    resp_run = api.speedtest_run(
        base,
        customer_id,
        location_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )

    request_id: Optional[str] = None
    if isinstance(resp_run, dict):
        request_id = (
            resp_run.get("requestId")
            or resp_run.get("request_id")
            or resp_run.get("id")
        )

    print(json.dumps({
        "step": "speedtest-run",
        "resp": resp_run,
        "request_id": request_id,
    }))

    if not request_id:
        raise RuntimeError("speedtest-run did not return requestId")

    # 2) 先等一段時間再開始查結果
    wait_sec = int(_getenv("SPEEDTEST_WAIT_SEC", "60"))
    print(json.dumps({
        "step": "speedtest-wait",
        "request_id": request_id,
        "seconds": wait_sec,
    }))
    time.sleep(wait_sec)

    # 3) 開始少量輪詢
    max_tries = int(_getenv("SPEEDTEST_MAX_TRIES", "3"))
    interval_sec = int(_getenv("SPEEDTEST_INTERVAL_SEC", "10"))

    last_error: Optional[str] = None
    resp_one: Optional[object] = None

    for attempt in range(1, max_tries + 1):
        try:
            resp_one = api.speedtest_result_by_id(
                base,
                customer_id,
                location_id,
                node_id,
                request_id,
                token=token,
                bearer=bearer,
                insecure=insecure,
            )
            # 呼叫成功（沒有丟 HTTPError）
            print(json.dumps({
                "step": "speedtest-result",
                "attempt": attempt,
                "request_id": request_id,
                "resp": resp_one,
            }))
            break

        except requests.HTTPError as e:
            status = e.response.status_code if e.response is not None else None
            body = e.response.text[:200] if e.response is not None else ""
            last_error = f"HTTP {status}: {body}"

            print(json.dumps({
                "step": "speedtest-result-retry",
                "attempt": attempt,
                "request_id": request_id,
                "status": status,
                "error": last_error,
            }))

            # 如果還有下一次機會，且是 400/404，就睡 interval_sec 秒再試
            if attempt < max_tries and status in (400, 404):
                time.sleep(interval_sec)
                continue

            # 其他情況（沒下一次或不是 400/404），直接丟出去
            raise

    if resp_one is None:
        # 全部嘗試完還失敗，就讓整個腳本 FAIL
        raise RuntimeError(f"speedtest-result failed after {max_tries} tries: {last_error}")


def _wifi_enabled_flag(status: object) -> Optional[bool]:
    """從 wifi-status 回傳的 JSON 抽出 enabled 狀態."""
    if isinstance(status, dict):
        # 1) 先看頂層有沒有 enabled
        if "enabled" in status:
            return bool(status.get("enabled"))

        # 2) 再看 wifiNetwork.enabled
        wn = status.get("wifiNetwork")
        if isinstance(wn, dict) and "enabled" in wn:
            return bool(wn.get("enabled"))

        # 3) 如果是 wifiNetworks 陣列，也處理一下（預留擴充）
        wns = status.get("wifiNetworks")
        if isinstance(wns, list) and wns and isinstance(wns[0], dict) and "enabled" in wns[0]:
            return bool(wns[0].get("enabled"))

    return None


def _run_wifi_tests(base: str, customer_id: str, location_id: str,
                    token: str, bearer: bool, insecure: bool) -> None:
    """wifi-status / wifi-enable / wifi-disable 功能測試，最後會盡量恢復原本狀態。

    這裡把重點步驟標示成三步：
      step 1: disable / enable WiFi（反轉目前狀態一次）
      step 2: restore WiFi（切回原本狀態）
      step 3: check no crash（先當 placeholder，實際判斷用 ok 欄位即可）
    """
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run wifi tests")

    # 先查目前狀態
    status_before = api.wifi_status(
        base,
        customer_id,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    enabled_before = _wifi_enabled_flag(status_before)
    print(json.dumps({
        "step": "wifi-status-before",
        "enabled": enabled_before,
        "resp": status_before,
    }))

    # 目標狀態：如果原本有值，就反轉；如果拿不到原始值，就先嘗試 enable 一次
    target_state = not bool(enabled_before) if enabled_before is not None else True
    action1 = "disable" if target_state is False else "enable"

    # step 1: 切換一次（disable 或 enable）
    resp_toggle = api.wifi_set_enabled(
        base,
        customer_id,
        location_id,
        target_state,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    status_mid = api.wifi_status(
        base,
        customer_id,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    enabled_mid = _wifi_enabled_flag(status_mid)
    print(json.dumps({
        "step": "wifi-step-1-toggle",
        "action": action1,
        "target": target_state,
        "enabled_mid": enabled_mid,
        "resp_toggle": resp_toggle,
        "status_mid": status_mid,
    }))

    # Optional hold time between toggle and restore (align with C6376350)
    hold_sec = int(os.environ.get("WIFI_TOGGLE_HOLD_SEC", "0"))
    if hold_sec > 0:
        print(json.dumps({
            "step": "wifi-wait-before-restore",
            "sec": hold_sec,
        }))
        time.sleep(hold_sec)

    # step 2 + step 3: 盡量恢復原本狀態，並檢查沒有 crash
    if enabled_before is not None and enabled_before != enabled_mid:
        resp_restore = api.wifi_set_enabled(
            base,
            customer_id,
            location_id,
            enabled_before,
            token=token,
            bearer=bearer,
            insecure=insecure,
        )
        status_after = api.wifi_status(
            base,
            customer_id,
            location_id,
            token=token,
            bearer=bearer,
            insecure=insecure,
        )
        enabled_after = _wifi_enabled_flag(status_after)
        ok = (enabled_after == enabled_before)
        action2 = "enable" if enabled_before else "disable"
        print(json.dumps({
            "step": "wifi-step-2-restore",
            "action": action2,
            "enabled_before": enabled_before,
            "enabled_after": enabled_after,
            "ok": ok,
            "resp_restore": resp_restore,
            "status_after": status_after,
        }))
        # step 3: check no crash（placeholder，實際上 ok==True 代表沒問題）
        print(json.dumps({
            "step": "wifi-step-3-check-no-crash",
            "ok": ok,
            "note": "placeholder; treat ok==True as no-crash",
        }))
        if not ok:
            raise RuntimeError("wifi enabled state mismatch after restore")
def _run_lte_test(base: str, location_id: str,
                  token: str, bearer: bool, insecure: bool) -> None:
    """lte-status 測試（僅查詢）。"""
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run LTE tests")

    resp = api.lte_status(
        base,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({
        "step": "lte-status",
        "resp": resp,
    }))


def _run_get_location_test(base: str, customer_id: str, node_id: str,
                           location_id: str,
                           token: str, bearer: bool, insecure: bool) -> None:
    """get-location 功能測試，確認回傳的 locationId 與前面取得的一致。"""
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run get-location test")

    loc2 = api.get_location_id(
        base,
        customer_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    ok = (loc2 == location_id)
    print(json.dumps({
        "step": "get-location-check",
        "location_id": location_id,
        "location_id_refetched": loc2,
        "ok": ok,
    }))
    if not ok:
        raise RuntimeError("location_id from get_location_id() mismatch")



# -------------------------------------------------
# Internet connectivity pre-check using cpe_info --internet
# -------------------------------------------------
def _wait_internet_connected() -> None:
    """在執行 speedtest 之前，透過 cpe_info --internet 確認 Internet Status: Connected。

    預設會重試 10 次，每次間隔 3 秒，可由環境變數覆蓋：
      INTERNET_CHECK_MAX_RETRIES
      INTERNET_CHECK_INTERVAL_SEC
    """
    cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")

    try:
        max_retries = int(_getenv("INTERNET_CHECK_MAX_RETRIES", "10"))
    except Exception:
        max_retries = 10

    try:
        interval_sec = float(_getenv("INTERNET_CHECK_INTERVAL_SEC", "3"))
    except Exception:
        interval_sec = 3.0

    last_output = ""

    for attempt in range(1, max_retries + 1):
        cmd = [cpe_info_tool, "--internet"]
        print(json.dumps({
            "step": "internet-check",
            "attempt": attempt,
            "max_retries": max_retries,
            "cmd": cmd,
        }))

        try:
            proc = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=30,
            )
            out = (proc.stdout or "").strip()
            last_output = out
        except Exception as e:
            print(json.dumps({
                "step": "internet-check-exception",
                "attempt": attempt,
                "error": str(e),
            }))
        else:
            print(json.dumps({
                "step": "internet-check-raw",
                "attempt": attempt,
                "rc": proc.returncode,
                "out": out,
            }))
            # 成功條件：rc == 0 且輸出中有 "Internet Status: Connected"
            if proc.returncode == 0 and "Internet Status: Connected" in out:
                print(json.dumps({
                    "step": "internet-check-ok",
                    "attempt": attempt,
                }))
                return

        # 還沒成功就睡一下再試
        if attempt < max_retries:
            time.sleep(interval_sec)

    # 全部重試完還是沒 Connected → 當成 precondition fail
    print(json.dumps({
        "step": "internet-check-failed",
        "max_retries": max_retries,
        "last_output": last_output[-200:],
    }))
    raise RuntimeError(
        f"internet not connected after {max_retries} checks via cpe_info --internet"
    )


def _run_noc_api_tests(base: str, customer_id: str, node_id: str, location_id: str,
                       token: str, bearer: bool, insecure: bool) -> None:
    """
    統一執行 NOC API 測試，並可透過環境變數決定是否啟用各項測試：

      ENABLE_SPEEDTEST  (預設 1)
      ENABLE_WIFI_TEST  (預設 1)
      ENABLE_LTE_TEST   (預設 1)
    """
    # 讀 env 開關
    enable_speedtest = _bool_env("ENABLE_SPEEDTEST", True)
    enable_wifi = _bool_env("ENABLE_WIFI_TEST", True)
    enable_lte = _bool_env("ENABLE_LTE_TEST", True)

    print(json.dumps({
        "event": "noc-api-tests-start",
        "enable_speedtest": enable_speedtest,
        "enable_wifi": enable_wifi,
        "enable_lte": enable_lte,
    }))

    # 一律先做 get-location 一致性檢查
    # WiFi long-run：只在第一次執行時檢查，後續 cycles 直接略過，避免因 NOC 偶發 timeout 中斷測試
    if not _CACHE.get("location_checked"):
        _run_get_location_test(base, customer_id, node_id, location_id,
                               token, bearer, insecure)
        _CACHE["location_checked"] = True
    else:
        print(json.dumps({
            "event": "get-location-skip",
            "reason": "already_checked",
        }))

    # speedtest
    if enable_speedtest:
        _wait_internet_connected()
        _run_speedtest_tests(base, customer_id, location_id, node_id,
                             token, bearer, insecure)
    else:
        print(json.dumps({
            "event": "speedtest-skip",
            "reason": "env_disabled",
        }))

    # wifi
    if enable_wifi:
        _run_wifi_tests(base, customer_id, location_id,
                        token, bearer, insecure)
    else:
        print(json.dumps({
            "event": "wifi-skip",
            "reason": "env_disabled",
        }))

    # lte
    if enable_lte:
        _run_lte_test(base, location_id,
                      token, bearer, insecure)
    else:
        print(json.dumps({
            "event": "lte-skip",
            "reason": "env_disabled",
        }))

    print(json.dumps({"event": "noc-api-tests-done"}))


# -------------------------------------------------
# main entrypoint for cycle_wrapper
# -------------------------------------------------
# -------------------------------------------------
# main entrypoint for cycle_wrapper
# -------------------------------------------------
def run() -> int:
    """
    entrypoint: ORIGINAL_ENTRY = main_impl_orig.py:run
    """
    # --- NOC 相關 ---
    base, email, password, bearer, insecure, customer_id = _resolve_noc_settings()

    if not email or not password:
        print(json.dumps({
            "event": "missing_credentials",
            "email": bool(email),
            "password": bool(password),
        }))
        return 2

    # --- CPE / Serial ---
    metrics_tool = _getenv("METRICS_TOOL", "/home/da40/charter/tools/cpe_metrics_agent_serial.py")
    dev = _getenv("CPE_DEV", "/dev/ttyUSB0")
    baud = int(_getenv("CPE_BAUD", "115200"))
    cpe_user = _getenv("CPE_USER", "root")
    cpe_password = _getenv("CPE_PASSWORD", "")
    # treat values like 'null', 'null # comment', 'none', 'nil' as empty to trigger cpe_info fallback
    try:
        _pw_raw = str(cpe_password).strip()
    except Exception:
        _pw_raw = ''
    if re.match(r"^(none|null|nil)\b", _pw_raw, re.IGNORECASE):
        cpe_password = ""

    cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
    if not cpe_password:
        cpe_password = _console_password(cpe_info_tool)
    # --- SSH 動作 ---
    ssh_user = _getenv("SSH_USER", "operator")
    ssh_pass = _getenv("SSH_PASSWORD", "")
    ssh_timeout_min = int(_getenv("SSH_TIMEOUT_MIN", "120"))
    ssh_action = _getenv("SSH_ACTION", "enable").strip().lower()

    # SSH flow 開關（預設啟用）
    enable_ssh_flow = _bool_env("ENABLE_SSH_FLOW", True)

    if ssh_action not in ("enable", "disable", "both"):
        print(json.dumps({"event": "bad_ssh_action", "ssh_action": ssh_action}))
        return 1

    print(json.dumps({
        "event": "params",
        "base": base,
        "customer_id": customer_id,
        "ssh_action": ssh_action,
        "ssh_user": ssh_user,
        "enable_ssh_flow": enable_ssh_flow,
    }))

    try:
        # 1) login + node/location
        token = _login(base, email, password, bearer, insecure)
        node_id = _node_id(metrics_tool, dev, baud, cpe_user, cpe_password)
        location_id = _location_id(base, customer_id, node_id, token, bearer, insecure)

        # 2) NOC API 測試（內部再依 env 判斷 speedtest / wifi / lte）
        _run_noc_api_tests(base, customer_id, node_id, location_id,
                           token, bearer, insecure)

        # 3) SSH enable / disable（可整個關掉）
        if enable_ssh_flow:
            if ssh_action in ("enable", "both"):
                _ssh_enable(base, customer_id, location_id, node_id,
                            ssh_pass, ssh_timeout_min, token, bearer, insecure)
            if ssh_action in ("disable", "both"):
                _ssh_disable(base, customer_id, location_id, node_id,
                             token, bearer, insecure)
        else:
            print(json.dumps({
                "event": "ssh-flow-skip",
                "reason": "env_disabled",
            }))

        # 4) Health check 前：先 wait -> 再做 SSH port check（避免 wait 期間 CPE reboot/hang）
        host = os.environ.get("SSH_HOST_LAN") or os.environ.get("CPE_HEALTH_HOST", "192.168.1.1")
        try:
            port = int(os.environ.get("CPE_HEALTH_PORT", "22"))
        except Exception:
            port = 22
        try:
            ssh_port_timeout = float(os.environ.get("SSH_PORT_CHECK_TIMEOUT", "3"))
        except Exception:
            ssh_port_timeout = 3.0

        # Wait before health check (moved here so ssh-port-check happens AFTER the wait)
        try:
            wait_raw = os.environ.get("CPE_HEALTH_WAIT_SEC") or os.environ.get("HEALTH_WAIT_SEC") or "15"
            wait_sec = int(wait_raw)
        except Exception:
            wait_sec = 15
        if wait_sec > 0:
            print(json.dumps({"event": "health-wait-before", "wait_sec": wait_sec}))
            time.sleep(wait_sec)

        ssh_open = _tcp_open(host, port, ssh_port_timeout)
        print(json.dumps({"event": "ssh-port-check", "host": host, "port": port, "open": ssh_open}))

        # If ssh is required, try to re-enable via NOC and wait for port open
        if (not ssh_open) and enable_ssh_flow and ssh_action in ("enable", "both"):
            print(json.dumps({"event": "ssh-port-recover", "action": "noc_ssh_enable"}))
            _ssh_enable(base, customer_id, location_id, node_id, ssh_pass, ssh_timeout_min, token, bearer, insecure)
            ssh_open = _wait_port_open(host, port, total_wait_sec=int(_getenv("SSH_READY_WAIT_SEC", "30")))
            print(json.dumps({"event": "ssh-port-after-enable", "open": ssh_open}))

        if _bool_env("LAN_SSH_REQUIRED", True) and not ssh_open:
            print(json.dumps({"event": "ssh-not-ready", "reason": "port_closed", "host": host, "port": port}))
            # best-effort logpull won't work if port closed, but still return fail
            return 1

        # 4.1) Reboot detection: take uptime sample before health
        up = _cpe_ssh_json(TOOLS_PATH, host=host, cmd_name="uptime", timeout_sec=int(_getenv("SSH_TOOL_TIMEOUT", "15")))
        prev_sec = _CACHE.get("prev_uptime_sec")
        raw = ""
        cur_sec: Optional[int] = None
        rc = None
        if isinstance(up, dict):
            rc = up.get("rc")
            # For uptime: success prints plain text (e.g. "27 min"); failure prints JSON meta with "raw".
            raw = str(up.get("raw") or up.get("uptime") or up.get("stdout_tail") or "")
            cur_sec = _parse_uptime_seconds(raw)
        parse_ok = (isinstance(cur_sec, int) and cur_sec >= 0)
        cmd_ok = (bool(up.get("ok")) if isinstance(up, dict) else False)
        print(json.dumps({
            "event": "uptime-sample",
            "cmd_ok": cmd_ok,
            "parse_ok": parse_ok,
            "rc": rc,
            "raw_tail": raw[-200:],
            "uptime_sec": cur_sec,
        }))
        if isinstance(prev_sec, (int, float)) and isinstance(cur_sec, int):
            # If uptime goes backwards by >60s, likely reboot occurred
            if cur_sec + 60 < int(prev_sec):
                print(json.dumps({
                    "event": "reboot-detected",
                    "prev_uptime_sec": int(prev_sec),
                    "cur_uptime_sec": cur_sec,
                }))
        if isinstance(cur_sec, int):
            _CACHE["prev_uptime_sec"] = cur_sec

        # 5) CPE health check (no extra wait inside helper)
        health_timeout = int(_getenv("CPE_HEALTH_TIMEOUT_SEC", "180"))
        res = run_cpe_health_check_ex(TOOLS_PATH, host=host, user=ssh_user, timeout=health_timeout, wait_before=False)
        if not bool(res.get("ok")):
            print(json.dumps({"event": "health-check-fail", "reason": res.get("reason"), "overall": res.get("overall"), "rc": res.get("rc")}))

            # Health timeout recovery: scan 22 -> noc ssh-enable -> wait -> retry once
            if str(res.get("reason")) == "timeout":
                print(json.dumps({"event": "health-timeout-recover", "attempt": 1}))
                ssh_open2 = _tcp_open(host, port, ssh_port_timeout)
                if (not ssh_open2) and enable_ssh_flow and ssh_action in ("enable", "both"):
                    _ssh_enable(base, customer_id, location_id, node_id, ssh_pass, ssh_timeout_min, token, bearer, insecure)
                    _wait_port_open(host, port, total_wait_sec=int(_getenv("SSH_READY_WAIT_SEC", "30")))
                res2 = run_cpe_health_check_ex(TOOLS_PATH, host=host, user=ssh_user, timeout=health_timeout, wait_before=False)
                print(json.dumps({"event": "health-check-retry", "ok": bool(res2.get("ok")), "reason": res2.get("reason"), "overall": res2.get("overall"), "rc": res2.get("rc")}))
                if bool(res2.get("ok")):
                    return 0

            # Best-effort pull-log (even if platform fail-hook can't)
            logpull_timeout = int(_getenv("CPE_LOG_TIMEOUT_SEC", "240"))
            for i in range(1, int(_getenv("LOGPULL_RETRIES", "3")) + 1):
                # ensure ssh ready each attempt
                if not _tcp_open(host, port, ssh_port_timeout) and enable_ssh_flow and ssh_action in ("enable", "both"):
                    print(json.dumps({"event": "logpull_ssh_enable", "attempt": i}))
                    _ssh_enable(base, customer_id, location_id, node_id, ssh_pass, ssh_timeout_min, token, bearer, insecure)
                    _wait_port_open(host, port, total_wait_sec=int(_getenv("SSH_READY_WAIT_SEC", "30")))
                ok_lp = _attempt_pull_log(TOOLS_PATH, host=host, node_id=node_id, logpull_timeout=logpull_timeout, attempts=1)
                if ok_lp:
                    break
                if i < int(_getenv("LOGPULL_RETRIES", "3")):
                    time.sleep(float(_getenv("LOGPULL_RETRY_SLEEP_SEC", "10")))

            return 1

        return 0
    except Exception as e:
        print(json.dumps({"event": "exception", "error": str(e)}))
        return 1

if __name__ == "__main__":
    sys.exit(run())