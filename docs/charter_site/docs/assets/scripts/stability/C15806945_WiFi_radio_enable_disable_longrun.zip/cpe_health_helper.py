
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import subprocess
import time
from typing import Optional, Any, Dict


def _env_bool(name: str, default: bool = False) -> bool:
    v = str(os.environ.get(name, "")).strip().lower()
    if not v:
        return default
    return v in ("1", "true", "yes", "y", "on")


def run_cpe_health_check_ex(
    tools_path: Optional[str] = None,
    host: Optional[str] = None,
    user: Optional[str] = None,
    timeout: int = 180,
    wait_before: bool = True,
) -> Dict[str, Any]:
    """Run one CPE health check via cpe_ssh.py.

    Notes:
      - Do NOT pass password via argv (avoid leaking into logs / ps). cpe_ssh.py will read SSH_PASSWORD env.
      - Returns a dict with ok/reason so caller can implement recovery (retry/enable ssh/logpull).
    """

    # 環境變數可以關掉 health check（例如 debug 用途）
    if _env_bool("DISABLE_HEALTH_CHECK", False):
        print(json.dumps({
            "event": "health-check-skip",
            "reason": "DISABLE_HEALTH_CHECK",
        }))
        return {"ok": True, "reason": "DISABLE_HEALTH_CHECK"}

    tools_path = tools_path or os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")

    host = host or os.environ.get("CPE_HEALTH_HOST", "192.168.1.1")
    user = user or os.environ.get("CPE_HEALTH_USER", "operator")

    cpe_ssh = os.environ.get("CPE_SSH_TOOL") or os.path.join(tools_path, "cpe_ssh.py")

    cmd = [
        "python3",
        cpe_ssh,
        "--host", host,
        "--cmd", "health",
    ]
    if user:
        cmd += ["--user", user]


    # Wait before running health check: prefer CPE_HEALTH_WAIT_SEC, then HEALTH_WAIT_SEC, default 15 seconds
    if wait_before:
        try:
            wait_raw = os.environ.get("CPE_HEALTH_WAIT_SEC") or os.environ.get("HEALTH_WAIT_SEC") or "15"
            wait_sec = int(wait_raw)
        except Exception:
            wait_sec = 15
        if wait_sec > 0:
            try:
                print(json.dumps({
                    "event": "health-wait-before",
                    "wait_sec": wait_sec,
                }))
            except Exception:
                pass
            time.sleep(wait_sec)

    print(json.dumps({
        "event": "health-check-start",
        "cmd": " ".join(cmd),
    }))

    try:
        proc = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        print(json.dumps({
            "event": "health-check-error",
            "error": "timeout",
            "timeout": timeout,
        }))
        return {"ok": False, "reason": "timeout", "timeout": timeout, "cmd": " ".join(cmd)}
    except Exception as e:
        print(json.dumps({
            "event": "health-check-exception",
            "error": str(e),
        }))
        return {"ok": False, "reason": "exception", "error": str(e), "cmd": " ".join(cmd)}

    out = (proc.stdout or "").strip()
    err = (proc.stderr or "").strip()
    rc = proc.returncode

    print(json.dumps({
        "event": "health-check-raw",
        "rc": rc,
        "stdout_tail": out[-400:],
        "stderr_tail": err[-400:],
    }))

    if not out:
        print(json.dumps({
            "event": "health-check-parse-error",
            "reason": "empty_stdout",
        }))
        return {"ok": False, "reason": "empty_stdout", "rc": rc}

    try:
        data = json.loads(out)
    except Exception as e:
        print(json.dumps({
            "event": "health-check-parse-error",
            "error": str(e),
        }))
        return {"ok": False, "reason": "json_parse_error", "error": str(e), "rc": rc, "stdout_tail": out[-400:], "stderr_tail": err[-400:]}

    overall = data.get("overall")
    ok_flag = data.get("ok")
    fail_count = data.get("fail_count")
    skip_count = data.get("skip_count")

    print(json.dumps({
        "event": "health-check-result",
        "overall": overall,
        "ok": ok_flag,
        "fail_count": fail_count,
        "skip_count": skip_count,
        "rc": rc,
    }))

    ok = bool(overall == "GOOD" and rc == 0)
    return {
        "ok": ok,
        "reason": "ok" if ok else "not_good",
        "overall": overall,
        "rc": rc,
        "fail_count": fail_count,
        "skip_count": skip_count,
        "stdout_tail": out[-400:],
        "stderr_tail": err[-400:],
        "data": data,
    }


def run_cpe_health_check(
    tools_path: Optional[str] = None,
    host: Optional[str] = None,
    user: Optional[str] = None,
    timeout: int = 180,
) -> bool:
    """Backwards-compatible bool helper."""
    res = run_cpe_health_check_ex(
        tools_path=tools_path,
        host=host,
        user=user,
        timeout=timeout,
        wait_before=True,
    )
    return bool(res.get("ok"))
