#!/usr/bin/env python3
"""Entry shim.

Some runners import a module named `main` and call `main(args)`.
Others execute `main.py` as a script.

We support both by providing `main()`/`run()` that delegate to cycle_wrapper.run().
"""

import cycle_wrapper


def main(_args=None):
    return cycle_wrapper.run()


def run():
    return cycle_wrapper.run()


if __name__ == '__main__':
    raise SystemExit(main())
