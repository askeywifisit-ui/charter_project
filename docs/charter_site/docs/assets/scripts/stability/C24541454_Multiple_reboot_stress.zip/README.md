# C24541454_Multiple_reboot_stress

## 1) 目的 / 覆蓋範圍
- 穩定性/壓力：反覆 reboot/power cycle 並確認系統恢復。

## 2) 前置條件 / 環境
- 會觸發 reboot；需定義 ready 判定與 retry/backoff。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`stability`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：2
- CYCLE_INTERVAL：30
- TOOLS_PATH：/home/da40/charter/tools
- SSH_HOST_LAN：192.168.1.1
- REBOOT_MUTE_SECS：60
- REBOOT_MUTE_WITH_LOCK：1
- ENABLE_REBOOT_TEST：1
- PROFILES_FILE：/home/da40/charter/.secrets/noc_profiles.json
- NOC_PROFILE：SPECTRUM_INT
- CUSTOMER_ID：'682d4e5179b80027cd6fb27e'

## 5) PASS/FAIL 判定
- PASS：每次 reboot 後都能恢復到 ready 狀態。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C24541454_Multiple_reboot_stress

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`stability`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：2
- CYCLE_INTERVAL：30
- TOOLS_PATH：/home/da40/charter/tools

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
> Professional update: remove hard-coded/empty NOC credentials and avoid serial node-id; use NOC_PROFILE+PROFILES_FILE and cpe_info --node-id.

C24541454_Multiple_reboot_stress
================================

Based on A2844344_Continuously_executing_reboot and PRD C24541454 "Multiple reboot stress".

## 1. Purpose

Per TestRail Test Case T4625700 "No crash should be seen after performing multiple reboot" and PRD C24541454.

The goal is:

1. Use NOC API to reboot the CPE repeatedly (stress test).
2. Optionally mute the console before reboot, to avoid noisy output during reboot.
3. After each reboot, verify that the CPE:
   - comes back online in the NOC, and
   - has working Internet / WAN connectivity (via `cpe_info --status`).
4. No crash / kernel panic / persistent offline state should be observed during the whole test.

If any reboot iteration fails to return to a healthy state within the configured limits, the whole test is considered FAIL.

## 2. High-level flow

The script uses the common pattern in this project:

- `cycle_wrapper.py` : controls **how many cycles to run, the interval between cycles, and fail behavior**.
- `main_impl_orig.py` : implements **one reboot + verification cycle**.

Overall behavior:

1. `cycle_wrapper.py` reads environment variables:

   - `CYCLES` — number of reboots to perform (here: 100).
   - `CYCLE_INTERVAL` — minimum seconds to wait between cycles.
   - `STOP_ON_FAIL` — if non-zero, stop immediately when a cycle fails.
   - `ORIGINAL_ENTRY` — entry point for the per-cycle implementation (default: `main_impl_orig.py:run`).

2. `cycle_wrapper.py` then loops `CYCLES` times, calling `main_impl_orig.run()` on each cycle.
3. If every cycle succeeds, the test result is PASS; if any cycle fails, final result is FAIL.

## 3. Per-cycle behavior (main_impl_orig.run)

`main_impl_orig.py` was originally written for A2844344 and reused here because the logic is identical to this PRD.

Per cycle:

1. Read config & tools path from env:

   - `TOOLS_PATH` (e.g. `/home/da40/charter/tools`).
   - `CPE_INFO_TOOL` (path to `cpe_info`).
   - `CPE_INFO_TOOL` / `cpe_info --node-id` 用於取得 `node_id`（不走 serial/console）。).
   - NOC / CPE credentials (`NOC_BASE`, `NOC_EMAIL`, `NOC_PASSWORD`, `CPE_DEV`, `CPE_BAUD`, `CPE_USER`, `CPE_PASSWORD`, ...).

2. (Optional) Health check before reboot (if future env flags enable it).

3. Prepare NOC info:

   - Use `METRICS_TOOL` on `CPE_DEV` to get `node_id`.
   - Use `noc_api_cli.py` to map `node_id` to `location_id` (customer/location under test).

4. Reboot via NOC API:

   - If `ENABLE_REBOOT_TEST=1`:
     - Read `REBOOT_MUTE_SECS` and `REBOOT_MUTE_WITH_LOCK`.
     - Call `cpe_ssh.set_console_mute()` to mute console for the specified period (if configured).
     - Call `noc_api_cli.reboot_node()` with `base`, `customer_id`, `location_id`, `node_id` and token.

5. Wait for reboot:

   - Sleep `POST_REBOOT_STATUS_WAIT_SEC` seconds to allow the CPE to finish booting.

6. Verify that the CPE is back online:

   - If `ENABLE_CPE_STATUS_CHECK=1`:

     - Repeat up to `CPE_STATUS_MAX_RETRIES`:
       1. Run `cpe_info --status`.
       2. Parse `Internet Status` and `Cloud Status` from the output.
       3. Require both to be exactly `Connected`.
       4. If not OK, sleep `CPE_STATUS_RETRY_INTERVAL_SEC` seconds and retry.

     - If, after all retries, both statuses are not `Connected`, this cycle fails.

7. (Optional) health checks after reboot can be added later; if they fail, the cycle also fails.

8. Return RC:

   - On success, `main_impl_orig.run()` returns `0`.
   - On any exception or verification failure, it prints a JSON error event and returns non-zero.

## 4. Result aggregation
```
