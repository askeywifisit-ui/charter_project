#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A2844344_Continuously_executing_reboot main implementation.

流程（每一個 cycle）：
  1. 使用 NOC_EMAIL / NOC_PASSWORD login 取得 token
  2. 透過 serial (METRICS_TOOL) 取得 node_id
  3. 透過 NOC API 取得 location_id
  4. 透過 NOC API 觸發 reboot-node（可選，ENABLE_REBOOT_TEST 控制），並搭配 cpe_ssh mute console
  5. 等待 POST_REBOOT_STATUS_WAIT_SEC 秒
  6. 執行 cpe_info --status，確認：
       - Internet Status: Connected
       - Cloud Status: Connected
     若未達成則整輪 FAIL
  (選用) 7. 若 ENABLE_SSH_FLOW=1，額外跑 SSH enable/disable flow（預設關閉）
"""

import os
import sys
import json
import time
import subprocess
from typing import Dict, Optional, Tuple

import requests  # 用來抓 HTTPError status code


# -------------------------------------------------
# 載入 tools 目錄底下的 noc_api_cli & cpe_ssh
# -------------------------------------------------
TOOLS_PATH = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
if TOOLS_PATH and TOOLS_PATH not in sys.path:
    sys.path.insert(0, TOOLS_PATH)

try:
    import noc_api_cli as api  # type: ignore
except Exception as e:  # 在 ChatGPT sandbox 會失敗，在實機應該 OK
    api = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "noc_api_cli", "error": str(e)}))

try:
    import cpe_ssh  # type: ignore
except Exception as e:
    cpe_ssh = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "cpe_ssh", "error": str(e)}))

_CACHE: Dict[str, object] = {}


def _getenv(name: str, default: str = "") -> str:
    v = os.environ.get(name, default)
    if v is None:
        return default
    return str(v)


def _bool_env(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    v = v.strip().lower()
    if v in ("1", "true", "yes", "on", "y"):
        return True
    if v in ("0", "false", "no", "off", "n"):
        return False
    return default


def _login(base: str, email: str, password: str, bearer: bool, insecure: bool) -> str:
    if "token" in _CACHE:
        return _CACHE["token"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot login to NOC")

    tok = api.login(base, email, password, bearer=bearer, insecure=insecure)
    _CACHE["token"] = tok
    print(json.dumps({"step": "login", "ok": True}))
    return tok


def _node_id(metrics_tool: str, dev: str, baud: int, user: str, password: str) -> str:
    """Resolve node_id via `cpe_info --node-id` only (no console/serial)."""
    if "node_id" in _CACHE:
        try:
            print(json.dumps({"step": "node-id", "cached": True, "node_id": _CACHE["node_id"]}))
        except Exception:
            pass
        return _CACHE["node_id"]  # type: ignore[return-value]

    try:
        max_retries = int(os.environ.get("NODE_ID_MAX_RETRIES", "3"))
    except Exception:
        max_retries = 3
    try:
        retry_interval = float(os.environ.get("NODE_ID_RETRY_INTERVAL_SEC", "2"))
    except Exception:
        retry_interval = 2.0

    def _norm_node_id(raw: str) -> str:
        s = (raw or "").strip()
        if not s:
            return ""
        for ln in s.splitlines():
            ln = ln.strip()
            if ln:
                s = ln
                break
        s = s.replace(":", "").strip().lower()
        if len(s) == 12 and all(c in "0123456789abcdef" for c in s):
            return s
        return ""

    cpe_info_tool = os.environ.get("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
    last_raw = ""

    for attempt in range(1, max_retries + 1):
        for extra_args in (["--node-id"], ["--node-id", "--value"]):
            cmd = ([cpe_info_tool] if os.path.exists(cpe_info_tool) else ["cpe_info"]) + extra_args
            try:
                proc = subprocess.run(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    timeout=20,
                )
                last_raw = (proc.stdout or "").strip()
            except Exception as e:
                last_raw = str(e)
                print(json.dumps({
                    "step": "node-id-cpe_info-exception",
                    "attempt": attempt,
                    "cmd": cmd,
                    "error": str(e),
                }))
                continue

            nid = _norm_node_id(last_raw)
            ok = (proc.returncode == 0 and bool(nid))
            print(json.dumps({
                "step": "node-id-cpe_info",
                "attempt": attempt,
                "cmd": cmd,
                "rc": proc.returncode,
                "raw": last_raw,
                "node_id": nid if ok else "",
                "ok": ok,
            }))
            if ok:
                _CACHE["node_id"] = nid
                return nid

        if attempt < max_retries:
            print(json.dumps({
                "step": "node-id-retry",
                "attempt": attempt,
                "next_wait_sec": retry_interval,
            }))
            time.sleep(retry_interval)

    raise RuntimeError(f"cpe_info --node-id failed after {max_retries} retries; last_output={last_raw!r}")


def _location_id(base: str, customer_id: str, node_id: str,
                 token: str, bearer: bool, insecure: bool) -> str:
    if "location_id" in _CACHE:
        return _CACHE["location_id"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot get location-id")

    loc_id = api.get_location_id(
        base,
        customer_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    _CACHE["location_id"] = loc_id
    print(json.dumps({"step": "location-id", "location_id": loc_id}))
    return loc_id


def _console_password(cpe_info_tool: str) -> str:
    """若 CPE_PASSWORD 未設定或為 null，嘗試透過 cpe_info 撈 console 密碼。"""
    try:
        proc = subprocess.run(
            [cpe_info_tool, "--password"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=15,
        )
        out = (proc.stdout or "").strip()
        for line in out.splitlines():
            line = line.strip()
            if not line:
                continue
            print(json.dumps({"step": "cpe-info-password", "line": line}))
            return line
    except Exception as e:
        print(json.dumps({
            "step": "cpe-info-password-error",
            "error": str(e),
        }))
    return ""


def _ssh_enable(base: str, customer_id: str, location_id: str, node_id: str,
                ssh_pass: str, timeout_min: int,
                token: str, bearer: bool, insecure: bool) -> None:
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot enable SSH")

    resp = api.ssh_enable(
        base,
        customer_id,
        location_id,
        node_id,
        ssh_pass,
        timeout_min,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({"step": "ssh-enable", "resp": resp}))


def _ssh_disable(base: str, customer_id: str, location_id: str, node_id: str,
                 token: str, bearer: bool, insecure: bool) -> None:
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot disable SSH")

    resp = api.ssh_disable(
        base,
        customer_id,
        location_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({"step": "ssh-disable", "resp": resp}))


def _run_reboot_test(base: str, customer_id: str, location_id: str, node_id: str,
                     token: str, bearer: bool, insecure: bool) -> None:
    """reboot-node 測試，並可選擇先 mute console 一段時間。"""
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run reboot test")

    mute_secs_str = _getenv("REBOOT_MUTE_SECS", "").strip()
    mute_with_lock = _bool_env("REBOOT_MUTE_WITH_LOCK", False)

    mute_secs = 0
    if mute_secs_str:
        try:
            mute_secs = int(mute_secs_str)
        except ValueError:
            print(json.dumps({
                "step": "reboot-mute-console",
                "event": "invalid_mute_secs",
                "mute_raw": mute_secs_str,
            }))

    if mute_secs > 0 and "cpe_ssh" in globals() and cpe_ssh is not None:
        try:
            until_ts = cpe_ssh.set_console_mute(
                mute_secs,
                use_lock=mute_with_lock,
                lock_timeout=5,
            )
            print(json.dumps({
                "step": "reboot-mute-console",
                "mute_secs": mute_secs,
                "until_ts": until_ts,
                "use_lock": mute_with_lock,
            }))
        except Exception as e:
            print(json.dumps({
                "step": "reboot-mute-console-fail",
                "mute_secs": mute_secs,
                "use_lock": mute_with_lock,
                "error": str(e),
            }))

    delay_str = _getenv("REBOOT_DELAY_SEC", "").strip()
    delay_val: Optional[float]
    if delay_str:
        try:
            delay_val = float(delay_str)
        except ValueError:
            print(json.dumps({
                "step": "reboot-node",
                "event": "invalid_delay",
                "delay_raw": delay_str,
            }))
            delay_val = None
    else:
        delay_val = None

    resp = api.reboot_node(
        base,
        customer_id,
        location_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
        delay=delay_val,
    )
    print(json.dumps({
        "step": "reboot-node",
        "delay": delay_val,
        "resp": resp,
    }))


def _parse_cpe_info_status(text: str) -> Tuple[Optional[str], Optional[str]]:
    internet_status: Optional[str] = None
    cloud_status: Optional[str] = None
    for line in text.splitlines():
        line = line.strip()
        lower = line.lower()
        if lower.startswith("internet status:"):
            internet_status = line.split(":", 1)[1].strip()
        elif lower.startswith("cloud status:"):
            cloud_status = line.split(":", 1)[1].strip()
    return internet_status, cloud_status


def _run_cpe_status_check(cpe_info_tool: str, timeout_sec: int = 30) -> None:
    """
    執行 cpe_info --status，並允許重試多次，避免 NOC Cloud 比 CPE 晚連上時過早判 FAIL。

    相關環境變數：
      - CPE_STATUS_MAX_RETRIES: 最多嘗試次數（預設 3）
      - CPE_STATUS_RETRY_INTERVAL_SEC: 每次重試間隔秒數（預設 30）
    """
    try:
        max_retries = int(os.environ.get("CPE_STATUS_MAX_RETRIES", "3"))
    except Exception:
        max_retries = 3
    try:
        retry_interval = float(os.environ.get("CPE_STATUS_RETRY_INTERVAL_SEC", "30"))
    except Exception:
        retry_interval = 30.0

    last_error: Optional[Exception] = None

    for attempt in range(1, max_retries + 1):
        cmd = [cpe_info_tool, "--status"]
        print(json.dumps({
            "step": "cpe-info-status-cmd",
            "attempt": attempt,
            "max_retries": max_retries,
            "retry_interval_sec": retry_interval,
            "cmd": cmd,
        }))

        try:
            proc = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=timeout_sec,
            )
        except Exception as e:
            last_error = e
            print(json.dumps({
                "step": "cpe-info-status-run-exception",
                "attempt": attempt,
                "error": str(e),
            }))
            ok = False
            rc = -1
            out = ""
            internet_status = None
            cloud_status = None
        else:
            out = (proc.stdout or "").strip()
            rc = proc.returncode
            internet_status, cloud_status = _parse_cpe_info_status(out)

            # NOTE: 必須 Internet / Cloud 都是完全 'Connected'
            internet_ok = (internet_status is not None and internet_status.strip().lower() == "connected")
            cloud_ok = (cloud_status is not None and cloud_status.strip().lower() == "connected")
            ok = (rc == 0 and internet_ok and cloud_ok)

        print(json.dumps({
            "step": "cpe-info-status",
            "attempt": attempt,
            "max_retries": max_retries,
            "rc": rc,
            "internet_status": internet_status,
            "cloud_status": cloud_status,
            "internet_ok": internet_ok if 'internet_ok' in locals() else None,
            "cloud_ok": cloud_ok if 'cloud_ok' in locals() else None,
            "ok": ok,
            "raw": out[:500] if out else "",
        }))

        if ok:
            # 一旦成功就直接返回，不丟 exception
            return

        # 若失敗，記錄最後一個錯誤（如果有），並視需要重試
        if not ok and attempt < max_retries:
            print(json.dumps({
                "step": "cpe-info-status-retry",
                "attempt": attempt,
                "next_wait_sec": retry_interval,
            }))
            time.sleep(retry_interval)

    # 若全部嘗試後仍未成功，丟出錯誤
    msg = (
        f"post-reboot cpe_info check failed after retries: "
        f"cpe_info rc={rc}; Internet Status={internet_status}; Cloud Status={cloud_status}"
    )
    if last_error is not None:
        msg = f"{msg}; last_error={last_error}"
    raise RuntimeError(msg)

def run() -> int:
    base = _getenv("NOC_BASE", "https://piranha-int.tau.dev-charter.net")
    email = _getenv("NOC_EMAIL")
    password = _getenv("NOC_PASSWORD")
    bearer = _bool_env("BEARER", False)
    insecure = _bool_env("INSECURE", False)
    customer_id = _getenv("CUSTOMER_ID")

    if not email or not password:
        print(json.dumps({
            "event": "missing_credentials",
            "email": bool(email),
            "password": bool(password),
        }))
        return 2

    metrics_tool = _getenv("METRICS_TOOL", "/home/da40/charter/tools/cpe_metrics_agent_serial.py")
    dev = _getenv("CPE_DEV", "/dev/ttyUSB0")
    baud = int(_getenv("CPE_BAUD", "115200"))
    cpe_user = _getenv("CPE_USER", "root")
    cpe_password = _getenv("CPE_PASSWORD", "")
    if str(cpe_password).strip().lower() in ("none", "null", "nil"):
        cpe_password = ""

    if not cpe_password:
        cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
        cpe_password = _console_password(cpe_info_tool)

    ssh_user = _getenv("SSH_USER", "operator")
    ssh_pass = _getenv("SSH_PASSWORD", "")
    ssh_timeout_min = int(_getenv("SSH_TIMEOUT_MIN", "120"))
    ssh_action = _getenv("SSH_ACTION", "enable").strip().lower()

    enable_ssh_flow = _bool_env("ENABLE_SSH_FLOW", False)
    enable_cpe_status_check = _bool_env("ENABLE_CPE_STATUS_CHECK", True)
    enable_reboot_test = _bool_env("ENABLE_REBOOT_TEST", True)

    post_reboot_wait_sec = int(_getenv("POST_REBOOT_STATUS_WAIT_SEC", "60"))

    if ssh_action not in ("enable", "disable", "both"):
        print(json.dumps({"event": "bad_ssh_action", "ssh_action": ssh_action}))
        return 1

    print(json.dumps({
        "event": "config",
        "base": base,
        "email": bool(email),
        "customer_id": customer_id,
        "metrics_tool": metrics_tool,
        "dev": dev,
        "baud": baud,
        "cpe_user": cpe_user,
        "ssh_user": ssh_user,
        "ssh_action": ssh_action,
        "enable_ssh_flow": enable_ssh_flow,
        "enable_cpe_status_check": enable_cpe_status_check,
        "enable_reboot_test": enable_reboot_test,
        "post_reboot_wait_sec": post_reboot_wait_sec,
    }))

    try:
        token = _login(base, email, password, bearer, insecure)
        node_id = _node_id(metrics_tool, dev, baud, cpe_user, cpe_password)
        location_id = _location_id(base, customer_id, node_id, token, bearer, insecure)

        if enable_reboot_test:
            _run_reboot_test(base, customer_id, location_id, node_id,
                             token, bearer, insecure)
        else:
            print(json.dumps({
                "event": "reboot-skip",
                "reason": "env_disabled",
            }))

        if enable_cpe_status_check:
            print(json.dumps({
                "step": "post-reboot-wait",
                "wait_sec": post_reboot_wait_sec,
            }))
            time.sleep(post_reboot_wait_sec)

            cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
            _run_cpe_status_check(cpe_info_tool)
        else:
            print(json.dumps({
                "event": "cpe-status-skip",
                "reason": "env_disabled",
            }))

        if enable_ssh_flow:
            if ssh_action in ("enable", "both"):
                _ssh_enable(base, customer_id, location_id, node_id,
                            ssh_pass, ssh_timeout_min, token, bearer, insecure)
            if ssh_action in ("disable", "both"):
                _ssh_disable(base, customer_id, location_id, node_id,
                             token, bearer, insecure)
        else:
            print(json.dumps({
                "event": "ssh-flow-skip",
                "reason": "env_disabled",
            }))

        return 0

    except Exception as e:
        print(json.dumps({"event": "exception", "error": str(e)}))
        return 1


if __name__ == "__main__":
    sys.exit(run())
