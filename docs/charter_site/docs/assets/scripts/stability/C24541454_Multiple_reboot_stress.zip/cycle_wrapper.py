#!/usr/bin/env python3
"""cycle_wrapper.py

Generic cycle wrapper with a **validated** precondition + per-cycle SSH ensure.

Precondition (only cycle #1):
  1) `cpe_info --cloud` retry
  2) still fail -> PDU reset **once** -> wait -> retry
  3) scan TCP/22; if closed -> NOC ssh-enable -> wait -> re-scan + `ssh uptime` probe

Every cycle (before running ORIGINAL_ENTRY):
  - scan TCP/22; if closed -> NOC ssh-enable (attempt:2, with ssh_enable_start/end/wait logs)
  - re-scan + `ssh uptime` probe

Env:
  - CYCLES, CYCLE_INTERVAL, STOP_ON_FAIL, ORIGINAL_ENTRY
  - CPE_INFO_TOOL (default: cpe_info)
  - PDU_SCRIPT + PDU_OUTLET_ID (preferred)  (compat: PDU_RESET_*)
  - NOC_PROFILE + PROFILES_FILE (optional) (fills NOC_BASE/NOC_EMAIL/NOC_PASSWORD)
  - CUSTOMER_ID, NOC_BASE, NOC_EMAIL, NOC_PASSWORD, BEARER, INSECURE
  - SSH_HOST_LAN, CPE_SSH_PORT, SSH_USER, SSH_PASSWORD

This file intentionally mirrors the event names used by A2435638 v7:
  step_start/step_progress/step_end, ssh_port, ssh_probe,
  ssh_enable_start/ssh_enable_end/ssh_enable_wait.
"""

from __future__ import annotations

import importlib
import json
import os
import socket
import subprocess
import sys
import time
from typing import Any, Dict, Optional, Tuple


# -----------------------------
# Small helpers
# -----------------------------

def _emit(event: str, **fields: Any) -> None:
    d = {"event": event}
    d.update(fields)
    print(json.dumps(d, ensure_ascii=False), flush=True)


def _g(name: str, default: str = "") -> str:
    v = os.environ.get(name)
    return default if v is None else str(v)


def _gi(name: str, default: int = 0) -> int:
    try:
        return int(float(_g(name, str(default)).strip() or str(default)))
    except Exception:
        return default


def _gb(name: str, default: bool = False) -> bool:
    v = _g(name, "")
    if not v:
        return default
    return v.strip().lower() in ("1", "true", "yes", "y", "on")


def _parse_bool(val: Any, default: bool = False) -> bool:
    if val is None:
        return default
    s = str(val).strip().lower()
    if not s:
        return default
    return s in ("1", "true", "yes", "y", "on")


def _run(argv, timeout: int = 30) -> Tuple[int, str]:
    try:
        cp = subprocess.run(
            argv,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=timeout,
        )
        return int(cp.returncode), (cp.stdout or "")
    except subprocess.TimeoutExpired:
        return 124, "timeout"
    except Exception as e:
        return 99, f"exception: {e}"


def _tcp_wait(host: str, port: int, timeout_sec: int = 60, interval_sec: float = 2.0) -> bool:
    deadline = time.time() + max(1, timeout_sec)
    while time.time() <= deadline:
        try:
            s = socket.create_connection((host, port), timeout=3)
            s.close()
            return True
        except Exception:
            time.sleep(max(0.2, float(interval_sec)))
    return False


def _resolve_entry(entry: str):
    if not entry:
        raise ValueError("Empty ORIGINAL_ENTRY")
    if ":" not in entry:
        raise ValueError(f"Bad ORIGINAL_ENTRY format: {entry!r}")
    mod_name, func_name = entry.split(":", 1)
    if mod_name.endswith(".py"):
        mod_name = mod_name[:-3]
    mod = importlib.import_module(mod_name)
    func = getattr(mod, func_name)
    return func


# -----------------------------
# NOC profile + module loader
# -----------------------------

def _load_profile_into_env() -> None:
    """If NOC_PROFILE + PROFILES_FILE exist, fill NOC_BASE/NOC_EMAIL/NOC_PASSWORD when empty."""
    prof = _g("NOC_PROFILE", "").strip()
    pf = _g("PROFILES_FILE", "") or _g("NOC_PROFILES_PATH", "")
    pf = (pf or "").strip()
    if not prof or not pf:
        return

    # Do not override explicit values
    base0 = _g("NOC_BASE", "").strip()
    email0 = _g("NOC_EMAIL", "").strip()
    pass0 = _g("NOC_PASSWORD", "").strip()

    try:
        raw = open(pf, "r", encoding="utf-8").read()
        data = json.loads(raw)
        obj = data.get(prof)
        if not isinstance(obj, dict):
            _emit("noc_profile_missing", ok=False, profile=prof, profiles_file=pf)
            return
        base = str(obj.get("base", "") or "").strip()
        email = str(obj.get("email", "") or "").strip()
        pw = str(obj.get("password", "") or "").strip()
        if base and not base0:
            os.environ["NOC_BASE"] = base
        if email and not email0:
            os.environ["NOC_EMAIL"] = email
        if pw and not pass0:
            os.environ["NOC_PASSWORD"] = pw
        _emit("noc_profile_loaded", ok=True, profile=prof, profiles_file=pf)
    except Exception as e:
        _emit("noc_profile_load_error", ok=False, profile=prof, profiles_file=pf, error=str(e))


def _get_noc_module():
    """Lazy import noc_api_cli from TOOLS_PATH."""
    tools = _g("TOOLS_PATH", "/home/da40/charter/tools").strip() or "/home/da40/charter/tools"
    if tools and tools not in sys.path:
        sys.path.insert(0, tools)
    try:
        import noc_api_cli as noc  # type: ignore
        return noc
    except Exception as e:
        _emit("import_warning", module="noc_api_cli", error=str(e))
        return None


def _noc_login() -> Tuple[str, Dict[str, Any]]:
    noc = _get_noc_module()
    if noc is None:
        raise RuntimeError("noc_api_cli not importable")
    base = _g("NOC_BASE", "https://piranha-int.tau.dev-charter.net").strip()
    email = _g("NOC_EMAIL", "").strip()
    password = _g("NOC_PASSWORD", "").strip()
    bearer = _gb("BEARER", False)
    insecure = _gb("INSECURE", False)
    if not email or not password:
        raise RuntimeError("NOC_EMAIL/NOC_PASSWORD not set (or missing in PROFILES_FILE)")
    token = noc.login(base, email, password, bearer=bearer, insecure=insecure)
    return token, {"base": base, "bearer": bearer, "insecure": insecure, "email": email}


def _noc_resolve_location(base: str, token: str, node_id: str) -> str:
    noc = _get_noc_module()
    if noc is None:
        raise RuntimeError("noc_api_cli not importable")
    customer_id = _g("CUSTOMER_ID", "").strip()
    if not customer_id:
        raise RuntimeError("CUSTOMER_ID not set")
    bearer = _gb("BEARER", False)
    insecure = _gb("INSECURE", False)
    loc_env = _g("LOCATION_ID", "").strip()
    if loc_env:
        return loc_env
    return noc.get_location_id(base, customer_id, node_id, token=token, bearer=bearer, insecure=insecure)


# -----------------------------
# CPE ready / PDU reset
# -----------------------------

def _cpe_info_tool() -> str:
    return _g("CPE_INFO_TOOL", "cpe_info").strip() or "cpe_info"


def _parse_cloud_connected(output: str) -> bool:
    # Expected line: "Cloud Status: Connected"
    for line in (output or "").splitlines():
        if ":" not in line:
            continue
        k, v = line.split(":", 1)
        if k.strip().lower() == "cloud status":
            return v.strip().lower() == "connected"
    return False


def wait_cpe_ready() -> bool:
    """Retry cpe_info --cloud until connected."""
    max_retries = _gi("CPE_READY_MAX_RETRIES", 10)
    interval = float(_g("CPE_READY_RETRY_INTERVAL_SEC", "3") or "3")
    cmd_timeout = _gi("CPE_READY_CMD_TIMEOUT_SEC", 20)
    tool = _cpe_info_tool()

    _emit("step_start", name="cpe_ready", cmd=f"{tool} --cloud", max_retries=max_retries)
    for attempt in range(1, max_retries + 1):
        rc, out = _run([tool, "--cloud"], timeout=cmd_timeout)
        ok = (rc == 0) and _parse_cloud_connected(out)
        _emit(
            "step_progress",
            name="cpe_ready",
            attempt=attempt,
            ok=ok,
            rc=rc,
            sample=(out.strip().splitlines()[-4:] if out else []),
        )
        if ok:
            _emit("step_end", name="cpe_ready", ok=True)
            return True
        if attempt < max_retries and interval > 0:
            time.sleep(interval)
    _emit("step_end", name="cpe_ready", ok=False)
    return False


def pdu_reset_once() -> bool:
    """PDU reset using PDU_SCRIPT + PDU_OUTLET_ID (preferred) with compatibility fallbacks."""
    # Preferred envs
    script = (_g("PDU_SCRIPT", "") or _g("PDU_RESET_SCRIPT", "")).strip()
    outlet_id = (_g("PDU_OUTLET_ID", "") or "").strip()
    action = (_g("PDU_RESET_ACTION", "reset") or "reset").strip()

    if not script:
        _emit("step_end", name="pdu_reset", ok=False, error="PDU_SCRIPT not set")
        return False

    timeout = _gi("PDU_RESET_TIMEOUT_SEC", _gi("PDU_TIMEOUT_SEC", 600))
    _emit("step_start", name="pdu_reset", script=script, outlet_id=outlet_id, timeout_sec=timeout)

    candidates = []
    if outlet_id:
        candidates += [
            ["python3", script, "--id", str(outlet_id), "--action", action],
            ["python3", script, action, str(outlet_id)],
        ]
    candidates += [
        ["python3", script, action],
        ["python3", script, "reset"],
        ["python3", script, "off"],
        ["python3", script, "on"],
    ]

    last: Optional[Dict[str, Any]] = None
    for argv in candidates:
        rc, out = _run(argv, timeout=timeout)
        last = {"argv": argv, "rc": rc, "out": (out or "")[-200:]}
        if rc == 0:
            _emit("step_end", name="pdu_reset", ok=True, argv=argv)
            return True
        _emit("step_progress", name="pdu_reset", ok=False, argv=argv, rc=rc, sample=(out.splitlines()[:2] if out else []))

    _emit("step_end", name="pdu_reset", ok=False, last=last)
    return False


# -----------------------------
# SSH ensure (scan22 -> noc enable -> uptime probe)
# -----------------------------

def _cpe_host() -> str:
    return _g("SSH_HOST_LAN", "192.168.1.1").strip() or "192.168.1.1"


def _cpe_ssh_user() -> str:
    return _g("SSH_USER", "operator").strip() or "operator"


def _get_cpe_ssh_password() -> str:
    pw = _g("SSH_PASSWORD", "").strip()
    if pw and pw.lower() not in ("null", "none"):
        return pw
    # fallback to cpe_info --password
    tool = _cpe_info_tool()
    rc, out = _run([tool, "--password"], timeout=15)
    if rc == 0 and out.strip():
        return out.strip().splitlines()[0].strip()
    return ""


def _get_node_id() -> str:
    nid = _g("NODE_ID", "").strip().lower().replace(":", "")
    if len(nid) == 12 and all(c in "0123456789abcdef" for c in nid):
        return nid

    tool = _cpe_info_tool()
    # try --node-id --value then --node-id
    for argv in ([tool, "--node-id", "--value"], [tool, "--node-id"]):
        rc, out = _run(argv, timeout=20)
        if rc != 0:
            continue
        raw = (out or "").strip()
        if not raw:
            continue
        # best-effort pick first token that looks like 12-hex
        for line in raw.splitlines():
            s = line.strip().lower().replace(":", "")
            if len(s) == 12 and all(c in "0123456789abcdef" for c in s):
                return s
    return ""


def enable_ssh_via_noc(node_id: str, ssh_password: str) -> bool:
    noc = _get_noc_module()
    if noc is None:
        _emit("ssh_enable_end", ok=False, error="noc_api_cli not importable")
        return False

    customer_id = _g("CUSTOMER_ID", "").strip()
    if not customer_id:
        _emit("ssh_enable_end", ok=False, error="CUSTOMER_ID not set")
        return False

    try:
        token, meta = _noc_login()
        base = meta["base"]
        bearer = bool(meta["bearer"])
        insecure = bool(meta["insecure"])
        location_id = _noc_resolve_location(base, token, node_id)
        timeout_min = _gi("SSH_TIMEOUT_MIN", 120)

        _emit(
            "ssh_enable_start",
            node_id=node_id,
            location_id=location_id,
            customer_id=customer_id,
            timeout_min=timeout_min,
            base=base,
        )
        resp = noc.ssh_enable(
            base,
            customer_id,
            location_id,
            node_id,
            ssh_password,
            timeout_min,
            token=token,
            bearer=bearer,
            insecure=insecure,
        )
        _emit("ssh_enable_end", ok=True, resp=resp)
        return True
    except Exception as e:
        _emit("ssh_enable_end", ok=False, error=str(e))
        return False


def _ssh_probe_uptime(host: str, user: str, pw: str) -> bool:
    tool = _g("CPE_SSH_TOOL", "/home/da40/charter/tools/cpe_ssh.py").strip() or "cpe_ssh.py"
    timeout = float(_g("CPE_SSH_TIMEOUT_SEC", _g("SSH_TOOL_TIMEOUT", "30")) or "30")
    t0 = time.time()
    rc, out = _run([
        "python3", tool,
        "--host", host,
        "--user", user,
        "--password", pw,
        "--timeout", str(timeout),
        "--cmd", "uptime",
    ], timeout=int(timeout) + 15)
    sec = round(time.time() - t0, 3)
    sample = (out or "").strip().splitlines()[-2:]
    ok = (rc == 0)
    _emit("ssh_probe", ok=ok, rc=rc, sec=sec, sample=sample)
    return ok


def ensure_ssh_ready(tag: str = "") -> bool:
    if not _gb("REQUIRE_SSH_READY", True):
        return True

    _load_profile_into_env()

    host = _cpe_host()
    port = _gi("CPE_SSH_PORT", 22)

    scan_timeout = _gi("SSH_SCAN_TIMEOUT_SEC", 60)
    scan_interval = float(_g("SSH_SCAN_INTERVAL_SEC", "2") or "2")
    enable_retries = _gi("SSH_ENABLE_RETRIES", 2)
    wait_after_enable = _gi("WAIT_AFTER_SSH_ENABLE_SEC", 60)

    ssh_user = _cpe_ssh_user()
    ssh_pass = _get_cpe_ssh_password()
    node_id = _get_node_id()

    _emit(
        "step_start",
        name="ssh_ready",
        tag=tag,
        host=host,
        port=port,
        scan_timeout_sec=scan_timeout,
        scan_interval_sec=scan_interval,
        user=ssh_user,
        have_password=bool(ssh_pass),
        node_id=node_id,
    )

    for attempt in range(1, enable_retries + 1):
        port_ok = _tcp_wait(host, port, timeout_sec=scan_timeout, interval_sec=scan_interval)
        _emit("ssh_port", ok=port_ok, attempt=attempt)

        if port_ok and ssh_pass and _ssh_probe_uptime(host, ssh_user, ssh_pass):
            _emit("step_end", name="ssh_ready", ok=True, tag=tag)
            return True

        if not _gb("AUTO_SSH_ENABLE", True):
            break

        if not node_id:
            _emit("ssh_enable_skip", ok=False, error="node_id not available")
            break
        if not ssh_pass:
            _emit("ssh_enable_skip", ok=False, error="ssh_password not available")
            break

        ok = enable_ssh_via_noc(node_id=node_id, ssh_password=ssh_pass)
        if not ok:
            _emit("ssh_enable_attempt_failed", attempt=attempt)
            continue

        if wait_after_enable > 0:
            _emit("ssh_enable_wait", seconds=wait_after_enable)
            time.sleep(wait_after_enable)

    _emit("step_end", name="ssh_ready", ok=False, tag=tag)
    return False


def precondition_first_cycle() -> bool:
    _load_profile_into_env()

    _emit("step_start", name="precondition", cycle=1)

    if not wait_cpe_ready():
        _emit("precondition_recover", action="pdu_reset")
        if not pdu_reset_once():
            _emit("step_end", name="precondition", ok=False, reason="pdu_reset_failed")
            return False
        wait_sec = _gi("PDU_WAIT_SEC", _gi("PDU_RESET_WAIT_SEC", 120))
        if wait_sec > 0:
            _emit("sleep", name="after_pdu_reset", seconds=wait_sec)
            time.sleep(wait_sec)
        if not wait_cpe_ready():
            _emit("step_end", name="precondition", ok=False, reason="cpe_not_ready")
            return False

    if not ensure_ssh_ready(tag="precondition"):
        _emit("step_end", name="precondition", ok=False, reason="ssh_not_ready")
        return False

    _emit("step_end", name="precondition", ok=True)
    return True


# -----------------------------
# Main
# -----------------------------

def run() -> int:
    cycles = _gi("CYCLES", 1)
    interval = _gi("CYCLE_INTERVAL", 30)
    stop_on_fail = _parse_bool(os.environ.get("STOP_ON_FAIL", "1"), default=True)
    entry = _g("ORIGINAL_ENTRY", "main_impl_orig.py:run")

    # Ensure profile-derived NOC creds are present before importing ORIGINAL_ENTRY.
    _load_profile_into_env()

    try:
        func = _resolve_entry(entry)
    except Exception as e:
        _emit("entry_resolve_error", entry=entry, error=str(e))
        return 1

    overall_rc = 0

    for i in range(cycles):
        cycle_idx = i + 1
        os.environ["CYCLE_INDEX"] = str(cycle_idx)
        os.environ["CYCLE_TOTAL"] = str(cycles)

        # Precondition only on first cycle
        if cycle_idx == 1 and _gb("PRECONDITION_FIRST_CYCLE", True):
            if not precondition_first_cycle():
                _emit("precondition_fail", cycle=1, rc=2)
                return 2

        # Per-cycle SSH ensure (including cycle #1)
        if not ensure_ssh_ready(tag=f"cycle_{cycle_idx}"):
            _emit("cycle_fail", cycle=cycle_idx, rc=3, reason="ssh_not_ready")
            return 3

        _emit("cycle_start", cycle=cycle_idx, total=cycles)
        try:
            rc = func()
        except SystemExit as se:
            rc = int(se.code or 0)
        except Exception as e:
            _emit("cycle_exception", cycle=cycle_idx, error=str(e))
            rc = 1

        try:
            rc = int(rc)
        except Exception:
            rc = 1

        _emit("cycle_end", cycle=cycle_idx, rc=rc)
        if rc != 0:
            overall_rc = rc
            if stop_on_fail:
                break

        if i < cycles - 1 and interval > 0:
            time.sleep(interval)

    _emit("all_cycles_done", rc=overall_rc)
    return overall_rc


if __name__ == "__main__":
    sys.exit(run())
