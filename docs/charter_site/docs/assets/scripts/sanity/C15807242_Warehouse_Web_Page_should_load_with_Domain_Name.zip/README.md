# C15807242_Warehouse_Web_Page_should_load_with_Domain_Name

## 1) 目的 / 覆蓋範圍
- 驗證特定 Web UI page 可在 LAN（IPv4/IPv6 link-local/Domain）載入。

## 2) 前置條件 / 環境
- 需 client 能存取 CPE Web UI（IPv4/IPv6/Domain 視腳本）。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'70'

## 5) PASS/FAIL 判定
- PASS：HTTP/頁面載入成功（依腳本判定）。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807242 - Warehouse Web Page should load with Domain Name

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'70'

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807242 - Warehouse Web Page should load with Domain Name

This script is generated from the C15807240 automation structure, but validates the **domain-name** entry point.

Default redirect behavior observed on devices:
- `http://MyRouter/warehouse` → `308 Location: https://myrouter/warehouse`
- (follow) `https://myrouter/warehouse` → `301 Location: /warehouse/`

So the script verifies **HTTP → HTTPS** on the domain entry, while fetching/validating the actual warehouse table via:
- `https://myrouter/cgi-bin/warehouse.cgi`

(Hostnames are case-insensitive. Redirect strictness is configurable via env.)

It uses:
- NOC API (factory reset + Wi‑Fi SSID/password change)
- Domain-name resolution + redirect verification (HTTP → HTTPS)
- Warehouse page fetch/parse via `cpe_warehouse_info.py` (IPv4 forced)

## What it verifies
1. (Optional) Factory reset via NOC API, then waits for the device to come back.
2. (Optional) `MyRouter` resolves to the expected LAN IPv4.
   - Uses `getent ahostsv4` first (ignores IPv6-only results like `fe80::...`).
   - Includes retries to tolerate DNS readiness after factory reset.
3. HTTP domain entry points redirect to HTTPS (final URL usually `/warehouse/`).
4. Warehouse page loads and returns a valid table.
5. Required fields exist, and key values look sane (IPv4 fields contain IPv4, etc.).
6. Default SSID/Password look like Base64 and decode to non-empty strings (optional).
7. (Optional) Change SSID/password via NOC API and verify warehouse page reflects the change.

## MAC validation (ifconfig -a)
If you need to comply with the requirement:
"All the MAC address should be validated against ifconfig -a",
this script can:
1) Enable SSH via NOC (kvConfigs), then
2) SSH into the CPE and run `ifconfig -a`, and
3) Compare the following fields (with fallbacks):
   - WAN MAC Address   ← br-wan
   - LAN MAC Address   ← br-home/BR_LAN
   - WLAN2.4 MAC Address ← wifi0
   - WLAN5.0 MAC Address ← home-ap-50 (fallback: wifi1)
   - WLAN6.0 MAC Address ← home-ap-60 (fallback: wifi2)

On some platforms, the `wifi1/wifi2` labels are reversed. You can tolerate this via:
- `ALLOW_WIFI5_WIFI6_SWAP=1`

Related env:
- `ENABLE_SSH_VIA_NOC=1`
- `SSH_ENABLE_PASSWORD` (or `SSH_PASSWORD`)
- `VALIDATE_MACS_VIA_SSH=1`
- `SSH_HOST` (default uses `EXPECTED_LAN_IP`)

## Key envs
See `manifest.yaml` for the full list. Most common:
- `NOC_PROFILE` + `PROFILES_FILE` (recommended)
- `CUSTOMER_ID`
- `METRICS_TOOL` + `CPE_DEV` (for node-id)
- `WAREHOUSE_ID` / `WAREHOUSE_PASSWORD`

Domain-name checks:
- `WAREHOUSE_HTTP_URLS` / `WAREHOUSE_EXPECT_HTTPS_URLS`
- `CHECK_DOMAIN_RESOLVE=1` + `EXPECTED_LAN_IP=192.168.1.1`
- `REDIRECT_MATCH_MODE=strict|prefix|https_only`

## Entry
`cycle_wrapper.py:run` (supports CYCLES / STOP_ON_FAIL / CPE_READY precondition / PDU reset)
```

```
