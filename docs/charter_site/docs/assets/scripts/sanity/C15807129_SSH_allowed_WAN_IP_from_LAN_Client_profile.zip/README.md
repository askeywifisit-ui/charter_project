# C15807129_SSH_allowed_WAN_IP_from_LAN_Client_profile

## 1) 目的 / 覆蓋範圍
- 驗證 SSH 可用性與安全策略（允許/拒絕、port 限制、帳密錯誤等）。

## 2) 前置條件 / 環境
- 需具備對應 client 位置（LAN/WAN）與連線條件。
- 若需 NOC enable SSH，請用 `.secrets`/`PROFILES_FILE`。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- （manifest 未包含常見 env 或解析不到；可直接查看 zip 內 manifest.yaml）

## 5) PASS/FAIL 判定
- PASS：SSH 行為符合預期策略。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807129 - SSH should be allowed to WAN IP from a LAN Client (profile switch)

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807129 - SSH should be allowed to WAN IP from a LAN Client (profile switch)

## Summary
This test verifies SSH behavior to the DUT **WAN interface addresses** when the client is on the **LAN side**.

- WAN IPv4: **ALLOW**
- WAN Global IPv6 (GUA): **ALLOW** (customer profile / IPv6 available)
- WAN Link-Local IPv6: **DENY** (customer profile / IPv6 available)

## Preconditions (Automation)
1. NOC login (get access token)
2. Get node_id via serial metrics (with retry handling)
3. Get location_id via NOC API
4. Enable SSH Manager (SSHM) via kvConfigs PATCH (set sshAuthPasswd / timeout)

## Test Flow (Automation)
1. Enable SSH via SSHM.
2. Discover DUT WAN IPv4 address and WAN interface (`ip -4 route get 8.8.8.8`).
3. (Optional) Discover WAN IPv6 global + link-local on the WAN interface.
4. From LAN client:
   - SSH to **WAN IPv4** → **ALLOW**
   - SSH to **WAN Global IPv6** → **ALLOW** (if enabled)
   - SSH to **WAN Link-Local IPv6** → **DENY** (if enabled)

## Profile Switch (Lab vs Customer)
- `TEST_PROFILE=customer` (default): run full coverage (IPv4 + IPv6 if available).
- `TEST_PROFILE=lab`: run **IPv4-only** subset (skip IPv6 steps).

IPv6 control:
- `ENABLE_IPV6=auto` (default): run IPv6 steps only if IPv6 route discovery succeeds (customer profile).
- `ENABLE_IPV6=false`: always skip IPv6 steps.
- `ENABLE_IPV6=true`: force IPv6 steps (will FAIL if IPv6 is not available).

## Tuning
- `WAN_SSH_TIMEOUT_SEC` (default 30): timeout for WAN SSH allow checks.
- Script performs a TCP port-22 precheck before running SSH to provide clearer diagnostics.

## Notes
- Link-local SSH uses a zone id (e.g. `%ens19`). Override via `LAN_IFACE`.
- Each SSH check is connect→command→disconnect (equivalent to exiting the session).
```

```
