#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
C15807128 - SSH should be allowed to local IP from LAN Client

Preconditions (script-enforced):
  1) NOC login (token)
  2) serial metrics -> node_id (with retry)
  3) NOC API -> location_id
  4) kvConfigs PATCH -> enable SSHM + set sshAuthPasswd

Validations:
  - SSH to LAN IPv4: ALLOW
  - SSH to LAN Global IPv6: ALLOW (if present)
  - SSH to LAN Link-local IPv6: NOT allowed (if present)
"""

import os
import sys
import json
import time
import re
import subprocess
import shlex
from typing import Dict, Optional, Tuple

TOOLS_PATH = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
if TOOLS_PATH and TOOLS_PATH not in sys.path:
    sys.path.insert(0, TOOLS_PATH)

try:
    import noc_api_cli as api  # type: ignore
except Exception as e:
    api = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "noc_api_cli", "error": str(e)}))

try:
    import cpe_ssh  # type: ignore
except Exception as e:
    cpe_ssh = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "cpe_ssh", "error": str(e)}))



# ------------------------------
# Quiet stdout: marker wrapper
# ------------------------------
MARK_BEGIN = "__RG_BEGIN__"
MARK_END   = "__RG_END__"

def _wrap_cmd(cmd: str) -> str:
    """Wrap remote cmd with markers so we can extract output even if SSH server prints banners."""
    wrapped = f"echo {MARK_BEGIN}; {cmd}; echo {MARK_END}"
    return "sh -lc " + shlex.quote(wrapped)

def _extract_marked(stdout: str) -> str:
    if not stdout:
        return ""
    b = stdout.find(MARK_BEGIN)
    e = stdout.find(MARK_END)
    if b == -1 or e == -1 or e < b:
        return stdout.strip()
    b2 = b + len(MARK_BEGIN)
    return stdout[b2:e].strip("\n\r ")

def _ssh_exec_marked(host: str, user: str, pw: str, cmd: str, timeout: float, login_shell: bool = True):
    """Return (rc, extracted_stdout, raw_stdout, stderr, sec)."""
    if cpe_ssh is None:
        raise RuntimeError("cpe_ssh not available")
    wrapped = _wrap_cmd(cmd)
    rc, out, err, sec = cpe_ssh.ssh_exec(host, user, pw, wrapped, timeout=timeout, login_shell=login_shell)
    return rc, _extract_marked(out), out, err, sec
_CACHE: Dict[str, object] = {}


def _getenv(name: str, default: str = "") -> str:
    v = os.environ.get(name, default)
    return default if v is None else str(v)


def _bool_env(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "on", "y")


def _run(cmd, timeout: float = 60.0) -> Tuple[int, str, str]:
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout)
    return p.returncode, p.stdout or "", p.stderr or ""


def _load_noc_profile(profile_name: str) -> Optional[Dict[str, str]]:
    path = (
        os.environ.get("NOC_PROFILES_PATH")
        or os.environ.get("PROFILES_FILE")
        or os.path.expanduser("~/.secrets/noc_profiles.json")
    )
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print(json.dumps({"event": "noc-profile-load-error", "profile": profile_name, "path": path, "error": str(e)}))
        return None

    prof = data.get(profile_name) or data.get(profile_name.upper())
    if not prof:
        print(json.dumps({"event": "noc-profile-load-error", "profile": profile_name, "path": path, "error": "profile not found"}))
        return None

    return {"base": prof.get("base"), "email": prof.get("email"), "password": prof.get("password")}


def _noc_creds() -> Tuple[str, str, str]:
    """Priority:
      1) NOC_BASE/NOC_EMAIL/NOC_PASSWORD if provided (and not "<fill>")
      2) NOC_PROFILE from profiles file
    """
    base = _getenv("NOC_BASE", "").strip()
    email = _getenv("NOC_EMAIL", "").strip()
    password = _getenv("NOC_PASSWORD", "").strip()

    if base and email and password and "<fill>" not in (base + email + password):
        return base, email, password

    prof_name = _getenv("NOC_PROFILE", "").strip()
    if prof_name:
        prof = _load_noc_profile(prof_name)
        if prof and prof.get("base") and prof.get("email") and prof.get("password"):
            return prof["base"], prof["email"], prof["password"]

    raise RuntimeError("NOC credentials missing: fill NOC_BASE/NOC_EMAIL/NOC_PASSWORD or provide NOC_PROFILE + profiles file")


def _login() -> str:
    if "token" in _CACHE:
        return _CACHE["token"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available")

    base, email, password = _noc_creds()
    bearer = _bool_env("NOC_BEARER", False)
    insecure = _bool_env("NOC_INSECURE", False)

    tok = api.login(base, email, password, bearer=bearer, insecure=insecure)
    _CACHE["token"] = tok
    print(json.dumps({"step": "login", "ok": True}))
    return tok


def _node_id() -> str:
    if "node_id" in _CACHE:
        return _CACHE["node_id"]  # type: ignore[return-value]

    metrics_tool = _getenv("METRICS_TOOL", "/home/da40/charter/tools/cpe_metrics_agent_serial.py")
    dev = _getenv("CPE_DEV", "/dev/ttyUSB0")
    baud = int(_getenv("CPE_BAUD", "115200"))
    user = _getenv("CPE_USER", "root")
    password = _getenv("CPE_PASSWORD", "null")

    max_retries = int(_getenv("NODE_ID_MAX_RETRIES", "10"))
    interval = float(_getenv("NODE_ID_RETRY_INTERVAL_SEC", "5"))

    last = ""
    for attempt in range(1, max_retries + 1):
        cmd = [metrics_tool, "--device", dev, "--baud", str(baud), "--user", user, "--cmd", "node-id"]

        pw_raw = (password or "").strip()
        pw_head = pw_raw.split()[0] if pw_raw else ""
        pw_head_l = pw_head.lower()
        is_error_like = (
            pw_head_l.startswith("curl:")
            or "connection timed out" in pw_raw.lower()
            or "error:" in pw_raw.lower()
            or "cannot fetch index.cgi" in pw_raw.lower()
        )
        if (not pw_raw) or (pw_head_l in ("null", "none")) or is_error_like:
            cmd += ["--password", "null"]
        else:
            cmd += ["--password", pw_head]

        print(json.dumps({"step": "node-id-cmd", "attempt": attempt, "cmd": cmd}))
        try:
            rc, out, err = _run(cmd, timeout=90.0)
        except Exception as e:
            last = str(e)
            print(json.dumps({"step": "node-id-exception", "attempt": attempt, "error": last}))
            time.sleep(interval)
            continue

        out_s = out.strip()
        print(json.dumps({"step": "node-id-raw", "attempt": attempt, "rc": rc, "out": out_s[:400]}))
        if rc == 0 and out_s:
            try:
                node_id = api.parse_node_id_from_text(out_s) if api else ""
            except Exception:
                node_id = ""
            node_id = (node_id or "").strip()
            if node_id:
                _CACHE["node_id"] = node_id
                print(json.dumps({"step": "node-id", "ok": True, "node_id": node_id}))
                return node_id

        last = (err or out).strip()
        print(json.dumps({"step": "node-id-retry", "attempt": attempt, "error": last[-200:]}))
        time.sleep(interval)

    # Fallback: derive node_id from WAN MAC via cpe_info
    cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
    try:
        rc2, out2, err2 = _run([cpe_info_tool, "--node-id", "--value"], timeout=20.0)
        raw2 = ((out2 or "") or (err2 or "")).strip()
        nid2 = raw2.replace(":", "").strip().lower()
        ok2 = (rc2 == 0 and bool(nid2))
        print(json.dumps({"step": "node-id-fallback-cpe_info", "ok": ok2, "rc": rc2, "raw": raw2[:200], "node_id": nid2 if ok2 else ""}))
        if ok2:
            _CACHE["node_id"] = nid2
            return nid2
    except Exception as e:
        print(json.dumps({"step": "node-id-fallback-cpe_info-exception", "error": str(e)}))

    raise RuntimeError(f"node-id failed: {last}")


def _location_id(token: str, node_id: str) -> str:
    if "location_id" in _CACHE:
        return _CACHE["location_id"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available")

    base, _, _ = _noc_creds()
    customer_id = _getenv("CUSTOMER_ID")
    bearer = _bool_env("NOC_BEARER", False)
    insecure = _bool_env("NOC_INSECURE", False)

    loc = api.get_location_id(base, customer_id, node_id, token=token, bearer=bearer, insecure=insecure)
    _CACHE["location_id"] = loc
    print(json.dumps({"step": "location-id", "ok": True, "location_id": loc}))
    return loc


def _enable_ssh(token: str, node_id: str, location_id: str) -> str:
    if api is None:
        raise RuntimeError("noc_api_cli not available")

    base, _, _ = _noc_creds()
    customer_id = _getenv("CUSTOMER_ID")
    passwd = _getenv("SSH_PASSWORD", "123456789")
    timeout_min = int(_getenv("SSH_TIMEOUT_MIN", "120"))
    bearer = _bool_env("NOC_BEARER", False)
    insecure = _bool_env("NOC_INSECURE", False)

    resp = api.ssh_enable(
        base,
        customer_id,
        location_id,
        node_id,
        passwd,
        timeout_min,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({"step": "ssh-enable", "ok": True, "resp": resp}))
    return passwd


def _parse_ipv6_addrs(ip6_addr_output: str) -> Tuple[Optional[str], Optional[str]]:
    g = None
    ll = None
    for line in (ip6_addr_output or "").splitlines():
        line = line.strip()
        m = re.search(r"\binet6\s+([0-9a-fA-F:]+)/\d+", line)
        if not m:
            continue
        ip = m.group(1).lower()
        if ip.startswith("fe80:"):
            ll = ip
        else:
            g = ip
    return g, ll


def _lan_iface_for(dst_ip: str) -> Optional[str]:
    try:
        rc, out, _ = _run(["sh", "-lc", f"ip route get {dst_ip}"], timeout=3.0)
        if rc != 0:
            return None
        m = re.search(r"\bdev\s+(\S+)", out)
        return m.group(1) if m else None
    except Exception:
        return None


def _ssh_exec(host: str, user: str, pw: str, cmd: str, timeout: float):
    """Execute remote cmd with marker wrapping; returns (rc, extracted, raw_out, err, sec)."""
    return _ssh_exec_marked(host, user, pw, cmd, timeout=timeout, login_shell=True)


def _expect_allow(host: str, user: str, pw: str, cmd: str, timeout: float) -> None:
    rc, extracted, raw_out, err, sec = _ssh_exec(host, user, pw, cmd, timeout)
    print(json.dumps({
        "step": "ssh-allow-check",
        "host": host,
        "rc": rc,
        "sec": sec,
        "stdout": extracted[-200:],
        "raw_stdout_tail": raw_out[-200:],
        "stderr": err[-200:],
    }))
    if rc != 0:
        raise RuntimeError(f"ssh expected ALLOW but failed rc={rc}: {err.strip()}")


def _expect_deny(host: str, user: str, pw: str, cmd: str, timeout: float) -> None:
    rc, extracted, raw_out, err, sec = _ssh_exec(host, user, pw, cmd, timeout)
    print(json.dumps({
        "step": "ssh-deny-check",
        "host": host,
        "rc": rc,
        "sec": sec,
        "stdout": extracted[-200:],
        "raw_stdout_tail": raw_out[-200:],
        "stderr": err[-200:],
    }))
    if rc == 0:
        raise RuntimeError("ssh expected DENY but succeeded")





def _parse_route_get(output: str) -> dict:
    # Works for both ipv4/ipv6: expects tokens like "dev <ifname>" and "src <ip>"
    toks = output.strip().split()
    res = {}
    for i, t in enumerate(toks):
        if t == "dev" and i + 1 < len(toks):
            res["dev"] = toks[i+1]
        if t == "src" and i + 1 < len(toks):
            res["src"] = toks[i+1]
    return res

def _parse_ipv6_addrs_on_iface(output: str) -> dict:
    # Return {"global": <ip or None>, "link_local": <ip or None>}
    g = None
    ll = None
    for line in output.splitlines():
        line = line.strip()
        if not line.startswith("inet6"):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        ip = parts[1].split("/")[0]
        scope = None
        if "scope" in parts:
            scope = parts[parts.index("scope")+1] if parts.index("scope")+1 < len(parts) else None
        if scope == "global" and not ip.startswith("fd") and g is None:
            # prefer GUA (2000::/3); if none exists, we'll fall back later
            g = ip
        if scope == "global" and g is None:
            g = ip
        if scope == "link" and ll is None:
            ll = ip
    return {"global": g, "link_local": ll}


def _tcp_check(host: str, port: int, timeout: float) -> tuple[bool, str]:
    import socket
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True, "tcp_connect_ok"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


def _norm(s: str) -> str:
    return (s or "").strip().lower()

def _is_true(s: str) -> bool:
    return _norm(s) in ("1","true","yes","y","on")

def _is_false(s: str) -> bool:
    return _norm(s) in ("0","false","no","n","off")

def _parse_route_get(output: str) -> dict:
    toks = output.strip().split()
    res = {}
    for i, t in enumerate(toks):
        if t == "dev" and i + 1 < len(toks):
            res["dev"] = toks[i+1]
        if t == "src" and i + 1 < len(toks):
            res["src"] = toks[i+1]
    return res

def _parse_ipv6_addrs_on_iface(output: str) -> dict:
    g = None
    ll = None
    for line in output.splitlines():
        line = line.strip()
        if not line.startswith("inet6"):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        ip = parts[1].split("/")[0]
        scope = None
        if "scope" in parts:
            j = parts.index("scope")+1
            scope = parts[j] if j < len(parts) else None
        if scope == "global" and g is None:
            g = ip
        if scope == "link" and ll is None:
            ll = ip
    return {"global": g, "link_local": ll}

def run() -> int:
    lan_ip = _getenv("SSH_HOST_LAN", "192.168.1.1")
    ssh_user = _getenv("SSH_USER", "operator")
    ssh_passwd = _getenv("SSH_AUTH_PASSWD", "123456789")
    timeout_sec = float(_getenv("SSH_CONNECT_TIMEOUT_SEC", "12"))
    wan_timeout = float(_getenv("WAN_SSH_TIMEOUT_SEC", "30"))
    lan_iface = _getenv("LAN_IFACE", "ens19")

    test_profile = _getenv("TEST_PROFILE", "customer")  # customer|lab
    enable_ipv6 = _getenv("ENABLE_IPV6", "auto")  # auto|true|false

    token = _login()
    node_id = _node_id()
    location_id = _location_id(token, node_id)
    _enable_ssh(token, node_id, location_id)

    # --- Discover WAN IPv4 and interface ---
    rc, out4, raw4, err4, sec4 = _ssh_exec(lan_ip, ssh_user, ssh_passwd, "ip -4 route get 8.8.8.8", timeout_sec)
    print(json.dumps({"step": "wan-route4", "rc": rc, "sec": sec4, "stdout": out4[-400:], "raw_stdout_tail": raw4[-200:], "stderr": err4[-200:]}))
    if rc != 0:
        raise RuntimeError(f"Failed to discover WAN route ipv4 rc={rc}: {err4.strip()}")
    info4 = _parse_route_get(out4)
    wan_v4 = info4.get("src")
    wan_if = info4.get("dev")
    if not wan_v4 or not wan_if:
        raise RuntimeError(f"Failed to parse WAN IPv4/dev from route-get: {out4}")
    print(json.dumps({"step": "wan-ipv4", "wan_if": wan_if, "wan_v4": wan_v4}))

    # --- IPv4 validation ---
    ok, reason = _tcp_check(wan_v4, 22, timeout=5.0)
    print(json.dumps({"step":"tcp-precheck","target":"wan_v4","host":wan_v4,"port":22,"ok":ok,"reason":reason}))
    _expect_allow(wan_v4, ssh_user, ssh_passwd, "echo WAN_V4_OK", wan_timeout)

    # --- Decide whether to run IPv6 steps ---
    do_ipv6 = True
    if _norm(test_profile) == "lab":
        do_ipv6 = False
    if _is_false(enable_ipv6):
        do_ipv6 = False

    wan_v6_global = None
    wan_v6_ll = None

    if do_ipv6:
        # Discover WAN IPv6 global via route-get
        rc, out6r, raw6r, err6r, sec6r = _ssh_exec(lan_ip, ssh_user, ssh_passwd, "ip -6 route get 2001:4860:4860::8888", timeout_sec)
        print(json.dumps({"step": "wan-route6", "rc": rc, "sec": sec6r, "stdout": out6r[-400:], "raw_stdout_tail": raw6r[-200:], "stderr": err6r[-200:]}))
        if rc != 0:
            if _norm(enable_ipv6) == "auto":
                do_ipv6 = False
                print(json.dumps({"step":"ipv6-skipped","reason":"no_ipv6_route","profile":test_profile}))
            else:
                raise RuntimeError(f"Failed to discover WAN route ipv6 rc={rc}: {err6r.strip()}")
        else:
            info6 = _parse_route_get(out6r)
            wan_v6_global = info6.get("src")
            # optional: keep wan_if from ipv4; route-get might also output dev
            if not wan_v6_global:
                if _norm(enable_ipv6) == "auto":
                    do_ipv6 = False
                    print(json.dumps({"step":"ipv6-skipped","reason":"no_ipv6_src","profile":test_profile}))
                else:
                    raise RuntimeError(f"Failed to parse WAN global IPv6 from route-get: {out6r}")
            else:
                print(json.dumps({"step":"wan-ipv6-global","wan_if":wan_if,"wan_v6_global":wan_v6_global}))

    if do_ipv6:
        # Discover WAN link-local on WAN interface
        rc, out6a, raw6a, err6a, sec6a = _ssh_exec(lan_ip, ssh_user, ssh_passwd, f"ip -6 addr show dev {wan_if}", timeout_sec)
        print(json.dumps({"step":"wan-ipv6-addrs","rc":rc,"sec":sec6a,"stdout":out6a[-500:],"raw_stdout_tail":raw6a[-200:],"stderr":err6a[-200:]}))
        if rc != 0:
            if _norm(enable_ipv6) == "auto":
                do_ipv6 = False
                print(json.dumps({"step":"ipv6-skipped","reason":"no_ipv6_addr_on_wan","profile":test_profile}))
            else:
                raise RuntimeError(f"Failed to query WAN iface ipv6 addrs rc={rc}: {err6a.strip()}")
        else:
            addrs = _parse_ipv6_addrs_on_iface(out6a)
            wan_v6_ll = addrs.get("link_local")
            if not wan_v6_ll:
                if _norm(enable_ipv6) == "auto":
                    do_ipv6 = False
                    print(json.dumps({"step":"ipv6-skipped","reason":"no_linklocal","profile":test_profile}))
                else:
                    raise RuntimeError(f"Failed to find WAN link-local IPv6 on iface {wan_if}")
            else:
                print(json.dumps({"step":"wan-ipv6-linklocal","wan_if":wan_if,"wan_v6_ll":wan_v6_ll}))

    if do_ipv6:
        ok6, reason6 = _tcp_check(wan_v6_global, 22, timeout=5.0)
        print(json.dumps({"step":"tcp-precheck","target":"wan_v6_global","host":wan_v6_global,"port":22,"ok":ok6,"reason":reason6}))
        _expect_allow(wan_v6_global, ssh_user, ssh_passwd, "echo WAN_V6_GLOBAL_OK", wan_timeout)

        ll_target = f"{wan_v6_ll}%{lan_iface}"
        _expect_deny(ll_target, ssh_user, ssh_passwd, "echo SHOULD_NOT_RUN", timeout_sec)
    else:
        print(json.dumps({"step":"ipv6-skipped-final","profile":test_profile,"enable_ipv6":enable_ipv6}))

    print(json.dumps({"ok": True, "case": "C15807129"}))
    return 0


if __name__ == "__main__":
    raise SystemExit(run())
