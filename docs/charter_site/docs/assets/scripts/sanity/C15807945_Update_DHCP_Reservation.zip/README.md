# C15807945_Update_DHCP_Reservation

## 1) 目的 / 覆蓋範圍
- 驗證 DHCP reservation 的新增/更新/刪除或 reset 後行為。

## 2) 前置條件 / 環境
- 需可透過平台/工具對 DHCP reservation API 操作。
- 注意：若目標 IP 已被占用，可能回 422（例如 used by Netgear）。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- （manifest 未包含常見 env 或解析不到；可直接查看 zip 內 manifest.yaml）

## 5) PASS/FAIL 判定
- PASS：reservation 操作成功且驗證點符合預期。
- FAIL：422/衝突或驗證點不符（需看 log）。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807945_Update_DHCP_Reservation

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807945_Update_DHCP_Reservation

## Purpose
Update an existing DHCP reservation (same **MAC**) from **OLD IPv4** to **NEW IPv4** and validate end-to-end:
- **precondition()** builds a baseline reservation (**MAC → OLD_IP**) (cycle #1 only)
- The test cycle updates the reservation to **MAC → NEW_IP** via NOC API
- CPE runtime reflects the update (reserved/leased tables show **NEW_IP**)
- LAN client renews and obtains **NEW_IP** and can ping

## Topology
Control PC (this runner) ↔ LAN (wired) ↔ CPE router

## Key dependencies (external tools)
- `cpe_info` : readiness + node-id
- NOC DHCP reservation APIs: direct HTTP calls in `lib/dhcp_api.py` (profile/secrets via `PROFILES_FILE`)
- `cpe_ssh.py` : query DHCP tables from CPE over SSH
- `lan_macvlan.py` : create isolated LAN client, renew DHCP, report IPv4 + ping

## Precondition behavior (cycle #1 only)
1. Readiness check via `cpe_info -status` (poll until `CLOUD_READY_TIMEOUT_SEC`)
2. If not ready: set serial mute then PDU reset once, then retry readiness
3. Resolve node-id via `cpe_info --node-id`
4. Ensure SSH is ready (scan port 22; if closed: NOC `ssh-enable`; then probe `uptime`)
5. Cleanup NOC DHCP reservations (default: clear **ALL** reservations in this lab location)
6. Create baseline reservation for `LAN_TEST_MAC` → `TEST_RESERVED_IP_OLD` (`TEST_HOSTNAME`)
7. Verify CPE reserved table contains the baseline entry, then renew LAN client and verify leased table matches **OLD_IP**

## Test cycle flow (Update)
1. Update reservation via NOC API: `LAN_TEST_MAC` → `TEST_RESERVED_IP_NEW`
2. **Wait a few seconds** after update (`WAIT_AFTER_RESERVATION_UPDATE_SEC`, default 5s)
3. Verify NOC reservation reflects **NEW_IP** (poll: `UPDATE_VERIFY_TIMEOUT_SEC/INTERVAL_SEC`)
4. Verify CPE reserved table reflects **NEW_IP** (poll)
5. Renew LAN client and assert it gets **NEW_IP** (and ping OK)
6. Verify CPE leased table eventually reflects **NEW_IP**

## Notes
- If `FORCE_DHCPRELEASE_ON_UPDATE=1` (default), the LAN renew step uses `lan_macvlan.py --release-then-renew` to send DHCPRELEASE (dhclient -r) before requesting a fresh lease. Ensure your `tools/lan_macvlan.py` is updated to support this flag.
- Do not store secrets in the script zip. Provide NOC/CPE passwords via `PROFILES_FILE` or environment variables.
- For `lan_macvlan.py`, prefer `LAN_TEST_IFACE=auto` to avoid interface-name collisions.
- `WAIT_AFTER_RESERVATION_UPDATE_SEC` exists because reservation enforcement can be eventually consistent.
```

```
