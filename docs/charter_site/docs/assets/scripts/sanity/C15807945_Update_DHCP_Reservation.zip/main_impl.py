#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""C15807945_Update_DHCP_Reservation

Automation replaces UI steps with NOC DHCP reservation APIs and replaces
serial-console `ovsh s DHCP_*` checks with SSH DHCP dumps (`tools/cpe_ssh.py`).

User requirements baked into this script:
- Cleanup scope: default to "clear ALL" NOC DHCP reservations (lab location)
- In precondition(): build 1 baseline DHCP reservation (MAC → OLD_IP)
- In run(): update the reservation to NEW_IP, then WAIT a few seconds before verification
"""

import os
import secrets
import time
from typing import Any, Dict, List, Optional, Tuple

from lib.util import jlog
from lib.precondition import precondition as _cpe_precondition
from lib.dhcp_api import (
    dhcp_resv_set,
    dhcp_resv_del_best_effort,
    dhcp_resv_list,
    ensure_ip_not_reserved,
    dhcp_resv_clear_all_best_effort,
)
from lib.dhcp_verify import (
    assert_reserved,
    lan_renew_and_assert_ip,
    wait_for_lease,
    get_dhcp_tables,
)

_NODE_ID: Optional[str] = None


def gen_laa_mac() -> str:
    """Generate a locally-administered, unicast MAC (02:xx:xx:xx:xx:xx)."""
    b = bytearray(secrets.token_bytes(6))
    b[0] = 0x02
    return ":".join(f"{x:02x}" for x in b)


def ensure_test_mac() -> str:
    """Ensure a MAC is available for this run."""
    mac = (os.environ.get("LAN_TEST_MAC") or os.environ.get("TEST_MAC") or "").strip()
    if not mac:
        mac = gen_laa_mac()
        os.environ["LAN_TEST_MAC"] = mac
        os.environ["TEST_MAC"] = mac
    return mac


def _norm_mac(x: str) -> str:
    return (x or "").strip().lower()


def _used_ips_from_dhcp_tables(data: Dict[str, Any]) -> set:
    """Collect IPs in use from CPE DHCP reserved/leased tables."""
    reserved = data.get("reserved") or data.get("dhcp", {}).get("reserved") or []
    leased = data.get("leased") or data.get("dhcp", {}).get("leased") or []

    used = set()
    for r in reserved or []:
        ip = str(r.get("ip_addr") or r.get("ip") or "").strip()
        if ip:
            used.add(ip)
    for l in leased or []:
        ip = str(l.get("inet_addr") or l.get("ip_addr") or l.get("ip") or "").strip()
        if ip:
            used.add(ip)
    return used


def pick_free_ip(preferred_ip: str, used: set) -> str:
    """Pick a free IP in the same /24 by scanning upward, then wrapping."""
    preferred_ip = (preferred_ip or "").strip()
    if not preferred_ip or preferred_ip not in used:
        return preferred_ip

    parts = preferred_ip.split(".")
    if len(parts) != 4:
        return preferred_ip

    base = ".".join(parts[:3])
    try:
        start = int(parts[3])
    except Exception:
        return preferred_ip

    def cand(n: int) -> str:
        return f"{base}.{n}"

    for n in range(start + 1, 255):
        if n in (0, 1, 255):
            continue
        ip = cand(n)
        if ip not in used:
            return ip

    for n in range(2, max(2, start)):
        if n in (0, 1, 255):
            continue
        ip = cand(n)
        if ip not in used:
            return ip

    return preferred_ip


def _extract_reservations_list(j: Any) -> List[Dict[str, Any]]:
    if j is None:
        return []
    if isinstance(j, list):
        return [x for x in j if isinstance(x, dict)]
    if isinstance(j, dict):
        for k in ("reservations", "items", "data"):
            v = j.get(k)
            if isinstance(v, list):
                return [x for x in v if isinstance(x, dict)]
    return []


def _noc_reservations(node_id: str) -> List[Dict[str, Any]]:
    return _extract_reservations_list(dhcp_resv_list(node_id))


def _noc_item_mac(it: Dict[str, Any]) -> str:
    return _norm_mac(str(it.get("mac") or it.get("id") or it.get("deviceMac") or ""))


def _noc_item_ip(it: Dict[str, Any]) -> str:
    return str(it.get("ip") or it.get("reservedIp") or it.get("reserved_ip") or "").strip()


def _cpe_reserved_has(mac: str, ip: str, dhcp_dump: Dict[str, Any]) -> bool:
    mac_n = _norm_mac(mac)
    ip_n = (ip or "").strip()
    reserved = dhcp_dump.get("reserved") or dhcp_dump.get("dhcp", {}).get("reserved") or []
    for r in reserved or []:
        if not isinstance(r, dict):
            continue
        m = _norm_mac(str(r.get("hw_addr") or r.get("mac") or ""))
        rip = str(r.get("ip_addr") or r.get("ip") or "").strip()
        if m == mac_n and rip == ip_n:
            return True
    return False


def _wait_until(event: str, fn, timeout_sec: float, interval_sec: float, **ctx) -> None:
    t0 = time.time()
    attempt = 0
    last_info: Any = None
    while time.time() - t0 < timeout_sec:
        attempt += 1
        try:
            ok, info = fn()
            last_info = info
            jlog(event, ok=ok, attempt=attempt, elapsed_sec=round(time.time() - t0, 2), **ctx, **(info or {}))
            if ok:
                return
        except Exception as e:
            last_info = {"error": str(e)}
            jlog(event, ok=False, attempt=attempt, elapsed_sec=round(time.time() - t0, 2), **ctx, error=str(e))
        time.sleep(max(0.2, interval_sec))

    raise RuntimeError(f"timeout_waiting_for_{event} last={last_info!r}")


def _env_ip(name: str, fallback_names: List[str]) -> str:
    for k in [name] + (fallback_names or []):
        v = (os.environ.get(k) or "").strip()
        if v:
            return v
    return ""


def precondition() -> Dict[str, Any]:
    """Cycle #1 only: ensure CPE ready + SSH ready, then build baseline reservation (OLD_IP)."""
    global _NODE_ID

    _NODE_ID = _cpe_precondition()

    test_name = os.environ.get("TEST_NAME", "C15807945_Update_DHCP_Reservation")
    mac = ensure_test_mac()
    hostname = (os.environ.get("TEST_HOSTNAME") or "").strip()

    old_ip = _env_ip("TEST_RESERVED_IP_OLD", ["TEST_RESERVED_IP"])
    new_ip = _env_ip("TEST_RESERVED_IP_NEW", [])

    if not mac or not hostname or not old_ip or not new_ip:
        raise RuntimeError("missing_env: require TEST_HOSTNAME + TEST_RESERVED_IP_OLD + TEST_RESERVED_IP_NEW; LAN_TEST_MAC optional")

    jlog("baseline_start", test=test_name, mac=mac, ip=old_ip, hostname=hostname)

    # 0) Clear ALL cloud DHCP reservations in this location (best-effort)
    if int(os.environ.get("CLEAR_ALL_NOC_DHCP_RESERVATIONS", "0") or "0") == 1:
        prefix = (os.environ.get("CLEAR_ALL_NOC_DHCP_RESERVATIONS_HOSTNAME_PREFIX") or "").strip()
        dhcp_resv_clear_all_best_effort(_NODE_ID, hostname_prefix=prefix)

    # 0.1) If preferred OLD/NEW IP is already in-use on CPE, pick a free one (same /24)
    if int(os.environ.get("AUTO_PICK_FREE_IP", "0") or "0") == 1:
        try:
            data = get_dhcp_tables()
            used = _used_ips_from_dhcp_tables(data or {})

            # OLD
            chosen_old = pick_free_ip(old_ip, used)
            if chosen_old and chosen_old != old_ip:
                jlog("ip_autopick", preferred_ip=old_ip, chosen_ip=chosen_old, reason="ip_in_use_on_cpe", which="old")
                old_ip = chosen_old

            # reserve the chosen OLD in used set so NEW won't collide
            if old_ip:
                used.add(old_ip)

            # NEW
            if new_ip == old_ip:
                used.add(new_ip)
            chosen_new = pick_free_ip(new_ip, used)
            if chosen_new and chosen_new != new_ip:
                jlog("ip_autopick", preferred_ip=new_ip, chosen_ip=chosen_new, reason="ip_in_use_on_cpe", which="new")
                new_ip = chosen_new

        except Exception as e:
            jlog("ip_autopick_skip", error=str(e))

    # persist effective IPs
    os.environ["TEST_RESERVED_IP_OLD"] = old_ip
    os.environ["TEST_RESERVED_IP_NEW"] = new_ip

    # 1) cleanup best-effort (by this run's MAC)
    dhcp_resv_del_best_effort(_NODE_ID, mac)

    # 2) ensure target OLD IP is not reserved by another MAC (best-effort)
    ensure_ip_not_reserved(_NODE_ID, old_ip, mac)

    # 3) add baseline reservation (OLD)
    dhcp_resv_set(_NODE_ID, mac, old_ip, hostname)

    # 4) verify reservation exists on CPE (reserved table)
    assert_reserved(mac, old_ip, hostname)

    wait_after_set = float(os.environ.get("WAIT_AFTER_RESERVATION_SET_SEC", "5") or "5")
    if wait_after_set > 0:
        jlog("wait_after_reservation_set", seconds=wait_after_set)
        time.sleep(wait_after_set)

    # 5) renew LAN client and assert it gets OLD_IP
    if int(os.environ.get("SKIP_LAN_RENEW", "0") or "0") != 1:
        lan_renew_and_assert_ip(mac, old_ip)
        wait_for_lease(mac, old_ip)
    else:
        jlog("skip_lan_renew", reason="SKIP_LAN_RENEW=1")

    os.environ["BASELINE_RESERVED_IP"] = old_ip
    os.environ["BASELINE_MAC"] = mac
    os.environ["UPDATE_TARGET_IP"] = new_ip

    jlog("baseline_end", ok=True, mac=mac, ip=old_ip, hostname=hostname)
    return {"node_id": _NODE_ID, "mac": mac, "old_ip": old_ip, "new_ip": new_ip, "hostname": hostname}


def run(cycle=None, total=None) -> int:
    """One cycle execution."""
    global _NODE_ID

    test_name = os.environ.get("TEST_NAME", "C15807945_Update_DHCP_Reservation")
    mac = ensure_test_mac()
    hostname = (os.environ.get("TEST_HOSTNAME") or "").strip()

    old_ip = _env_ip("BASELINE_RESERVED_IP", ["TEST_RESERVED_IP_OLD", "TEST_RESERVED_IP"])
    new_ip = _env_ip("UPDATE_TARGET_IP", ["TEST_RESERVED_IP_NEW"])

    if not _NODE_ID:
        _NODE_ID = _cpe_precondition()

    jlog(
        "test_start",
        test=test_name,
        cycle=cycle,
        total=total,
        mac=mac,
        old_ip=old_ip,
        new_ip=new_ip,
        hostname=hostname,
    )

    if not mac or not hostname or not old_ip or not new_ip:
        raise RuntimeError("missing_env: require TEST_HOSTNAME + TEST_RESERVED_IP_OLD + TEST_RESERVED_IP_NEW")

    # 1) Update reservation: MAC -> NEW_IP (NOC API)
    jlog("dhcp_resv_update_start", mac=mac, old_ip=old_ip, new_ip=new_ip)
    dhcp_resv_set(_NODE_ID, mac, new_ip, hostname)
    jlog("dhcp_resv_update_set_ok", ok=True, mac=mac, new_ip=new_ip)

    # 2) Wait a few seconds after update (user request)
    wait_after_update = float(os.environ.get("WAIT_AFTER_RESERVATION_UPDATE_SEC", "5") or "5")
    if wait_after_update > 0:
        jlog("wait_after_reservation_update", seconds=wait_after_update)
        time.sleep(wait_after_update)

    # 3) Verify update propagation (polling)
    timeout = float(os.environ.get("UPDATE_VERIFY_TIMEOUT_SEC", "90") or "90")
    interval = float(os.environ.get("UPDATE_VERIFY_INTERVAL_SEC", "5") or "5")
    mac_n = _norm_mac(mac)

    def _noc_check() -> Tuple[bool, Dict[str, Any]]:
        items = _noc_reservations(_NODE_ID)
        hit = None
        for it in items:
            if _noc_item_mac(it) == mac_n:
                hit = it
                break
        if not hit:
            return False, {"noc_count": len(items), "reason": "mac_not_found"}
        ip = _noc_item_ip(hit)
        ok = (ip == new_ip)
        return ok, {"noc_count": len(items), "noc_ip": ip}

    _wait_until("verify_noc_reservation_updated", _noc_check, timeout, interval, mac=mac, expect_ip=new_ip)

    def _cpe_check() -> Tuple[bool, Dict[str, Any]]:
        d = get_dhcp_tables()
        ok = _cpe_reserved_has(mac, new_ip, d or {})
        reserved = d.get("reserved") or d.get("dhcp", {}).get("reserved") or []
        return ok, {"cpe_reserved_count": (len(reserved) if isinstance(reserved, list) else None)}

    _wait_until("verify_cpe_reserved_updated", _cpe_check, timeout, interval, mac=mac, expect_ip=new_ip)

    # 4) Renew LAN client and assert it gets NEW_IP (and ping OK)
    if int(os.environ.get("SKIP_LAN_RENEW", "0") or "0") != 1:
        force_rel = int(os.environ.get("FORCE_DHCPRELEASE_ON_UPDATE", "1") or "1") == 1
        lan_renew_and_assert_ip(mac, new_ip, release_then_renew=force_rel)
        # 5) Verify leased table eventually reflects NEW_IP
        wait_for_lease(mac, new_ip)
    else:
        jlog("skip_lan_renew", reason="SKIP_LAN_RENEW=1")

    jlog("test_end", test=test_name, ok=True)
    return 0


if __name__ == "__main__":
    import sys

    sys.exit(run())
