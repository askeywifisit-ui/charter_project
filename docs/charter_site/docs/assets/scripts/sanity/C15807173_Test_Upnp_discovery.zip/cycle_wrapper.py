#!/usr/bin/env python3
"""Generic cycle wrapper.

Reads env:
  - CYCLES
  - CYCLE_INTERVAL
  - STOP_ON_FAIL
  - ORIGINAL_ENTRY (e.g. "main_impl_orig.py:run")

Runs the entry once per cycle.
"""

import importlib
import json
import os
import sys
import time


def _parse_bool(val, default=False):
    if val is None:
        return default
    s = str(val).strip().lower()
    return s in ("1", "true", "yes", "y", "on")


def _resolve_entry(entry: str):
    if not entry or ":" not in entry:
        raise ValueError(f"Bad ORIGINAL_ENTRY: {entry!r}")
    mod_name, func_name = entry.split(":", 1)
    if mod_name.endswith(".py"):
        mod_name = mod_name[:-3]
    mod = importlib.import_module(mod_name)
    func = getattr(mod, func_name)
    return func


def run() -> int:
    cycles = int(os.environ.get("CYCLES", "1"))
    interval = int(os.environ.get("CYCLE_INTERVAL", "30"))
    stop_on_fail = _parse_bool(os.environ.get("STOP_ON_FAIL", "1"), default=True)
    entry = os.environ.get("ORIGINAL_ENTRY", "main_impl_orig.py:run")

    try:
        func = _resolve_entry(entry)
    except Exception as e:
        print(json.dumps({"event": "entry_resolve_error", "entry": entry, "error": str(e)}), flush=True)
        return 1

    overall_rc = 0
    for i in range(cycles):
        print(json.dumps({"event": "cycle_start", "cycle": i + 1, "total": cycles}), flush=True)
        try:
            rc = func()
        except SystemExit as se:
            rc = int(se.code or 0)
        except Exception as e:
            print(json.dumps({"event": "cycle_exception", "cycle": i + 1, "error": str(e)}), flush=True)
            rc = 1

        try:
            rc = int(rc)
        except Exception:
            rc = 1

        print(json.dumps({"event": "cycle_end", "cycle": i + 1, "rc": rc}), flush=True)
        if rc != 0:
            overall_rc = rc
            if stop_on_fail:
                break

        if i < cycles - 1 and interval > 0:
            time.sleep(interval)

    print(json.dumps({"event": "all_cycles_done", "rc": overall_rc}), flush=True)
    return overall_rc


if __name__ == "__main__":
    sys.exit(run())
