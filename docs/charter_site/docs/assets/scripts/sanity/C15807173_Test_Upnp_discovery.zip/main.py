#!/usr/bin/env python3
import sys
import main_impl

if __name__ == '__main__':
    sys.exit(main_impl.run())
