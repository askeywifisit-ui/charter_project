#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""C15807173 - Test Upnp discovery

PDF sanity_plan page 70-71 summary:
- Enable UPnP in Plume NOC.
- Verify miniupnpd process exists on router.
- From LAN client, run upnpc to discover IGD.
- Capture SSDP notify packets (udp/1900):
  - when ON: NTS: ssdp:alive
  - when OFF: NTS: ssdp:byebye

This script automates with:
- noc_api_cli: upnp_status/upnp_set
- cpe_ssh (via tools/cpe_ssh.py module): run ps | grep miniupnpd
- LAN client checks: upnpc + tcpdump

All logs as one-line JSON.
"""

import json
import os
import re
import shlex
import subprocess
import sys
import time
import traceback
from typing import Dict, Optional, Tuple

TOOLS_PATH = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
if TOOLS_PATH and TOOLS_PATH not in sys.path:
    sys.path.insert(0, TOOLS_PATH)

try:
    import noc_api_cli as api  # type: ignore
except Exception as e:
    api = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "noc_api_cli", "error": str(e)}), flush=True)

try:
    import cpe_ssh  # type: ignore
except Exception as e:
    cpe_ssh = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "cpe_ssh", "error": str(e)}), flush=True)


def jlog(step: str, **kv):
    print(json.dumps({"step": step, **kv}, ensure_ascii=False), flush=True)


def _getenv(k: str, default: str = "") -> str:
    v = os.environ.get(k)
    return default if v is None else str(v)


def _bool_env(k: str, default: bool = False) -> bool:
    v = os.environ.get(k)
    if v is None:
        return default
    return str(v).strip().lower() in ("1", "true", "yes", "y", "on")


def _run(cmd, timeout: float = 60.0, env=None) -> Dict[str, object]:
    t0 = time.time()
    try:
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout, env=env)
        sec = time.time() - t0
        out = p.stdout or ""
        err = p.stderr or ""
        js = None
        try:
            js = json.loads(out) if out.strip().startswith("{") else None
        except Exception:
            js = None
        return {"ok": p.returncode == 0, "rc": p.returncode, "sec": sec, "stdout": out, "stderr": err, "json": js}
    except subprocess.TimeoutExpired as e:
        sec = time.time() - t0
        out = (e.stdout or "")
        err = (e.stderr or "")
        return {"ok": False, "rc": 124, "sec": sec, "stdout": out, "stderr": (str(err) + "\nTIMEOUT").strip(), "json": None}


def _rc(r: Dict[str, object]) -> int:
    v = r.get("rc")
    try:
        return int(v) if v is not None else 1
    except Exception:
        return 1


# ----------------------
# NOC helpers
# ----------------------

_CACHE: Dict[str, object] = {}


def _load_noc_profile(profile_name: str) -> Optional[Dict[str, str]]:
    path = (
        os.environ.get("NOC_PROFILES_PATH")
        or os.environ.get("PROFILES_FILE")
        or os.path.expanduser("~/.secrets/noc_profiles.json")
    )
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        jlog("noc-profile-load-error", profile=profile_name, path=path, error=str(e))
        return None

    prof = data.get(profile_name) or data.get(profile_name.upper())
    if not prof:
        jlog("noc-profile-load-error", profile=profile_name, path=path, error="profile not found")
        return None

    return {
        "base": prof.get("base"),
        "email": prof.get("email"),
        "password": prof.get("password"),
        "customer_id": prof.get("customer_id") or prof.get("customerId") or prof.get("CUSTOMER_ID"),
    }


def _noc_creds() -> Tuple[str, str, str]:
    base = _getenv("NOC_BASE", "").strip()
    email = _getenv("NOC_EMAIL", "").strip()
    password = _getenv("NOC_PASSWORD", "").strip()

    if base and email and password and "<fill>" not in (base + email + password):
        return base, email, password

    prof_name = _getenv("NOC_PROFILE", "").strip()
    if prof_name:
        prof = _load_noc_profile(prof_name)
        if prof and prof.get("base") and prof.get("email") and prof.get("password"):
            return str(prof["base"]), str(prof["email"]), str(prof["password"])

    raise RuntimeError("NOC credentials missing")


def _noc_customer_id() -> str:
    cid = _getenv("CUSTOMER_ID", "").strip()
    if cid and "<fill>" not in cid:
        return cid

    prof_name = _getenv("NOC_PROFILE", "").strip()
    prof = _load_noc_profile(prof_name) if prof_name else None
    cid2 = str((prof or {}).get("customer_id") or "").strip()
    if cid2:
        return cid2

    raise RuntimeError("CUSTOMER_ID missing (set env CUSTOMER_ID or put customer_id in noc_profiles.json profile)")


def _login() -> str:
    if "token" in _CACHE:
        return _CACHE["token"]  # type: ignore
    if api is None:
        raise RuntimeError("noc_api_cli not available")

    base, email, password = _noc_creds()
    bearer = _bool_env("NOC_BEARER", False)
    insecure = _bool_env("NOC_INSECURE", False)
    tok = api.login(base, email, password, bearer=bearer, insecure=insecure)
    _CACHE["token"] = tok
    jlog("login", ok=True)
    return tok


def _node_id() -> str:
    """Resolve node_id via cpe_info only (SSH-only workflow)."""
    if "node_id" in _CACHE:
        return _CACHE["node_id"]  # type: ignore

    cpe_info_tool = _getenv("CPE_INFO_TOOL", os.path.join(TOOLS_PATH, "cpe_info"))
    max_retries = int(_getenv("NODE_ID_MAX_RETRIES", "5"))
    interval = float(_getenv("NODE_ID_RETRY_INTERVAL_SEC", "2"))

    last_raw = ""
    for attempt in range(1, max_retries + 1):
        for extra_args in (["--node-id", "--value"], ["--node-id"]):
            cmd = [cpe_info_tool] + extra_args
            jlog("node-id-cpe_info-cmd", attempt=attempt, cmd=cmd)
            r0 = _run(cmd, timeout=20)
            raw0 = ((r0.get("stdout") or "") or (r0.get("stderr") or "")).strip()
            last_raw = raw0
            nid0 = raw0.replace(":", "").strip().lower()
            ok = (_rc(r0) == 0 and len(nid0) == 12 and all(c in "0123456789abcdef" for c in nid0))
            jlog("node-id-cpe_info", attempt=attempt, ok=ok, rc=_rc(r0), raw=raw0[:120], node_id=nid0 if ok else "")
            if ok:
                _CACHE["node_id"] = nid0
                jlog("node-id", ok=True, node_id=nid0, method="cpe_info")
                return nid0
        time.sleep(interval)

    raise RuntimeError(f"node-id failed via cpe_info: {last_raw[:200]}")


def _location_id(token: str, node_id: str) -> str:
    if "location_id" in _CACHE:
        return _CACHE["location_id"]  # type: ignore
    if api is None:
        raise RuntimeError("noc_api_cli not available")

    base, _, _ = _noc_creds()
    customer_id = _noc_customer_id()
    bearer = _bool_env("NOC_BEARER", False)
    insecure = _bool_env("NOC_INSECURE", False)

    loc = api.get_location_id(base, customer_id, node_id, token=token, bearer=bearer, insecure=insecure)
    _CACHE["location_id"] = loc
    jlog("location-id", ok=True, location_id=loc)
    return loc


def _wait_ssh_port_open(host: str, port: int = 22) -> bool:
    """Wait for SSH TCP port open (ref: C24532530).

    Env:
      SSH_PORT_MAX_RETRIES (default 10)
      SSH_PORT_INTERVAL_SEC (default 3)
      SSH_PORT_CHECK_TIMEOUT (default 3)
    """
    import socket

    max_retries = int(_getenv("SSH_PORT_MAX_RETRIES", "10"))
    interval_sec = float(_getenv("SSH_PORT_INTERVAL_SEC", "3"))
    check_timeout = float(_getenv("SSH_PORT_CHECK_TIMEOUT", "3"))

    last_err = ""
    for attempt in range(1, max_retries + 1):
        jlog("ssh-port-wait", host=host, port=port, attempt=attempt, max_retries=max_retries, timeout=check_timeout)
        try:
            with socket.create_connection((host, int(port)), timeout=check_timeout):
                jlog("ssh-port-wait-ok", host=host, port=port, attempt=attempt)
                return True
        except Exception as e:
            last_err = str(e)
            if attempt < max_retries:
                time.sleep(interval_sec)

    jlog("ssh-port-wait-failed", host=host, port=port, max_retries=max_retries, last_error=last_err)
    return False


def _enable_ssh(token: str, node_id: str, location_id: str) -> str:
    """Enable SSH via NOC so subsequent validations can use SSH."""
    if api is None:
        raise RuntimeError("noc_api_cli not available")

    base, _, _ = _noc_creds()
    customer_id = _noc_customer_id()
    passwd = _getenv("SSH_PASSWORD", "123456789")
    timeout_min = int(_getenv("SSH_TIMEOUT_MIN", "120"))
    bearer = _bool_env("NOC_BEARER", False)
    insecure = _bool_env("NOC_INSECURE", False)

    resp = api.ssh_enable(
        base,
        customer_id,
        location_id,
        node_id,
        passwd,
        timeout_min,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    jlog("ssh-enable", ok=True, resp=resp)
    return passwd


# ----------------------
# SSH miniupnpd check
# ----------------------

def _ssh_cmd(host: str, user: str, pw: str, cmd: str, timeout: float) -> Dict[str, object]:
    """SSH exec with exception safety."""
    try:
        if cpe_ssh is not None:
            rc, out, err, sec = cpe_ssh.ssh_exec(host, user, pw, cmd, timeout=timeout, login_shell=True)
            return {"ok": rc == 0, "rc": rc, "sec": sec, "stdout": out or "", "stderr": err or ""}
    except Exception as e:
        return {"ok": False, "rc": 255, "sec": 0.0, "stdout": "", "stderr": f"cpe_ssh_exec_exception: {e}"}

    # fallback
    ssh_cmd = [
        "sshpass", "-p", pw,
        "ssh", "-tt",
        "-o", "StrictHostKeyChecking=no",
        "-o", "UserKnownHostsFile=/dev/null",
        "-o", "LogLevel=ERROR",
        f"{user}@{host}",
        "sh", "-lc", cmd,
    ]
    return _run(ssh_cmd, timeout=max(8.0, timeout + 5.0))


def _cpe_ssh_tool_meta(host: str, user: str, pw: str, tool_cmd: str, timeout: float, extra: Optional[list] = None) -> Dict[str, object]:
    tool = _getenv("CPE_SSH_TOOL", os.path.join(TOOLS_PATH, "cpe_ssh.py"))
    cmd = ["python3", tool, "--host", host, "--user", user, "--password", pw, "--cmd", tool_cmd, "--timeout", str(int(timeout))]
    if extra:
        cmd.extend([str(x) for x in extra])
    r = _run(cmd, timeout=max(10.0, timeout + 15.0))
    out = (r.get("stdout") or "").strip()
    meta = None
    try:
        meta = json.loads(out) if out.startswith("{") else None
    except Exception:
        meta = None
    return {"ok": bool(r.get("ok")) and bool(meta), "rc": r.get("rc"), "meta": meta, "stdout_tail": out[-400:], "stderr_tail": str(r.get("stderr") or "")[-200:], "cmd": cmd}


def _miniupnpd_running(host: str, user: str, pw: str, timeout: float, expect: Optional[bool] = None) -> bool:
    """Check miniupnpd via SSH-only commands (no console).

    Note: avoid depending on cpe_ssh.py subcommands here because some environments
    may restrict / behave differently.
    """
    # Follow test plan / manual check style: `ps | grep miniupnpd`
    cmd = _getenv(
        "MINIUPNPD_CMD",
        "ps | grep miniupnpd",
    )
    r = _ssh_cmd(host, user, pw, cmd, timeout=timeout)
    out = ((r.get("stdout") or "") + "\n" + (r.get("stderr") or "")).strip()

    # Determine presence robustly:
    # - accept '/usr/sbin/miniupnpd' line
    # - ignore the grep process line
    lines = [ln.strip() for ln in out.splitlines() if ln.strip()]
    proc_lines = [ln for ln in lines if ("miniupnpd" in ln and "grep miniupnpd" not in ln)]
    found = bool(proc_lines)

    ok = found
    if expect is False:
        ok = not found
    elif expect is True:
        ok = found

    jlog(
        "miniupnpd",
        ok=ok,
        found=found,
        expect=expect,
        rc=r.get("rc"),
        cmd=cmd,
        proc_tail=proc_lines[-2:] if proc_lines else [],
        out_tail=out[-300:],
    )
    return ok


# ----------------------
# LAN client checks
# ----------------------

def _run_upnp_igd_tester(iface: str, target_ip: str) -> Dict[str, object]:
    tester = _getenv("UPNP_IGD_TESTER", os.path.join(TOOLS_PATH, "upnp_igd_tester.py"))
    timeout = float(_getenv("UPNP_IGD_TIMEOUT_SEC", "60"))
    port = int(_getenv("UPNP_IGD_TEST_PORT", "54321"))
    proto = (_getenv("UPNP_IGD_PROTOCOL", "TCP") or "TCP").strip().upper()

    cmd = ["python3", tester, "--iface", iface, "--target-ip", target_ip, "--port", str(port), "--protocol", proto]
    r = _run(cmd, timeout=max(15.0, timeout + 10.0))

    out = (r.get("stdout") or "").strip()
    err = (r.get("stderr") or "").strip()

    ok = False
    meta = None
    # tool prints a one-line JSON with event upnp-igd-tester-result
    for ln in (out.splitlines()[-80:]):
        ln = ln.strip()
        if ln.startswith("{") and "upnp-igd-tester-result" in ln:
            try:
                meta = json.loads(ln)
                ok = bool(meta.get("ok"))
                break
            except Exception:
                meta = None

    # Workaround: some CPE SOAP responses include garbage chars in NewInternalClient.
    # If tester fails with phase=port_query_verify but we can regex-extract the
    # expected LAN client IP from the 'got' field, treat as pass.
    relaxed = False
    if (not ok) and isinstance(meta, dict) and meta.get("phase") == "port_query_verify":
        local_ip = _ipv4_from_iface(iface)
        reason = str(meta.get("reason") or "")
        m = re.search(r"got\s+([0-9\.]+)", reason)
        got_ip = m.group(1) if m else ""
        if local_ip and got_ip and got_ip == local_ip:
            relaxed = True
            ok = True

    # Extract key lines from tester stdout for easier debugging
    key_lines = []
    mapping_line = ""
    for ln in out.splitlines():
        if "GetSpecificPortMappingEntry result" in ln:
            mapping_line = ln.strip()
        if any(k in ln for k in [
            "Selected (target-ip match)",
            "Found IGD service",
            "External IP reported by IGD",
            "AddPortMapping succeeded",
            "GetSpecificPortMappingEntry result",
            "Port mapping verification PASSED",
            "TEST PASSED",
            "TEST FAILED",
        ]):
            key_lines.append(ln.strip())
    # keep last ~8 key lines
    key_lines = key_lines[-8:]

    jlog(
        "upnp-igd-tester",
        ok=ok,
        relaxed=relaxed,
        rc=r.get("rc"),
        cmd=cmd,
        meta=meta,
        mapping_line=mapping_line,
        key_lines=key_lines,
        stdout_tail=out[-600:],
        stderr_tail=err[-300:],
    )
    return {
        "ok": ok,
        "relaxed": relaxed,
        "rc": r.get("rc"),
        "meta": meta,
        "mapping_line": mapping_line,
        "key_lines": key_lines,
        "out": out,
        "err": err,
    }


def _capture_ssdp(iface: str, timeout_sec: int, bpf: str) -> str:
    # tcpdump -A prints payload; -l line-buffer; -vv for headers.
    cmd = ["tcpdump", "-ni", iface, "-vv", "-A"] + shlex.split(bpf)
    try:
        cp = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout_sec)
        out = (cp.stdout or "")
        err = (cp.stderr or "")
        jlog("tcpdump", ok=True, rc=cp.returncode, cmd=cmd, stderr_tail=err[-200:])
        return out + "\n" + err
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or "")
        err = (e.stderr or "")
        jlog("tcpdump", ok=True, rc=124, cmd=cmd, timeout=True)
        return (out or "") + "\n" + (err or "")


def _ipv4_from_iface(iface: str) -> str:
    r = _run(["ip", "-4", "-o", "addr", "show", "dev", iface], timeout=5)
    out = (r.get("stdout") or "")
    m = re.search(r"\binet\s+(\d+\.\d+\.\d+\.\d+)/", out)
    return m.group(1) if m else ""


def _ssdp_msearch(iface: str, timeout_sec: float = 3.0, st: str = "ssdp:all") -> list[dict]:
    """Send SSDP M-SEARCH from iface IPv4 and collect responses."""
    import socket

    local_ip = _ipv4_from_iface(iface)
    if not local_ip:
        raise RuntimeError(f"cannot resolve IPv4 for iface {iface}")

    mcast_grp = "239.255.255.250"
    mcast_port = 1900

    msg = "\r\n".join([
        "M-SEARCH * HTTP/1.1",
        f"HOST: {mcast_grp}:{mcast_port}",
        'MAN: "ssdp:discover"',
        f"MX: {int(timeout_sec)}",
        f"ST: {st}",
        "",
        "",
    ]).encode("utf-8")

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind((local_ip, 0))
    sock.settimeout(timeout_sec)

    try:
        sock.sendto(msg, (mcast_grp, mcast_port))
        res = []
        while True:
            try:
                data, addr = sock.recvfrom(65535)
            except socket.timeout:
                break
            raw = data.decode(errors="ignore")
            headers = {}
            for line in raw.split("\r\n")[1:]:
                if not line or ":" not in line:
                    continue
                k, v = line.split(":", 1)
                headers[k.strip().lower()] = v.strip()
            res.append({"addr": addr[0], "port": addr[1], "headers": headers, "raw": raw[:400]})
        return res
    finally:
        sock.close()


def _ssdp_expect_target(iface: str, target_ip: str, expect_present: bool) -> bool:
    retries = int(_getenv("SSDP_MSEARCH_RETRIES", "3"))
    timeout = float(_getenv("SSDP_MSEARCH_TIMEOUT_SEC", "3"))
    sleep_sec = float(_getenv("SSDP_MSEARCH_RETRY_SLEEP_SEC", "3"))

    last = None
    for attempt in range(1, retries + 1):
        res = _ssdp_msearch(iface, timeout_sec=timeout, st="ssdp:all")
        hits = [r for r in res if r.get("addr") == target_ip]
        present = bool(hits)
        loc = (hits[0].get("headers") or {}).get("location") if hits else None
        jlog(
            "ssdp-msearch",
            attempt=attempt,
            expect_present=expect_present,
            present=present,
            hits=len(hits),
            location=loc,
        )
        last = {"present": present, "hits": hits[:2]}
        if present == expect_present:
            return True
        if attempt < retries:
            time.sleep(sleep_sec)

    jlog("ssdp-msearch-final", ok=False, last=last)
    return False


def _has_nts(payload: str, want: str) -> bool:
    # look for NTS: ssdp:alive / ssdp:byebye in payload
    return bool(re.search(r"\bNTS:\s*" + re.escape(want) + r"\b", payload or "", flags=re.I))


_MUTE_FILE = "/home/da40/charter/var/serial.mute"
_MUTE_LOCK_FILE = "/home/da40/charter/var/serial.mute.lock"


def _serial_mute(secs: int, reason: str = "reboot") -> None:
    """Mute serial/console access to avoid boot-time locks.

    Preferred: tools/serial_mute.py --set <secs>
    Fallback: write /home/da40/charter/var/serial.mute (=epoch seconds)
              optional lock file when REBOOT_MUTE_WITH_LOCK=1

    Also prints a JSON log with until epoch for observability.
    """
    try:
        secs = int(secs)
    except Exception:
        secs = 0
    secs = max(0, secs)
    until = int(time.time() + secs) if secs > 0 else 0

    tool = _getenv("SERIAL_MUTE_TOOL", os.path.join(TOOLS_PATH, "serial_mute.py"))

    # try tool first
    try:
        r = _run(["python3", tool, "--set", str(int(secs))], timeout=15)
        ok = bool(r.get("ok"))
        jlog(
            "serial-mute",
            ok=ok,
            method="serial_mute.py",
            rc=r.get("rc"),
            secs=int(secs),
            until=until,
            reason=reason,
            out_tail=str(r.get("stdout") or "")[-120:],
            err_tail=str(r.get("stderr") or "")[-120:],
        )
        if ok:
            return
    except Exception as e:
        jlog("serial-mute", ok=False, method="serial_mute.py", secs=int(secs), until=until, reason=reason, error=str(e))

    # fallback: file based
    try:
        os.makedirs(os.path.dirname(_MUTE_FILE), exist_ok=True)
        if until > 0:
            with open(_MUTE_FILE, "w") as f:
                f.write(str(until))
            try:
                os.chmod(_MUTE_FILE, 0o664)
            except Exception:
                pass

        with_lock = _bool_env("REBOOT_MUTE_WITH_LOCK", False)
        if with_lock and until > 0:
            try:
                with open(_MUTE_LOCK_FILE, "w") as f:
                    f.write(str(until))
                try:
                    os.chmod(_MUTE_LOCK_FILE, 0o664)
                except Exception:
                    pass
            except Exception:
                pass

        jlog(
            "serial-mute",
            ok=True,
            method="file",
            secs=int(secs),
            until=until,
            reason=reason,
            with_lock=bool(_bool_env("REBOOT_MUTE_WITH_LOCK", False)),
        )
    except Exception as e:
        jlog("serial-mute", ok=False, method="file", secs=int(secs), until=until, reason=reason, error=str(e))


def _cpe_ready_wait() -> bool:
    """Wait until cpe_info reports Internet Connected (and optionally Cloud Connected).

    During reboot/boot, cpe_info may hang; allow configurable timeout and treat TIMEOUT as "still booting".
    """
    if not _bool_env("CPE_READY_CHECK", True):
        jlog("cpe-ready-skip", ok=True, reason="env_disabled")
        return True

    tool = _getenv("CPE_INFO_TOOL", os.path.join(TOOLS_PATH, "cpe_info"))
    max_retries = int(_getenv("CPE_READY_MAX_RETRIES", "20"))
    interval = float(_getenv("CPE_READY_RETRY_INTERVAL_SEC", "6"))
    require_cloud = _bool_env("CPE_READY_REQUIRE_CLOUD", True)
    status_timeout = float(_getenv("CPE_INFO_STATUS_TIMEOUT_SEC", "20"))

    last = ""
    for attempt in range(1, max_retries + 1):
        r = _run([tool, "--status"], timeout=status_timeout)
        out = ((r.get("stdout") or "") + "\n" + (r.get("stderr") or "")).strip()
        last = out

        ok_inet = "Internet Status: Connected" in out
        ok_cloud = ("Cloud Status: Connected" in out) if require_cloud else True
        ok = (_rc(r) == 0 and ok_inet and ok_cloud)
        jlog("cpe-ready", attempt=attempt, ok=ok, inet=ok_inet, cloud=ok_cloud, rc=_rc(r), out_tail=out[-200:])
        if ok:
            return True
        if attempt < max_retries:
            time.sleep(interval)

    jlog("cpe-ready-failed", ok=False, last_tail=last[-240:])
    return False


def run() -> int:
    if api is None:
        raise RuntimeError("noc_api_cli not available")

    try:
        token = _login()
        node_id = _node_id()
        os.environ["NODE_ID"] = node_id
        location_id = _location_id(token, node_id)

        base, _, _ = _noc_creds()
        customer_id = _noc_customer_id()
        bearer = _bool_env("NOC_BEARER", False)
        insecure = _bool_env("NOC_INSECURE", False)

        # Precondition (per C00000001): enable SSH via NOC first, then wait port.
        if _bool_env("SSH_ENABLE_AT_START", True):
            _enable_ssh(token, node_id, location_id)

        # (Optional) wait until SSH port is reachable
        lan_ip = _getenv("SSH_HOST_LAN", "192.168.1.1").strip()
        _wait_ssh_port_open(lan_ip, 22)

    except Exception as e:
        jlog("fatal", ok=False, error=str(e))
        raise

    lan_ip = _getenv("SSH_HOST_LAN", "192.168.1.1").strip()
    ssh_user = _getenv("SSH_USER", "operator").strip()
    ssh_pw = _getenv("SSH_PASSWORD", "123456789")
    ssh_timeout = float(_getenv("SSH_TOOL_TIMEOUT", "20"))

    iface = (_getenv("LAN_IFACE", "") or _getenv("PING_IFACE", "eno2")).strip()
    if not iface:
        raise RuntimeError("missing LAN_IFACE")

    # Capture filter: add host filter to reduce noise
    bpf = _getenv("TCPDUMP_FILTER", "udp port 1900")
    if "host" not in bpf:
        bpf = f"({bpf}) and host {lan_ip}"

    # Workaround A: prepare logpull directory so worker fail-hook won't fail on /tmp/logpull missing
    try:
        _ssh_cmd(lan_ip, ssh_user, ssh_pw, "mkdir -p /tmp/logpull", timeout=ssh_timeout)
        jlog("prep", ok=True, what="mkdir_/tmp/logpull")
    except Exception as e:
        jlog("prep", ok=False, what="mkdir_/tmp/logpull", error=str(e))

    try:
        # Enable UPnP
        if _bool_env("UPNP_ENABLE_AT_START", True):
            # If enable triggers reboot, mute console noise before action
            if _bool_env("EXPECT_REBOOT_AFTER_UPNP_ENABLE", True):
                _serial_mute(int(_getenv("REBOOT_MUTE_SECS", "90")))

            jlog("upnp-set", action="enable")
            api.upnp_set(base, customer_id, location_id, enabled=True, token=token, bearer=bearer, insecure=insecure)
            time.sleep(float(_getenv("UPNP_APPLY_WAIT_SEC", "10")))

            # Wait CPE back (reboot) and SSH ready
            if _bool_env("EXPECT_REBOOT_AFTER_UPNP_ENABLE", True):
                if not _cpe_ready_wait():
                    raise RuntimeError("cpe not ready after upnp enable (expected reboot)")
                _wait_ssh_port_open(lan_ip, 22)

        st = api.upnp_status(base, customer_id, location_id, token=token, bearer=bearer, insecure=insecure)
        jlog("upnp-status", status=st)

        # Wait SSH port open before running validations
        _wait_ssh_port_open(lan_ip, 22)

        jlog("verify", phase="miniupnpd")

        # SSH probe gate (avoid silent failures)
        pr = _ssh_cmd(lan_ip, ssh_user, ssh_pw, "echo RG_SSH_OK", timeout=ssh_timeout)
        jlog("ssh-probe", ok=bool(pr.get("ok")), rc=pr.get("rc"), out_tail=str(pr.get("stdout") or "")[-120:], err_tail=str(pr.get("stderr") or "")[-120:])
        if not pr.get("ok"):
            raise RuntimeError("ssh probe failed")

        # miniupnpd running (retry)
        retries = int(_getenv("MINIUPNPD_RETRIES", "5"))
        interval = float(_getenv("MINIUPNPD_RETRY_INTERVAL_SEC", "3"))
        last_ok = False
        for attempt in range(1, retries + 1):
            ok = _miniupnpd_running(lan_ip, ssh_user, ssh_pw, timeout=ssh_timeout, expect=True)
            jlog("miniupnpd-check", attempt=attempt, ok=ok)
            last_ok = ok
            if ok:
                break
            if attempt < retries:
                time.sleep(interval)
        if not last_ok:
            raise RuntimeError("miniupnpd not running after enable")

        # Give miniupnpd a short extra settle window before real AddPortMapping test.
        upnp_ready_wait = float(_getenv("UPNP_READY_WAIT_SEC", "4") or "4")
        if upnp_ready_wait > 0:
            jlog("upnp-ready-wait", seconds=upnp_ready_wait)
            time.sleep(upnp_ready_wait)

        jlog("verify", phase="upnp_igd_tester")
        igd_retries = int(_getenv("UPNP_IGD_RETRIES", "3") or "3")
        igd_retry_wait = float(_getenv("UPNP_IGD_RETRY_WAIT_SEC", "3") or "3")
        igd = None
        last_meta = {}
        for attempt in range(1, igd_retries + 1):
            igd = _run_upnp_igd_tester(iface, target_ip=lan_ip)
            last_meta = igd.get("meta") or {}
            if igd.get("ok"):
                jlog("upnp-igd-tester-retry", attempt=attempt, ok=True)
                break

            reason = str(last_meta.get("reason") or "")
            phase = str(last_meta.get("phase") or "")
            retryable = ("SOAP fault unknown" in reason) or (phase == "other" and not reason)
            jlog("upnp-igd-tester-retry", attempt=attempt, ok=False, retryable=retryable, phase=phase, reason=reason)
            if (attempt < igd_retries) and retryable:
                time.sleep(igd_retry_wait)
                continue
            break

        if not (igd and igd.get("ok")):
            raise RuntimeError(f"upnp_igd_tester failed: phase={last_meta.get('phase')} reason={last_meta.get('reason')}")

        # SSDP M-SEARCH ON: expect SSDP response from target
        if _bool_env("REQUIRE_SSDP_MSEARCH_ON", True):
            jlog("verify", phase="ssdp_msearch_on")
            if not _ssdp_expect_target(iface, lan_ip, expect_present=True):
                # stimulus: rerun IGD tester once and try again
                jlog("stimulus", what="retest_upnp_igd_tester_once")
                _run_upnp_igd_tester(iface, target_ip=lan_ip)
                if not _ssdp_expect_target(iface, lan_ip, expect_present=True):
                    raise RuntimeError("SSDP M-SEARCH ON: no response from target")

        # (legacy) tcpdump alive capture (disabled by default)
        if _bool_env("REQUIRE_SSDP_ALIVE", False):
            jlog("verify", phase="ssdp_alive")
            cap_on = int(_getenv("TCPDUMP_TIMEOUT_ON_SEC", "180"))
            payload = _capture_ssdp(iface, cap_on, bpf)
            ok_alive = _has_nts(payload, "ssdp:alive")
            jlog("ssdp-alive", ok=ok_alive)
            if not ok_alive:
                raise RuntimeError("missing ssdp:alive in capture")

        # Disable UPnP and verify OFF (SSDP M-SEARCH should NOT see target)
        if _bool_env("UPNP_DISABLE_AT_END", True):
            # If disable triggers reboot, mute console noise before action
            if _bool_env("EXPECT_REBOOT_AFTER_UPNP_DISABLE", True):
                _serial_mute(int(_getenv("REBOOT_MUTE_SECS", "90")))

            jlog("upnp-set", action="disable")
            api.upnp_set(base, customer_id, location_id, enabled=False, token=token, bearer=bearer, insecure=insecure)

            # wait reboot + ready
            if _bool_env("EXPECT_REBOOT_AFTER_UPNP_DISABLE", True):
                time.sleep(float(_getenv("UPNP_APPLY_WAIT_SEC", "30")))
                if not _cpe_ready_wait():
                    raise RuntimeError("cpe not ready after upnp disable (expected reboot)")
                _wait_ssh_port_open(lan_ip, 22)
            else:
                time.sleep(2)

            if _bool_env("REQUIRE_SSDP_MSEARCH_OFF", True):
                jlog("verify", phase="ssdp_msearch_off")
                if not _ssdp_expect_target(iface, lan_ip, expect_present=False):
                    raise RuntimeError("SSDP M-SEARCH OFF: still got response from target")

            # (legacy) tcpdump byebye capture (disabled by default)
            if _bool_env("REQUIRE_SSDP_BYEBYE", False):
                cap_off = int(_getenv("TCPDUMP_TIMEOUT_OFF_SEC", "180"))
                payload = _capture_ssdp(iface, cap_off, bpf)
                ok_bye = _has_nts(payload, "ssdp:byebye")
                jlog("ssdp-byebye", ok=ok_bye)
                if not ok_bye:
                    raise RuntimeError("missing ssdp:byebye in capture")

            jlog("verify", phase="miniupnpd_stopped")

            # IMPORTANT: _miniupnpd_running(expect=False) returns True when miniupnpd is NOT found.
            # So we should fail only if it returns False.
            retries = int(_getenv("MINIUPNPD_STOP_RETRIES", "10"))
            interval = float(_getenv("MINIUPNPD_STOP_RETRY_INTERVAL_SEC", "3"))
            stopped_ok = False
            for attempt in range(1, retries + 1):
                ok = _miniupnpd_running(lan_ip, ssh_user, ssh_pw, timeout=ssh_timeout, expect=False)
                jlog("miniupnpd-stopped-check", attempt=attempt, ok=ok)
                stopped_ok = ok
                if ok:
                    break
                if attempt < retries:
                    time.sleep(interval)
            if not stopped_ok:
                raise RuntimeError("miniupnpd still running after disable")

        jlog("ok", case="C15807173")
        return 0
    except Exception as e:
        jlog("exception", ok=False, error=str(e), trace=traceback.format_exc()[-1200:])
        return 1


if __name__ == "__main__":
    raise SystemExit(run())
