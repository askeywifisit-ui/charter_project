# C15807242_Warehouse_Web_Page_should_load_with_Domain_Name

- Suite: **sanity**
- Script ID（可能因 delete/import 變動）：`11F_140=5209`
- 版本（manifest version）：`v3_mac_validate_rounds`
- Entrypoint：`cycle_wrapper.py:run`

> 本頁由工具依 11F_140 最新 export zip 自動產生/更新（2026-03-10）。

## 目的（Purpose）

（以腳本內實作為準；此頁主要提供快速落地的安裝/執行資訊。）


## 前置條件（Preconditions）

- 平台服務需正常（web/api/worker）
- tools 需可用（`/home/da40/charter/tools`）


## 需依環境替換（給外部單位）

以下參數通常因環境而異（請用 Environment Template / `.secrets` 注入）：

- `PROFILES_FILE` / `NOC_PROFILE` / `CUSTOMER_ID`
- `CPE_HOST` / `LAN_PARENT_IFACE` / `WIFI_IFACE` / `PING_IFACE`
- 任何 `*_PASSWORD` / `*_EMAIL` 一律不得寫死（用 `<fill>` 或 secrets）


## Key env quick reference

- `TOOLS_PATH`: `/home/da40/charter/tools`
- `PROFILES_FILE`: `/home/da40/charter/.secrets/noc_profiles.json`
- `NOC_PROFILE`: `SPECTRUM_INT`
- `CUSTOMER_ID`: `682d4e5179b80027cd6fb27e`
- `SSH_USER`: `operator`
- `SSH_PASSWORD`: `<fill>`
- `CPE_DEV`: `/dev/ttyUSB0`


## manifest.yaml（節錄：env）

```yaml
name: C15807242_Warehouse_Web_Page_should_load_with_Domain_Name
suite: sanity
version: v3_mac_validate_rounds
entrypoint: cycle_wrapper.py:run
env:
  PDU_OUTLET_ID: 1
  CPE_DEV: /dev/ttyUSB0
  WEB_SLEEP_SEC: '5'
  WEB_RETRIES: '15'
  CYCLES: '1'
  CYCLE_INTERVAL: '70'
  STOP_ON_FAIL: 1
  ORIGINAL_ENTRY: main_impl_orig.py:run
  CPE_READY_CHECK: '1'
  CPE_READY_REQUIRE_CLOUD: '1'
  CPE_READY_MAX_RETRIES: '5'
  CPE_READY_RETRY_INTERVAL_SEC: '3'
  PDU_RESET_ON_NOT_READY: '1'
  PDU_RESET_SCRIPT: /home/da40/charter/tools/pdu_outlet1.py
  PDU_RESET_ACTION: reset
  PDU_RESET_TIMEOUT_SEC: '600'
  PDU_RESET_WAIT_SEC: '120'
  TOOLS_PATH: /home/da40/charter/tools
  METRICS_TOOL: /home/da40/charter/tools/cpe_metrics_agent_serial.py
  NODE_ID_MAX_RETRIES: '10'
  NODE_ID_RETRY_INTERVAL_SEC: '3'
  NODE_ID_FALLBACK_CPE_INFO: '1'
  CPE_INFO_TOOL: ./cpe_info
  CPE_BAUD: '115200'
  CPE_USER: root
  CPE_PASSWORD: ''
  CUSTOMER_ID: 682d4e5179b80027cd6fb27e
  NOC_PROFILE: SPECTRUM_INT
  PROFILES_FILE: /home/da40/charter/.secrets/noc_profiles.json
  NOC_BASE: https://piranha-int.tau.dev-charter.net
  NOC_EMAIL: ''
  NOC_PASSWORD: ''
  BEARER: <fill>
  INSECURE: 0
  WAREHOUSE_HTTP_URLS: http://MyRouter/warehouse
  WAREHOUSE_EXPECT_HTTPS_URLS: https://myrouter/warehouse
  PRIMARY_WAREHOUSE_HTTPS_URL: https://myrouter/cgi-bin/warehouse.cgi
  WAREHOUSE_TOOL: /home/da40/charter/tools/cpe_warehouse_info.py
  WAREHOUSE_ID: ''
  WAREHOUSE_PASSWORD: ''
  WAREHOUSE_TIMEOUT_SEC: '3'
  WAREHOUSE_RETRIES: '15'
  WAREHOUSE_SLEEP_SEC: '5'
  REDIRECT_MATCH_MODE: strict
  ALLOW_RELATIVE_LOCATION: '1'
  CHECK_HTTP_REDIRECT: '1'
  RECHECK_REDIRECT_AFTER_WIFI: '1'
  REDIRECT_CHECK_FINAL: '1'
  REDIRECT_FINAL_TIMEOUT_SEC: '12'
  REDIRECT_RETRIES: '15'
  REDIRECT_SLEEP_SEC: '5'
  CHECK_DOMAIN_RESOLVE: '1'
  EXPECTED_LAN_IP: 192.168.1.1
  DOMAIN_RESOLVE_STRICT: '1'
  DOMAIN_RESOLVE_RETRIES: '30'
  DOMAIN_RESOLVE_SLEEP_SEC: '5'
  ENABLE_SSH_VIA_NOC: '1'
  SSH_ENABLE_TIMEOUT_MIN: '30'
  SSH_ENABLE_PASSWORD: <fill>
  SSH_ENABLE_WAIT_SEC: '30'
  VALIDATE_MACS_VIA_SSH: '1'
  MAC_VALIDATION_STRICT: '1'
  WAN_IFACES: br-wan
  LAN_IFACES: br-home,BR_LAN,br-lan
  ALLOW_WIFI5_WIFI6_SWAP: '1'
  WLAN5_IFACES: wifi1
  WLAN6_IFACES: wifi2
  SSH_HOST: ''
  SSH_USER: operator
  SSH_PASSWORD: <fill>
  SSH_TIMEOUT_SEC: '30'
  SSH_READY_RETRIES: '10'
  SSH_READY_SLEEP_SEC: '3'
  SSH_READY_TIMEOUT_SEC: '8'
  SSH_READY_CMD: echo ready
  SSH_IFCONFIG_RETRIES: '3'
  SSH_IFCONFIG_SLEEP_SEC: '3'
  SSH_IFCONFIG_MAX_TIMEOUT_SEC: '60'
  REQUIRED_FIELDS: 'Manufacturer,Model #,WAN MAC Address,LAN MAC Address,IPv4 Address,Default SSID,Default Password,Current
    SSID,Current Password'
  CHECK_DEFAULT_B64: '1'
  EXPECT_SAME_AS_DEFAULT: '1'
  DO_FACTORY_RESET: '1'
  FR_SETTLE_WAIT_SEC: '120'
  RESET_MUTE_SECS: '60'
  RESET_MUTE_WITH_LOCK: '1'
  CONSOLE_LOCK_TIMEOUT_SEC: '5'
  CONSOLE_LOCK_RETRY_TIMEOUT_SEC: '60'
  CONSOLE_LOCK_RETRY_INTERVAL_SEC: '3'
  FACTORY_RESET_MUTE_SECS: ''
  FACTORY_RESET_MUTE_WITH_LOCK: '0'
  FACTORY_RESET_MUTE_LOCK_TIMEOUT_SEC: '5'
  CHANGE_WIFI: '1'
  NEW_WIFI_SSID: QA_Auto_SSID
  NEW_WIFI_PASSWORD: <fill>
  WIFI_APPLY_WAIT_SEC: '60'
  MAC_VALIDATE_ROUNDS: '3'
  MAC_VALIDATE_ROUND_BACKOFF_SEC: '10'
```


## Run（建議 API 方式）

```bash
export CHARTER_BASE="http://<CONTROL_PC_IP>:5173"
SCRIPT_ID=<SCRIPT_ID_11F_140>
curl -sS -X POST "$CHARTER_BASE/api/scripts/$SCRIPT_ID/run" | python3 -m json.tool
```


## Artifacts / Evidence

```bash
RID=<RUN_ID>
curl -sS "$CHARTER_BASE/api/runs/$RID/log" > run_${RID}_log.json
curl -sS "$CHARTER_BASE/api/runs/$RID/log-archives" | python3 -m json.tool
# 若有 log archive：
curl -fsSL "$CHARTER_BASE/api/runs/$RID/log-archive" -o run_${RID}_cpe_log.tar.gz
```


## Cleanup

```bash
curl -sS -X DELETE "$CHARTER_BASE/api/runs/purge?older_than_days=0" | python3 -m json.tool
```
