#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
C15807130 - SSH should be allowed to local IP from WLAN Client

Preconditions (script-enforced):
  1) NOC login (token)
  2) serial metrics -> node_id (with retry)
  3) NOC API -> location_id
  4) kvConfigs PATCH -> enable SSHM + set sshAuthPasswd

Validations:
  - SSH to LAN IPv4: ALLOW
  - SSH to LAN Global IPv6: ALLOW (if present)
  - SSH to LAN Link-local IPv6: NOT allowed (if present)
"""

import os
import sys
import json
import time
import re
import subprocess
import shlex
from typing import Dict, Optional, Tuple


def _emit(step: str, **kv):
    payload = {"step": step, **kv}
    try:
        print(json.dumps(payload, ensure_ascii=False), flush=True)
    except Exception:
        print(str(payload), flush=True)




def _ping_iface(iface: str, target: str, count: int = 2, timeout_sec: int = 3) -> dict:
    cmd = ["ping", "-I", iface, "-c", str(int(count)), "-W", str(int(timeout_sec)), str(target)]
    r = _run_local(cmd, timeout=max(10, int(count) * int(timeout_sec) + 5))
    return {
        "ok": bool((r or {}).get("ok")),
        "rc": (r or {}).get("rc"),
        "iface": iface,
        "target": target,
        "stdout_tail": (r or {}).get("stdout", "")[-300:],
        "stderr_tail": (r or {}).get("stderr", "")[-200:],
    }
TOOLS_PATH = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
if TOOLS_PATH and TOOLS_PATH not in sys.path:
    sys.path.insert(0, TOOLS_PATH)

try:
    import noc_api_cli as api  # type: ignore
except Exception as e:
    api = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "noc_api_cli", "error": str(e)}))

try:
    import cpe_ssh  # type: ignore
except Exception as e:
    cpe_ssh = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "cpe_ssh", "error": str(e)}))



# ------------------------------
# Quiet stdout: marker wrapper
# ------------------------------
MARK_BEGIN = "__RG_BEGIN__"
MARK_END   = "__RG_END__"

def _wrap_cmd(cmd: str) -> str:
    """Wrap remote cmd with markers so we can extract output even if SSH server prints banners."""
    wrapped = f"echo {MARK_BEGIN}; {cmd}; echo {MARK_END}"
    return "sh -lc " + shlex.quote(wrapped)

def _extract_marked(stdout: str) -> str:
    if not stdout:
        return ""
    b = stdout.find(MARK_BEGIN)
    e = stdout.find(MARK_END)
    if b == -1 or e == -1 or e < b:
        return stdout.strip()
    b2 = b + len(MARK_BEGIN)
    return stdout[b2:e].strip("\n\r ")

def _ssh_exec_marked(host: str, user: str, pw: str, cmd: str, timeout: float, login_shell: bool = True):
    """Return (rc, extracted_stdout, raw_stdout, stderr, sec)."""
    if cpe_ssh is None:
        raise RuntimeError("cpe_ssh not available")
    wrapped = _wrap_cmd(cmd)
    rc, out, err, sec = cpe_ssh.ssh_exec(host, user, pw, wrapped, timeout=timeout, login_shell=login_shell)
    return rc, _extract_marked(out), out, err, sec



def _source_ip_from_iface(iface: str) -> str:
    """Get IPv4 source IP for a given interface (best-effort)."""
    iface = (iface or '').strip()
    if not iface:
        return ''
    try:
        cp = subprocess.run(['ip','-4','addr','show','dev',iface], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=5)
        out = cp.stdout or ''
        m = re.search(r'inet\s+(\d+\.\d+\.\d+\.\d+)/', out)
        return m.group(1) if m else ''
    except Exception:
        return ''


def _ssh_shell_exec_marked(host: str, user: str, pw: str, cmd: str, timeout: float):
    """
    Fallback SSH execution using a shell session (no remote 'exec' request).

    Some CPE SSH servers may reject 'exec' channel requests (e.g. "exec request failed on channel 0")
    but still allow interactive shell sessions. This function forces TTY allocation (-tt) and feeds
    the wrapped command into the remote shell via stdin.
    """
    wrapped = _wrap_cmd(cmd)
    source_ip = _getenv('SSH_SOURCE_IP','').strip()
    if not source_ip:
        iface = _getenv('CLIENT_IFACE','').strip()
        source_ip = _source_ip_from_iface(iface)
    ssh_cmd = [
        'sshpass', '-p', pw,
        'ssh', '-tt',
        "-o", "StrictHostKeyChecking=no",
        "-o", "UserKnownHostsFile=/dev/null",
        "-o", "LogLevel=ERROR",
        "-o", "UserKnownHostsFile=/dev/null",
        "-o", "PreferredAuthentications=password",
        "-o", "PubkeyAuthentication=no",
        "-o", "NumberOfPasswordPrompts=1",
        *( ['-b', source_ip] if source_ip else [] ),
        "-o", f"ConnectTimeout={max(3, int(timeout))}",
        f"{user}@{host}",
    ]
    # Run wrapped command in remote shell then exit.
    # Use CRLF to play nicer with some TTY shells.
    payload = (wrapped + "\r\nexit\r\n").encode("utf-8", errors="ignore")
    t0 = time.time()
    try:
        p = subprocess.run(
            ssh_cmd,
            input=payload,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=max(5.0, timeout + 8.0),
        )
        sec = time.time() - t0
        out = p.stdout.decode("utf-8", errors="replace")
        err = p.stderr.decode("utf-8", errors="replace")
        return p.returncode, _extract_marked(out), out, err, sec
    except subprocess.TimeoutExpired as e:
        sec = time.time() - t0
        out = (e.stdout or b"").decode("utf-8", errors="replace")
        err = (e.stderr or b"").decode("utf-8", errors="replace")
        return 124, _extract_marked(out), out, (err + "\nssh_shell_timeout").strip(), sec


def _ssh_probe_marked(host: str, user: str, pw: str, cmd: str, timeout: float):
    """
    Probe SSH by trying exec first (via cpe_ssh), then fallback to shell mode if needed.

    Returns a dict with:
      ok, method, rc, sec, extracted, raw_out, err
    """
    retries = int(_getenv("SSH_CONNECT_RETRIES", "3"))
    wait_sec = float(_getenv("SSH_CONNECT_RETRY_WAIT_SEC", "2"))
    force_shell = _bool_env("SSH_FORCE_SHELL", False)

    last = None
    for attempt in range(1, max(1, retries) + 1):
        # 1) Prefer exec (tool) unless forced shell.
        if not force_shell:
            rc, extracted, raw_out, err, sec = _ssh_exec_marked(host, user, pw, cmd, timeout=timeout, login_shell=True)
            res = {
                "ok": (rc == 0),
                "method": "exec",
                "attempt": attempt,
                "rc": rc,
                "sec": sec,
                "extracted": extracted,
                "raw_out": raw_out,
                "err": err,
            }
            # Success
            if res["ok"]:
                return res

            # If exec channel is rejected, try shell-mode fallback.
            if "exec request failed on channel" in (err or ""):
                try:
                    rc2, extracted2, raw_out2, err2, sec2 = _ssh_shell_exec_marked(host, user, pw, cmd, timeout=timeout)
                    res2 = {
                        "ok": (rc2 == 0 and bool(extracted2)),
                        "method": "shell",
                        "attempt": attempt,
                        "rc": rc2,
                        "sec": sec2,
                        "extracted": extracted2,
                        "raw_out": raw_out2,
                        "err": err2,
                        "exec_err_tail": (err or "")[-200:],
                    }
                    if res2["ok"]:
                        return res2
                    last = res2
                except Exception as e:
                    last = {**res, "method": "shell", "ok": False, "err": f"{err}\n{e}"}
            else:
                last = res
        else:
            # Forced shell mode
            rc2, extracted2, raw_out2, err2, sec2 = _ssh_shell_exec_marked(host, user, pw, cmd, timeout=timeout)
            res2 = {
                "ok": (rc2 == 0 and bool(extracted2)),
                "method": "shell",
                "attempt": attempt,
                "rc": rc2,
                "sec": sec2,
                "extracted": extracted2,
                "raw_out": raw_out2,
                "err": err2,
            }
            if res2["ok"]:
                return res2
            last = res2

        if attempt < max(1, retries):
            time.sleep(max(0.1, wait_sec))

    return last or {"ok": False, "method": "unknown", "attempt": 0, "rc": 1, "sec": 0.0, "extracted": [], "raw_out": "", "err": "no_attempt"}

_CACHE: Dict[str, object] = {}


def _getenv(name: str, default: str = "") -> str:
    v = os.environ.get(name, default)
    return default if v is None else str(v)


def _bool_env(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "on", "y")


def _norm(v: object) -> str:
    """Normalize env-like values (strip + lower)."""
    return str(v or "").strip().lower()


def _is_false(v: object) -> bool:
    """Return True if env-like value represents boolean false."""
    return _norm(v) in ("0", "false", "no", "off", "n")


def _run(cmd, timeout: float = 60.0) -> Tuple[int, str, str]:
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout)
    return p.returncode, p.stdout or "", p.stderr or ""


def _load_noc_profile(profile_name: str) -> Optional[Dict[str, str]]:
    path = (
        os.environ.get("NOC_PROFILES_PATH")
        or os.environ.get("PROFILES_FILE")
        or os.path.expanduser("~/.secrets/noc_profiles.json")
    )
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print(json.dumps({"event": "noc-profile-load-error", "profile": profile_name, "path": path, "error": str(e)}))
        return None

    prof = data.get(profile_name) or data.get(profile_name.upper())
    if not prof:
        print(json.dumps({"event": "noc-profile-load-error", "profile": profile_name, "path": path, "error": "profile not found"}))
        return None

    return {"base": prof.get("base"), "email": prof.get("email"), "password": prof.get("password")}


def _noc_creds() -> Tuple[str, str, str]:
    """Priority:
      1) NOC_BASE/NOC_EMAIL/NOC_PASSWORD if provided (and not "<fill>")
      2) NOC_PROFILE from profiles file
    """
    base = _getenv("NOC_BASE", "").strip()
    email = _getenv("NOC_EMAIL", "").strip()
    password = _getenv("NOC_PASSWORD", "").strip()

    if base and email and password and "<fill>" not in (base + email + password):
        return base, email, password

    prof_name = _getenv("NOC_PROFILE", "").strip()
    if prof_name:
        prof = _load_noc_profile(prof_name)
        if prof and prof.get("base") and prof.get("email") and prof.get("password"):
            return prof["base"], prof["email"], prof["password"]

    raise RuntimeError("NOC credentials missing: fill NOC_BASE/NOC_EMAIL/NOC_PASSWORD or provide NOC_PROFILE + profiles file")


def _login() -> str:
    if "token" in _CACHE:
        return _CACHE["token"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available")

    base, email, password = _noc_creds()
    bearer = _bool_env("NOC_BEARER", False)
    insecure = _bool_env("NOC_INSECURE", False)

    tok = api.login(base, email, password, bearer=bearer, insecure=insecure)
    _CACHE["token"] = tok
    print(json.dumps({"step": "login", "ok": True}))
    return tok


def _node_id() -> str:
    if "node_id" in _CACHE:
        return _CACHE["node_id"]  # type: ignore[return-value]

    metrics_tool = _getenv("METRICS_TOOL", "/home/da40/charter/tools/cpe_metrics_agent_serial.py")
    dev = _getenv("CPE_DEV", "/dev/ttyUSB0")
    baud = int(_getenv("CPE_BAUD", "115200"))
    user = _getenv("CPE_USER", "root")
    password = _getenv("CPE_PASSWORD", "null")

    max_retries = int(_getenv("NODE_ID_MAX_RETRIES", "10"))
    interval = float(_getenv("NODE_ID_RETRY_INTERVAL_SEC", "5"))

    last = ""
    for attempt in range(1, max_retries + 1):
        cmd = [metrics_tool, "--device", dev, "--baud", str(baud), "--user", user, "--cmd", "node-id"]

        pw_raw = (password or "").strip()
        pw_head = pw_raw.split()[0] if pw_raw else ""
        pw_head_l = pw_head.lower()
        is_error_like = (
            pw_head_l.startswith("curl:")
            or "connection timed out" in pw_raw.lower()
            or "error:" in pw_raw.lower()
            or "cannot fetch index.cgi" in pw_raw.lower()
        )
        if (not pw_raw) or (pw_head_l in ("null", "none")) or is_error_like:
            cmd += ["--password", "null"]
        else:
            cmd += ["--password", pw_head]

        print(json.dumps({"step": "node-id-cmd", "attempt": attempt, "cmd": cmd}))
        try:
            rc, out, err = _run(cmd, timeout=90.0)
        except Exception as e:
            last = str(e)
            print(json.dumps({"step": "node-id-exception", "attempt": attempt, "error": last}))
            time.sleep(interval)
            continue

        out_s = out.strip()
        print(json.dumps({"step": "node-id-raw", "attempt": attempt, "rc": rc, "out": out_s[:400]}))
        if rc == 0 and out_s:
            try:
                node_id = api.parse_node_id_from_text(out_s) if api else ""
            except Exception:
                node_id = ""
            node_id = (node_id or "").strip()
            if node_id:
                _CACHE["node_id"] = node_id
                print(json.dumps({"step": "node-id", "ok": True, "node_id": node_id}))
                return node_id

        last = (err or out).strip()
        print(json.dumps({"step": "node-id-retry", "attempt": attempt, "error": last[-200:]}))
        time.sleep(interval)

    # Fallback: derive node_id from WAN MAC via cpe_info
    cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
    try:
        rc2, out2, err2 = _run([cpe_info_tool, "--node-id", "--value"], timeout=20.0)
        raw2 = ((out2 or "") or (err2 or "")).strip()
        nid2 = raw2.replace(":", "").strip().lower()
        ok2 = (rc2 == 0 and bool(nid2))
        print(json.dumps({"step": "node-id-fallback-cpe_info", "ok": ok2, "rc": rc2, "raw": raw2[:200], "node_id": nid2 if ok2 else ""}))
        if ok2:
            _CACHE["node_id"] = nid2
            return nid2
    except Exception as e:
        print(json.dumps({"step": "node-id-fallback-cpe_info-exception", "error": str(e)}))

    raise RuntimeError(f"node-id failed: {last}")


def _location_id(token: str, node_id: str) -> str:
    if "location_id" in _CACHE:
        return _CACHE["location_id"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available")

    base, _, _ = _noc_creds()
    customer_id = _getenv("CUSTOMER_ID")
    bearer = _bool_env("NOC_BEARER", False)
    insecure = _bool_env("NOC_INSECURE", False)

    loc = api.get_location_id(base, customer_id, node_id, token=token, bearer=bearer, insecure=insecure)
    _CACHE["location_id"] = loc
    print(json.dumps({"step": "location-id", "ok": True, "location_id": loc}))
    return loc


def _enable_ssh(token: str, node_id: str, location_id: str) -> str:
    if api is None:
        raise RuntimeError("noc_api_cli not available")

    base, _, _ = _noc_creds()
    customer_id = _getenv("CUSTOMER_ID")
    passwd = _getenv("SSH_PASSWORD", "123456789")
    timeout_min = int(_getenv("SSH_TIMEOUT_MIN", "120"))
    bearer = _bool_env("NOC_BEARER", False)
    insecure = _bool_env("NOC_INSECURE", False)

    resp = api.ssh_enable(
        base,
        customer_id,
        location_id,
        node_id,
        passwd,
        timeout_min,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({"step": "ssh-enable", "ok": True, "resp": resp}))
    return passwd


def _parse_ipv6_addrs(ip6_addr_output: str) -> Tuple[Optional[str], Optional[str]]:
    g = None
    ll = None
    for line in (ip6_addr_output or "").splitlines():
        line = line.strip()
        # Support both busybox iproute2 style and ifconfig style:
        #   ip:      inet6 fd00::1/64 scope global
        #   ifconfig: inet6 addr: fe80::.../64 Scope:Link
        m = re.search(r"\binet6\s+([0-9a-fA-F:]+)/\d+", line)
        if not m:
            m = re.search(r"\binet6\s+addr:\s*([0-9a-fA-F:]+)/\d+", line, flags=re.I)
        if not m:
            continue
        ip = m.group(1).lower()
        if ip.startswith("fe80:"):
            ll = ip
        else:
            g = ip
    return g, ll


def _expect_deny_link_local_ipv6_from_wlan(dst_ll6: str, user: str, pw: str, wlan_iface: str, timeout: float) -> None:
    """From WLAN client, try to SSH using LAN link-local IPv6 and expect DENY.

    Source LLA is taken from WIFI_LL_SRC cache (captured right after Wi-Fi connects). If absent,
    we probe as fallback.
    """
    dst_ll6 = (dst_ll6 or "").strip().lower()
    wlan_iface = (wlan_iface or "").strip()
    if not dst_ll6 or not wlan_iface:
        raise RuntimeError("missing dst_ll6 or wlan_iface")

    host = f"{dst_ll6}%{wlan_iface}"

    # Source bind: prefer cached Wi-Fi link-local.
    src_bind = _get_wlan_ll_ipv6_cached(wlan_iface)
    src_ll6 = (src_bind.split('%', 1)[0] if src_bind else "")

    if not src_bind and _bool_env("WIFI_LL_IPV6_REQUIRED", True):
        raise RuntimeError(f"WIFI_LL_IPV6_REQUIRED=1 but WIFI_LL_SRC missing and no WLAN LLA detected on iface={wlan_iface!r}")

    ssh_cmd = [
        'sshpass', '-p', pw,
        'ssh', '-6', '-tt',
        '-o', 'StrictHostKeyChecking=no',
        '-o', 'UserKnownHostsFile=/dev/null',
        '-o', 'LogLevel=ERROR',
        '-o', 'PreferredAuthentications=password',
        '-o', 'PubkeyAuthentication=no',
        '-o', 'NumberOfPasswordPrompts=1',
        '-o', f'ConnectTimeout={max(3, int(timeout))}',
        *( ['-b', src_bind] if src_bind else [] ),
        f'{user}@{host}',
    ]

    # If SSH is allowed, we should be able to run a trivial command.
    payload = ("uptime\nexit\n").encode('utf-8', errors='ignore')
    t0 = time.time()
    try:
        p = subprocess.run(ssh_cmd, input=payload, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=max(6.0, timeout + 8.0))
        sec = time.time() - t0
        out = p.stdout.decode('utf-8', errors='replace')
        err = p.stderr.decode('utf-8', errors='replace')
        ok = (p.returncode == 0)
        print(json.dumps({
            'step': 'ssh-deny-check',
            'host': dst_ll6,
            'zone': wlan_iface,
            'method': 'sshpass_ipv6_ll',
            'bind_src_ll6': src_ll6,
            'bind_src_arg': src_bind,
            'rc': p.returncode,
            'sec': sec,
            'stdout_tail': (out or '')[-200:],
            'stderr_tail': (err or '')[-200:],
        }, ensure_ascii=False), flush=True)
        if ok:
            raise RuntimeError('ssh expected DENY (link-local IPv6) but succeeded')
    except subprocess.TimeoutExpired as e:
        sec = time.time() - t0
        out = (e.stdout or b'').decode('utf-8', errors='replace')
        err = (e.stderr or b'').decode('utf-8', errors='replace')
        print(json.dumps({
            'step': 'ssh-deny-check',
            'host': dst_ll6,
            'zone': wlan_iface,
            'method': 'sshpass_ipv6_ll',
            'bind_src_ll6': src_ll6,
            'bind_src_arg': src_bind,
            'rc': 124,
            'sec': sec,
            'stdout_tail': (out or '')[-200:],
            'stderr_tail': (err or '')[-200:],
            'timeout': True,
        }, ensure_ascii=False), flush=True)
        # timeout is considered DENY
        return


def _lan_iface_for(dst_ip: str) -> Optional[str]:
    try:
        rc, out, _ = _run(["sh", "-lc", f"ip route get {dst_ip}"], timeout=3.0)
        if rc != 0:
            return None
        m = re.search(r"\bdev\s+(\S+)", out)
        return m.group(1) if m else None
    except Exception:
        return None


def _ll_ipv6_from_mac(mac: str) -> str:
    """Compute link-local IPv6 from MAC (EUI-64).

    Example:
      mac=90:D3:CF:EB:6A:4E -> fe80::92d3:cfff:feeb:6a4e
    """
    m = re.sub(r"[^0-9a-fA-F]", "", mac or "").lower()
    if len(m) != 12:
        return ""
    b = [int(m[i:i+2], 16) for i in range(0, 12, 2)]
    b[0] ^= 0x02  # flip U/L bit
    eui = b[:3] + [0xFF, 0xFE] + b[3:]
    hextets = [f"{eui[i]:02x}{eui[i+1]:02x}" for i in range(0, 8, 2)]
    return "fe80::" + ":".join(hextets)


def _wait_wlan_carrier(iface: str, timeout_sec: int = 30, interval_sec: float = 1.0) -> bool:
    iface = (iface or "").strip()
    if not iface:
        return False
    path = f"/sys/class/net/{iface}/carrier"
    t0 = time.time()
    attempt = 0
    while True:
        attempt += 1
        val = ""
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                val = (f.read() or "").strip()
        except Exception:
            val = ""
        ok = (val == "1")
        _emit("wifi-carrier", ok=ok, iface=iface, attempt=attempt, carrier=val)
        if ok:
            return True
        if (time.time() - t0) >= float(timeout_sec):
            return False
        time.sleep(max(0.1, float(interval_sec)))


def _get_wlan_ll_ipv6_cached(wlan_iface: str) -> str:
    """Get WLAN link-local IPv6 from cache or probe.

    We cache right after Wi-Fi connects because wlx LLA may disappear later.
    Returns string without brackets, but WITH %iface for bind usage.
    """
    wlan_iface = (wlan_iface or "").strip()
    if not wlan_iface:
        return ""

    cached = (os.environ.get("WIFI_LL_SRC") or "").strip()
    if cached:
        return cached

    # probe a few times
    retries = int(os.environ.get("WIFI_LL_DETECT_RETRIES", "5") or "5")
    wait_sec = float(os.environ.get("WIFI_LL_DETECT_WAIT_SEC", "1") or "1")

    def _parse_ll(out: str) -> str:
        m = re.search(r"\binet6\s+(fe80:[0-9a-fA-F:]+)/\d+", out or "")
        if not m:
            m = re.search(r"\binet6\s+addr:\s*(fe80:[0-9a-fA-F:]+)/\d+", out or "", flags=re.I)
        if not m:
            return ""
        ll = m.group(1).lower()
        return f"{ll}%{wlan_iface}"

    last_out = ""
    last_err = ""
    last_rc = None
    for attempt in range(1, max(1, retries) + 1):
        for cmd in ([['ip','-6','addr','show','dev',wlan_iface,'scope','link'], ['ip','-6','addr','show','dev',wlan_iface], ['ifconfig', wlan_iface]]):
            try:
                cp = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=5)
                last_rc = cp.returncode
                last_out = cp.stdout or ""
                last_err = cp.stderr or ""
                got = _parse_ll(last_out)
                if got:
                    os.environ["WIFI_LL_SRC"] = got
                    _emit("wifi-ll-src", ok=True, attempt=attempt, iface=wlan_iface, ll_src=got)
                    return got
            except FileNotFoundError:
                continue
            except Exception as e:
                last_err = f"{last_err}\n{e}".strip()

        if attempt < max(1, retries) and wait_sec > 0:
            time.sleep(wait_sec)

    _emit("wifi-ll-src", ok=False, iface=wlan_iface, last_rc=last_rc, out_tail=last_out[-200:], err_tail=last_err[-200:])
    return ""


def _ssh_exec(host: str, user: str, pw: str, cmd: str, timeout: float):
    """Execute remote cmd with marker wrapping; returns (rc, extracted, raw_out, err, sec)."""
    return _ssh_exec_marked(host, user, pw, cmd, timeout=timeout, login_shell=True)


def _expect_allow(host: str, user: str, pw: str, cmd: str, timeout: float) -> None:
    """Expect SSH ALLOW.

    If WLAN_REQUIRED=1 and SSH_SOURCE_IP is set, prefer using cpe_ssh.py with --bind-src
    to guarantee traffic uses WLAN source IP (avoid routing/default-metric ambiguity).
    """
    wlan_required = _bool_env("WLAN_REQUIRED", False)
    bind_src = _getenv("SSH_SOURCE_IP", "").strip()
    tools_path = _getenv("TOOLS_PATH", "/home/da40/charter/tools")
    cpe_ssh_tool = _getenv("CPE_SSH_TOOL", os.path.join(tools_path, "cpe_ssh.py"))
    pybin = _getenv("PYTHON", "python3")

    if wlan_required and bind_src:
        # Use tool mode: more reliable than parsing exec/shell output.
        allow_cmd = (_getenv("SSH_ALLOW_CMD", "uptime") or "uptime").strip()
        t0 = time.time()
        r = _run_local([
            pybin, cpe_ssh_tool,
            "--host", host,
            "--user", user,
            "--password", pw,
            "--bind-src", bind_src,
            "--cmd", allow_cmd,
        ], timeout=max(10.0, float(timeout) + 10.0))
        sec = time.time() - t0
        out = (r or {}).get("stdout", "")
        err = (r or {}).get("stderr", "")
        ok = bool((r or {}).get("ok"))
        rc = (r or {}).get("rc")
        print(json.dumps({
            "step": "ssh-allow-check",
            "host": host,
            "method": "cpe_ssh_tool_bind_src",
            "bind_src": bind_src,
            "cmd": allow_cmd,
            "rc": rc,
            "sec": sec,
            "stdout_tail": (out or "")[-200:],
            "stderr_tail": (err or "")[-200:],
        }, ensure_ascii=False), flush=True)
        if not ok:
            raise RuntimeError(f"ssh expected ALLOW but failed (tool) rc={rc}: {str(err).strip()}")
        return

    # Legacy probe mode (non-WLAN paths)
    res = _ssh_probe_marked(host, user, pw, cmd, timeout)
    extracted = (res.get("extracted") or [])
    raw_out = (res.get("raw_out") or "")
    err = (res.get("err") or "")
    print(json.dumps({
        "step": "ssh-allow-check",
        "host": host,
        "method": res.get("method"),
        "attempt": res.get("attempt"),
        "rc": res.get("rc"),
        "sec": res.get("sec"),
        "stdout": (extracted[-1] if extracted else "")[-200:],
        "raw_stdout_tail": raw_out[-200:],
        "stderr": err[-200:],
    }, ensure_ascii=False), flush=True)
    if not res.get("ok"):
        raise RuntimeError(f"ssh expected ALLOW but failed rc={res.get('rc')}: {str(err).strip()}")

def _expect_deny(host: str, user: str, pw: str, cmd: str, timeout: float) -> None:
    res = _ssh_probe_marked(host, user, pw, cmd, timeout)
    extracted = (res.get("extracted") or [])
    raw_out = (res.get("raw_out") or "")
    err = (res.get("err") or "")
    print(json.dumps({
        "step": "ssh-deny-check",
        "host": host,
        "method": res.get("method"),
        "attempt": res.get("attempt"),
        "rc": res.get("rc"),
        "sec": res.get("sec"),
        "stdout": (extracted[-1] if extracted else "")[-200:],
        "raw_stdout_tail": raw_out[-200:],
        "stderr": err[-200:],
    }))
    if res.get("ok"):
        raise RuntimeError("ssh expected DENY but succeeded")

def _run_local(cmd, timeout: float = 90.0, env=None):
    t0 = time.time()
    try:
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout, env=env)
        sec = time.time() - t0
        out = p.stdout or ""
        err = p.stderr or ""
        js = None
        try:
            js = json.loads(out) if out.strip().startswith("{") else None
        except Exception:
            js = None
        return {"ok": p.returncode == 0, "rc": p.returncode, "stdout": out, "stderr": err, "sec": sec, "json": js}
    except subprocess.TimeoutExpired as e:
        sec = time.time() - t0
        out = (e.stdout or "")
        err = (e.stderr or "")
        js = None
        try:
            js = json.loads(out) if out.strip().startswith("{") else None
        except Exception:
            js = None
        return {"ok": False, "rc": 124, "stdout": out, "stderr": (err + "\\nTIMEOUT").strip(), "sec": sec, "json": js}


def _choose_wifi_creds(creds: dict, band: str, prefer: str = "current") -> Optional[Dict[str, str]]:
    """Pick {ssid, psk, source} from cpe_ssh --cmd wifi-creds output."""
    band = (band or "").strip().lower()
    if band in ("2.4", "2.4g", "2g", "24g"):
        band = "2g"
    elif band in ("5", "5g"):
        band = "5g"
    elif band in ("6", "6g"):
        band = "6g"

    prefer = (prefer or "current").strip().lower()
    if prefer not in ("current", "default"):
        prefer = "current"

    def _from_default() -> Optional[Dict[str, str]]:
        d = creds.get("default") or {}
        if not isinstance(d, dict):
            return None
        # try requested band, else 5g -> 2g -> 6g
        order = [band] if band else []
        for b in ("5g", "2g", "6g"):
            if b not in order:
                order.append(b)
        for b in order:
            item = d.get(b)
            if isinstance(item, dict):
                ssid = (item.get("ssid") or "").strip()
                psk = (item.get("psk") or "").strip()
                if ssid and psk:
                    return {"ssid": ssid, "psk": psk, "source": f"default:{b}"}
        return None

    def _infer_band_from_ifname(ifname: str) -> Optional[str]:
        s = (ifname or "").strip().lower()
        # common convention: wifi0=2g, wifi1=5g, wifi2=6g
        if s.endswith("0"):
            return "2g"
        if s.endswith("1"):
            return "5g"
        if s.endswith("2"):
            return "6g"
        return None

    def _from_current() -> Optional[Dict[str, str]]:
        c = creds.get("current") or {}
        if not isinstance(c, dict):
            return None
        vifs = c.get("vifs") or []
        if not isinstance(vifs, list):
            return None

        # try band match first if possible
        if band:
            for v in vifs:
                if not isinstance(v, dict):
                    continue
                ssid = (v.get("ssid") or "").strip()
                psk = (v.get("psk") or "").strip()
                ifname = (v.get("if_name") or "").strip()
                vb = _infer_band_from_ifname(ifname)
                if ssid and psk and vb == band:
                    return {"ssid": ssid, "psk": psk, "source": f"current:{ifname or vb or 'vif'}"}

        # fallback: first usable
        for v in vifs:
            if not isinstance(v, dict):
                continue
            ssid = (v.get("ssid") or "").strip()
            psk = (v.get("psk") or "").strip()
            ifname = (v.get("if_name") or "").strip()
            if ssid and psk:
                return {"ssid": ssid, "psk": psk, "source": f"current:{ifname or 'vif'}"}
        return None

    if prefer == "current":
        return _from_current() or _from_default()
    return _from_default() or _from_current()

def _ip4_addr(iface: str) -> str:
    r = _run_local(["ip", "-4", "-o", "addr", "show", "dev", iface], timeout=10)
    out = (r.get("stdout") or "")
    m = re.search(r"inet\s+(\d+\.\d+\.\d+\.\d+)/", out)
    return m.group(1) if m else ""


def _wifi_connect(iface: str, ssid: str, psk: str) -> dict:
    """Connect test-platform Wi-Fi NIC to SSID using tools wifi_iwd.py (preferred) or wifi_nm.py.

    Returns: {ok, method, iface, ipv4, tool_status?}
    """
    pybin = os.environ.get('PYTHON', 'python3')
    tools_path = os.environ.get('TOOLS_PATH', '/home/da40/charter/tools')

    method = (os.environ.get('WIFI_METHOD', 'auto') or 'auto').strip().lower()
    band = (os.environ.get('WIFI_BAND', '') or '').strip().lower()
    timeout_sec = int(os.environ.get('WIFI_TIMEOUT_SEC', '70'))
    dhcp_timeout = int(os.environ.get('WIFI_DHCP_TIMEOUT_SEC', '60'))
    nm_retries = int(os.environ.get('WIFI_NM_RETRIES', '2'))

    env = os.environ.copy()
    env['WIFI_PSK'] = psk

    def try_iwd():
        tool = os.environ.get('WIFI_IWD_TOOL') or os.path.join(tools_path, 'wifi_iwd.py')
        cmd = [
            pybin, tool, '--json',
            'ensure',
            '--iface', iface,
            '--ssid', ssid,
            '--password-env', 'WIFI_PSK',
            '--timeout', str(timeout_sec),
            '--dhcp-timeout', str(dhcp_timeout),
            # Keep only iwd to avoid NM/iwd race (can cause periodic deauth by local choice)
            '--takeover', '--no-main-default',
        ]
        if band:
            cmd += ['--band', band]
        return _run_local(cmd, timeout=max(120, timeout_sec + dhcp_timeout + 40), env=env)

    def try_nm():
        tool = os.environ.get('WIFI_NM_TOOL') or os.path.join(tools_path, 'wifi_nm.py')
        cmd = [
            pybin, tool, '--json',
            'ensure',
            '--iface', iface,
            '--ssid', ssid,
            '--password-env', 'WIFI_PSK',
            '--timeout', str(timeout_sec),
            '--retries', str(nm_retries),
        ]
        if band:
            cmd += ['--band', band]
        return _run_local(cmd, timeout=max(120, timeout_sec + 60), env=env)

    tries = ['iwd', 'nm'] if method == 'auto' else [method]
    last = None
    used = None
    for m in tries:
        r = try_iwd() if m == 'iwd' else try_nm()
        last = r
        js = (r or {}).get('json') if isinstance(r, dict) else None
        # If tool returned JSON with status.ip4, use it
        tool_ip4 = None
        if isinstance(js, dict):
            st = js.get('status') or js.get('status_before_restore') or {}
            if isinstance(st, dict):
                tool_ip4 = st.get('ip4')
        _emit('wifi-connect', method=m, ok=bool((r or {}).get('ok')), rc=(r or {}).get('rc'), iface=iface, ssid=ssid, sec=(r or {}).get('sec'))
        if r.get('ok'):
            used = m
            # Prefer tool-provided ip4
            if tool_ip4:
                return {"ok": True, "method": used, "iface": iface, "ipv4": str(tool_ip4)}
            break

    if not used:
        return {"ok": False, "error": "wifi connect failed", "stdout_tail": (last or {}).get('stdout','')[-800:], "stderr_tail": (last or {}).get('stderr','')[-800:], "json": (last or {}).get('json')}

    # Fallback: poll ip for a short window
    for _ in range(15):
        ip = _ip4_addr(iface)
        if ip:
            _emit('wifi-ipv4', ok=True, iface=iface, ipv4=ip)
            return {"ok": True, "method": used, "iface": iface, "ipv4": ip}
        time.sleep(2)

    _emit('wifi-ipv4', ok=False, iface=iface, ipv4='')
    return {"ok": False, "error": "no ipv4 on wifi iface after connect", "iface": iface, "json": (last or {}).get('json')}
def run() -> int:
    if not _bool_env("ENABLE_SSH_FLOW", True):
        print(json.dumps({"event": "skip", "reason": "ENABLE_SSH_FLOW=0"}), flush=True)
        return 0

    lan_ip = _getenv("SSH_HOST_LAN", "192.168.1.1")
    ssh_user = _getenv("SSH_USER", "operator")
    timeout = float(_getenv("SSH_TOOL_TIMEOUT", "15"))

    test_profile = _getenv("TEST_PROFILE", "customer")  # customer|lab
    enable_ipv6 = _getenv("ENABLE_IPV6", "false")        # auto|true|false

    wifi_iface_used = ""

    try:
        token = _login()
        node_id = _node_id()
        os.environ["NODE_ID"] = str(node_id or "")
        location_id = _location_id(token, node_id)
        ssh_passwd = _enable_ssh(token, node_id, location_id)

        settle = float(_getenv("SSH_ENABLE_SETTLE_SEC", "2"))
        if settle > 0:
            print(json.dumps({"step": "ssh-enable-settle", "sec": settle}), flush=True)
            time.sleep(settle)

        if _bool_env("ENABLE_WIFI_CONNECT", True):
            wifi_iface = _getenv("WIFI_IFACE", "wlx6cb0ce1ff230").strip()
            wifi_iface_used = wifi_iface
            wlan_required = _bool_env("WLAN_REQUIRED", True)
            wifi_band = _getenv("WIFI_BAND", "").strip()
            wifi_prefer = (_getenv("WIFI_CRED_PREFER", "current") or "current").split("#", 1)[0].strip()
            wifi_timeout = float(_getenv("WIFI_TIMEOUT_SEC", "70"))

            _emit("wifi-start", iface=wifi_iface, required=wlan_required, band=wifi_band, prefer=wifi_prefer)

            tools_path = _getenv("TOOLS_PATH", "/home/da40/charter/tools")
            pybin = _getenv("PYTHON", "python3")
            cpe_ssh_tool = _getenv("CPE_SSH_TOOL", tools_path + "/cpe_ssh.py")
            ssh_pass = _getenv("SSH_PASSWORD", "")

            cmd = [
                pybin, cpe_ssh_tool,
                "--host", lan_ip,
                "--user", ssh_user,
                "--password", ssh_pass,
                "--cmd", "wifi-creds",
                "--which", "both",
            ]
            r = _run_local(cmd, timeout=max(60.0, wifi_timeout + 15.0))
            creds_json = r.get("json") if isinstance(r, dict) else None
            print(json.dumps({
                "step": "wifi-creds",
                "ok": bool((r or {}).get("ok")),
                "rc": (r or {}).get("rc"),
                "iface": wifi_iface,
                "band": wifi_band,
                "prefer": wifi_prefer,
            }, ensure_ascii=False), flush=True)

            if not (isinstance(creds_json, dict) and creds_json.get("ok")):
                raise RuntimeError("wifi-creds failed (cpe_ssh.py --cmd wifi-creds)")

            chosen = _choose_wifi_creds(creds_json, wifi_band, prefer=wifi_prefer)
            o_ssid = _getenv("WIFI_SSID", "").strip()
            o_psk = _getenv("WIFI_PSK", "").strip()
            if o_ssid and o_psk:
                chosen = {"ssid": o_ssid, "psk": o_psk, "source": "override"}

            if not chosen:
                raise RuntimeError("no usable ssid/psk from wifi-creds")

            ssid = chosen.get("ssid")
            psk = chosen.get("psk")
            print(json.dumps({
                "step": "wifi-creds-select",
                "ok": True,
                "ssid": ssid,
                "source": chosen.get("source"),
                "iface": wifi_iface,
            }, ensure_ascii=False), flush=True)

            wres = _wifi_connect(wifi_iface, ssid, psk)
            if not wres.get("ok"):
                raise RuntimeError(f"wifi_connect_failed: {wres}")

            src_ip = str(wres.get("ipv4") or "").strip().split("/", 1)[0]
            _emit("wifi-ready", ok=bool(src_ip), iface=wifi_iface, ipv4=src_ip, method=wres.get("method"), ssid=ssid)

            pr = _ping_iface(wifi_iface, lan_ip, count=2, timeout_sec=3)
            _emit("ping-router", **pr)
            if not pr.get("ok"):
                raise RuntimeError("wifi ping to router failed; cannot proceed to ssh")

            os.environ["SSH_SOURCE_IP"] = src_ip
            os.environ["SSH_FORCE_SHELL"] = "1"

            # Wait for Wi-Fi carrier (NO-CARRIER means link not established; LLA may not exist).
            carrier_timeout = int(_getenv("WIFI_CARRIER_WAIT_SEC", "30") or "30")
            if not _wait_wlan_carrier(wifi_iface, timeout_sec=carrier_timeout, interval_sec=1.0):
                raise RuntimeError(f"WIFI_CARRIER_WAIT_SEC={carrier_timeout} but carrier did not become 1 on iface={wifi_iface!r}")

            # Cache WLAN link-local IPv6 early (wlx LLA may disappear later).
            _ = _get_wlan_ll_ipv6_cached(wifi_iface)

            if wlan_required and not src_ip:
                raise RuntimeError("WLAN_REQUIRED=1 but no wlan ipv4 obtained")

        # First verify IPv4 allow from WLAN source.
        _expect_allow(lan_ip, ssh_user, ssh_passwd, "echo SSH_OK", timeout)

        # Then try to SSH using Link Local IPv6 address of LAN interface (expect DENY).
        if _bool_env("WLAN_REQUIRED", False) and _bool_env("ENABLE_LL_IPV6_TEST", True):
            try:
                wifi_iface = _getenv("WIFI_IFACE", "").strip()

                # Prefer deterministic computation from LAN MAC (node_id) to avoid relying on remote command execution.
                node_mac = (_getenv("NODE_ID", "") or "").strip()
                ll6 = _ll_ipv6_from_mac(node_mac)
                _emit(
                    "lan-ll6",
                    ok=bool(ll6),
                    iface=_getenv("LAN_LL_IPV6_IFACE", "br-home"),
                    ll6=ll6 or "",
                    source="eui64_from_node_id",
                    node_id=node_mac,
                )

                if ll6:
                    _expect_deny_link_local_ipv6_from_wlan(ll6, ssh_user, ssh_passwd, wifi_iface, timeout=float(timeout))
                else:
                    if _bool_env("LL_IPV6_REQUIRED", False):
                        raise RuntimeError(f"LL_IPV6_REQUIRED=1 but cannot compute link-local IPv6 from NODE_ID={node_mac!r}")
                    _emit("lan-ll6-skip", reason="no_link_local_ipv6_computed")
            except Exception as e:
                if _bool_env("LL_IPV6_REQUIRED", False):
                    raise
                _emit("lan-ll6-error", error=str(e))

        if _is_false(enable_ipv6) or _norm(test_profile) == "lab":
            print(json.dumps({"step": "ipv6-skipped-final", "profile": test_profile, "enable_ipv6": enable_ipv6}), flush=True)

        print(json.dumps({"ok": True, "case": "C15807130"}), flush=True)
        return 0
    finally:
        # Cleanup handled by cycle_wrapper.py (wifi-disconnect)
        pass

    if __name__ == "__main__":
        raise SystemExit(run())
