# C15807133_SSH_authorized_only_on_port_22

## 1) 目的 / 覆蓋範圍
- 驗證 SSH 可用性與安全策略（允許/拒絕、port 限制、帳密錯誤等）。

## 2) 前置條件 / 環境
- 需具備對應 client 位置（LAN/WAN）與連線條件。
- 若需 NOC enable SSH，請用 `.secrets`/`PROFILES_FILE`。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- （manifest 未包含常見 env 或解析不到；可直接查看 zip 內 manifest.yaml）

## 5) PASS/FAIL 判定
- PASS：SSH 行為符合預期策略。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807133_SSH_authorized_only_on_port_22

## 1) 目的 / 覆蓋範圍
- 驗證 SSH 安全策略與可用性（例如僅允許 port 22、錯誤憑證不可登入、disable 後不可登入等）。

## 2) 前置條件 / 環境
- 需可從指定 client 端連到 CPE（LAN/WAN 視腳本而定）。
- 若透過 NOC 使能 SSH，需提供 NOC profile/credentials（建議走 `.secrets`/`PROFILES_FILE`）。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`

## 5) PASS/FAIL 判定
- PASS：符合策略（允許/拒絕）行為與預期一致。
- FAIL：SSH policy 或連線條件不符。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807133 - SSH should be authorized only on port 22

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807133 - SSH should be authorized only on port 22

## Summary
This script verifies that SSH is **not accessible** on a non-standard port (port 26), i.e. SSH should be authorized only on port 22.

## Preconditions (Automation)
1. NOC login (get token)
2. Get node_id via serial metrics (with retry)
3. Get location_id via NOC API
4. Enable SSH Manager (SSHM) via kvConfigs PATCH (set sshAuthPasswd / timeout)

## Validation
- From LAN client, attempt to connect to DUT LAN IPv4 on TCP port **26** should **FAIL** (timeout/refused/unreachable all treated as not allowed).

Notes:
- This case is implemented as a TCP connect check to port 26 (fast, robust). If the port is open and accepts a TCP connection, the test FAILs.
```

```
```
