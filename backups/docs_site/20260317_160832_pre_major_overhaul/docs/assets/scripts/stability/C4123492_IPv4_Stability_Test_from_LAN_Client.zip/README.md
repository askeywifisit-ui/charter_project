# C4123492_IPv4_Stability_Test_from_LAN_Client

## 1) 目的 / 覆蓋範圍
- （待補：此腳本驗證的功能點/場景）

## 2) 前置條件 / 環境
- （待補：環境/拓撲/前置條件）

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`stability`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'30'
- TOOLS_PATH：/home/da40/charter/tools
- PING_IFACE：eno2
- PROFILES_FILE：/home/da40/charter/.secrets/noc_profiles.json
- NOC_PROFILE：SPECTRUM_INT
- CUSTOMER_ID：682d4e5179b80027cd6fb27e

## 5) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C4123492 — IPv4 Stability Test from the LAN Client（專業版 / v11）

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`stability`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'30'
- TOOLS_PATH：/home/da40/charter/tools

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C4123492 — IPv4 Stability Test from the LAN Client（專業版 / v11）

## 目的
在**LAN Client** 端長時間監控 IPv4 連通性是否間歇性中斷。

本腳本對齊 Test Plan：
- LAN Client 必須拿到 IPv4 位址
- 連續執行 4~5 小時以上
- 若封包丟失超過門檻（預設 10%）或連續失敗，觸發 **CPE logpull**

---

## 特色
- **Precondition 只在 cycle #1 跑一次**：
  1) `cpe_info --cloud` 檢查 CPE cloud ready（失敗會 retry）
  2) 超過指定 retry 次數仍失敗 → **PDU reset 1 次** → 再 retry
  3) 進行 SSH port 22 掃描，必要時透過 **NOC API** 自動 enable SSH
  4) SSH ready probe（預設 `uptime`）

- **每一個 cycle 都會先 scan port 22**，若沒開則走 NOC `ssh-enable`（attempt=2），確保失敗時能抓 log。

- **LAN ping backend 可切換 / 自動 fallback**：
  - `auto`（預設）：macvlan → pbr → plain
    - 若環境**沒有 passwordless sudo**（常見於客戶端），會自動略過 macvlan/pbr，直接使用 plain（避免 log 出現 `sudo: a password is required`）
  - `macvlan`：以 netns/macvlan 模擬「真 LAN Client」
  - `pbr`：以 PBR 強制走 LAN 介面路由
  - `plain`：不動 routing/netns，直接用 `net_probe.py` 綁 src-ip 或 iface ping

---

## 測試流程（每 cycle）
1) Ensure SSH ready（scan 22 → 필요 시 NOC ssh-enable → `uptime` probe）
2) **LAN Client ping CPE**（目標：`CPE_HOST`）
3) **CPE ping WAN gateway**（自動偵測 default gw，或使用 `CPE_WAN_GATEWAY`）
4) 若觸發條件成立：
   - `loss_pct >= LOSS_TRIGGER_PCT`（預設 10%）或
   - `consecutive_fail >= CONSEC_FAIL_TRIGGER_N`（預設 3）
   → 執行 `cpe_ssh.py --cmd pull-log` 抓取 log，並附加 run id

---

## 重要環境變數（manifest.yaml）
### 基本
- `CYCLES` / `CYCLE_INTERVAL`：總循環次數 / 間隔秒數（預設 300 次 * 60 秒 = 5 小時）
- `STOP_ON_FAIL`：是否遇到 fail 就停止（預設 0）

### NOC / SSH
- `PROFILES_FILE`：NOC profile JSON（**建議把 secrets 放這裡**）
- `NOC_PROFILE`：要套用的 profile 名稱
- `SSH_PASSWORD`：CPE operator 密碼（可留空；會用 `SSH_PASSWORD_DEFAULT`）

### LAN ping backend
- `LAN_PING_BACKEND`：`auto|macvlan|pbr|plain`
- macvlan：`LAN_PARENT_IFACE`（空=自動）
- pbr：`PBR_IFACE / PBR_SRC_IP / PBR_GW / PBR_SUBNET ...`
- plain：`PROBE_IFACE / PROBE_SRC_IP`

### 觸發 logpull
- `LOSS_TRIGGER_PCT`：loss 超過此百分比就抓 log
- `CONSEC_FAIL_TRIGGER_N`：連續 fail 次數達到就抓 log

---

## 依賴工具（control PC）
- `/home/da40/charter/tools/cpe_info`
- `/home/da40/charter/tools/cpe_ssh.py`
- `/home/da40/charter/tools/noc_api_cli.py`
- `/home/da40/charter/tools/net_probe.py`
- （可選）`/home/da40/charter/tools/lan_macvlan.py`
- （可選）`/home/da40/charter/tools/pbr_cpe.py`

---

## Pass / Fail 判定
- 任一 cycle 中：
  - LAN ping CPE 失敗，或
  - CPE ping WAN gateway 失敗
  → 此 cycle 記為 FAIL（rc=1）

（是否停止由 `STOP_ON_FAIL` 決定）
```

```
