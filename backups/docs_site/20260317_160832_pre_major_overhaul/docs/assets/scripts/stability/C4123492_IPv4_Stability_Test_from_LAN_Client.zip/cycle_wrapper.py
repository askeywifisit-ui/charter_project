#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generic cycle wrapper (WAN-arch compatible).

Design goals (aligned to your verified scripts like A2435638):
- Runner entry stays `cycle_wrapper.py:run`.
- Each cycle executes `ORIGINAL_ENTRY` (default: main_impl.py:run).
- Supports CYCLE_TOTAL/CYCLES, CYCLE_INTERVAL_SEC/CYCLE_INTERVAL, STOP_ON_FAIL.
- Optional precondition() runs once in cycle #1 when PRECONDITION_FIRST_CYCLE=1.
- Emits JSON events + human logs.

NOTE: We parse manifest.yaml via PyYAML (requirements.txt includes PyYAML).
"""

from __future__ import annotations

import importlib.util
import json
import os
import pathlib
import subprocess
import sys
import time
from typing import Any, Dict, Tuple

try:
    import yaml  # type: ignore
except Exception:
    yaml = None


def log(msg: str) -> None:
    print(msg, flush=True)


def _load_manifest() -> Tuple[Dict[str, Any], Dict[str, Any], str, str, int, float, int]:
    here = pathlib.Path(__file__).resolve().parent
    mp = here / "manifest.yaml"
    if not mp.exists():
        mp = here / "manifest.yml"

    man: Dict[str, Any] = {}
    if mp.exists():
        if yaml is None:
            raise RuntimeError("PyYAML is required but not installed")
        try:
            man = yaml.safe_load(mp.read_text(encoding="utf-8")) or {}
        except Exception as e:
            raise RuntimeError(f"manifest parse error: {e}")

    env = dict((man.get("env") or {}))

    # Runner-facing entrypoint (for display)
    manifest_entry = (man.get("entrypoint") or man.get("entry") or "main.py:run")

    # The real per-cycle entry we will execute
    original_entry = env.get("ORIGINAL_ENTRY") or os.environ.get("ORIGINAL_ENTRY") or "main_impl.py:run"
    if str(original_entry).strip() == "":
        original_entry = "main_impl.py:run"

    # Wrapper vars with aliases
    cycles_raw = env.get("CYCLE_TOTAL")
    if cycles_raw is None:
        cycles_raw = env.get("CYCLES")
    if cycles_raw is None:
        cycles_raw = os.environ.get("CYCLE_TOTAL") or os.environ.get("CYCLES") or "1"

    interval_raw = env.get("CYCLE_INTERVAL_SEC")
    if interval_raw is None:
        interval_raw = env.get("CYCLE_INTERVAL")
    if interval_raw is None:
        interval_raw = os.environ.get("CYCLE_INTERVAL_SEC") or os.environ.get("CYCLE_INTERVAL") or "0"

    stop_raw = env.get("STOP_ON_FAIL")
    if stop_raw is None:
        stop_raw = os.environ.get("STOP_ON_FAIL") or "0"

    cycles = int(str(cycles_raw).strip())
    interval = float(str(interval_raw).strip())
    stop_on_fail = int(str(stop_raw).strip())

    return man, env, str(manifest_entry), str(original_entry), cycles, interval, stop_on_fail


def _resolve_entry(entry_str: str):
    """entry_str format: 'file.py:func' relative to this directory."""
    here = pathlib.Path(__file__).resolve().parent
    mod_file, _, func_name = entry_str.partition(":")
    if not func_name:
        func_name = "run"
    mod_path = here / mod_file
    if not mod_path.exists():
        raise FileNotFoundError(f"entry module not found: {mod_path}")
    spec = importlib.util.spec_from_file_location("script_entry", str(mod_path))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load module from {mod_path}")
    mod = importlib.util.module_from_spec(spec)  # type: ignore
    spec.loader.exec_module(mod)  # type: ignore
    fn = getattr(mod, func_name, None)
    if not callable(fn):
        raise AttributeError(f"entry function not found: {func_name} in {mod_file}")
    return mod, fn, str(mod_path), func_name


def _apply_env(env_overlay: Dict[str, Any]) -> Dict[str, str | None]:
    """Apply manifest env into os.environ.

    Important safety: if manifest provides an empty value (""/None), DO NOT overwrite an existing env var.
    This avoids accidentally clearing secrets injected by the platform.
    """
    backup: Dict[str, str | None] = {}
    for k, v in env_overlay.items():
        key = str(k)
        backup[key] = os.environ.get(key)

        if v is None:
            continue
        sval = str(v)
        if sval.strip() == "" and os.environ.get(key) is not None:
            # keep existing env if manifest leaves it empty
            continue
        os.environ[key] = sval
    return backup


def _restore_env(backup: Dict[str, str | None]) -> None:
    for k, prev in backup.items():
        if prev is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = prev


def _run_final_cpe_info() -> bool:
    """Optional final `cpe_info --internet` check."""
    tool = os.environ.get("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
    cmd = [tool, "--internet"]
    timeout_s = float(os.environ.get("CPE_INFO_TIMEOUT_SEC", "60"))
    log(f"[runner] Final CPE internet check: {' '.join(cmd)} (timeout={timeout_s}s)")
    t0 = time.time()
    try:
        proc = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout_s)
        dt = time.time() - t0
        out = (proc.stdout or "")
        ok = (proc.returncode == 0) and ("Internet Status: Connected" in out)
        print(json.dumps({"event": "final_status", "cmd": " ".join(cmd), "rc": proc.returncode, "ok": ok, "sec": round(dt, 3)}), flush=True)
        if out.strip():
            log(out.strip())
        log(f"[runner] Final CPE internet rc={proc.returncode} ok={ok} ({dt:.2f}s)")
        return ok
    except subprocess.TimeoutExpired:
        dt = time.time() - t0
        print(json.dumps({"event": "final_status", "cmd": " ".join(cmd), "rc": None, "ok": False, "timeout": True, "sec": round(dt, 3)}), flush=True)
        log(f"[runner] Final CPE internet check TIMEOUT after {dt:.2f}s")
        return False
    except Exception as e:
        dt = time.time() - t0
        print(json.dumps({"event": "final_status", "cmd": " ".join(cmd), "rc": None, "ok": False, "error": repr(e), "sec": round(dt, 3)}), flush=True)
        log(f"[runner] Final CPE internet check EXCEPTION after {dt:.2f}s: {e!r}")
        return False


def run() -> int:
    man, menv, manifest_entry, original_entry, cycles, interval, stop_on_fail = _load_manifest()

    # Optional: run precondition() once in cycle #1
    try:
        precondition_first_cycle = int(str(menv.get("PRECONDITION_FIRST_CYCLE", os.environ.get("PRECONDITION_FIRST_CYCLE", "1"))).strip())
    except Exception:
        precondition_first_cycle = 1

    # Safety: avoid accidental recursion
    if str(original_entry).strip() == "cycle_wrapper.py:run":
        log("[wrapper] WARNING: ORIGINAL_ENTRY points to cycle_wrapper.py:run — overriding to main_impl.py:run")
        original_entry = "main_impl.py:run"

    mod, fn, mod_path, func_name = _resolve_entry(str(original_entry))
    precond_fn = getattr(mod, "precondition", None)

    name = str(man.get("name") or "unnamed")
    print(json.dumps({"event": "runner_start", "name": name}), flush=True)
    log(f"[runner] START  {name}")
    log(f"          cycles={cycles} interval={interval}s stop_on_fail={stop_on_fail} original_entry={original_entry} (manifest_entry={manifest_entry})")

    overall_rc = 0
    per_cycle = []

    for i in range(1, cycles + 1):
        print(json.dumps({"event": "cycle_start", "i": i, "cycle": i, "total": cycles}), flush=True)
        log(f"[runner] Cycle #{i} — invoking {mod_path}:{func_name}")

        backup = _apply_env(menv)
        backup_cycle = {"CYCLE_INDEX": os.environ.get("CYCLE_INDEX"), "CYCLE_TOTAL": os.environ.get("CYCLE_TOTAL")}
        os.environ["CYCLE_INDEX"] = str(i)
        os.environ["CYCLE_TOTAL"] = str(cycles)

        t0 = time.time()
        rc = 1
        err = None
        try:
            if i == 1 and precondition_first_cycle == 1 and callable(precond_fn):
                log("[runner] Precondition() — running once in cycle #1")
                pre_rc = int(precond_fn())
                if pre_rc != 0:
                    rc = pre_rc
                    raise RuntimeError(f"precondition failed rc={pre_rc}")
            rc = int(fn())
        except SystemExit as e:
            rc = int(e.code) if isinstance(e.code, int) else 1
        except Exception as e:
            err = repr(e)
            rc = 1
        finally:
            # restore cycle vars
            if backup_cycle["CYCLE_INDEX"] is None:
                os.environ.pop("CYCLE_INDEX", None)
            else:
                os.environ["CYCLE_INDEX"] = backup_cycle["CYCLE_INDEX"]  # type: ignore
            if backup_cycle["CYCLE_TOTAL"] is None:
                os.environ.pop("CYCLE_TOTAL", None)
            else:
                os.environ["CYCLE_TOTAL"] = backup_cycle["CYCLE_TOTAL"]  # type: ignore
            _restore_env(backup)

        dur = time.time() - t0
        ok = (rc == 0)
        per_cycle.append({"i": i, "ok": ok, "rc": rc, "dur_sec": round(dur, 3), "err": err})

        print(json.dumps({"event": "cycle_end", "i": i, "ok": ok, "rc": rc, "dur_sec": round(dur, 3)}), flush=True)
        log(f"[runner] Cycle #{i} {'✓ PASS' if ok else '✗ FAIL'} rc={rc} ({dur:.2f}s)")

        if not ok and stop_on_fail:
            overall_rc = 1
            log("[runner] STOP_ON_FAIL=1 — aborting further cycles")
            break

        if i < cycles and interval > 0:
            time.sleep(interval)

        overall_rc = max(overall_rc, 0 if ok else 1)

    # Optional final status check
    final_internet_ok = None
    if os.environ.get("FINAL_STATUS_CHECK", "0") == "1":
        final_internet_ok = _run_final_cpe_info()

    passed = sum(1 for c in per_cycle if c["ok"])
    failed = len(per_cycle) - passed

    print(json.dumps({
        "event": "runner_summary",
        "name": name,
        "cycles_planned": cycles,
        "cycles_ran": len(per_cycle),
        "passed": passed,
        "failed": failed,
        "final_internet_ok": final_internet_ok,
        "rc": overall_rc,
    }), flush=True)

    log(f"[runner] END  rc={overall_rc}  passed={passed} failed={failed}")
    return int(overall_rc)


if __name__ == "__main__":
    sys.exit(run())
