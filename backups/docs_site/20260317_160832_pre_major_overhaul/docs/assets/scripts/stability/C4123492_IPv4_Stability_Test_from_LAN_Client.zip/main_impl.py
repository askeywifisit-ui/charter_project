#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""C4123492 - IPv4 Stability Test from the LAN Client (professional).

Key behaviors (aligned to your lab/customer scripting style):
- precondition() runs once (cycle #1 via cycle_wrapper):
    * cpe_info --cloud retry -> (optional) PDU reset once -> retry
    * ensure SSH ready (scan port 22 + NOC ssh-enable if needed)
- every cycle:
    * scan port 22 + (optional) ssh-enable (attempt=2)
    * LAN client ping CPE (target=CPE_HOST)
    * CPE ping WAN gateway (auto-detect or env CPE_WAN_GATEWAY)
    * if loss>=LOSS_TRIGGER_PCT or consecutive fails>=CONSEC_FAIL_TRIGGER_N => logpull

LAN ping backends:
- auto (default): macvlan -> pbr -> plain
- macvlan: uses tools/lan_macvlan.py module (netns/macvlan)
- pbr: uses tools/pbr_cpe.py (setup+teardown) then net_probe ping
- plain: uses tools/net_probe.py ping

This script avoids jq and console access.
"""

from __future__ import annotations

import atexit
import json
import os
import pathlib
import re
import socket
import subprocess
import sys
import time
from typing import Any, Dict, Optional, Tuple

# Ensure tools modules (noc_api_cli, etc.) are importable.
_TP = (os.environ.get('TOOLS_PATH') or os.environ.get('TOOLS_DIR') or '/home/da40/charter/tools').strip()
if _TP and _TP not in sys.path:
    sys.path.insert(0, _TP)


# ------------------------------------------------------------
# Logging helpers
# ------------------------------------------------------------

def _ts() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())


def _emit(event: str, **k: Any) -> None:
    d: Dict[str, Any] = {"event": event}
    if _gi("LOG_INCLUDE_TS", 0) == 1:
        d["ts"] = _ts()
    d.update(k)
    print(json.dumps(d, ensure_ascii=False), flush=True)


def _log(msg: str) -> None:
    print(msg, flush=True)


# ------------------------------------------------------------
# Env helpers
# ------------------------------------------------------------

def _g(name: str, default: Any = "") -> str:
    v = os.environ.get(name)
    if v is None:
        return str(default)
    return str(v)


def _gi(name: str, default: int) -> int:
    try:
        return int(str(os.environ.get(name, str(default))).strip())
    except Exception:
        return int(default)


def _gb(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    s = str(v).strip().lower()
    if s in ("1", "true", "yes", "on", "y"):
        return True
    if s in ("0", "false", "no", "off", "n"):
        return False
    return default


# ------------------------------------------------------------
# Tool paths
# ------------------------------------------------------------

def _tools_path() -> str:
    return (_g("TOOLS_PATH", _g("TOOLS_DIR", "/home/da40/charter/tools")) or "/home/da40/charter/tools").strip()


def _tool(name: str) -> str:
    """Return tool path.
    Search order: TOOLS_PATH/<name>, then local script dir (packaged fallback).
    """
    tp = pathlib.Path(_tools_path())
    here = pathlib.Path(__file__).resolve().parent
    for p in (tp / name, here / name):
        try:
            if p.exists():
                return str(p)
        except Exception:
            pass
    return str(tp / name)



def _cpe_info_tool() -> str:
    return _g("CPE_INFO_TOOL", _tool("cpe_info"))


def _cpe_host() -> str:
    return _g("CPE_HOST", "192.168.1.1").strip() or "192.168.1.1"


def _cpe_ssh_user() -> str:
    return (_g("CPE_SSH_USER", _g("CPE_USER", "operator")) or "operator").strip() or "operator"


def _cpe_ssh_port() -> int:
    return _gi("CPE_SSH_PORT", 22)




def _ping_iface() -> str:
    """Single source of truth for LAN-client interface.

    Users can set PING_IFACE only, and other iface knobs will follow.
    """
    for key in ("PING_IFACE", "PROBE_IFACE", "PBR_IFACE", "LAN_PARENT_IFACE"):
        v = _g(key, "").strip()
        if v:
            return v
    return ""

def _get_cpe_password() -> str:
    for k in ("SSH_PASSWORD", "CPE_SSH_PASSWORD", "CPE_PASSWORD", "CPE_PASS", "PASSWORD"):
        v = os.environ.get(k)
        if v and str(v).strip().lower() not in ("", "none", "null"):
            return str(v).strip()
    dflt = os.environ.get("SSH_PASSWORD_DEFAULT", "123456789")
    return str(dflt).strip() if dflt else ""


def _run(argv: list[str], timeout: float = 30.0) -> Tuple[int, str]:
    """Run a subprocess and emit a compact event."""
    t0 = time.time()
    try:
        p = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)
        out = (p.stdout or "").strip()
        _emit(
            "cmd",
            ok=(p.returncode == 0),
            rc=p.returncode,
            sec=round(time.time() - t0, 3),
            argv=argv,
            sample=out.splitlines()[:3],
        )
        return p.returncode, out
    except subprocess.TimeoutExpired:
        _emit("cmd", ok=False, rc=None, timeout=True, sec=round(time.time() - t0, 3), argv=argv)
        return 124, ""


# ------------------------------------------------------------
# Lazy imports of tools modules (IMPORTANT)
# cycle_wrapper imports this module before applying manifest env overlay.
# ------------------------------------------------------------

_NOC_MOD = None


def _get_noc_module():
    global _NOC_MOD
    if _NOC_MOD is not None:
        return _NOC_MOD
    tp = _tools_path()
    try:
        if tp and tp not in sys.path:
            sys.path.insert(0, tp)
        import noc_api_cli as _noc  # type: ignore

        _NOC_MOD = _noc
        return _NOC_MOD
    except Exception as e:
        _emit("noc_import_error", ok=False, tools_path=tp, error=str(e))
        _NOC_MOD = None
        return None


_PROFILE_LOADED = False


def _load_profile_into_env() -> None:
    """Load NOC profile secrets from PROFILES_FILE if NOC_PROFILE is set."""
    global _PROFILE_LOADED
    if _PROFILE_LOADED:
        return

    profile = _g("NOC_PROFILE", "").strip()
    if not profile:
        _PROFILE_LOADED = True
        return

    path = os.environ.get("PROFILES_FILE") or os.path.expanduser("~/.secrets/noc_profiles.json")

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        _emit("noc_profile_missing", profile=profile, path=path)
        return
    except Exception as e:
        _emit("noc_profile_load_error", profile=profile, path=path, error=str(e))
        return

    prof = data.get(profile) or data.get(profile.upper()) or {}
    if not prof:
        _emit("noc_profile_not_found", profile=profile, path=path)
        return

    applied = []
    mapping = {
        "NOC_BASE": "base",
        "NOC_EMAIL": "email",
        "NOC_PASSWORD": "password",
        "CUSTOMER_ID": "customer_id",
        "LOCATION_ID": "location_id",
        "BEARER": "bearer",
        "INSECURE": "insecure",
    }

    for env_k, json_k in mapping.items():
        if os.environ.get(env_k) and str(os.environ.get(env_k)).strip() != "":
            continue
        if json_k in prof and prof[json_k] is not None:
            os.environ[env_k] = str(prof[json_k])
            applied.append(env_k)

    _emit("noc_profile_loaded", profile=profile, applied=applied)
    _PROFILE_LOADED = True


# ------------------------------------------------------------
# TCP helpers
# ------------------------------------------------------------

def _tcp_open(host: str, port: int, per_try_timeout: float = 2.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=per_try_timeout):
            return True
    except Exception:
        return False


def _tcp_wait(host: str, port: int, timeout_sec: int, interval_sec: float = 2.0) -> bool:
    t0 = time.time()
    while time.time() - t0 < timeout_sec:
        if _tcp_open(host, port, per_try_timeout=min(2.0, interval_sec)):
            return True
        time.sleep(interval_sec)
    return False


# ------------------------------------------------------------
# PDU reset (used only in precondition)
# ------------------------------------------------------------

def _pdu_reset_once() -> bool:
    script = _g("PDU_SCRIPT", "").strip()
    if not script:
        _emit("step_end", name="pdu_reset", ok=False, error="PDU_SCRIPT not set")
        return False

    outlet_id = _g("PDU_OUTLET_ID", "").strip()

    # keep only PDU_SCRIPT + PDU_OUTLET_ID, try common syntaxes
    candidates: list[list[str]] = []
    base = os.path.basename(script)
    if base in ("pdu_outlet1.py",):
        candidates = [["python3", script, "reset"]]
    else:
        if outlet_id:
            candidates += [
                ["python3", script, "--outlet", outlet_id, "--action", "reset"],
                ["python3", script, "--outlet-id", outlet_id, "--action", "reset"],
                ["python3", script, "--id", outlet_id, "--action", "reset"],
                ["python3", script, str(outlet_id), "reset"],
            ]
        candidates += [["python3", script, "reset"]]

    _emit("step_start", name="pdu_reset", script=script, outlet_id=outlet_id)
    for argv in candidates:
        rc, out = _run(argv, timeout=60)
        if rc == 0:
            _emit("step_end", name="pdu_reset", ok=True, argv=argv)
            wait_sec = _gi("PDU_WAIT_SEC", 120)
            if wait_sec > 0:
                _emit("pdu_wait", seconds=wait_sec)
                time.sleep(wait_sec)
            return True
        _emit("step_progress", name="pdu_reset", ok=False, argv=argv, rc=rc, sample=out.splitlines()[:2])

    _emit("step_end", name="pdu_reset", ok=False)
    return False


# ------------------------------------------------------------
# CPE ready (cloud) check with optional one-time PDU reset
# ------------------------------------------------------------

def _cpe_cloud_connected(timeout_sec: int) -> Tuple[bool, list[str]]:
    rc, out = _run([_cpe_info_tool(), "--cloud"], timeout=timeout_sec)
    ok = (rc == 0) and ("Cloud Status: Connected" in out or "Connected" in out)
    return ok, out.splitlines()[:3]


def cpe_ready_with_one_pdu_reset() -> bool:
    """Retry cpe_info --cloud, then PDU reset once, then retry."""
    timeout = _gi("CPE_INFO_TIMEOUT_SEC", 30)
    before_n = _gi("CPE_READY_RETRIES_BEFORE_RESET", 3)
    after_n = _gi("CPE_READY_RETRIES_AFTER_RESET", 6)
    sleep_sec = _gi("CPE_READY_RETRY_SLEEP_SEC", 10)
    do_reset = _gb("DO_PDU_RESET_ON_READY_FAIL", True)

    _emit(
        "step_start",
        name="cpe_ready",
        before_retries=before_n,
        after_retries=after_n,
        sleep_sec=sleep_sec,
        do_pdu_reset=do_reset,
        tool=_cpe_info_tool(),
    )

    def _try(n: int, phase: str) -> bool:
        for i in range(1, n + 1):
            ok, sample = _cpe_cloud_connected(timeout)
            _emit("step_progress", name="cpe_ready", phase=phase, try_no=i, ok=ok, sample=sample)
            if ok:
                return True
            if i < n:
                time.sleep(sleep_sec)
        return False

    if _try(before_n, "before_reset"):
        _emit("step_end", name="cpe_ready", ok=True)
        return True

    if do_reset:
        _emit("cpe_ready_timeout", ok=False, action="pdu_reset_once")
        _pdu_reset_once()

    if _try(after_n, "after_reset"):
        _emit("step_end", name="cpe_ready", ok=True)
        return True

    _emit("step_end", name="cpe_ready", ok=False)
    return False


# ------------------------------------------------------------
# NOC SSH enable helpers
# ------------------------------------------------------------

def _noc_login() -> Tuple[str, Dict[str, Any]]:
    noc = _get_noc_module()
    if noc is None:
        raise RuntimeError("noc_api_cli not importable")

    base = _g("NOC_BASE", "https://piranha-int.tau.dev-charter.net").strip()
    email = _g("NOC_EMAIL", "").strip()
    password = _g("NOC_PASSWORD", "").strip()
    bearer = _gb("BEARER", False)
    insecure = _gb("INSECURE", False)

    if not email or not password:
        raise RuntimeError("NOC_EMAIL/NOC_PASSWORD not set (or missing in PROFILES_FILE)")

    token = noc.login(base, email, password, bearer=bearer, insecure=insecure)
    meta = {"base": base, "bearer": bearer, "insecure": insecure, "email": email}
    return token, meta


def _noc_resolve_location(base: str, token: str, node_id: str) -> str:
    noc = _get_noc_module()
    if noc is None:
        raise RuntimeError("noc_api_cli not importable")

    customer_id = _g("CUSTOMER_ID", "").strip()
    if not customer_id:
        raise RuntimeError("CUSTOMER_ID not set")

    bearer = _gb("BEARER", False)
    insecure = _gb("INSECURE", False)

    loc_env = _g("LOCATION_ID", "").strip()
    if loc_env:
        return loc_env

    return noc.get_location_id(base, customer_id, node_id, token=token, bearer=bearer, insecure=insecure)


def _get_node_id() -> str:
    rc, out = _run([_cpe_info_tool(), "--node-id"], timeout=15)
    if rc != 0:
        return ""
    for line in out.splitlines():
        s = line.strip()
        if s:
            return s
    return ""


def enable_ssh_via_noc(node_id: str, ssh_password: str) -> bool:
    noc = _get_noc_module()
    if noc is None:
        _emit("ssh_enable", ok=False, error="noc_api_cli not importable")
        return False

    customer_id = _g("CUSTOMER_ID", "").strip()
    if not customer_id:
        _emit("ssh_enable", ok=False, error="CUSTOMER_ID not set")
        return False

    try:
        token, meta = _noc_login()
        base = meta["base"]
        bearer = bool(meta["bearer"])
        insecure = bool(meta["insecure"])
        location_id = _noc_resolve_location(base, token, node_id)

        timeout_min = _gi("SSH_TIMEOUT_MIN", 120)
        _emit(
            "ssh_enable_start",
            node_id=node_id,
            location_id=location_id,
            customer_id=customer_id,
            timeout_min=timeout_min,
            base=base,
        )

        resp = noc.ssh_enable(
            base,
            customer_id,
            location_id,
            node_id,
            ssh_password,
            timeout_min,
            token=token,
            bearer=bearer,
            insecure=insecure,
        )
        _emit("ssh_enable_end", ok=True, resp=resp)
        return True
    except Exception as e:
        _emit("ssh_enable_end", ok=False, error=str(e))
        return False


def _cpe_ssh_cli(extra_argv: list[str], *, timeout: float) -> Tuple[int, str]:
    tool = _tool("cpe_ssh.py")
    argv = ["python3", tool] + extra_argv
    return _run(argv, timeout=timeout)


def ensure_ssh_ready() -> bool:
    """Ensure SSH port open + simple command works; enable via NOC if needed."""
    host = _cpe_host()
    port = _cpe_ssh_port()

    scan_timeout = _gi("SSH_SCAN_TIMEOUT_SEC", 30)
    scan_interval = float(_g("SSH_SCAN_INTERVAL_SEC", "2") or "2")

    ssh_user = _cpe_ssh_user()
    ssh_pass = _get_cpe_password()
    ssh_timeout = float(_g("CPE_SSH_TIMEOUT_SEC", "30") or "30")

    node_id = _get_node_id()

    _emit(
        "step_start",
        name="ssh_ready",
        host=host,
        port=port,
        scan_timeout_sec=scan_timeout,
        scan_interval_sec=scan_interval,
        user=ssh_user,
        have_password=bool(ssh_pass),
        node_id=node_id,
    )

    enable_retries = _gi("SSH_ENABLE_RETRIES", 2)
    wait_after_enable = _gi("WAIT_AFTER_SSH_ENABLE_SEC", 60)

    def _ssh_probe() -> bool:
        # Use uptime (banner-safe: tool prints short string)
        extra = [
            "--host",
            host,
            "--user",
            ssh_user,
            "--password",
            ssh_pass,
            "--timeout",
            str(ssh_timeout),
            "--cmd",
            "uptime",
        ]
        t0 = time.time()
        rc, out = _cpe_ssh_cli(extra, timeout=ssh_timeout + 15)
        sec = round(time.time() - t0, 3)
        sample = (out or "").strip().splitlines()[-2:]
        ok = rc == 0
        _emit("ssh_probe", ok=ok, rc=rc, sec=sec, sample=sample)
        return ok

    for attempt in range(1, enable_retries + 1):
        port_ok = _tcp_wait(host, port, timeout_sec=scan_timeout, interval_sec=scan_interval)
        _emit("ssh_port", ok=port_ok, attempt=attempt)

        if port_ok and _ssh_probe():
            _emit("step_end", name="ssh_ready", ok=True)
            return True

        if not node_id:
            _emit("ssh_enable_skip", ok=False, error="node_id not available")
            break
        if not ssh_pass:
            _emit("ssh_enable_skip", ok=False, error="ssh_password not available")
            break

        ok = enable_ssh_via_noc(node_id=node_id, ssh_password=ssh_pass)
        if not ok:
            _emit("ssh_enable_attempt_failed", attempt=attempt)
            continue
        if wait_after_enable > 0:
            _emit("ssh_enable_wait", seconds=wait_after_enable)
            time.sleep(wait_after_enable)

    _emit("step_end", name="ssh_ready", ok=False)
    return False


# ------------------------------------------------------------
# WAN gateway detection and ping from CPE
# ------------------------------------------------------------

def _wan_gw_from_ssh() -> str:
    """Try to detect WAN default gateway from CPE via SSH (best-effort)."""
    gw_env = _g("CPE_WAN_GATEWAY", "").strip()
    if gw_env:
        return gw_env

    # Use python import to run arbitrary remote cmd (not via cpe_ssh --cmd)
    tp = _tools_path()
    if tp and tp not in sys.path:
        sys.path.insert(0, tp)
    try:
        import cpe_ssh as cpe_ssh_mod  # type: ignore
    except Exception as e:
        _emit("wan_gw_detect", ok=False, error=f"import cpe_ssh failed: {e}")
        return ""

    host = _cpe_host()
    user = _cpe_ssh_user()
    pw = _get_cpe_password()
    timeout = float(_g("CPE_SSH_TIMEOUT_SEC", "30") or "30")

    candidates = [
        "ip route show default | awk '{print $3; exit}'",
        "route -n | awk '$1==\"0.0.0.0\" {print $2; exit}'",
    ]

    for cmd in candidates:
        try:
            rc, out, err, sec = cpe_ssh_mod.ssh_exec(host, user, pw, cmd, timeout=timeout, login_shell=True)
            txt = (out or "") + "\n" + (err or "")
            m = re.search(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b", txt)
            if rc == 0 and m:
                gw = m.group(1)
                _emit("wan_gw_detect", ok=True, gw=gw, cmd=cmd, sec=sec)
                return gw
            _emit("wan_gw_detect", ok=False, cmd=cmd, rc=rc, sample=txt.strip().splitlines()[:2])
        except Exception as e:
            _emit("wan_gw_detect", ok=False, cmd=cmd, error=str(e))

    return ""


def cpe_ping(target: str, count: int) -> Dict[str, Any]:
    host = _cpe_host()
    user = _cpe_ssh_user()
    pw = _get_cpe_password()
    timeout = float(_g("CPE_SSH_TIMEOUT_SEC", "30") or "30")

    extra = [
        "--host",
        host,
        "--user",
        user,
        "--password",
        pw,
        "--timeout",
        str(timeout),
        "--cmd",
        "ping",
        "--target",
        target,
        "--count",
        str(count),
    ]

    t0 = time.time()
    rc, out = _cpe_ssh_cli(extra, timeout=timeout + max(10, count * 3))
    sec = round(time.time() - t0, 3)

    ok = rc == 0
    loss_pct = None
    try:
        j = json.loads(out or "{}")
        ok = bool(j.get("ok")) if "ok" in j else ok
        loss_pct = j.get("loss_pct")
    except Exception:
        pass

    return {"ok": ok, "rc": rc, "sec": sec, "loss_pct": loss_pct, "sample": (out or "").splitlines()[:3]}


# ------------------------------------------------------------
# LAN ping backends
# ------------------------------------------------------------

PING_SUMMARY_RE = re.compile(r"(?P<tx>\d+)\s+packets\s+transmitted,\s+(?P<rx>\d+)\s+received.*?(?P<loss>\d+\.?\d*)%")


def _parse_loss_pct(text: str) -> Optional[float]:
    m = PING_SUMMARY_RE.search(text or "")
    if not m:
        return None
    try:
        return float(m.group("loss"))
    except Exception:
        return None


def _sudo_prefix() -> list[str]:
    # non-interactive sudo only
    return ["sudo", "-n"]


def _can_sudo() -> bool:
    try:
        p = subprocess.run(_sudo_prefix() + ["true"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return p.returncode == 0
    except Exception:
        return False


def _have_priv() -> bool:
    """True if we can do privileged net ops (root or passwordless sudo).

    Customer environments often block passwordless sudo, so auto backend should
    skip macvlan/pbr to avoid noisy failures.
    """
    if os.geteuid() == 0:
        return True
    return _can_sudo()



def lan_ping_plain(target: str, count: int, deadline: int) -> Dict[str, Any]:
    tool = _tool("net_probe.py")

    is_v6 = ":" in (target or "")
    src_ip = _g("PROBE_SRC_IP", "").strip()
    iface = _g("PROBE_IFACE", "").strip() or _ping_iface()

    argv = ["python3", tool]
    if is_v6:
        argv += ["--ipv", "6"]
    if src_ip:
        argv += ["--src-ip", src_ip]
    elif iface:
        argv += ["--iface", iface]
    argv += ["--json", "ping", target, "-c", str(count), "--deadline", str(deadline)]

    rc, out = _run(argv, timeout=max(deadline + 10, count * 3 + 10))
    ok = rc == 0
    loss_pct = None
    rtt = None
    try:
        j = json.loads(out or "{}")
        ok = bool(j.get("ok"))
        loss_pct = j.get("loss_percent")
        rtt = j.get("rtt_ms")
    except Exception:
        pass

    return {"backend": "plain", "ok": ok, "rc": rc, "loss_pct": loss_pct, "rtt_ms": rtt}



def lan_ping_pbr(target: str, count: int, deadline: int) -> Dict[str, Any]:
    """Best-effort: pbr_cpe.py setup+teardown + net_probe ping."""
    if os.geteuid() != 0 and not _can_sudo():
        # Without passwordless sudo, we cannot apply ip rule/route changes.
        return {"backend": "pbr", "ok": False, "rc": 1, "error": "sudo_required"}
    pbr = _tool("pbr_cpe.py")

    iface = _g("PBR_IFACE", _g("PROBE_IFACE", "eno2")).strip() or "eno2"
    src_ip = _g("PBR_SRC_IP", "").strip()
    gw = _g("PBR_GW", _cpe_host()).strip() or _cpe_host()
    subnet = _g("PBR_SUBNET", "192.168.1.0/24").strip() or "192.168.1.0/24"

    # auto-detect src-ip from iface if empty
    if not src_ip:
        try:
            rc, out = _run(["bash", "-lc", f"ip -4 -o addr show dev {iface} | awk '{{print $4}}' | head -n1"], timeout=5)
            if rc == 0:
                cand = (out.splitlines()[:1] or [""])[0].strip()
                if "/" in cand:
                    src_ip = cand.split("/", 1)[0]
        except Exception:
            pass

    if not src_ip:
        return {"backend": "pbr", "ok": False, "rc": 2, "error": "PBR_SRC_IP_not_set"}

    table_id = _gi("PBR_TABLE_ID", 100)
    prio_from = _gi("PBR_PRIO_FROM", 1000)
    prio_to = _gi("PBR_PRIO_TO", 1001)

    base = ["python3", pbr, "--src-ip", src_ip, "--iface", iface, "--gw", gw, "--subnet", subnet,
            "--table-id", str(table_id), "--prio-from", str(prio_from), "--prio-to", str(prio_to)]

    # setup
    setup_cmd = base + ["setup"]
    if os.geteuid() != 0:
        setup_cmd = _sudo_prefix() + setup_cmd
    rc_setup, _ = _run(setup_cmd, timeout=15)
    if rc_setup != 0:
        return {"backend": "pbr", "ok": False, "rc": rc_setup, "error": "pbr_setup_failed"}

    try:
        # ping via net_probe using src-ip
        # Reuse plain backend but force src-ip
        tool_np = _tool("net_probe.py")
        argv = ["python3", tool_np, "--src-ip", src_ip, "--json", "ping", target, "-c", str(count), "--deadline", str(deadline)]
        rc, out = _run(argv, timeout=max(deadline + 10, count * 3 + 10))
        ok = rc == 0
        loss_pct = None
        rtt = None
        try:
            j = json.loads(out or "{}")
            ok = bool(j.get("ok"))
            loss_pct = j.get("loss_percent")
            rtt = j.get("rtt_ms")
        except Exception:
            pass
        return {"backend": "pbr", "ok": ok, "rc": rc, "loss_pct": loss_pct, "rtt_ms": rtt, "src_ip": src_ip}
    finally:
        # teardown best-effort
        td_cmd = base + ["teardown"]
        if os.geteuid() != 0:
            td_cmd = _sudo_prefix() + td_cmd
        _run(td_cmd, timeout=15)


def lan_ping_macvlan(target: str, count: int, timeout_w: int) -> Dict[str, Any]:
    """Use tools/lan_macvlan.py module to create a netns + macvlan, renew DHCP, then ping."""
    if os.geteuid() != 0 and not _can_sudo():
        # Current lan_macvlan implementation relies on sudo -n for netns/macvlan.
        return {"backend": "macvlan", "ok": False, "rc": 1, "error": "sudo_required"}
    tp = _tools_path()
    if tp and tp not in sys.path:
        sys.path.insert(0, tp)

    try:
        import lan_macvlan as lm  # type: ignore
    except Exception as e:
        return {"backend": "macvlan", "ok": False, "rc": 2, "error": f"import_failed: {e}"}

    parent = _g("LAN_PARENT_IFACE", "").strip() or _ping_iface() or None

    # lan_macvlan internally uses sudo -n for privileged ops; still might fail.
    t0 = time.time()
    try:
        with lm.MacvlanNS(parent_iface=parent, ns="auto", v_iface="lan_test0", mac=None) as mv:
            mv.renew_dhcp()

            # Execute ping in the netns but capture output to parse loss
            # Reuse lan_macvlan helpers for DNS-resolv fix.
            if re.match(r"^\d{1,3}(?:\.\d{1,3}){3}$", target):
                cp = lm._ip_netns_exec(mv.ns, ["ping", "-c", str(count), "-W", str(timeout_w), target], timeout=timeout_w * count + 10)
                txt = (cp.stdout or "") + "\n" + (cp.stderr or "")
            else:
                dns = mv.get_dns_servers()
                txt = ""
                if dns:
                    resolv_text = lm.build_resolv_conf(dns)
                    resolv_path = f"/tmp/resolv_{mv.ns}_{os.getpid()}.conf"
                    lm._write_text(resolv_path, resolv_text)
                    cp = lm.netns_exec_with_resolv(mv.ns, resolv_path, ["ping", "-c", str(count), "-W", str(timeout_w), target], timeout=timeout_w * count + 10)
                    txt = (cp.stdout or "") + "\n" + (cp.stderr or "")
                else:
                    cp = lm._ip_netns_exec(mv.ns, ["ping", "-c", str(count), "-W", str(timeout_w), target], timeout=timeout_w * count + 10)
                    txt = (cp.stdout or "") + "\n" + (cp.stderr or "")

            loss = _parse_loss_pct(txt)
            ok = loss is not None and loss < 100.0
            sec = round(time.time() - t0, 3)
            return {
                "backend": "macvlan",
                "ok": ok,
                "rc": 0 if ok else 1,
                "loss_pct": loss,
                "sec": sec,
                "parent": mv.parent_iface,
                "src_ipv4": mv.get_ipv4(),
            }
    except Exception as e:
        sec = round(time.time() - t0, 3)
        # permission errors are common in customer env
        return {"backend": "macvlan", "ok": False, "rc": 1, "sec": sec, "error": str(e)}


def lan_ping_auto(target: str, count: int, deadline: int) -> Dict[str, Any]:
    """auto: try macvlan -> pbr -> plain."""
    # If we cannot run passwordless sudo, trying macvlan/pbr will produce noisy
    # failures like "sudo: a password is required". In those customer envs,
    # skip directly to the plain backend.
    if not _have_priv():
        _emit("lan_ping_skip", backend="macvlan", reason="sudo_unavailable")
        _emit("lan_ping_skip", backend="pbr", reason="sudo_unavailable")
        r = lan_ping_plain(target, count=count, deadline=deadline)
        _emit("lan_ping_attempt", backend="plain", **{k: r.get(k) for k in ("ok", "loss_pct")})
        return r
    # macvlan
    mv_count = _gi("LAN_MACVLAN_PING_COUNT", count)
    mv_to = _gi("LAN_MACVLAN_PING_TIMEOUT_SEC", 2)
    r1 = lan_ping_macvlan(target, count=mv_count, timeout_w=mv_to)
    _emit("lan_ping_attempt", backend="macvlan", **{k: r1.get(k) for k in ("ok", "loss_pct", "error", "sec")})
    if r1.get("ok"):
        return r1

    # pbr
    r2 = lan_ping_pbr(target, count=count, deadline=deadline)
    _emit("lan_ping_attempt", backend="pbr", **{k: r2.get(k) for k in ("ok", "loss_pct", "error", "src_ip")})
    if r2.get("ok"):
        return r2

    # plain
    r3 = lan_ping_plain(target, count=count, deadline=deadline)
    _emit("lan_ping_attempt", backend="plain", **{k: r3.get(k) for k in ("ok", "loss_pct")})
    return r3


def lan_ping(target: str, count: int, deadline: int) -> Dict[str, Any]:
    mode = _g("LAN_PING_BACKEND", "auto").strip().lower() or "auto"
    if mode == "plain":
        return lan_ping_plain(target, count=count, deadline=deadline)
    if mode == "pbr":
        return lan_ping_pbr(target, count=count, deadline=deadline)
    if mode == "macvlan":
        to_w = _gi("LAN_MACVLAN_PING_TIMEOUT_SEC", 2)
        return lan_ping_macvlan(target, count=count, timeout_w=to_w)
    return lan_ping_auto(target, count=count, deadline=deadline)


# ------------------------------------------------------------
# Logpull (triggered)
# ------------------------------------------------------------

def _detect_run_dir() -> str:
    p = os.environ.get("RUN_DIR", "")
    if p and re.search(r"/run_\d+(?:/|$)", p) and os.path.isdir(p):
        return p
    cwd = os.getcwd()
    m = re.search(r"(.*?/run_\d+)(?:/|$)", cwd)
    if m and os.path.isdir(m.group(1)):
        return m.group(1)
    here = os.path.dirname(os.path.abspath(__file__))
    m = re.search(r"(.*?/run_\d+)(?:/|$)", here)
    if m and os.path.isdir(m.group(1)):
        return m.group(1)
    return cwd


def _list_files(path: str, pattern: str) -> set[str]:
    try:
        import glob

        return set(glob.glob(os.path.join(path, pattern)))
    except Exception:
        return set()


def logpull() -> Dict[str, Any]:
    host = _cpe_host()
    user = _cpe_ssh_user()
    pw = _get_cpe_password()

    latest_dir = _g("LOGPULL_LATEST_DIR", "/tmp/logpull").strip() or "/tmp/logpull"
    pattern = _g("LOGPULL_PATTERN", "*.tar.gz").strip() or "*.tar.gz"

    run_dir = _detect_run_dir()
    out_dir = os.path.join(run_dir, "cpe_log")
    os.makedirs(out_dir, exist_ok=True)

    before = _list_files(out_dir, "*.tar.gz")

    _emit("logpull_start", dest=out_dir, latest_dir=latest_dir, pattern=pattern)
    argv = [
        "python3",
        _tool("cpe_ssh.py"),
        "--host",
        host,
        "--user",
        user,
        "--password",
        pw,
        "--cmd",
        "pull-log",
        "--latest-from-dir",
        latest_dir,
        "--pattern",
        pattern,
        "--dest",
        out_dir,
    ]
    rc, out = _run(argv, timeout=240)

    after = _list_files(out_dir, "*.tar.gz")
    new_files = sorted(list(after - before), key=lambda p: os.path.getmtime(p) if os.path.exists(p) else 0)
    picked = new_files[-1] if new_files else None

    # rename add run id (best-effort)
    if picked:
        rename_tool = _tool("log_rename_add_runid.py")
        _run(["python3", rename_tool, "--dest", out_dir, "--file", picked, "--pattern", "*.tar.gz"], timeout=30)

    meta = {
        "ok": rc == 0,
        "rc": rc,
        "dest": out_dir,
        "file": picked,
        "sample": (out or "").splitlines()[-3:],
    }
    _emit("logpull_end", **meta)
    return meta


# ------------------------------------------------------------
# Test execution
# ------------------------------------------------------------

_CONSEC_FAIL: Dict[str, int] = {"lan_ping_cpe": 0, "cpe_ping_wan_gw": 0}


def _update_consec(name: str, ok: bool) -> int:
    if ok:
        _CONSEC_FAIL[name] = 0
    else:
        _CONSEC_FAIL[name] = int(_CONSEC_FAIL.get(name, 0)) + 1
    return _CONSEC_FAIL[name]


def _should_trigger(loss_pct: Optional[float], consec: int) -> bool:
    trig_loss = _gi("LOSS_TRIGGER_PCT", 10)
    trig_consec = _gi("CONSEC_FAIL_TRIGGER_N", 3)
    loss_bad = (loss_pct is not None) and (loss_pct >= float(trig_loss))
    consec_bad = consec >= trig_consec
    return loss_bad or consec_bad


def precondition() -> int:
    """Run once in cycle #1 (via cycle_wrapper)."""
    _load_profile_into_env()

    _emit("precondition_start")

    if not cpe_ready_with_one_pdu_reset():
        _emit("precondition_end", ok=False, reason="cpe_not_ready")
        return 1

    # Ensure SSH ready (port scan + ssh-enable if needed)
    if not ensure_ssh_ready():
        _emit("precondition_end", ok=False, reason="ssh_not_ready")
        return 1

    _emit("precondition_end", ok=True)
    return 0


def run() -> int:
    """Per-cycle test body."""
    _load_profile_into_env()

    cycle = _gi("CYCLE_INDEX", 0)
    total = _gi("CYCLE_TOTAL", 0)
    _emit("cycle_context", cycle=cycle, total=total)

    # 0) ensure ssh ready each cycle (required)
    ssh_ok = ensure_ssh_ready()
    if _gb("REQUIRE_SSH_READY", True) and not ssh_ok:
        _emit("cycle_fail", reason="ssh_not_ready")
        return 1

    # 1) LAN ping CPE
    cpe_ip = _cpe_host()
    lan_count = _gi("LAN_PING_CPE_COUNT", 20)
    lan_deadline = _gi("LAN_PING_CPE_DEADLINE_SEC", 20)

    _emit("step_start", name="lan_ping_cpe", target=cpe_ip, count=lan_count, deadline=lan_deadline)
    res_lan = lan_ping(cpe_ip, count=lan_count, deadline=lan_deadline)
    loss_lan = res_lan.get("loss_pct")
    ok_lan = bool(res_lan.get("ok"))
    consec_lan = _update_consec("lan_ping_cpe", ok_lan)
    _emit("step_end", name="lan_ping_cpe", ok=ok_lan, backend=res_lan.get("backend"), loss_pct=loss_lan, consec_fail=consec_lan)

    # 2) CPE ping WAN gateway
    gw = _wan_gw_from_ssh()
    res_gw: Dict[str, Any] = {"ok": True, "skipped": True}
    ok_gw = True
    loss_gw = None
    consec_gw = 0
    if gw:
        cpe_gw_count = _gi("CPE_PING_GW_COUNT", 10)
        _emit("step_start", name="cpe_ping_wan_gw", target=gw, count=cpe_gw_count)
        res_gw = cpe_ping(gw, count=cpe_gw_count)
        ok_gw = bool(res_gw.get("ok"))
        loss_gw = res_gw.get("loss_pct")
        consec_gw = _update_consec("cpe_ping_wan_gw", ok_gw)
        _emit("step_end", name="cpe_ping_wan_gw", ok=ok_gw, loss_pct=loss_gw, consec_fail=consec_gw)
    else:
        _emit("step_end", name="cpe_ping_wan_gw", ok=True, skipped=True, reason="gw_not_found")

    # 3) trigger logpull?
    triggered = False
    trigger_reason = []
    if _should_trigger(loss_lan if isinstance(loss_lan, (int, float)) else None, consec_lan):
        triggered = True
        trigger_reason.append("lan")
    if _should_trigger(loss_gw if isinstance(loss_gw, (int, float)) else None, consec_gw):
        triggered = True
        trigger_reason.append("wan_gw")

    logpull_meta = None
    if triggered and _gb("LOGPULL_ON_TRIGGER", True) and ssh_ok:
        _emit("trigger", ok=True, reason=trigger_reason)
        logpull_meta = logpull()
    elif triggered:
        _emit("trigger", ok=False, reason=trigger_reason, skipped=True, ssh_ok=ssh_ok)

    # 4) overall cycle rc
    cycle_ok = ok_lan and ok_gw
    _emit(
        "cycle_result",
        ok=cycle_ok,
        lan={"ok": ok_lan, "loss_pct": loss_lan, "backend": res_lan.get("backend"), "consec_fail": consec_lan},
        wan_gw={"ok": ok_gw, "loss_pct": loss_gw, "gw": gw, "consec_fail": consec_gw},
        triggered=triggered,
        logpull=logpull_meta,
    )

    return 0 if cycle_ok else 1


if __name__ == "__main__":
    sys.exit(run())
