#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""main_impl.py - professional harness for C24541455_Multiple_speedtest

Responsibilities:
- Load NOC profile (NOC_PROFILE + PROFILES_FILE) without hard-coded creds.
- Precondition (optional, run once in cycle #1 via cycle_wrapper):
    * cpe_info --cloud ready check with retry.
- Delegate the actual test logic to main_impl_orig.run().
"""
import json
import os
import subprocess
import sys
import time
from typing import Any, Dict, List, Optional

TOOLS_PATH = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools").strip()
CPE_INFO_TOOL = os.environ.get("CPE_INFO_TOOL", os.path.join(TOOLS_PATH, "cpe_info")).strip()

def _emit(event: str, **kv: Any) -> None:
    obj = {"event": event}
    obj.update(kv)
    if "cycle" not in obj:
        try:
            obj["cycle"] = int(str(os.environ.get("CYCLE_INDEX", "0")).strip() or 0)
        except Exception:
            obj["cycle"] = 0
    if "tag" not in obj and obj.get("cycle", 0):
        obj["tag"] = f"cycle_{obj['cycle']}"
    try:
        print(json.dumps(obj, ensure_ascii=False))
    except Exception:
        print(obj)


def _read_json_file(path: str) -> Optional[Dict[str, Any]]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None

def _env_nonempty(name: str) -> str:
    return str(os.environ.get(name, "")).strip()

def load_noc_profile() -> None:
    """Load NOC_PROFILE from PROFILES_FILE.
    Supports keys: base/base_url, email, password, customer_id/customerId/CUSTOMER_ID.
    Only sets env vars when the value is non-empty (prevents empty-string override bugs).
    """
    profile = _env_nonempty("NOC_PROFILE")
    profiles_file = _env_nonempty("PROFILES_FILE")
    if not profile or not profiles_file:
        return

    data = _read_json_file(profiles_file)
    if not isinstance(data, dict) or profile not in data:
        _emit("noc_profile_missing", profile=profile, profiles_file=profiles_file)
        return

    p = data.get(profile) or {}
    applied: List[str] = []

    def _set_if(name: str, val: Optional[str]) -> None:
        nonlocal applied
        if val is None:
            return
        val = str(val).strip()
        if not val:
            return
        # do not overwrite an already-nonempty env var
        if _env_nonempty(name):
            return
        os.environ[name] = val
        applied.append(name)

    _set_if("NOC_BASE", p.get("base") or p.get("base_url") or p.get("NOC_BASE"))
    _set_if("NOC_EMAIL", p.get("email") or p.get("NOC_EMAIL"))
    _set_if("NOC_PASSWORD", p.get("password") or p.get("NOC_PASSWORD"))
    _set_if("CUSTOMER_ID", p.get("customer_id") or p.get("customerId") or p.get("CUSTOMER_ID"))

    _emit("noc_profile_loaded", profile=profile, applied=applied)

def _run(cmd: List[str], timeout: int = 30) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)

def cpe_cloud_ready(max_retries: int = 10, sleep_sec: float = 3.0, timeout_sec: int = 20) -> bool:
    tool = CPE_INFO_TOOL
    for n in range(1, max_retries + 1):
        t0 = time.time()
        try:
            proc = _run([tool, "--cloud"], timeout=timeout_sec)
            ok = (proc.returncode == 0) and ("Connected" in (proc.stdout or ""))
        except Exception as e:
            ok = False
            proc = None
            out = str(e)
        else:
            out = (proc.stdout or "").strip().splitlines()[:3]
        _emit("step_progress", name="cpe_ready", phase="cloud", try_no=n, ok=ok, sec=round(time.time()-t0,3),
              sample=out if isinstance(out, list) else [out], tag="precondition")
        if ok:
            return True
        if n < max_retries:
            time.sleep(sleep_sec)
    return False

def precondition() -> int:
    load_noc_profile()
    _emit("step_start", name="cpe_ready", phase="cloud",
          max_retries=int(os.environ.get("CPE_CLOUD_MAX_RETRIES","10")),
          sleep_sec=float(os.environ.get("CPE_CLOUD_RETRY_INTERVAL_SEC","3")),
          tool=CPE_INFO_TOOL, tag="precondition")
    ok = cpe_cloud_ready(
        max_retries=int(os.environ.get("CPE_CLOUD_MAX_RETRIES","10")),
        sleep_sec=float(os.environ.get("CPE_CLOUD_RETRY_INTERVAL_SEC","3")),
        timeout_sec=int(os.environ.get("CPE_CLOUD_TIMEOUT_SEC","20")),
    )
    _emit("step_end", name="cpe_ready", ok=ok, tag="precondition")
    return 0 if ok else 2

def run() -> int:
    load_noc_profile()
    import importlib
    mod = importlib.import_module("main_impl_orig")
    try:
        rc = mod.run()
    except SystemExit as e:
        try:
            return int(e.code)
        except Exception:
            return 1
    except Exception as e:
        _emit("exception", error=repr(e))
        return 1
    try:
        return int(rc)
    except Exception:
        return 0

if __name__ == "__main__":
    raise SystemExit(run())
