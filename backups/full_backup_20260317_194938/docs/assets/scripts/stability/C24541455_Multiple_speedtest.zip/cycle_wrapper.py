#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""cycle_wrapper.py

Professional cycle harness used by stability scripts.

Env:
  - CYCLES (int)
  - CYCLE_INTERVAL (sec, float)
  - STOP_ON_FAIL (0/1)
  - PRECONDITION_FIRST_CYCLE (0/1)  -> if the target module has precondition(), run once in cycle #1
  - ORIGINAL_ENTRY  e.g. "main_impl.py:run"
  - FATAL_RC_CODES  e.g. "3,4"  -> abort further cycles even if STOP_ON_FAIL=0
It injects:
  - CYCLE_INDEX (1..CYCLES)
  - CYCLE_TOTAL (CYCLES)
"""
import importlib
import json
import os
import time
from typing import Callable, Optional, Tuple

def _now():
    return time.time()

def _log(obj):
    try:
        print(json.dumps(obj, ensure_ascii=False))
    except Exception:
        print(obj)

def _get_int(name: str, default: int) -> int:
    try:
        return int(str(os.environ.get(name, default)).strip())
    except Exception:
        return default

def _get_float(name: str, default: float) -> float:
    try:
        return float(str(os.environ.get(name, default)).strip())
    except Exception:
        return default

def _get_bool(name: str, default: bool=False) -> bool:
    v = str(os.environ.get(name, "")).strip().lower()
    if not v:
        return default
    return v in ("1","true","yes","y","on")

def _parse_entry(s: str) -> Tuple[str,str]:
    if ":" not in s:
        raise ValueError(f"bad entry '{s}', expected module.py:func")
    mod_s, func = s.split(":", 1)
    mod = mod_s[:-3] if mod_s.endswith(".py") else mod_s
    return mod, func

def _load_func(entry: str) -> Tuple[object, Callable[[], int]]:
    mod_name, fn_name = _parse_entry(entry)
    mod = importlib.import_module(mod_name)
    fn = getattr(mod, fn_name)
    return mod, fn

def run() -> int:
    cycles = _get_int("CYCLES", 1)
    interval = _get_float("CYCLE_INTERVAL", 60.0)
    stop_on_fail = _get_bool("STOP_ON_FAIL", True)
    pre_first = _get_bool("PRECONDITION_FIRST_CYCLE", True)
    entry = os.environ.get("ORIGINAL_ENTRY", "main_impl.py:run").strip()

    fatal_rc_codes = set()
    try:
        raw = (os.environ.get("FATAL_RC_CODES") or "").strip()
        if raw:
            for x in raw.split(","):
                x = x.strip()
                if x:
                    fatal_rc_codes.add(int(x))
    except Exception:
        fatal_rc_codes = set()

    _log({"event":"runner_start","name": os.environ.get("name") or os.environ.get("TEST_NAME") or "",
          "cycles": cycles, "interval_sec": interval, "stop_on_fail": int(stop_on_fail),
          "fatal_rc_codes": sorted(list(fatal_rc_codes)), "original_entry": entry})

    overall_rc = 0
    err: Optional[str] = None

    # load target module/fn once
    try:
        mod, fn = _load_func(entry)
        precond = getattr(mod, "precondition", None)
        precond_fn = precond if callable(precond) else None
    except Exception as e:
        _log({"event":"runner_load_error","error":repr(e)})
        return 2

    for i in range(1, cycles+1):
        os.environ["CYCLE_INDEX"] = str(i)
        os.environ["CYCLE_TOTAL"] = str(cycles)

        t0 = _now()
        _log({"event":"cycle_start","i": i, "cycle": i, "total": cycles})
        rc = 0
        err = None

        try:
            if i == 1 and pre_first and precond_fn is not None:
                _log({"event":"precondition_start"})
                pre_rc = int(precond_fn())
                if pre_rc != 0:
                    rc = pre_rc
                    err = f"precondition_failed_rc={pre_rc}"
                else:
                    _log({"event":"precondition_ok"})
            if rc == 0:
                rc = int(fn())
        except SystemExit as e:
            try:
                rc = int(e.code)
            except Exception:
                rc = 1
        except Exception as e:
            err = repr(e)
            if rc == 0:
                rc = 1

        dur = _now() - t0
        ok = (rc == 0)
        _log({"event":"cycle_end","i": i, "ok": ok, "rc": rc, "dur_sec": round(dur,3), "error": err})

        if not ok:
            overall_rc = rc or 1
            if stop_on_fail or (rc in fatal_rc_codes):
                _log({"event":"runner_abort","reason":"stop_on_fail" if stop_on_fail else "fatal_rc",
                      "rc": rc})
                break

        if i < cycles and interval > 0:
            _log({"event":"cycle_pause","i": i, "next": i+1, "sec": interval})
            time.sleep(interval)

    _log({"event":"runner_done","rc": overall_rc})
    return int(overall_rc)

if __name__ == "__main__":
    raise SystemExit(run())
