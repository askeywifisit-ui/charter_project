# C24541455_Multiple_speedtest

## 1) 目的 / 覆蓋範圍
- 執行多次 speedtest（穩定性/壓力）並檢查結果/趨勢。

## 2) 前置條件 / 環境
- 需 WAN uplink 正常，speedtest server/服務可用。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`stability`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：3
- CYCLE_INTERVAL：30

## 5) PASS/FAIL 判定
- PASS：每次 speedtest 都成功且結果在合理範圍（依腳本判定）。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C24541455_Multiple_speedtest

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`stability`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：3
- CYCLE_INTERVAL：30

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C24541455_Multiple_speedtest

## 目的 / Purpose

這支腳本用來做 **Multiple NOC speedtest（預設 100 次）穩定度測試（PRD C24541455）**：

- 每一個 cycle 都會：
  1. 透過 NOC API 登入（login），確認帳號密碼可用。
  2. 透過 serial (`cpe_metrics_agent_serial.py --cmd node-id`) 取得 CPE 的 `node_id`。
  3. 透過 NOC API 查詢對應的 `location_id`。
  4. 觸發一次 speedtest（`POST /speedTest`），並輪詢結果（`GET /speedTestResults/{requestId}`）。
  5. 解析 download / upload / latency 等結果。
  6. 執行一次 CPE health check（`cpe_ssh.py --cmd health`）。
  7. 視設定決定是否執行 SSH enable/disable flow。

- `cycle_wrapper.py` 控制要連續跑幾輪 (`CYCLES`) 與每輪間隔 (`CYCLE_INTERVAL`)，
  可以用來做數小時甚至數十小時的 speedtest 壓力測試。

---

## 檔案架構

- `manifest.yaml`
  - 所有環境變數集中管理（CYCLES、NOC 帳密、speedtest 相關秒數、SSH 帳密等）。
- `cycle_wrapper.py`
  - 讀取 `manifest.yaml` 的 `env`，依 `CYCLES / CYCLE_INTERVAL / STOP_ON_FAIL` 跑外層迴圈。
  - 每一輪呼叫 `ORIGINAL_ENTRY` 指定的 entry function。
- `main_impl.py`
  - shim：載入 `main_impl_orig.run()`，並把回傳碼 / 例外轉成 cycle_wrapper 期待的 rc。
- `main_impl_orig.py`
  - 主要邏輯實作：
    - NOC login、node-id、location-id
    - NOC API 測試（以 speedtest 為主）
    - CPE health check
    - SSH flow（enable / disable）
- `cpe_health_helper.py`
  - 包一層 `cpe_ssh.py --cmd health`，做 CPE 自身 health 檢查。
- `main.py`
  - 方便在 lab 直接執行，會載入 `manifest.yaml` 然後呼叫 `cycle_wrapper.run()`。

---

## 單一 cycle 流程（對應 `main_impl_orig.run()`）

1. **讀取環境變數**
   - NOC 相關：
     - `NOC_BASE`, `NOC_EMAIL`, `NOC_PASSWORD`, `CUSTOMER_ID`, `BEARER`, `INSECURE`
   - Serial / tools：
     - `CPE_DEV`, `CPE_BAUD`, `CPE_USER`, `CPE_PASSWORD`
     - `TOOLS_PATH`, `METRICS_TOOL`, `CPE_INFO_TOOL`
   - Speedtest / NOC API 開關：
     - `ENABLE_NOC_API_TESTS`
     - `ENABLE_SPEEDTEST`（這顆預設為 `1`）
     - `ENABLE_WIFI_TEST`（預設 `0`）
     - `ENABLE_LTE_TEST`（預設 `0`）
   - SSH / health：
     - `SSH_USER`, `SSH_PASSWORD`, `SSH_HOST_LAN`
     - `SSH_TIMEOUT_MIN`, `SSH_ACTION`, `ENABLE_SSH_FLOW`
     - `CPE_HEALTH_WAIT_SEC`

2. **NOC login + node-id + location-id**
   - 呼叫 `noc_api_cli` 登入 NOC，取得 access token。
   - 使用 `METRICS_TOOL`（`cpe_metrics_agent_serial.py`）透過 serial 執行 `--cmd node-id` 取得 `node_id`。
   - 透過 NOC API 以 `CUSTOMER_ID + node_id` 查詢 `location_id`。

3. **NOC API 測試：speedtest**

   - `_run_noc_api_tests()` 會根據 env 決定要跑哪些子測試：
     - `ENABLE_SPEEDTEST = 1` → 會呼叫 `_run_speedtest_tests()`。
     - `ENABLE_WIFI_TEST = 0` → WiFi 測試跳過。
     - `ENABLE_LTE_TEST = 0` → LTE 測試跳過。

   - `_run_speedtest_tests()` 流程：
     1. 呼叫 NOC API `POST /speedTest` 觸發 speedtest，取得 `requestId`。
     2. 先 sleep `SPEEDTEST_WAIT_SEC` 秒（預設 `60`）。
     3. 在 `SPEEDTEST_MAX_TRIES` 次內，每隔 `SPEEDTEST_INTERVAL_SEC` 秒：
        - 呼叫 `GET /speedTestResults/{requestId}` 查詢結果。
        - 若成功，解析結果中的：
          - `downloadSpeed`
          - `uploadSpeed`
          - `latency`
        - 以 JSON log 印出 `event=“speedtest_metrics”`，方便平台收集資料。

4. **CPE health check**

   - speedtest 完成後，呼叫 `run_cpe_health_check()`：
     - 透過 `cpe_ssh.py` 以 `--cmd health` 登入 CPE，取得 health 狀態。
     - 解析輸出的 JSON，確認 `overall` 是否為 `GOOD`。
   - 若 health check 失敗，會丟出 exception，當輪 cycle 視為 FAIL。

5. **SSH flow（可選）**

   - 若 `ENABLE_SSH_FLOW = 1`：
```
