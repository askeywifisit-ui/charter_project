#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
C24541455_Multiple_speedtest main implementation (Multiple NOC speedtest, PRD C24541455).

流程：
  1. 使用 NOC_EMAIL / NOC_PASSWORD login 取得 token
  2. 透過 cpe_info 取得 node_id
  3. 透過 NOC API 取得 location_id
  4. 跑一輪 NOC API 測試：
     - get-location 一致性確認
     - speedtest-run + speedtest-result (輪詢等待結果)
     - wifi-status / wifi-enable / wifi-disable（最後會還原）
     - lte-status
  5. 根據 SSH_ACTION (enable / disable / both) 做 ssh-enable / ssh-disable

依賴：
  - /home/da40/charter/tools/noc_api_cli.py (用 import noc_api_cli as api)
"""

import os
import sys
import json
import time
import subprocess
import socket
from typing import Dict, Optional

import requests  # 用來抓 HTTPError status code
from cpe_health_helper import run_cpe_health_check


# ------------------------------
# Log helpers
# ------------------------------

def _cycle_index() -> int:
    try:
        return int(str(os.environ.get("CYCLE_INDEX", "0")).strip() or 0)
    except Exception:
        return 0

# Auto-annotate JSON log lines with the current cycle index.
# This prevents confusion when reading logs across cycle_end / cycle_start boundaries.
_orig_print = print  # type: ignore

def print(*args, **kwargs):  # type: ignore
    if args and isinstance(args[0], str):
        s = args[0].strip()
        if s.startswith("{") and s.endswith("}"):
            try:
                obj = json.loads(s)
                if isinstance(obj, dict) and "cycle" not in obj:
                    obj["cycle"] = _cycle_index()
                    s = json.dumps(obj, ensure_ascii=False)
                    args = (s,) + args[1:]
            except Exception:
                pass
    return _orig_print(*args, **kwargs)




# 用來讓 cycle_wrapper 讀取本次 speedtest 的結果
_last_speedtest_metrics: Optional[Dict[str, float]] = None


def get_last_speedtest_metrics() -> Optional[Dict[str, float]]:
    """
    給 cycle_wrapper 用：
    回傳本次 run() 內最後一次 speedtest 的 DL / UL / latency。
    如果這次 run 沒有成功拿到數值，回傳 None。
    """
    return _last_speedtest_metrics


def _first_numeric_key(obj: object, candidates) -> Optional[float]:
    """
    在巢狀 JSON 裡面找第一個符合 key 且是數字的值。
    candidates: 依序嘗試的欄位名稱。
    """
    if isinstance(obj, dict):
        for k in candidates:
            if k in obj and isinstance(obj[k], (int, float)):
                return float(obj[k])
        for v in obj.values():
            val = _first_numeric_key(v, candidates)
            if val is not None:
                return val
    elif isinstance(obj, list):
        for v in obj:
            val = _first_numeric_key(v, candidates)
            if val is not None:
                return val
    return None


def _extract_speedtest_metrics(resp: object) -> Optional[Dict[str, float]]:
    """
    嘗試從 speedtest-result 的 JSON 裡面抽出 download / upload / latency。

    這裡先假設 NOC 回傳的欄位名稱類似：
      - downloadSpeed  (吞吐 / DL)
      - uploadSpeed    (吞吐 / UL)
      - latency        (延遲)

    如果你實際看到的 JSON 不同，只要把下面 KEY 清單換成實際的 key 即可。
    """
    dl = _first_numeric_key(resp, ["downloadSpeed", "download", "downstream", "dlMbps"])
    ul = _first_numeric_key(resp, ["uploadSpeed", "upload", "upstream", "ulMbps"])
    lat = _first_numeric_key(resp, ["latency", "ping", "rtt"])

    if dl is None and ul is None and lat is None:
        return None

    return {
        "downloadSpeed": dl,
        "uploadSpeed": ul,
        "latency": lat,
    }


# -------------------------------------------------
# 載入 tools 目錄底下的 noc_api_cli
# -------------------------------------------------
TOOLS_PATH = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
if TOOLS_PATH and TOOLS_PATH not in sys.path:
    sys.path.insert(0, TOOLS_PATH)

try:
    import noc_api_cli as api  # type: ignore
except Exception as e:  # 在 ChatGPT sandbox 會失敗，在實機應該 OK
    api = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "noc_api_cli", "error": str(e)}))

_CACHE: Dict[str, object] = {}


# -------------------------------------------------
# 小工具
# -------------------------------------------------
def _getenv(name: str, default: str = "") -> str:
    v = os.environ.get(name)
    return default if v is None else str(v)


def _bool_env(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return str(v).strip().lower() in ("1", "true", "yes", "y")

def _load_noc_profile(profile_name: str) -> Optional[Dict[str, str]]:
    """載入指定的 NOC profile 設定。

    讀取順序：
      1. 環境變數 NOC_PROFILES_PATH
      2. 環境變數 PROFILES_FILE
      3. 預設 ~/.secrets/noc_profiles.json

    回傳 dict，例如: {"base": "...", "email": "...", "password": "..." }。
    如果檔案不存在或 profile 找不到，回傳 None，並印出對應事件。
    """
    path = (
        os.environ.get("NOC_PROFILES_PATH")
        or os.environ.get("PROFILES_FILE")
        or os.path.expanduser("~/.secrets/noc_profiles.json")
    )

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError as e:
        print(json.dumps({
            "event": "noc-profile-load-error",
            "profile": profile_name,
            "path": path,
            "error": str(e),
        }))
        return None
    except Exception as e:
        print(json.dumps({
            "event": "noc-profile-load-error",
            "profile": profile_name,
            "path": path,
            "error": f"load-error: {e}",
        }))
        return None




# -------------------------------------------------
# login / node / location
# -------------------------------------------------
def _login(base: str, email: str, password: str, bearer: bool, insecure: bool) -> str:
    if "token" in _CACHE:
        return _CACHE["token"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot login to NOC")

    tok = api.login(base, email, password, bearer=bearer, insecure=insecure)
    _CACHE["token"] = tok
    print(json.dumps({"step": "login", "ok": True}))
    return tok


def _node_id() -> str:
    """Get node_id via cpe_info --node-id (no serial/console lock)."""
    if "node_id" in _CACHE:
        return _CACHE["node_id"]  # type: ignore[return-value]

    tools_path = _getenv("TOOLS_PATH", "/home/da40/charter/tools").strip()
    cpe_info = _getenv("CPE_INFO_TOOL", os.path.join(tools_path, "cpe_info")).strip() or os.path.join(tools_path, "cpe_info")

    max_retries = int(_getenv("NODE_ID_MAX_RETRIES", "10"))
    last_err = None
    for attempt in range(1, max_retries + 1):
        cmd = [cpe_info, "--node-id"]
        print(json.dumps({"step": "node-id-cmd", "attempt": attempt, "max_retries": max_retries, "cmd": cmd}))
        try:
            proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=30)
            out = (proc.stdout or "").strip()
            rc = proc.returncode
        except Exception as e:
            out = str(e)
            rc = 1
            last_err = e

        node = out.strip().splitlines()[-1].strip() if out else ""
        print(json.dumps({"step": "node-id-raw", "attempt": attempt, "rc": rc, "out": node}))
        if rc == 0 and node and len(node) >= 8:
            _CACHE["node_id"] = node
            print(json.dumps({"step": "node-id", "attempt": attempt, "node_id": node}))
            return node

        if attempt < max_retries:
            time.sleep(1.0)

    raise RuntimeError(f"cannot get node-id via cpe_info after {max_retries} tries: {last_err}")
def _ssh_port_open(host: str, port: int = 22, timeout_sec: float = 2.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout_sec):
            return True
    except Exception:
        return False

def _ssh_probe_uptime(tools_path: str, host: str, user: str, password: str, timeout_sec: int = 30) -> bool:
    cpe_ssh = os.path.join(tools_path, "cpe_ssh.py")
    cmd = [sys.executable, cpe_ssh, "--host", host, "--user", user, "--password", password, "--cmd", "uptime"]
    try:
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout_sec)
        out = (proc.stdout or "").strip().splitlines()[:2]
        ok = (proc.returncode == 0)
        print(json.dumps({"event":"ssh_probe", "ok": ok, "rc": proc.returncode, "sample": out}))
        return ok
    except Exception as e:
        print(json.dumps({"event":"ssh_probe", "ok": False, "error": str(e)}))
        return False

def _ssh_gate_lan(base: str, customer_id: str, location_id: str, node_id: str,
                  ssh_pass: str, timeout_min: int, token: str, bearer: bool, insecure: bool) -> None:
    """Ensure LAN SSH is reachable before running heavy tests."""
    if not _bool_env("SSH_GATE_EACH_CYCLE", True):
        return
    host = _getenv("SSH_HOST_LAN", "192.168.1.1")
    user = _getenv("SSH_USER", "operator")
    pw = _getenv("SSH_PASSWORD", ssh_pass) or ssh_pass
    port_timeout = float(_getenv("SSH_PORT_TIMEOUT_SEC", "2"))

    open0 = _ssh_port_open(host, 22, timeout_sec=port_timeout)
    print(json.dumps({"event":"ssh_gate_start","host": host, "open": open0}))
    if open0:
        _ssh_probe_uptime(TOOLS_PATH, host, user, pw, timeout_sec=30)
        return

    if _bool_env("HEALTH_RECOVERY_ENABLE_SSH", True):
        # Try enable via NOC once (or SSH_ENABLE_RETRIES times)
        tries = int(_getenv("SSH_ENABLE_RETRIES", "2"))
        wait_sec = int(_getenv("WAIT_AFTER_SSH_ENABLE_SEC", "60"))
        for k in range(1, tries+1):
            print(json.dumps({"event":"ssh_gate_enable_attempt","attempt": k, "tries": tries}))
            _ssh_enable(base, customer_id, location_id, node_id, ssh_pass, timeout_min, token, bearer, insecure)
            time.sleep(float(wait_sec))
            if _ssh_port_open(host, 22, timeout_sec=port_timeout):
                print(json.dumps({"event":"ssh_gate_open","ok": True, "attempt": k}))
                _ssh_probe_uptime(TOOLS_PATH, host, user, pw, timeout_sec=30)
                return
        print(json.dumps({"event":"ssh_gate_open","ok": False}))

def _location_id(base: str, customer_id: str, node_id: str,
                 token: str, bearer: bool, insecure: bool) -> str:
    if "location_id" in _CACHE:
        return _CACHE["location_id"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot query location_id")

    loc = api.get_location_id(base, customer_id, node_id,
                              token=token, bearer=bearer, insecure=insecure)
    _CACHE["location_id"] = loc
    print(json.dumps({"step": "location-id", "location_id": loc}))
    return loc


# -------------------------------------------------
# CPE console password fallback
# -------------------------------------------------
def _console_password(cpe_info_tool: str) -> str:
    """
    若 CPE_PASSWORD 未設定或為 null，嘗試透過 cpe_info 撈 console 密碼。
    """
    try:
        proc = subprocess.run(
            [cpe_info_tool, "--password"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=15,
        )
        out = (proc.stdout or "").strip()
        for line in out.splitlines():
            line = line.strip()
            if line:
                return line
    except Exception:
        pass
    return ""


# -------------------------------------------------
# SSH enable / disable
# -------------------------------------------------
def _ssh_enable(base: str, customer_id: str, location_id: str, node_id: str,
                ssh_pass: str, timeout_min: int,
                token: str, bearer: bool, insecure: bool) -> None:
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot enable SSH")

    resp = api.ssh_enable(
        base,
        customer_id,
        location_id,
        node_id,
        ssh_pass,
        timeout_min,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({"step": "ssh-enable", "resp": resp}))


def _ssh_disable(base: str, customer_id: str, location_id: str, node_id: str,
                 token: str, bearer: bool, insecure: bool) -> None:
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot disable SSH")

    resp = api.ssh_disable(
        base,
        customer_id,
        location_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({"step": "ssh-disable", "resp": resp}))


# -------------------------------------------------
# NOC API 測試 helpers
# -------------------------------------------------
def _run_speedtest_tests(base: str, customer_id: str, location_id: str, node_id: str,
                         token: str, bearer: bool, insecure: bool) -> None:
    """
    SpeedTest 測試流程：

      1) POST /speedTest 觸發一次測速 → 拿到 requestId
      2) 先等 SPEEDTEST_WAIT_SEC 秒（預設 60）
      3) 最多重試 SPEEDTEST_MAX_TRIES 次，每次間隔 SPEEDTEST_INTERVAL_SEC 秒
         呼叫 GET /speedTestResults/{requestId} 查單筆結果

    三個參數都用 env 控制：
      SPEEDTEST_WAIT_SEC
      SPEEDTEST_MAX_TRIES
      SPEEDTEST_INTERVAL_SEC
    """
    global _last_speedtest_metrics
    _last_speedtest_metrics = None

    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run speedtest tests")

    # 1) 觸發一次 speed test
    resp_run = api.speedtest_run(
        base,
        customer_id,
        location_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )

    request_id: Optional[str] = None
    if isinstance(resp_run, dict):
        request_id = (
            resp_run.get("requestId")
            or resp_run.get("request_id")
            or resp_run.get("id")
        )

    print(json.dumps({
        "step": "speedtest-run",
        "resp": resp_run,
        "request_id": request_id,
    }))

    if not request_id:
        raise RuntimeError("speedtest-run did not return requestId")

    # 2) 先等一段時間再開始查結果
    wait_sec = int(_getenv("SPEEDTEST_WAIT_SEC", "60"))
    print(json.dumps({
        "step": "speedtest-wait",
        "request_id": request_id,
        "seconds": wait_sec,
    }))
    time.sleep(wait_sec)

    # 3) 開始少量輪詢
    max_tries = int(_getenv("SPEEDTEST_MAX_TRIES", "3"))
    interval_sec = int(_getenv("SPEEDTEST_INTERVAL_SEC", "10"))

    last_error: Optional[str] = None
    resp_one: Optional[object] = None

    for attempt in range(1, max_tries + 1):
        try:
            resp_one = api.speedtest_result_by_id(
                base,
                customer_id,
                location_id,
                node_id,
                request_id,
                token=token,
                bearer=bearer,
                insecure=insecure,
            )
            # 呼叫成功（沒有丟 HTTPError）
            print(json.dumps({
                "step": "speedtest-result",
                "attempt": attempt,
                "request_id": request_id,
                "resp": resp_one,
            }))

            # 解析本次 speedtest 的 throughput / latency，存成全域給 cycle_wrapper 用
            metrics = _extract_speedtest_metrics(resp_one)
            if metrics is not None:
                _last_speedtest_metrics = metrics
                print(json.dumps({
                    "event": "speedtest_metrics",
                    **metrics,
                }))
            else:
                # 沒有找到 DL / UL / latency 欄位
                _last_speedtest_metrics = None
                print(json.dumps({
                    "event": "speedtest_metrics_missing",
                    "reason": "no_dl_ul_latency_found_in_response",
                }))

            break

        except requests.HTTPError as e:
            status = e.response.status_code if e.response is not None else None
            body = e.response.text[:200] if e.response is not None else ""
            last_error = f"HTTP {status}: {body}"

            print(json.dumps({
                "step": "speedtest-result-retry",
                "attempt": attempt,
                "request_id": request_id,
                "status": status,
                "error": last_error,
            }))

            # 如果還有下一次機會，且是 400/404，就睡 interval_sec 秒再試
            if attempt < max_tries and status in (400, 404):
                time.sleep(interval_sec)
                continue

            # 其他情況（沒下一次或不是 400/404），直接丟出去
            raise

    if resp_one is None:
        # 全部嘗試完還失敗，就讓整個腳本 FAIL
        raise RuntimeError(f"speedtest-result failed after {max_tries} tries: {last_error}")


def _wifi_enabled_flag(status: object) -> Optional[bool]:
    """從 wifi-status 回傳的 JSON 抽出 enabled 狀態."""
    if isinstance(status, dict):
        # 1) 先看頂層有沒有 enabled
        if "enabled" in status:
            return bool(status.get("enabled"))

        # 2) 再看 wifiNetwork.enabled
        wn = status.get("wifiNetwork")
        if isinstance(wn, dict) and "enabled" in wn:
            return bool(wn.get("enabled"))

        # 3) 如果是 wifiNetworks 陣列，也處理一下（預留擴充）
        wns = status.get("wifiNetworks")
        if isinstance(wns, list) and wns and isinstance(wns[0], dict) and "enabled" in wns[0]:
            return bool(wns[0].get("enabled"))

    return None


def _run_wifi_tests(base: str, customer_id: str, location_id: str,
                    token: str, bearer: bool, insecure: bool) -> None:
    """wifi-status / wifi-enable / wifi-disable 功能測試，最後會盡量恢復原本狀態。"""
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run wifi tests")

    # 先查目前狀態
    status_before = api.wifi_status(
        base,
        customer_id,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    enabled_before = _wifi_enabled_flag(status_before)
    print(json.dumps({
        "step": "wifi-status-before",
        "enabled": enabled_before,
        "resp": status_before,
    }))

    target_state = not bool(enabled_before) if enabled_before is not None else True

    # 切換一次
    resp_toggle = api.wifi_set_enabled(
        base,
        customer_id,
        location_id,
        target_state,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    status_mid = api.wifi_status(
        base,
        customer_id,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    enabled_mid = _wifi_enabled_flag(status_mid)
    print(json.dumps({
        "step": "wifi-toggle",
        "target": target_state,
        "enabled_mid": enabled_mid,
        "resp_toggle": resp_toggle,
        "status_mid": status_mid,
    }))

    # 盡量恢復原本狀態
    if enabled_before is not None and enabled_before != enabled_mid:
        resp_restore = api.wifi_set_enabled(
            base,
            customer_id,
            location_id,
            enabled_before,
            token=token,
            bearer=bearer,
            insecure=insecure,
        )
        status_after = api.wifi_status(
            base,
            customer_id,
            location_id,
            token=token,
            bearer=bearer,
            insecure=insecure,
        )
        enabled_after = _wifi_enabled_flag(status_after)
        ok = (enabled_after == enabled_before)
        print(json.dumps({
            "step": "wifi-restore",
            "enabled_before": enabled_before,
            "enabled_after": enabled_after,
            "ok": ok,
            "resp_restore": resp_restore,
            "status_after": status_after,
        }))
        if not ok:
            raise RuntimeError("wifi enabled state mismatch after restore")


def _run_lte_test(base: str, location_id: str,
                  token: str, bearer: bool, insecure: bool) -> None:
    """lte-status 測試（僅查詢）。"""
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run LTE tests")

    resp = api.lte_status(
        base,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({
        "step": "lte-status",
        "resp": resp,
    }))


def _run_get_location_test(base: str, customer_id: str, node_id: str,
                           location_id: str,
                           token: str, bearer: bool, insecure: bool) -> None:
    """get-location 功能測試，確認回傳的 locationId 與前面取得的一致。"""
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run get-location test")

    loc2 = api.get_location_id(
        base,
        customer_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    ok = (loc2 == location_id)
    print(json.dumps({
        "step": "get-location-check",
        "location_id": location_id,
        "location_id_refetched": loc2,
        "ok": ok,
    }))
    if not ok:
        raise RuntimeError("location_id from get_location_id() mismatch")


# -------------------------------------------------
# Internet connectivity pre-check using cpe_info --internet
# -------------------------------------------------
def _wait_internet_connected() -> None:
    """在執行 speedtest 之前，透過 cpe_info --internet 確認 Internet Status: Connected。

    預設會重試 10 次，每次間隔 3 秒，可由環境變數覆蓋：
      INTERNET_CHECK_MAX_RETRIES
      INTERNET_CHECK_INTERVAL_SEC
    """
    cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")

    try:
        max_retries = int(_getenv("INTERNET_CHECK_MAX_RETRIES", "10"))
    except Exception:
        max_retries = 10

    try:
        interval_sec = float(_getenv("INTERNET_CHECK_INTERVAL_SEC", "3"))
    except Exception:
        interval_sec = 3.0

    last_output = ""

    for attempt in range(1, max_retries + 1):
        cmd = [cpe_info_tool, "--internet"]
        print(json.dumps({
            "step": "internet-check",
            "attempt": attempt,
            "max_retries": max_retries,
            "cmd": cmd,
        }))

        try:
            proc = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=30,
            )
            out = (proc.stdout or "").strip()
            last_output = out
        except Exception as e:
            print(json.dumps({
                "step": "internet-check-exception",
                "attempt": attempt,
                "error": str(e),
            }))
        else:
            print(json.dumps({
                "step": "internet-check-raw",
                "attempt": attempt,
                "rc": proc.returncode,
                "out": out,
            }))
            # 成功條件：rc == 0 且輸出中有 "Internet Status: Connected"
            if proc.returncode == 0 and "Internet Status: Connected" in out:
                print(json.dumps({
                    "step": "internet-check-ok",
                    "attempt": attempt,
                }))
                return

        # 還沒成功就睡一下再試
        if attempt < max_retries:
            time.sleep(interval_sec)

    # 全部重試完還是沒 Connected → 當成 precondition fail
    print(json.dumps({
        "step": "internet-check-failed",
        "max_retries": max_retries,
        "last_output": last_output[-200:],
    }))
    raise RuntimeError(
        f"internet not connected after {max_retries} checks via cpe_info --internet"
    )


def _run_noc_api_tests(base: str, customer_id: str, node_id: str, location_id: str,
                       token: str, bearer: bool, insecure: bool,
                       ssh_pass: str, ssh_timeout_min: int) -> None:
    """
    統一執行 NOC API 測試，並可透過環境變數決定是否啟用各項測試：

      ENABLE_SPEEDTEST  (預設 1)
      ENABLE_WIFI_TEST  (預設 1)
      ENABLE_LTE_TEST   (預設 1)
    """
    # 讀 env 開關
    enable_speedtest = _bool_env("ENABLE_SPEEDTEST", True)
    enable_wifi = _bool_env("ENABLE_WIFI_TEST", True)
    enable_lte = _bool_env("ENABLE_LTE_TEST", True)

    print(json.dumps({
        "event": "noc-api-tests-start",
        "enable_speedtest": enable_speedtest,
        "enable_wifi": enable_wifi,
        "enable_lte": enable_lte,
    }))

    # 一律先做 get-location 一致性檢查
    _run_get_location_test(base, customer_id, node_id, location_id,
                           token, bearer, insecure)

    # speedtest

    if enable_speedtest:
        _wait_internet_connected()
        _run_speedtest_tests(base, customer_id, location_id, node_id,
                             token, bearer, insecure)
        # 在 health 之前先檢查 SSH port 是否開啟，如未開則透過 NOC API 重新 enable SSH
        host = os.environ.get("CPE_HEALTH_HOST", "192.168.1.1")
        try:
            port = int(os.environ.get("CPE_HEALTH_PORT", "22"))
        except Exception:
            port = 22
        try:
            ssh_port_timeout = float(os.environ.get("SSH_PORT_CHECK_TIMEOUT", "3"))
        except Exception:
            ssh_port_timeout = 3.0
        ssh_open = False
        try:
            with socket.create_connection((host, port), timeout=ssh_port_timeout):
                ssh_open = True
        except Exception:
            ssh_open = False
        print(json.dumps({
            "event": "ssh-port-check",
            "host": host,
            "port": port,
            "open": ssh_open,
        }))
        if not ssh_open:
            # 透過 NOC API 再次 enable SSH（延長 / 重新打開 SSH 視後端實作而定）
            _ssh_enable(base, customer_id, location_id, node_id,
                        ssh_pass, ssh_timeout_min, token, bearer, insecure)
            # 簡單等待一下再給 health 使用
            time.sleep(2.0)
        # CPE health check after speedtest metrics
        health_ok = run_cpe_health_check(TOOLS_PATH, timeout=180)
        if not health_ok:
            # --- health recovery ladder (professional) ---
            host = _getenv("SSH_HOST_LAN", "192.168.1.1")
            port_open = _ssh_port_open(host, 22, timeout_sec=float(_getenv("SSH_PORT_TIMEOUT_SEC","2")))
            ping_ok = True
            try:
                p = subprocess.run(["ping","-c","1","-W","1", host], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                ping_ok = (p.returncode == 0)
            except Exception:
                ping_ok = False
            print(json.dumps({"event":"fail_diag","cycle": int(_getenv("CYCLE_INDEX","1") or "1"),
                              "ping": ping_ok, "ssh_port_open": port_open}))

            # cloud snapshot
            try:
                proc = subprocess.run([ _getenv("CPE_INFO_TOOL", os.path.join(TOOLS_PATH, "cpe_info")), "--cloud"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=int(_getenv("CPE_CLOUD_TIMEOUT_SEC","20")))
                sample = (proc.stdout or "").strip().splitlines()[:3]
                print(json.dumps({"event":"fail_cloud","ok": ("Connected" in (proc.stdout or "")), "rc": proc.returncode, "sample": sample}))
            except Exception as e:
                print(json.dumps({"event":"fail_cloud","ok": False, "error": str(e)}))

            # attempt ssh enable if port closed
            if _bool_env("HEALTH_RECOVERY_ENABLE_SSH", True) and (not port_open):
                tries = int(_getenv("SSH_ENABLE_RETRIES", "2"))
                wait_sec = int(_getenv("HEALTH_RECOVERY_WAIT_AFTER_ENABLE_SEC", _getenv("WAIT_AFTER_SSH_ENABLE_SEC","60")))
                for k in range(1, tries+1):
                    print(json.dumps({"event":"health_recovery_enable_attempt","attempt": k, "tries": tries}))
                    _ssh_enable(base, customer_id, location_id, node_id, ssh_pass, ssh_timeout_min, token, bearer, insecure)
                    time.sleep(float(wait_sec))
                    if _ssh_port_open(host, 22, timeout_sec=float(_getenv("SSH_PORT_TIMEOUT_SEC","2"))):
                        print(json.dumps({"event":"health_recovery_port_open","ok": True, "attempt": k}))
                        break

            # retry health once
            if _bool_env("HEALTH_RECOVERY_RETRY", True):
                print(json.dumps({"event":"health_recovery_retry","timeout": 180}))
                health_ok = run_cpe_health_check(TOOLS_PATH, timeout=180)

            # optional PDU reset and retry once more
            if (not health_ok) and _bool_env("HEALTH_RECOVERY_PDU_RESET", False) and _getenv("PDU_SCRIPT","").strip():
                pdu_script = _getenv("PDU_SCRIPT")
                outlet_id = _getenv("PDU_OUTLET_ID","1")
                wait_sec = int(_getenv("HEALTH_RECOVERY_PDU_WAIT_SEC", "120"))
                print(json.dumps({"event":"health_recovery_pdu_reset","script": pdu_script, "outlet": outlet_id}))
                try:
                    subprocess.run([sys.executable, pdu_script, "reset", "--outlet", str(outlet_id)], timeout=60)
                except Exception as e:
                    print(json.dumps({"event":"health_recovery_pdu_reset_error","error": str(e)}))
                time.sleep(float(wait_sec))
                # after reset, wait cloud + ssh gate again
                _ssh_gate_lan(base, customer_id, location_id, node_id, ssh_pass, ssh_timeout_min, token, bearer, insecure)
                health_ok = run_cpe_health_check(TOOLS_PATH, timeout=240)

            if not health_ok:
                raise RuntimeError("CPE health check failed after speedtest (after recovery)")
    else:
        print(json.dumps({
            "event": "speedtest-skip",
            "reason": "env_disabled",
        }))



    # wifi
    if enable_wifi:
        _run_wifi_tests(base, customer_id, location_id,
                        token, bearer, insecure)
    else:
        print(json.dumps({
            "event": "wifi-skip",
            "reason": "env_disabled",
        }))

    # lte
    if enable_lte:
        _run_lte_test(base, location_id,
                      token, bearer, insecure)
    else:
        print(json.dumps({
            "event": "lte-skip",
            "reason": "env_disabled",
        }))

    print(json.dumps({"event": "noc-api-tests-done"}))


# -------------------------------------------------
# main entrypoint for cycle_wrapper
# -------------------------------------------------
# -------------------------------------------------
# main entrypoint for cycle_wrapper
# -------------------------------------------------
def run() -> int:
    """
    entrypoint: ORIGINAL_ENTRY = main_impl_orig.py:run
    """
    # --- NOC 相關 ---
    profile_name = _getenv("NOC_PROFILE", "")
    base = _getenv("NOC_BASE", "")
    email = _getenv("NOC_EMAIL")
    password = _getenv("NOC_PASSWORD")
    customer_id = _getenv("CUSTOMER_ID")
    if not str(customer_id).strip():
        print(json.dumps({"event":"error","error":"CUSTOMER_ID missing/empty"}))
        return 2

    # 若有指定 NOC_PROFILE，嘗試從 noc_profiles.json 補齊 base/email/password
    if profile_name:
        prof = _load_noc_profile(profile_name)
        if prof:
            if not base:
                base = prof.get("base", base)
            if not email:
                email = prof.get("email", email)
            if not password:
                password = prof.get("password", password)
    # 若仍未設定 base，使用原本的預設值
    if not base:
        base = "https://piranha-int.tau.dev-charter.net"
    bearer = _bool_env("BEARER", False)
    insecure = _bool_env("INSECURE", False)

    if not email or not password:
        print(json.dumps({
            "event": "missing_credentials",
            "email": bool(email),
            "password": bool(password),
        }))

    # --- CPE / Serial ---
    metrics_tool = _getenv("METRICS_TOOL", "/home/da40/charter/tools/cpe_metrics_agent_serial.py")
    dev = _getenv("CPE_DEV", "/dev/ttyUSB0")
    baud = int(_getenv("CPE_BAUD", "115200"))
    cpe_user = _getenv("CPE_USER", "root")
    cpe_password = _getenv("CPE_PASSWORD", "")
    if str(cpe_password).strip().lower() in ("none", "null", "nil"):
        cpe_password = ""

    cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
    if not cpe_password:
        cpe_password = _console_password(cpe_info_tool)
        print(json.dumps({"step": "console-password-fallback", "len": len(cpe_password)}))

    # --- SSH 動作 ---
    ssh_user = _getenv("SSH_USER", "operator")
    ssh_pass = _getenv("SSH_PASSWORD", "")
    ssh_timeout_min = int(_getenv("SSH_TIMEOUT_MIN", "120"))
    ssh_action = _getenv("SSH_ACTION", "enable").strip().lower()

    # SSH flow 開關（預設啟用）
    enable_ssh_flow = _bool_env("ENABLE_SSH_FLOW", True)

    if ssh_action not in ("enable", "disable", "both"):
        print(json.dumps({"event": "bad_ssh_action", "ssh_action": ssh_action}))
        return 1

    print(json.dumps({
        "event": "params",
        "base": base,
        "customer_id": customer_id,
        "ssh_action": ssh_action,
        "ssh_user": ssh_user,
        "enable_ssh_flow": enable_ssh_flow,
    }))

    try:
        # 1) login + node/location
        token = _login(base, email, password, bearer, insecure)
        node_id = _node_id()
        location_id = _location_id(base, customer_id, node_id, token, bearer, insecure)
        _ssh_gate_lan(base, customer_id, location_id, node_id, ssh_pass, ssh_timeout_min, token, bearer, insecure)

        # 2) NOC API 測試（內部再依 env 判斷 speedtest / wifi / lte）

        _run_noc_api_tests(base, customer_id, node_id, location_id,
                           token, bearer, insecure, ssh_pass, ssh_timeout_min)
        # 3) SSH enable / disable（可整個關掉）
        if enable_ssh_flow:
            if ssh_action in ("enable", "both"):
                _ssh_enable(base, customer_id, location_id, node_id,
                            ssh_pass, ssh_timeout_min, token, bearer, insecure)
            if ssh_action in ("disable", "both"):
                _ssh_disable(base, customer_id, location_id, node_id,
                             token, bearer, insecure)
        else:
            print(json.dumps({
                "event": "ssh-flow-skip",
                "reason": "env_disabled",
            }))

        return 0

    except Exception as e:
        print(json.dumps({"event": "exception", "error": str(e)}))
        return 1

if __name__ == "__main__":
    sys.exit(run())
