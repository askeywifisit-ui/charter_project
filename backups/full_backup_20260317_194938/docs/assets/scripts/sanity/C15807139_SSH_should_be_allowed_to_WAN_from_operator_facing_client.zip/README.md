# C15807139_SSH_should_be_allowed_to_WAN_from_operator_facing_client

## 1) 目的 / 覆蓋範圍
- 驗證 SSH 可用性與安全策略（允許/拒絕、port 限制、帳密錯誤等）。

## 2) 前置條件 / 環境
- 需具備對應 client 位置（LAN/WAN）與連線條件。
- 若需 NOC enable SSH，請用 `.secrets`/`PROFILES_FILE`。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'70'
- TOOLS_PATH：/home/da40/charter/tools
- SSH_HOST_LAN：192.168.1.1
- PING_IFACE：eno2
- PROFILES_FILE：/home/da40/charter/.secrets/noc_profiles.json
- NOC_PROFILE：SPECTRUM_INT
- CUSTOMER_ID：682d4e5179b80027cd6fb27e

## 5) PASS/FAIL 判定
- PASS：SSH 行為符合預期策略。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807139 — SSH should be allowed to WAN from operator facing client (T4625129)

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'70'
- TOOLS_PATH：/home/da40/charter/tools

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807139 — SSH should be allowed to WAN from operator facing client (T4625129)

## What this script validates
After enabling SSH Manager (SSHM) via NOC kvConfigs, validate SSH allow/deny behavior:

### Required
- **WAN IPv4**: reach auth stage (not refused) and login works

### Customer site (IPv6 available)
- **WAN Global IPv6 (GUA)**: reach auth stage and login works
- **WAN Link-local IPv6 (fe80::/10)**: **DENY**
- **LAN Global IPv6** (on CPE LAN iface, e.g. br-home): reach auth stage and login works
- **LAN Link-local IPv6**: **DENY**

## Preconditions (automated)
1. CPE ready check (cycle wrapper): `cpe_info -status` -> Internet/Cloud Connected (retry; optional PDU reset)
2. Node-id: `cpe_info --node-id` (no serial/console)
3. Ensure LAN-side SSH is reachable (port 22 scan; if closed -> NOC ssh-enable)
4. NOC login (token) -> location_id
5. kvConfigs PATCH -> enable SSHM + set sshAuthPasswd

## Lab vs Customer switch (IPv6 skip)
Your lab may have no IPv6.

- `TEST_PROFILE=lab`  -> **skip all IPv6 verification** (IPv4-only)
- `TEST_PROFILE=customer` (default) -> run IPv6 verification (subject to ENABLE_IPV6/IPV6_REQUIRED)

IPv6 control:
- `ENABLE_IPV6=auto` (default): attempt IPv6 discovery
- `ENABLE_IPV6=false`: skip IPv6
- `ENABLE_IPV6=true`: force IPv6 steps
- `IPV6_REQUIRED=1` (default): if IPv6 is enabled but cannot be discovered -> **FAIL**
- `IPV6_REQUIRED=0`: if IPv6 is enabled but cannot be discovered -> **SKIP IPv6**

## Interface hints
Link-local SSH needs a zone id (`%<iface>`). The script can auto-detect, or you can pin it:

- `CLIENT_WAN_IFACE=auto|<iface>`
- `CLIENT_LAN_IFACE=auto|<iface>`
- `CPE_LAN_IFACE=br-home` (override if platform differs)


## WAN SSH login binding (important)

這個 case 需要 **真的從 WAN-side client 去 login 到 CPE 的 WAN IP**。
腳本會自動挑選本機 (control PC) 的 source IP 來確保走 WAN 連線路徑：

- IPv4: 會找本機介面中，CIDR 網段可涵蓋 `CPE WAN IPv4` 的位址；找不到才 fallback `ip route get` 的 src。
- IPv6: 同樣以 global IPv6 網段比對，找不到才 fallback `ip -6 route get` 的 src。

你也可以手動指定：

- `WAN_SSH_BIND_SRC4`：指定 WAN IPv4 login 時綁定的來源 IP
- `WAN_SSH_BIND_SRC6`：指定 WAN IPv6 login 時綁定的來源 IPv6
- `WAN_SSH_BIND_IFACE`：指定用哪個本機介面抓 source IP（若同時指定 SRC，SRC 優先）

（同名的相容變數也支援：`WAN_BIND_SRC4/WAN_BIND_SRC6/WAN_BIND_IFACE`、`WAN_SRC_IP4/WAN_SRC_IP6`。）

## Optional environment validation
- `REQUIRE_OPERATOR_FACING=1`: enforce that the runner is truly on WAN side for the WAN IPv4 route
```

```
