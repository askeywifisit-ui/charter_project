#!/usr/bin/env python3
# -*- coding: utf-8 -*-

""" 
C15807139 — SSH should be allowed to WAN from operator facing client (T4625129)

This script follows the intent of the manual test plan:
  - Enable SSHM via NOC kvConfigs (sshAuthEnable + sshAuthPasswd)
  - Verify SSH access rules:
      * WAN IPv4  : ALLOW (should reach authentication, then login works)
      * WAN IPv6 GUA: ALLOW (customer site; lab may not have IPv6)
      * WAN IPv6 link-local: DENY
      * LAN IPv6 global: ALLOW (customer site)
      * LAN IPv6 link-local: DENY

Lab / customer switching:
  - TEST_PROFILE=lab -> auto-skip IPv6 only when IPV6_REQUIRED=0 (lab often has no stable IPv6)
  - ENABLE_IPV6=false -> skip IPv6
  - IPV6_REQUIRED=1 -> if IPv6 is expected but cannot be discovered, FAIL
"""

import os
import sys
import json
import time
import re
import subprocess
import shlex
import shutil
import traceback
import faulthandler
faulthandler.enable()
from typing import Dict, Optional, Tuple, List

# --- logging helper (flush for worker log) ---
def jprint(obj):
    try:
        print(json.dumps(obj, ensure_ascii=False), flush=True)
    except Exception:
        # fallback
        try:
            print(str(obj), flush=True)
        except Exception:
            pass


TOOLS_PATH = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
if TOOLS_PATH and TOOLS_PATH not in sys.path:
    sys.path.insert(0, TOOLS_PATH)

try:
    import noc_api_cli as api  # type: ignore
except Exception as e:
    api = None  # type: ignore
    jprint({"event": "import_warning", "module": "noc_api_cli", "error": str(e)})

try:
    import cpe_ssh  # type: ignore
except Exception as e:
    cpe_ssh = None  # type: ignore
    jprint({"event": "import_warning", "module": "cpe_ssh", "error": str(e)})


import socket
import ipaddress

try:
    import paramiko  # type: ignore
except Exception as e:
    paramiko = None  # type: ignore
    jprint({"event": "import_warning", "module": "paramiko", "error": str(e)})


# ------------------------------
# Quiet stdout: marker wrapper
# ------------------------------
MARK_BEGIN = "__RG_BEGIN__"
MARK_END   = "__RG_END__"

def _wrap_cmd(cmd: str) -> str:
    """Wrap remote cmd with markers so we can extract output even if SSH server prints banners."""
    wrapped = f"echo {MARK_BEGIN}; {cmd}; echo {MARK_END}"
    return "sh -lc " + shlex.quote(wrapped)

def _extract_marked(stdout: str) -> str:
    if not stdout:
        return ""
    b = stdout.find(MARK_BEGIN)
    e = stdout.find(MARK_END)
    if b == -1 or e == -1 or e < b:
        return stdout.strip()
    b2 = b + len(MARK_BEGIN)
    return stdout[b2:e].strip("\n\r ")

def _ssh_exec_marked(host: str, user: str, pw: str, cmd: str, timeout: float, login_shell: bool = True):
    """Return (rc, extracted_stdout, raw_stdout, stderr, sec)."""
    if cpe_ssh is None:
        raise RuntimeError("cpe_ssh not available")
    wrapped = _wrap_cmd(cmd)
    rc, out, err, sec = cpe_ssh.ssh_exec(host, user, pw, wrapped, timeout=timeout, login_shell=login_shell)
    return rc, _extract_marked(out), out, err, sec
_CACHE: Dict[str, object] = {}


def _getenv(name: str, default: str = "") -> str:
    v = os.environ.get(name, default)
    return default if v is None else str(v)


def _bool_env(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "on", "y")


def _run(cmd, timeout: float = 60.0) -> Tuple[int, str, str]:
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout)
    return p.returncode, p.stdout or "", p.stderr or ""


def _tcp_connect_check(host: str, port: int = 22, timeout: float = 3.0, bind_src: Optional[str] = None) -> Tuple[bool, str]:
    """Best-effort TCP connect check.

    Returns (ok, err). If bind_src is provided, bind the outgoing socket to that
    source IP (helps ensure we test the intended path).
    """
    t0 = time.time()
    try:
        # Decide address family
        af = socket.AF_INET6 if ":" in (host or "") else socket.AF_INET
        sock = socket.socket(af, socket.SOCK_STREAM)
        try:
            sock.settimeout(float(timeout))
            if bind_src:
                # Bind to source IP (port 0)
                if af == socket.AF_INET6:
                    sock.bind((bind_src, 0, 0, 0))
                else:
                    sock.bind((bind_src, 0))
            if af == socket.AF_INET6:
                # getaddrinfo handles link-local zone (e.g. fe80::1%ens20)
                infos = socket.getaddrinfo(host, int(port), socket.AF_INET6, socket.SOCK_STREAM)
                sock.connect(infos[0][4])
            else:
                sock.connect((host, int(port)))
            return True, ""
        finally:
            try:
                sock.close()
            except Exception:
                pass
    except Exception as e:
        dt = round(time.time() - t0, 3)
        return False, f"{type(e).__name__}: {e} (dt={dt}s)"

def _ssh_banner(host: str, port: int = 22, timeout: float = 2.0, bind_src: str | None = None) -> str:
    """Read SSH server banner for diagnostics (best-effort).

    Returns a short string (may be empty) or an error marker.
    """
    t0 = time.time()
    try:
        af = socket.AF_INET6 if ':' in (host or '') else socket.AF_INET
        s = socket.socket(af, socket.SOCK_STREAM)
        try:
            s.settimeout(float(timeout))
            if bind_src:
                if af == socket.AF_INET6:
                    s.bind((bind_src, 0, 0, 0))
                else:
                    s.bind((bind_src, 0))
            if af == socket.AF_INET6:
                infos = socket.getaddrinfo(host, int(port), socket.AF_INET6, socket.SOCK_STREAM)
                s.connect(infos[0][4])
            else:
                s.connect((host, int(port)))
            try:
                data = s.recv(128)
            except Exception:
                data = b''
            banner = (data or b'').decode('utf-8', errors='replace').strip()
            return banner[:120]
        finally:
            try:
                s.close()
            except Exception:
                pass
    except Exception as e:
        dt = round(time.time() - t0, 3)
        return f'BANNER_ERR:{type(e).__name__}:{e} (dt={dt}s)'



# ------------------------------
# Local interface helpers (for WAN-side SSH binding)
# ------------------------------

def _env_any(names, default: str = "") -> str:
    for n in names:
        v = os.environ.get(n)
        if v is None:
            continue
        s = str(v).strip()
        if not s:
            continue
        return s
    return default


def _ip_route_get(dst: str, ipv6: bool = False) -> dict:
    """Return parsed dict from `ip route get` output: {"dev":..., "src":...}."""
    cmd = f"ip {'-6' if ipv6 else '-4'} route get {shlex.quote(dst)}"
    rc, out, err = _run(["sh", "-lc", cmd], timeout=3.0)
    if rc != 0:
        return {"rc": rc, "out": out, "err": err}
    info = _parse_route_get(out)
    info["rc"] = rc
    return info


def _local_ipv4_addrs() -> list[dict]:
    """List global IPv4 addresses as dicts: {iface, ip, prefix, network}."""
    rc, out, _ = _run(["sh", "-lc", "ip -4 -o addr show scope global"], timeout=3.0)
    res: list[dict] = []
    if rc != 0:
        return res
    for line in (out or "").splitlines():
        toks = line.split()
        if len(toks) < 4:
            continue
        # format: <idx>: <if> inet <ip/prefix> ...
        iface = toks[1]
        if "inet" not in toks:
            continue
        ip_cidr = toks[toks.index("inet") + 1]
        try:
            ipi = ipaddress.ip_interface(ip_cidr)
        except Exception:
            continue
        res.append({
            "iface": iface,
            "ip": str(ipi.ip),
            "prefix": int(ipi.network.prefixlen),
            "network": str(ipi.network),
        })
    return res


def _local_ipv6_addrs(scope: str = "global") -> list[dict]:
    """List IPv6 addresses for scope (global|link)."""
    cmd = f"ip -6 -o addr show scope {scope}"
    rc, out, _ = _run(["sh", "-lc", cmd], timeout=3.0)
    res: list[dict] = []
    if rc != 0:
        return res
    for line in (out or "").splitlines():
        toks = line.split()
        if len(toks) < 4 or "inet6" not in toks:
            continue
        iface = toks[1]
        ip_cidr = toks[toks.index("inet6") + 1]
        try:
            ipi = ipaddress.ip_interface(ip_cidr)
        except Exception:
            continue
        res.append({
            "iface": iface,
            "ip": str(ipi.ip),
            "prefix": int(ipi.network.prefixlen),
            "network": str(ipi.network),
            "scope": scope,
        })
    return res


def _pick_bind_src4(target_ip: str, prefer_iface: str = "auto", avoid_ifaces: Optional[set] = None) -> Tuple[Optional[str], Optional[str]]:
    """Pick a source IPv4 address for connecting to target_ip.

    Priority:
      1) WAN_SSH_BIND_SRC4 / WAN_BIND_SRC4 / WAN_SRC_IP4 / WAN_SRC_IP
      2) WAN_SSH_BIND_IFACE / WAN_BIND_IFACE / WAN_IFACE / CLIENT_WAN_IFACE (if not auto)
      3) auto: find local iface whose CIDR network contains target_ip
      4) fallback: ip route get <target_ip> -> src
    """
    avoid_ifaces = avoid_ifaces or set()

    src_override = _env_any(["WAN_SSH_BIND_SRC4", "WAN_BIND_SRC4", "WAN_SRC_IP4", "WAN_SRC_IP", "SSH_WAN_SRC_IP4", "SSH_WAN_SRC_IP"], "")
    if src_override and src_override.strip().lower() != "auto":
        return src_override.strip(), None

    iface_override = _env_any(["WAN_SSH_BIND_IFACE", "WAN_BIND_IFACE", "WAN_IFACE"], "")
    iface_candidate = (iface_override or "").strip() or (prefer_iface or "").strip()
    if iface_candidate and iface_candidate.lower() != "auto":
        for a in _local_ipv4_addrs():
            if a.get("iface") == iface_candidate:
                return a.get("ip"), iface_candidate

    # auto by network match
    try:
        tip = ipaddress.ip_address(target_ip)
    except Exception:
        tip = None

    if tip is not None:
        cands = []
        for a in _local_ipv4_addrs():
            try:
                net = ipaddress.ip_network(a["network"], strict=False)
            except Exception:
                continue
            if tip in net and a.get("iface") not in avoid_ifaces:
                cands.append(a)
        # Prefer prefer_iface if it matched
        if prefer_iface and prefer_iface.lower() != "auto":
            for a in cands:
                if a.get("iface") == prefer_iface:
                    return a.get("ip"), a.get("iface")
        if len(cands) == 1:
            return cands[0].get("ip"), cands[0].get("iface")
        if len(cands) > 1:
            # Prefer non-br*/lo by heuristic
            for a in cands:
                if not str(a.get("iface", "")).startswith(("br", "lo")):
                    return a.get("ip"), a.get("iface")
            return cands[0].get("ip"), cands[0].get("iface")

    # fallback: route get
    info = _ip_route_get(target_ip, ipv6=False)
    src = (info.get("src") or "").strip() if isinstance(info, dict) else ""
    dev = (info.get("dev") or "").strip() if isinstance(info, dict) else ""
    return (src or None), (dev or None)


def _pick_bind_src6(target_ip: str, prefer_iface: str = "auto", avoid_ifaces: Optional[set] = None) -> Tuple[Optional[str], Optional[str]]:
    """Pick a source IPv6 address for connecting to target_ip (global)."""
    avoid_ifaces = avoid_ifaces or set()

    src_override = _env_any(["WAN_SSH_BIND_SRC6", "WAN_BIND_SRC6", "WAN_SRC_IP6", "SSH_WAN_SRC_IP6"], "")
    if src_override and src_override.strip().lower() != "auto":
        return src_override.strip(), None

    iface_override = _env_any(["WAN_SSH_BIND_IFACE", "WAN_BIND_IFACE", "WAN_IFACE"], "")
    iface_candidate = (iface_override or "").strip() or (prefer_iface or "").strip()
    if iface_candidate and iface_candidate.lower() != "auto":
        for a in _local_ipv6_addrs(scope="global"):
            if a.get("iface") == iface_candidate:
                return a.get("ip"), iface_candidate

    try:
        tip = ipaddress.ip_address(target_ip.split('%', 1)[0])
    except Exception:
        tip = None

    if tip is not None:
        cands = []
        for a in _local_ipv6_addrs(scope="global"):
            try:
                net = ipaddress.ip_network(a["network"], strict=False)
            except Exception:
                continue
            if tip in net and a.get("iface") not in avoid_ifaces:
                cands.append(a)
        if prefer_iface and prefer_iface.lower() != "auto":
            for a in cands:
                if a.get("iface") == prefer_iface:
                    return a.get("ip"), a.get("iface")
        if len(cands) == 1:
            return cands[0].get("ip"), cands[0].get("iface")
        if len(cands) > 1:
            for a in cands:
                if not str(a.get("iface", "")).startswith(("br", "lo")):
                    return a.get("ip"), a.get("iface")
            return cands[0].get("ip"), cands[0].get("iface")

    info = _ip_route_get(target_ip.split('%', 1)[0], ipv6=True)
    src = (info.get("src") or "").strip() if isinstance(info, dict) else ""
    dev = (info.get("dev") or "").strip() if isinstance(info, dict) else ""
    return (src or None), (dev or None)


def _split_ipv6_zone(addr: str) -> Tuple[str, int]:
    """Split IPv6%zone and return (ip, scopeid)."""
    a = (addr or "").strip()
    if "%" not in a:
        return a, 0
    ip, zone = a.split("%", 1)
    try:
        return ip, socket.if_nametoindex(zone)
    except Exception:
        return ip, 0


def _sshpass_ssh_exec(host: str, user: str, pw: str, remote_cmd: str,
                      timeout: float, bind_src: Optional[str] = None) -> Tuple[int, str, str, float, List[str]]:
    """Run OpenSSH (optionally via sshpass) with ssh -b <bind_src>.

    Returns (rc, stdout, stderr, sec, sanitized_cmd_list).
    """
    t0 = time.time()
    t = max(3, int(float(timeout)))
    ssh_path = shutil.which("ssh") or "ssh"
    sshpass_path = shutil.which("sshpass") if pw else None

    h = (host or "").strip()
    bs = (bind_src or "").strip()
    is_v6 = (":" in h) or (":" in bs) or ("%" in h)

    base = [
        ssh_path,
        # IMPORTANT: OpenSSH `ssh` expects raw IPv6 (NO brackets). Brackets are for scp/sftp.
        # Force AF=inet6 when target/bind looks like IPv6.
        *( ["-6"] if is_v6 else [] ),
        "-o", "StrictHostKeyChecking=no",
        "-o", "UserKnownHostsFile=/dev/null",
        "-o", "LogLevel=ERROR",
        "-o", f"ConnectTimeout={t}",
        "-o", "ServerAliveInterval=5",
        "-o", "ServerAliveCountMax=2",
        "-o", "PreferredAuthentications=password",
        "-o", "PubkeyAuthentication=no",
        "-o", "NumberOfPasswordPrompts=1",
    ]
    if bind_src:
        base += ["-b", str(bind_src)]

    # NOTE: do NOT wrap IPv6 in [] for ssh.
    full = base + [f"{user}@{h}", remote_cmd]
    sanitized = full[:]  # no password yet
    if pw:
        if not sshpass_path:
            sec = round(time.time() - t0, 3)
            return 127, "", "sshpass not installed", sec, ["sshpass", "-p", "***"] + sanitized
        full = [sshpass_path, "-p", pw] + full
        sanitized = [sshpass_path, "-p", "***"] + sanitized

    try:
        rc, out, err = _run(full, timeout=float(t + 15))
    except subprocess.TimeoutExpired:
        rc, out, err = 124, "", f"ssh timeout after {t}s"
    except Exception as e:
        rc, out, err = 255, "", f"{type(e).__name__}: {e}"

    sec = round(time.time() - t0, 3)
    return int(rc), (out or ""), (err or ""), sec, sanitized


def _wan_login_v4_check(wan_v4: str, ssh_user: str, ssh_passwd: str,
                        bind_src4: Optional[str], login_retries: int,
                        login_interval: float, login_timeout: float) -> None:
    """Raises on failure."""
    # Enter WAN IPv4 login validation
    jprint({"step": "wan-v4-login-enter", "target": wan_v4, "user": ssh_user, "bind_src": bind_src4})

    # quick env/tool visibility (guarded)
    try:
        ssh_bin = shutil.which("ssh")
        sshpass_bin = shutil.which("sshpass")
    except Exception as e:
        ssh_bin = None
        sshpass_bin = None
        jprint({"step": "ssh-tools-check-error", "error": str(e), "traceback": traceback.format_exc()})

    jprint({
        "step": "ssh-tools-check",
        "ssh": bool(ssh_bin),
        "sshpass": bool(sshpass_bin),
        "bind_src": bind_src4,
    })

    # quick WAN-path diagnostics (helps distinguish routing vs firewall vs sshd)
    ok_tcp, err_tcp = _tcp_connect_check(wan_v4, 22, timeout=min(2.0, float(login_timeout)), bind_src=bind_src4)
    banner = _ssh_banner(wan_v4, 22, timeout=min(2.0, float(login_timeout)), bind_src=bind_src4)
    jprint({"step": "wan-v4-tcp-check", "ok": ok_tcp, "err": err_tcp, "banner": banner, "bind_src": bind_src4})

    # If sshpass isn't installed, fallback to Paramiko so we still produce useful logs.
    use_paramiko = bool(ssh_passwd) and (not sshpass_bin)
    if use_paramiko:
        jprint({"step": "sshpass_missing", "fallback": "paramiko"})

    last_err = ""
    for a in range(1, max(1, int(login_retries)) + 1):
        jprint({"step": "ssh-wan-v4-attempt", "attempt": a, "target": wan_v4, "user": ssh_user, "bind_src": bind_src4})
        try:
            if use_paramiko:
                rc_p, out_p, err_p, sec_p = _paramiko_exec(
                    wan_v4, ssh_user, ssh_passwd, "echo WAN_V4_OK", login_timeout, bind_src=bind_src4
                )
                jprint({
                    "step": "ssh-wan-v4-login-paramiko",
                    "attempt": a,
                    "rc": rc_p,
                    "sec": sec_p,
                    "stdout": (out_p or "")[-200:],
                    "stderr": (err_p or "")[-400:],
                })
                if rc_p == 0 and "WAN_V4_OK" in (out_p or ""):
                    return
                last_err = f"paramiko rc={rc_p} err={err_p}"
            else:
                rc_s, out_s, err_s, sec_s, cmd_s = _sshpass_ssh_exec(
                    wan_v4, ssh_user, ssh_passwd, "echo WAN_V4_OK", login_timeout, bind_src=bind_src4
                )
                jprint({
                    "step": "ssh-wan-v4-login",
                    "attempt": a,
                    "rc": rc_s,
                    "sec": sec_s,
                    "cmd": cmd_s,
                    "stdout": (out_s or "")[-200:],
                    "stderr": (err_s or "")[-400:],
                })
                if rc_s == 0 and "WAN_V4_OK" in (out_s or ""):
                    return
                last_err = f"rc={rc_s} err={err_s}"
        except Exception as e:
            jprint({
                "step": "ssh-wan-v4-login-exception",
                "attempt": a,
                "error": str(e),
                "traceback": traceback.format_exc(),
            })
            last_err = f"exception: {e}"

        if a < login_retries and login_interval > 0:
            time.sleep(float(login_interval))

    raise RuntimeError(f"WAN IPv4 SSH login failed after {login_retries} tries: {last_err}")

def _paramiko_exec(host: str, user: str, password: str, cmd: str, timeout: float,
                  bind_src: Optional[str] = None) -> Tuple[int, str, str, float]:
    """Execute remote cmd via Paramiko (password auth). Supports binding to source IP.

    Returns (rc, stdout, stderr, sec). On failure, rc=255 with stderr containing the exception.
    """
    t0 = time.time()
    if paramiko is None:
        return 255, "", "paramiko not available", 0.0

    try:
        # Decide address family
        h = (host or "").strip()
        is_v6 = ":" in h

        sock = None
        transport = None
        client = None

        host_has_zone = ("%" in h)
        use_manual = bool(bind_src) or host_has_zone

        if use_manual:
            bs = (bind_src or "").strip()
            is_v6_bind = ":" in bs
            fam = socket.AF_INET6 if (is_v6 or is_v6_bind or host_has_zone) else socket.AF_INET
            sock = socket.socket(fam, socket.SOCK_STREAM)
            sock.settimeout(timeout)

            if fam == socket.AF_INET6:
                hip, hscope = _split_ipv6_zone(h)
                if bs:
                    bip, bscope = _split_ipv6_zone(bs)
                    # If host has a zone but bind doesn't, inherit host scope for bind.
                    if bscope == 0 and hscope != 0:
                        bscope = hscope
                    sock.bind((bip, 0, 0, bscope))
                sock.connect((hip, 22, 0, hscope))
            else:
                if bs:
                    sock.bind((bs, 0))
                sock.connect((h, 22))

            transport = paramiko.Transport(sock)
            transport.banner_timeout = timeout
            transport.auth_timeout = timeout
            transport.connect(username=user, password=password)
            chan = transport.open_session(timeout=timeout)
            chan.exec_command(cmd)
            out_b = chan.makefile("rb", -1).read() or b""
            err_b = chan.makefile_stderr("rb", -1).read() or b""
            rc = chan.recv_exit_status()
            try:
                transport.close()
            except Exception:
                pass
            sec = round(time.time() - t0, 3)
            return int(rc), out_b.decode("utf-8", errors="replace"), err_b.decode("utf-8", errors="replace"), sec

        # No bind_src: normal SSHClient connect
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(
            hostname=h,
            port=22,
            username=user,
            password=password,
            timeout=timeout,
            auth_timeout=timeout,
            banner_timeout=timeout,
            look_for_keys=False,
            allow_agent=False,
        )
        stdin, stdout, stderr = client.exec_command(cmd, timeout=timeout)
        out_b = stdout.read() or b""
        err_b = stderr.read() or b""
        rc = stdout.channel.recv_exit_status()
        try:
            client.close()
        except Exception:
            pass
        sec = round(time.time() - t0, 3)
        return int(rc), out_b.decode("utf-8", errors="replace"), err_b.decode("utf-8", errors="replace"), sec

    except Exception as e:
        sec = round(time.time() - t0, 3)
        return 255, "", f"{type(e).__name__}: {e}", sec


def _expect_allow_paramiko(host: str, user: str, pw: str, cmd: str, timeout: float,
                           bind_src: Optional[str] = None) -> None:
    jprint({
        "step": "ssh-allow-paramiko-attempt",
        "host": host,
        "user": user,
        "bind_src": bind_src,
        "remote_cmd": cmd,
    })
    rc, out, err, sec = _paramiko_exec(host, user, pw, cmd, timeout, bind_src=bind_src)
    jprint({
        "step": "ssh-allow-paramiko-check",
        "host": host,
        "rc": rc,
        "sec": sec,
        "stdout": (out or "")[-200:],
        "stderr": (err or "")[-300:],
    })
    if rc != 0:
        raise RuntimeError(f"ssh expected ALLOW but failed rc={rc}: {err.strip()}")


def _expect_deny_paramiko(host: str, user: str, pw: str, cmd: str, timeout: float,
                          bind_src: Optional[str] = None) -> None:
    jprint({
        'step': 'ssh-deny-paramiko-attempt',
        'host': host,
        'user': user,
        'bind_src': bind_src,
        'remote_cmd': cmd,
    })
    rc, out, err, sec = _paramiko_exec(host, user, pw, cmd, timeout, bind_src=bind_src)
    jprint({
        'step': 'ssh-deny-paramiko-check',
        'host': host,
        'rc': rc,
        'sec': sec,
        'stdout': (out or '')[-200:],
        'stderr': (err or '')[-300:],
    })
    if rc == 0:
        raise RuntimeError('ssh expected DENY but succeeded')



def _load_noc_profile(profile_name: str) -> Optional[Dict[str, str]]:
    path = (
        os.environ.get("NOC_PROFILES_PATH")
        or os.environ.get("PROFILES_FILE")
        or os.path.expanduser("~/.secrets/noc_profiles.json")
    )
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        jprint({"event": "noc-profile-load-error", "profile": profile_name, "path": path, "error": str(e)})
        return None

    prof = data.get(profile_name) or data.get(profile_name.upper())
    if not prof:
        jprint({"event": "noc-profile-load-error", "profile": profile_name, "path": path, "error": "profile not found"})
        return None

    return {"base": prof.get("base"), "email": prof.get("email"), "password": prof.get("password")}


def _noc_creds() -> Tuple[str, str, str]:
    """Priority:
      1) NOC_BASE/NOC_EMAIL/NOC_PASSWORD if provided (and not "<fill>")
      2) NOC_PROFILE from profiles file
    """
    base = _getenv("NOC_BASE", "").strip()
    email = _getenv("NOC_EMAIL", "").strip()
    password = _getenv("NOC_PASSWORD", "").strip()

    if base and email and password and "<fill>" not in (base + email + password):
        return base, email, password

    prof_name = _getenv("NOC_PROFILE", "").strip()
    if prof_name:
        prof = _load_noc_profile(prof_name)
        if prof and prof.get("base") and prof.get("email") and prof.get("password"):
            return prof["base"], prof["email"], prof["password"]

    raise RuntimeError("NOC credentials missing: fill NOC_BASE/NOC_EMAIL/NOC_PASSWORD or provide NOC_PROFILE + profiles file")


def _login() -> str:
    if "token" in _CACHE:
        return _CACHE["token"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available")

    base, email, password = _noc_creds()
    bearer = _bool_env("NOC_BEARER", False)
    insecure = _bool_env("NOC_INSECURE", False)

    tok = api.login(base, email, password, bearer=bearer, insecure=insecure)
    _CACHE["token"] = tok
    jprint({"step": "login", "ok": True})
    return tok


def _node_id() -> str:
    if "node_id" in _CACHE:
        return _CACHE["node_id"]  # type: ignore[return-value]

    # Preferred (no-console): cpe_info --node-id
    cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
    for attempt in range(1, 4):
        try:
            rc, out, err = _run([cpe_info_tool, "--node-id"], timeout=20.0)
            raw = ((out or "") + (err or "")).strip()
            nid = (raw or "").strip().lower()
            ok = (rc == 0 and bool(nid))
            jprint({"step": "node-id-cpe_info", "attempt": attempt, "ok": ok, "rc": rc, "raw": raw[:120], "node_id": nid if ok else ""})
            if ok:
                _CACHE["node_id"] = nid
                return nid
        except Exception as e:
            jprint({"step": "node-id-cpe_info-exception", "attempt": attempt, "error": str(e)})
        time.sleep(2)

    # Optional fallback: serial metrics (DISABLED by default)
    if _bool_env("NODE_ID_USE_SERIAL", False):
        metrics_tool = _getenv("METRICS_TOOL", "/home/da40/charter/tools/cpe_metrics_agent_serial.py")
        dev = _getenv("CPE_DEV", "/dev/ttyUSB0")
        baud = int(_getenv("CPE_BAUD", "115200"))
        user = _getenv("CPE_USER", "root")
        password = _getenv("CPE_PASSWORD", "null")

        max_retries = int(_getenv("NODE_ID_MAX_RETRIES", "10"))
        interval = float(_getenv("NODE_ID_RETRY_INTERVAL_SEC", "5"))

        last = ""
        for attempt in range(1, max_retries + 1):
            cmd = [metrics_tool, "--device", dev, "--baud", str(baud), "--user", user, "--cmd", "node-id"]

            pw_raw = (password or "").strip()
            pw_head = pw_raw.split()[0] if pw_raw else ""
            pw_head_l = pw_head.lower()
            is_error_like = (
                pw_head_l.startswith("curl:")
                or "connection timed out" in pw_raw.lower()
                or "error:" in pw_raw.lower()
                or "cannot fetch index.cgi" in pw_raw.lower()
            )
            if (not pw_raw) or (pw_head_l in ("null", "none")) or is_error_like:
                cmd += ["--password", "null"]
            else:
                cmd += ["--password", pw_head]

            jprint({"step": "node-id-cmd", "attempt": attempt, "cmd": cmd})
            try:
                rc, out, err = _run(cmd, timeout=90.0)
            except Exception as e:
                last = str(e)
                jprint({"step": "node-id-exception", "attempt": attempt, "error": last})
                time.sleep(interval)
                continue

            out_s = out.strip()
            jprint({"step": "node-id-raw", "attempt": attempt, "rc": rc, "out": out_s[:400]})
            if rc == 0 and out_s:
                try:
                    node_id = api.parse_node_id_from_text(out_s) if api else ""
                except Exception:
                    node_id = ""
                node_id = (node_id or "").strip()
                if node_id:
                    _CACHE["node_id"] = node_id
                    jprint({"step": "node-id", "ok": True, "node_id": node_id})
                    return node_id

            last = (err or out).strip()
            jprint({"step": "node-id-retry", "attempt": attempt, "error": last[-200:]})
            time.sleep(interval)

        raise RuntimeError(f"node-id failed (serial): {last}")

    raise RuntimeError("node-id failed: cpe_info --node-id")


def _location_id(token: str, node_id: str) -> str:
    if "location_id" in _CACHE:
        return _CACHE["location_id"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available")

    base, _, _ = _noc_creds()
    customer_id = _getenv("CUSTOMER_ID")
    bearer = _bool_env("NOC_BEARER", False)
    insecure = _bool_env("NOC_INSECURE", False)

    loc = api.get_location_id(base, customer_id, node_id, token=token, bearer=bearer, insecure=insecure)
    _CACHE["location_id"] = loc
    jprint({"step": "location-id", "ok": True, "location_id": loc})
    return loc


def _enable_ssh(token: str, node_id: str, location_id: str) -> str:
    if api is None:
        raise RuntimeError("noc_api_cli not available")

    base, _, _ = _noc_creds()
    customer_id = _getenv("CUSTOMER_ID")
    passwd = _getenv("SSH_PASSWORD", "123456789")
    timeout_min = int(_getenv("SSH_TIMEOUT_MIN", "120"))
    bearer = _bool_env("NOC_BEARER", False)
    insecure = _bool_env("NOC_INSECURE", False)

    resp = api.ssh_enable(
        base,
        customer_id,
        location_id,
        node_id,
        passwd,
        timeout_min,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    jprint({"step": "ssh-enable", "ok": True, "resp": resp})
    return passwd


def _parse_ipv6_addrs(ip6_addr_output: str) -> Tuple[Optional[str], Optional[str]]:
    g = None
    ll = None
    for line in (ip6_addr_output or "").splitlines():
        line = line.strip()
        m = re.search(r"\binet6\s+([0-9a-fA-F:]+)/\d+", line)
        if not m:
            continue
        ip = m.group(1).lower()
        if ip.startswith("fe80:"):
            ll = ip
        else:
            g = ip
    return g, ll


def _lan_iface_for(dst_ip: str) -> Optional[str]:
    try:
        rc, out, _ = _run(["sh", "-lc", f"ip route get {dst_ip}"], timeout=3.0)
        if rc != 0:
            return None
        m = re.search(r"\bdev\s+(\S+)", out)
        return m.group(1) if m else None
    except Exception:
        return None


def _ssh_exec(host: str, user: str, pw: str, cmd: str, timeout: float):
    """Execute remote cmd with marker wrapping; returns (rc, extracted, raw_out, err, sec)."""
    return _ssh_exec_marked(host, user, pw, cmd, timeout=timeout, login_shell=True)


def _expect_allow(host: str, user: str, pw: str, cmd: str, timeout: float) -> None:
    jprint({"step":"ssh-allow-attempt","host":host,"user":user,"remote_cmd":cmd})
    rc, extracted, raw_out, err, sec = _ssh_exec(host, user, pw, cmd, timeout)
    jprint({
        "step": "ssh-allow-check",
        "host": host,
        "rc": rc,
        "sec": sec,
        "stdout": extracted[-200:],
        "raw_stdout_tail": raw_out[-200:],
        "stderr": err[-200:],
    })
    if rc != 0:
        raise RuntimeError(f"ssh expected ALLOW but failed rc={rc}: {err.strip()}")


def _expect_deny(host: str, user: str, pw: str, cmd: str, timeout: float) -> None:
    jprint({"step":"ssh-deny-attempt","host":host,"user":user,"remote_cmd":cmd})
    rc, extracted, raw_out, err, sec = _ssh_exec(host, user, pw, cmd, timeout)
    jprint({
        "step": "ssh-deny-check",
        "host": host,
        "rc": rc,
        "sec": sec,
        "stdout": extracted[-200:],
        "raw_stdout_tail": raw_out[-200:],
        "stderr": err[-200:],
    })
    if rc == 0:
        raise RuntimeError("ssh expected DENY but succeeded")





def _parse_route_get(output: str) -> dict:
    # Works for both ipv4/ipv6: expects tokens like "dev <ifname>" and "src <ip>"
    toks = output.strip().split()
    res = {}
    for i, t in enumerate(toks):
        if t == "dev" and i + 1 < len(toks):
            res["dev"] = toks[i+1]
        if t == "src" and i + 1 < len(toks):
            res["src"] = toks[i+1]
    return res

def _parse_ipv6_addrs_on_iface(output: str) -> dict:
    # Return {"global": <ip or None>, "link_local": <ip or None>}
    g = None
    ll = None
    for line in output.splitlines():
        line = line.strip()
        if not line.startswith("inet6"):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        ip = parts[1].split("/")[0]
        scope = None
        if "scope" in parts:
            scope = parts[parts.index("scope")+1] if parts.index("scope")+1 < len(parts) else None
        if scope == "global" and not ip.startswith("fd") and g is None:
            # prefer GUA (2000::/3); if none exists, we'll fall back later
            g = ip
        if scope == "global" and g is None:
            g = ip
        if scope == "link" and ll is None:
            ll = ip
    return {"global": g, "link_local": ll}


def _tcp_check(host: str, port: int, timeout: float) -> tuple[bool, str]:
    import socket
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True, "tcp_connect_ok"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


def _ssh_banner_check(host: str, *, timeout: float = 3.0, bind_src: Optional[str] = None) -> Tuple[bool, str, str]:
    """Try to read SSH banner from TCP/22.

    Returns (ok, banner, err).
    """
    try:
        af = socket.AF_INET6 if ":" in (host or "") else socket.AF_INET
        s = socket.socket(af, socket.SOCK_STREAM)
        try:
            s.settimeout(float(timeout))
            if bind_src:
                if af == socket.AF_INET6:
                    s.bind((bind_src, 0, 0, 0))
                else:
                    s.bind((bind_src, 0))
            if af == socket.AF_INET6:
                hip, hscope = _split_ipv6_zone(host)
                s.connect((hip, 22, 0, hscope))
            else:
                s.connect((host, 22))
            data = b""
            try:
                data = s.recv(128) or b""
            except Exception:
                data = b""
            banner = data.decode("utf-8", errors="replace").strip()
            ok = banner.startswith("SSH-")
            return ok, banner, ""
        finally:
            try:
                s.close()
            except Exception:
                pass
    except Exception as e:
        return False, "", f"{type(e).__name__}: {e}"


def _norm(s: str) -> str:
    return (s or "").strip().lower()

def _is_true(s: str) -> bool:
    return _norm(s) in ("1","true","yes","y","on")

def _is_false(s: str) -> bool:
    return _norm(s) in ("0","false","no","n","off")

def _parse_route_get(output: str) -> dict:
    toks = output.strip().split()
    res = {}
    for i, t in enumerate(toks):
        if t == "dev" and i + 1 < len(toks):
            res["dev"] = toks[i+1]
        if t == "src" and i + 1 < len(toks):
            res["src"] = toks[i+1]
    return res

def _parse_ipv6_addrs_on_iface(output: str) -> dict:
    """Parse `ip -6 addr show dev <iface>`.

    Returns:
      {
        "gua": first global IPv6 that is NOT ULA,
        "ula": first ULA (fdxx/fcxx),
        "global": gua if present else ula,
        "link_local": first fe80:: address,
      }
    """
    gua = None
    ula = None
    ll = None
    for line in output.splitlines():
        line = line.strip()
        if not line.startswith("inet6"):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        ip = parts[1].split("/")[0]
        ip_l = ip.lower()

        # Many platforms include scope info; keep it best-effort.
        scope = None
        if "scope" in parts:
            j = parts.index("scope") + 1
            scope = parts[j] if j < len(parts) else None

        if ip_l.startswith("fe80:"):
            if ll is None:
                ll = ip
            continue

        # Treat both "global" and "" (some busybox outputs omit scope) as candidates.
        if scope in ("global", None):
            if ip_l.startswith(("fd", "fc")):
                if ula is None:
                    ula = ip
            else:
                if gua is None:
                    gua = ip

    return {"gua": gua, "ula": ula, "global": gua or ula, "link_local": ll}



def _discover_wan_linklocal_v6(lan_ip: str, ssh_user: str, ssh_passwd: str, *, wan_if: str, wan_v6_global: str, cpe_lan_iface: str, timeout_sec: float) -> tuple[Optional[str], Optional[str], dict]:
    """Discover CPE WAN IPv6 link-local address.

    Returns (ll_addr, ll_iface, meta).

    Why this exists:
      - Some platforms put the WAN global IPv6 on a bridge (e.g. br-wan) but the link-local
        may live on an underlying physical port.
      - The test requires verifying WAN link-local SSH is **DENIED**, so we need the real
        WAN link-local address (best-effort, with explicit meta for traceability).
    """

    meta: dict = {"method": None, "errors": []}

    def _get_ll_on_iface(iface: str) -> Optional[str]:
        rc, out, raw, err, sec = _ssh_exec(lan_ip, ssh_user, ssh_passwd, f"ip -6 addr show dev {iface}", timeout_sec)
        meta.setdefault('probes', []).append({"iface": iface, "rc": rc, "sec": sec, "err": (err or '')[:200], "tail": (out or '')[-300:]})
        if rc != 0:
            meta['errors'].append(f"ip -6 addr show dev {iface} rc={rc}: {(err or '').strip()}")
            return None
        addrs = _parse_ipv6_addrs_on_iface(out or '')
        return addrs.get('link_local')

    # 1) Directly on wan_if
    ll = _get_ll_on_iface(wan_if)
    if ll:
        meta['method'] = 'wan_if'
        return ll, wan_if, meta

    # 2) Find the iface that owns wan_v6_global (sometimes differs from wan_if)
    try:
        rc, out, raw, err, sec = _ssh_exec(lan_ip, ssh_user, ssh_passwd, 'ip -6 -o addr show scope global', timeout_sec)
        meta.setdefault('global_addr_list', {"rc": rc, "sec": sec, "err": (err or '')[:200], "tail": (out or '')[-400:]})
        if rc == 0 and wan_v6_global:
            target = None
            try:
                target = ipaddress.ip_address(wan_v6_global)
            except Exception:
                target = None
            for line in (out or '').splitlines():
                # format: <idx>: <iface> inet6 <addr>/<pfx> ...
                parts = line.split()
                if len(parts) < 4:
                    continue
                iface = parts[1]
                if parts[2] != 'inet6':
                    continue
                addr = parts[3].split('/')[0]
                try:
                    if target and ipaddress.ip_address(addr) == target:
                        ll2 = _get_ll_on_iface(iface)
                        if ll2:
                            meta['method'] = 'owner_iface'
                            return ll2, iface, meta
                except Exception:
                    continue
    except Exception as e:
        meta['errors'].append(f"global_addr_owner_parse_error: {type(e).__name__}: {e}")

    # 3) If wan_if is a bridge, check bridge member ports (sysfs brif)
    try:
        rc, out, raw, err, sec = _ssh_exec(lan_ip, ssh_user, ssh_passwd, f"ls -1 /sys/class/net/{wan_if}/brif 2>/dev/null || true", timeout_sec)
        ports = [ln.strip() for ln in (out or '').splitlines() if ln.strip()]
        meta['bridge_ports'] = {"wan_if": wan_if, "ports": ports, "rc": rc, "sec": sec}
        for port in ports:
            ll3 = _get_ll_on_iface(port)
            if ll3:
                meta['method'] = 'bridge_port'
                return ll3, port, meta
    except Exception as e:
        meta['errors'].append(f"bridge_port_discovery_error: {type(e).__name__}: {e}")

    # 4) Last resort: any link-local not on LAN iface / lo
    try:
        rc, out, raw, err, sec = _ssh_exec(lan_ip, ssh_user, ssh_passwd, 'ip -6 -o addr show scope link', timeout_sec)
        meta.setdefault('link_addr_list', {"rc": rc, "sec": sec, "err": (err or '')[:200], "tail": (out or '')[-400:]})
        if rc == 0:
            for line in (out or '').splitlines():
                parts = line.split()
                if len(parts) < 4:
                    continue
                iface = parts[1]
                if iface in ('lo', cpe_lan_iface):
                    continue
                if parts[2] != 'inet6':
                    continue
                addr = parts[3].split('/')[0]
                if addr.lower().startswith('fe80:'):
                    meta['method'] = 'fallback_any'
                    return addr, iface, meta
    except Exception as e:
        meta['errors'].append(f"fallback_linklocal_error: {type(e).__name__}: {e}")

    meta['method'] = 'not_found'
    return None, None, meta

def _ssh_target(user: str, host: str) -> str:
    # NOTE: OpenSSH `ssh` expects raw IPv6 (NO brackets). Brackets are for scp/sftp.
    h = (host or "").strip()
    return f"{user}@{h}"


def _local_iface_for(dst_ip: str, ipv6: bool = False) -> Optional[str]:
    try:
        cmd = f"ip {'-6' if ipv6 else '-4'} route get {shlex.quote(dst_ip)}"
        rc, out, _ = _run(["sh", "-lc", cmd], timeout=3.0)
        if rc != 0:
            return None
        info = _parse_route_get(out)
        return info.get("dev")
    except Exception:
        return None


def _ssh_probe_password_prompt(host: str, user: str, timeout_sec: float) -> None:
    """Non-interactive probe: ensure we can reach auth stage (not connection refused).

    We use BatchMode=yes so ssh will NOT prompt for password; a good sign is:
      - Permission denied (publickey,password)
      - Permission denied

    Bad signs (treated as failure):
      - Connection refused
      - timed out / no route / network unreachable
    """
    t = max(3, int(timeout_sec))
    h = (host or "").strip()
    is_v6 = (":" in h) or ("%" in h)
    cmd = [
        "ssh",
        *( ["-6"] if is_v6 else [] ),
        "-o", "BatchMode=yes",
        "-o", f"ConnectTimeout={t}",
        "-o", "StrictHostKeyChecking=no",
        "-o", "UserKnownHostsFile=/dev/null",
        "-o", "PreferredAuthentications=publickey,password",
        "-o", "PubkeyAuthentication=yes",
        _ssh_target(user, host),
        "exit",
    ]
    jprint({"step":"ssh-probe-cmd","host":host,"cmd":cmd})
    rc, out, err = _run(cmd, timeout=float(t + 8))
    msg = (err or out or "").strip()
    msg_l = msg.lower()
    jprint({"step": "ssh-probe", "host": host, "rc": rc, "stderr_tail": msg[-300:]})

    # Expected: permission denied (because BatchMode prevents password prompt)
    if "permission denied" in msg_l:
        return

    # Common bad connectivity failures
    bad = [
        "connection refused",
        "no route to host",
        "network is unreachable",
        "connection timed out",
        "operation timed out",
        "could not resolve hostname",
    ]
    if any(b in msg_l for b in bad):
        raise RuntimeError(f"ssh probe failed (connectivity/refused): {msg}")

    # Host key problems should not happen due to options; still handle.
    if "host key verification failed" in msg_l:
        raise RuntimeError(f"ssh probe failed (host key): {msg}")

    # If we got here, treat it as inconclusive but not an outright refusal.
    # Do not fail hard; the actual password login will decide.
    jprint({"step": "ssh-probe", "host": host, "note": "inconclusive"})

def run() -> int:
    # Ensure any unhandled exceptions still show up in stdout JSON logs (runner may not capture stderr).
    def _stdout_excepthook(exctype, value, tb):
        try:
            jprint({"step": "unhandled-exception", "type": getattr(exctype, '__name__', str(exctype)), "error": str(value), "traceback": ''.join(traceback.format_tb(tb))[-3000:]})
        except Exception:
            pass
        try:
            sys.__excepthook__(exctype, value, tb)
        except Exception:
            pass
    sys.excepthook = _stdout_excepthook

    # --- Basic inputs ---
    lan_ip = _getenv("SSH_HOST_LAN", "192.168.1.1").strip()
    ssh_user = _getenv("SSH_USER", "operator").strip()

    # For compatibility with older manifests:
    # - SSH_PASSWORD is the kvconfig sshAuthPasswd
    # - SSH_AUTH_PASSWD may be used by older scripts
    ssh_passwd = _getenv("SSH_AUTH_PASSWD", "").strip() or _getenv("SSH_PASSWORD", "123456789").strip()

    timeout_sec = float(_getenv("SSH_TOOL_TIMEOUT", _getenv("SSH_CONNECT_TIMEOUT_SEC", "12")))
    login_timeout = float(_getenv("WAN_SSH_TIMEOUT_SEC", "30"))

    # IPv6 switches
    test_profile = _getenv("TEST_PROFILE", "customer")  # customer|lab
    enable_ipv6 = _getenv("ENABLE_IPV6", "auto")  # auto|true|false
    ipv6_required = _bool_env("IPV6_REQUIRED", True)
    skip_ipv6 = _bool_env("SKIP_IPV6", False)

    # Interface names
    cpe_lan_iface = _getenv("CPE_LAN_IFACE", "br-home").strip() or "br-home"
    client_lan_iface = _getenv("CLIENT_LAN_IFACE", "auto").strip()
    client_wan_iface = _getenv("CLIENT_WAN_IFACE", "auto").strip()

    require_operator_facing = _bool_env("REQUIRE_OPERATOR_FACING", False)

    # --- Preconditions: enable SSHM ---
    token = _login()
    node_id = _node_id()
    location_id = _location_id(token, node_id)
    enabled_pw = _enable_ssh(token, node_id, location_id)
    # Use enabled password unless explicitly overridden
    ssh_passwd = _getenv("SSH_AUTH_PASSWD", "").strip() or enabled_pw or ssh_passwd

    # --- Discover WAN IPv4 + WAN interface on CPE (via LAN ssh to the router) ---
    rc, out4, raw4, err4, sec4 = _ssh_exec(lan_ip, ssh_user, ssh_passwd, "ip -4 route get 8.8.8.8", timeout_sec)
    jprint({"step": "discover-wan-route4", "rc": rc, "sec": sec4, "stdout": out4[-400:], "stderr": err4[-200:]})
    if rc != 0:
        raise RuntimeError(f"Failed to discover WAN route ipv4 rc={rc}: {err4.strip()}")
    info4 = _parse_route_get(out4)
    wan_v4 = (info4.get("src") or "").strip()
    wan_if = (info4.get("dev") or "").strip()
    if not wan_v4 or not wan_if:
        raise RuntimeError(f"Failed to parse WAN IPv4/dev from route-get: {out4}")
    jprint({"step": "discover-wan-ipv4", "wan_if": wan_if, "wan_v4": wan_v4})

    # After enabling SSHM, some platforms need a short propagation window before WAN-side SSH becomes reachable.
    try:
        enable_wait = float(_getenv("SSH_ENABLE_WAIT_SEC", "2"))
    except Exception:
        enable_wait = 2.0
    if enable_wait > 0:
        jprint({"step": "ssh-enable-wait", "sec": enable_wait})
        time.sleep(enable_wait)

    # Optional: ensure this runner is truly "operator-facing" (WAN-side) for the WAN IP.
    if require_operator_facing:
        dev_local = _local_iface_for(wan_v4, ipv6=False)
        if dev_local:
            # If route to WAN IP is via the DUT LAN gateway interface (common in hairpin), it isn't operator-facing.
            dev_local_l = dev_local.lower()
            if dev_local_l in ("br-home", "br0", "lan", "home", "eth0"):
                raise RuntimeError(f"operator-facing check failed: route to WAN IPv4 uses local dev={dev_local}")

    # Pick a WAN-side source IP to make sure this really tests "WAN port" path.
    # We avoid using the same local interface that reaches CPE LAN IP when possible.
    lan_local_dev = _local_iface_for(lan_ip, ipv6=False) or ""
    avoid_ifaces = set([lan_local_dev]) if lan_local_dev else set()

    jprint({
        "step": "wan-ssh-bind-select-start",
        "target": wan_v4,
        "lan_local_dev": lan_local_dev,
        "prefer_iface": client_wan_iface,
        "avoid_ifaces": sorted(list(avoid_ifaces)),
    })
    wan_bind_src4, wan_bind_dev4 = _pick_bind_src4(wan_v4, prefer_iface=client_wan_iface, avoid_ifaces=avoid_ifaces)
    jprint({
        "step": "wan-ssh-bind-v4",
        "target": wan_v4,
        "prefer_iface": client_wan_iface,
        "avoid_ifaces": sorted(list(avoid_ifaces)),
        "bind_src": wan_bind_src4,
        "bind_dev": wan_bind_dev4,
    })
    # --- WAN IPv4 validation (real login), bound to chosen source IP (-b) ---
    # We prefer OpenSSH here because it matches manual validation and avoids Paramiko bind quirks.
    login_retries = int(_getenv("WAN_SSH_LOGIN_RETRIES", "8"))
    login_interval = float(_getenv("WAN_SSH_LOGIN_INTERVAL_SEC", "5"))
    # Use a dedicated login timeout (do NOT inherit from WAN_SSH_READY_TIMEOUT_SEC, which is often very small).
    login_timeout = float(_getenv("WAN_SSH_LOGIN_TIMEOUT_SEC", "10"))
    jprint({"step": "wan-ssh-login-start", "target": wan_v4, "bind_src": wan_bind_src4, "bind_dev": wan_bind_dev4, "retries": login_retries, "interval": login_interval, "timeout": login_timeout})
    try:
        _wan_login_v4_check(wan_v4, ssh_user, ssh_passwd, wan_bind_src4, login_retries, login_interval, login_timeout)
    except Exception as e:
        jprint({"step": "wan-ssh-login-failed", "error": str(e), "traceback": traceback.format_exc()})
        raise
    jprint({"step": "wan-ssh-login-ok", "target": wan_v4})

    # --- Decide whether to run IPv6 steps ---

    # --- Decide whether to run IPv6 steps ---
    do_ipv6 = True
    # Lab profiles often don't have stable WAN IPv6; only auto-skip in lab when IPv6 isn't required.
    if _norm(test_profile) == "lab" and (not ipv6_required) and _norm(enable_ipv6) in ("auto", "", "1", "true", "yes", "y", "on"):
        do_ipv6 = False
    if _is_false(enable_ipv6):
        do_ipv6 = False
    if skip_ipv6:
        do_ipv6 = False

    wan_v6_global = None
    wan_v6_ll = None
    lan_v6_global = None
    lan_v6_ll = None

    if do_ipv6:
        _gap = float(_getenv('IPV4_TO_IPV6_SLEEP_SEC', '3'))
        if _gap > 0:
            jprint({'step': 'ipv4-to-ipv6-wait', 'sec': _gap})
            time.sleep(_gap)
        # 1) WAN Global IPv6 (via route-get)
        rc, out6r, raw6r, err6r, sec6r = _ssh_exec(lan_ip, ssh_user, ssh_passwd, "ip -6 route get 2001:4860:4860::8888", timeout_sec)
        jprint({"step": "discover-wan-route6", "rc": rc, "sec": sec6r, "stdout": out6r[-400:], "stderr": err6r[-200:]})
        if rc != 0:
            if _norm(enable_ipv6) == "auto" and not ipv6_required:
                do_ipv6 = False
                jprint({"step": "ipv6-skip", "reason": "no_ipv6_route", "profile": test_profile})
            else:
                raise RuntimeError(f"Failed to discover WAN route ipv6 rc={rc}: {err6r.strip()}")
        else:
            info6 = _parse_route_get(out6r)
            wan_v6_global = (info6.get("src") or "").strip()
            if not wan_v6_global:
                if _norm(enable_ipv6) == "auto" and not ipv6_required:
                    do_ipv6 = False
                    jprint({"step": "ipv6-skip", "reason": "no_ipv6_src", "profile": test_profile})
                else:
                    raise RuntimeError(f"Failed to parse WAN global IPv6 from route-get: {out6r}")
            else:
                jprint({"step": "discover-wan-ipv6-global", "wan_if": wan_if, "wan_v6_global": wan_v6_global})
    if do_ipv6:
        # 2) WAN link-local (best-effort: WAN iface, owner iface, bridge ports)
        jprint({"step": "ipv6-wan-linklocal-discover-start", "wan_if": wan_if, "wan_v6_global": wan_v6_global})
        wan_v6_ll, wan_ll_iface, ll_meta = _discover_wan_linklocal_v6(
            lan_ip, ssh_user, ssh_passwd,
            wan_if=wan_if or '',
            wan_v6_global=wan_v6_global or '',
            cpe_lan_iface=cpe_lan_iface,
            timeout_sec=timeout_sec,
        )
        jprint({"step": "ipv6-wan-linklocal-discover-result", "wan_v6_ll": wan_v6_ll, "ll_iface": wan_ll_iface, "meta": ll_meta})
        if not wan_v6_ll:
            if _norm(enable_ipv6) == "auto" and not ipv6_required:
                do_ipv6 = False
                jprint({"step": "ipv6-skip", "reason": "no_wan_linklocal", "profile": test_profile})
            else:
                raise RuntimeError(f"Failed to find WAN link-local IPv6 (wan_if={wan_if}, wan_v6_global={wan_v6_global})")
        else:
            jprint({"step": "discover-wan-ipv6-linklocal", "wan_if": wan_if, "ll_iface": wan_ll_iface or wan_if, "wan_v6_ll": wan_v6_ll})

    if do_ipv6:
        # 3) LAN IPv6 addresses on CPE LAN interface
        rc, out6l, raw6l, err6l, sec6l = _ssh_exec(lan_ip, ssh_user, ssh_passwd, f"ip -6 addr show dev {cpe_lan_iface}", timeout_sec)
        jprint({"step": "discover-lan-ipv6-addrs", "rc": rc, "sec": sec6l, "stdout": out6l[-500:], "stderr": err6l[-200:]})
        if rc != 0:
            if ipv6_required:
                raise RuntimeError(f"Failed to query LAN iface ipv6 addrs rc={rc}: {err6l.strip()}")
            jprint({"step": "ipv6-skip", "reason": "no_ipv6_addr_on_lan", "profile": test_profile})
            do_ipv6 = False
        else:
            addrs_l = _parse_ipv6_addrs_on_iface(out6l)
            lan_v6_ll = addrs_l.get("link_local")
            # Prefer GUA (non-ULA); if none exists, fall back to "global" if allowed.
            lan_v6_global = addrs_l.get("gua") or addrs_l.get("global")
            if not lan_v6_global and ipv6_required:
                raise RuntimeError(f"Failed to find LAN global IPv6 on iface {cpe_lan_iface}")
            jprint({"step": "discover-lan-ipv6", "cpe_lan_iface": cpe_lan_iface, "lan_v6_global": lan_v6_global, "lan_v6_ll": lan_v6_ll})

    if do_ipv6:
        # Resolve client ifaces for scoped link-local tests
        if _norm(client_wan_iface) == "auto":
            client_wan_iface = _local_iface_for(wan_v4, ipv6=False) or client_wan_iface
        if _norm(client_lan_iface) == "auto":
            client_lan_iface = _local_iface_for(lan_ip, ipv6=False) or client_lan_iface

        # Pick bind sources for real login on IPv6 (to ensure we truly hit WAN/LAN path)
        wan_bind_src6, wan_bind_dev6 = _pick_bind_src6(wan_v6_global, prefer_iface=client_wan_iface)
        lan_bind_src6, lan_bind_dev6 = (None, None)
        if lan_v6_global:
            lan_bind_src6, lan_bind_dev6 = _pick_bind_src6(lan_v6_global, prefer_iface=client_lan_iface)

        jprint({
            "step": "ssh-bind-v6",
            "wan_v6_global": wan_v6_global,
            "client_wan_iface": client_wan_iface,
            "wan_bind_src6": wan_bind_src6,
            "wan_bind_dev6": wan_bind_dev6,
            "lan_v6_global": lan_v6_global,
            "client_lan_iface": client_lan_iface,
            "lan_bind_src6": lan_bind_src6,
            "lan_bind_dev6": lan_bind_dev6,
        })

        # WAN Global IPv6 allow (sshpass; supports IPv6 bracket host)
        jprint({"step": "wan-v6-login-start", "target": wan_v6_global, "bind_src": wan_bind_src6, "bind_dev": wan_bind_dev6, "retries": login_retries, "interval": login_interval, "timeout": login_timeout})
        _ssh_probe_password_prompt(wan_v6_global, ssh_user, timeout_sec)
        ok = False
        for attempt in range(1, int(login_retries) + 1):
            rc, out, err, sec, cmd = _sshpass_ssh_exec(
                wan_v6_global, ssh_user, ssh_passwd,
                "echo WAN_V6_OK",
                timeout=float(login_timeout),
                bind_src=wan_bind_src6,
            )
            jprint({"step": "ssh-wan-v6-login", "attempt": attempt, "rc": rc, "sec": sec, "cmd": cmd, "stdout": out[-200:], "stderr": err[-200:]})
            if rc == 0 and "WAN_V6_OK" in (out or ""):
                ok = True
                break
            time.sleep(float(login_interval))
        if not ok:
            raise RuntimeError(f"WAN IPv6 global SSH login failed to {wan_v6_global}")
        jprint({"step": "wan-v6-login-ok", "target": wan_v6_global})

        # WAN Link-local deny (TCP connect must fail)
        wan_ll_target = wan_v6_ll
        if wan_ll_target and client_wan_iface and _norm(client_wan_iface) != "auto" and "%" not in wan_ll_target:
            wan_ll_target = f"{wan_ll_target}%{client_wan_iface}"
        if wan_ll_target:
            ok_tcp, err_tcp = _tcp_connect_check(wan_ll_target, 22, timeout=float(timeout_sec), bind_src=wan_bind_src6)
            jprint({"step": "wan-v6-ll-tcp-check", "target": wan_ll_target, "ok": ok_tcp, "err": err_tcp, "bind_src": wan_bind_src6})
            if ok_tcp:
                raise RuntimeError(f"WAN link-local SSH reachable but should be denied: {wan_ll_target}")

        # LAN Global IPv6 allow (if present)
        if lan_v6_global:
            jprint({"step": "lan-v6-login-start", "target": lan_v6_global, "bind_src": lan_bind_src6, "bind_dev": lan_bind_dev6, "retries": login_retries, "interval": login_interval, "timeout": login_timeout})
            _ssh_probe_password_prompt(lan_v6_global, ssh_user, timeout_sec)
            ok = False
            for attempt in range(1, int(login_retries) + 1):
                rc, out, err, sec, cmd = _sshpass_ssh_exec(
                    lan_v6_global, ssh_user, ssh_passwd,
                    "echo LAN_V6_OK",
                    timeout=float(login_timeout),
                    bind_src=lan_bind_src6,
                )
                jprint({"step": "ssh-lan-v6-login", "attempt": attempt, "rc": rc, "sec": sec, "cmd": cmd, "stdout": out[-200:], "stderr": err[-200:]})
                if rc == 0 and "LAN_V6_OK" in (out or ""):
                    ok = True
                    break
                time.sleep(float(login_interval))
            if not ok:
                raise RuntimeError(f"LAN IPv6 global SSH login failed to {lan_v6_global}")
            jprint({"step": "lan-v6-login-ok", "target": lan_v6_global})

        # LAN Link-local deny (TCP connect must fail)
        lan_ll_target = lan_v6_ll
        if lan_ll_target and client_lan_iface and _norm(client_lan_iface) != "auto" and "%" not in lan_ll_target:
            lan_ll_target = f"{lan_ll_target}%{client_lan_iface}"
        if lan_ll_target:
            ok_tcp, err_tcp = _tcp_connect_check(lan_ll_target, 22, timeout=float(timeout_sec), bind_src=lan_bind_src6)
            jprint({"step": "lan-v6-ll-tcp-check", "target": lan_ll_target, "ok": ok_tcp, "err": err_tcp, "bind_src": lan_bind_src6})
            if ok_tcp:
                raise RuntimeError(f"LAN link-local SSH reachable but should be denied: {lan_ll_target}")

    else:
        jprint({"step": "ipv6-skipped-final", "profile": test_profile, "enable_ipv6": enable_ipv6})

    jprint({"ok": True, "case": "C15807139"})
    return 0


if __name__ == "__main__":
    raise SystemExit(run())
