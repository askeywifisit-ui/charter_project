#!/usr/bin/env python3
"""cycle_wrapper

Generic cycle wrapper with stability-style precondition.

What it does:
  - Runs `ORIGINAL_ENTRY` once per cycle.
  - Precondition on cycle #1:
      1) CPE ready check via `cpe_info -status` (Internet/Cloud Connected)
         - retry
         - if still not ready: PDU reset once, wait, then retry
      2) Ensure LAN-side SSH is usable (port 22 scan + optional uptime probe)
         - if not reachable: enable SSH via NOC API (same pattern as A2435638/C00000001)
  - Before EVERY cycle:
      - port 22 scan; if closed -> NOC ssh-enable (attempts=2)

Notes:
  - This wrapper does NOT use serial/console.
  - NOC credentials should come from `PROFILES_FILE` + `NOC_PROFILE`.
  - PDU control uses `PDU_SCRIPT` + optional `PDU_OUTLET_ID` env.
"""

from __future__ import annotations

import importlib
import json
import os
import re
import shlex
import socket
import subprocess
import sys
import time
import traceback
from typing import Any, Dict, Tuple


def emit(event: str, **k: Any) -> None:
    k["event"] = event
    print(json.dumps(k, ensure_ascii=False), flush=True)


def _parse_bool(val: str | None, default: bool = False) -> bool:
    if val is None:
        return default
    s = str(val).strip().lower()
    if s in ("1", "true", "yes", "y", "on"):
        return True
    if s in ("0", "false", "no", "n", "off"):
        return False
    return default


def _env_int(name: str, default: int) -> int:
    v = os.environ.get(name)
    if v is None:
        return default
    try:
        return int(str(v).strip())
    except Exception:
        return default


def _env_float(name: str, default: float) -> float:
    v = os.environ.get(name)
    if v is None:
        return default
    try:
        return float(str(v).strip())
    except Exception:
        return default


def _run_cmd(cmd: str | list[str], timeout: float) -> Tuple[int, str, str]:
    if isinstance(cmd, str):
        args = shlex.split(cmd)
    else:
        args = cmd
    p = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    return p.returncode, p.stdout or "", p.stderr or ""


def _parse_cpe_status(text: str) -> tuple[bool, bool]:
    internet_ok = bool(re.search(r"Internet\s+Status\s*:\s*Connected", text, re.IGNORECASE))
    cloud_ok = bool(re.search(r"Cloud\s+Status\s*:\s*Connected", text, re.IGNORECASE))
    return internet_ok, cloud_ok


def is_tcp_open(host: str, port: int = 22, timeout: float = 3.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except Exception:
        return False


def _tools_import() -> Tuple[object | None, str]:
    """Import noc_api_cli from TOOLS_PATH. Returns (module_or_none, error_str)."""
    tools_path = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
    if tools_path and tools_path not in sys.path:
        sys.path.insert(0, tools_path)
    try:
        import noc_api_cli as api  # type: ignore
        return api, ""
    except Exception as e:
        return None, f"{type(e).__name__}: {e}"


def _load_profile(profiles_file: str, profile_name: str) -> Dict[str, Any]:
    j = json.load(open(profiles_file, "r", encoding="utf-8"))
    p = j.get(profile_name) or (j.get("profiles", {}) or {}).get(profile_name)
    if not isinstance(p, dict):
        raise RuntimeError(f"NOC profile not found: {profile_name}")
    return p


def _get_node_id() -> str:
    """Node-id via cpe_info --node-id (no console)."""
    cpe_info = os.environ.get("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
    for attempt in range(1, 4):
        try:
            out = subprocess.check_output([cpe_info, "--node-id"], text=True, timeout=20).strip()
            nid = (out or "").strip().lower()
            if nid:
                emit("node_id", ok=True, attempt=attempt, node_id=nid)
                return nid
        except Exception as e:
            emit("node_id", ok=False, attempt=attempt, error=str(e))
            time.sleep(2)
    raise RuntimeError("cpe_info --node-id failed")


def _noc_ssh_enable(*, api_mod: object, node_id: str, ssh_pass: str) -> None:
    """Enable SSH via NOC API using PROFILES_FILE/NOC_PROFILE."""
    profiles_file = os.environ.get("PROFILES_FILE", "")
    profile_name = os.environ.get("NOC_PROFILE", "")
    if not profiles_file or not profile_name:
        raise RuntimeError("missing PROFILES_FILE / NOC_PROFILE")

    p = _load_profile(profiles_file, profile_name)

    base = p.get("base") or p.get("NOC_BASE") or getattr(api_mod, "DEFAULT_BASE", "")
    customer_id = (
        os.environ.get("CUSTOMER_ID", "")
        or os.environ.get("NOC_CUSTOMER_ID", "")
        or p.get("customer_id")
        or p.get("customerId")
        or p.get("NOC_CUSTOMER_ID")
        or getattr(api_mod, "DEFAULT_CUSTOMER_ID", "")
    )
    email = p.get("email") or p.get("NOC_EMAIL") or os.environ.get("NOC_EMAIL", "")
    password = p.get("password") or p.get("NOC_PASSWORD") or os.environ.get("NOC_PASSWORD", "")
    bearer = bool(p.get("bearer", False))
    insecure = bool(p.get("insecure", False))

    missing = [k for k, v in {"base": base, "customer_id": customer_id, "email": email, "password": password}.items() if not str(v).strip()]
    if missing:
        raise RuntimeError("profile/env missing: " + ",".join(missing))

    timeout_min = int(os.environ.get("SSH_TIMEOUT_MIN", "120"))

    token = api_mod.login(base, email, password, bearer=bearer, insecure=insecure)
    location_id = api_mod.get_location_id(base, customer_id, node_id, token=token, bearer=bearer, insecure=insecure)

    emit("ssh_enable_start", node_id=node_id, location_id=location_id)
    api_mod.ssh_enable(
        base,
        customer_id,
        location_id,
        node_id,
        ssh_pass,
        timeout_min,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )


def ensure_ssh_ready(host: str, *, force_enable: bool, attempts: int) -> bool:
    """Port-scan + optional NOC enable + wait."""
    port = int(os.environ.get("SSH_PORT", "22"))
    if (not force_enable) and is_tcp_open(host, port, timeout=3.0):
        return True

    if not _parse_bool(os.environ.get("AUTO_SSH_ENABLE", "1"), True):
        emit("ssh_not_ready", host=host, port=port, reason="AUTO_SSH_ENABLE=0", force=force_enable)
        return False

    api_mod, api_err = _tools_import()
    if api_mod is None:
        emit("ssh_not_ready", host=host, port=port, reason="noc_api_cli_import_failed", error=api_err, force=force_enable)
        return False

    ssh_pass = os.environ.get("SSH_PASSWORD", "").strip()
    if not ssh_pass:
        emit("ssh_not_ready", host=host, port=port, reason="missing_SSH_PASSWORD", force=force_enable)
        return False

    last_err = ""
    for a in range(1, max(1, int(attempts)) + 1):
        try:
            node_id = _get_node_id()
            _noc_ssh_enable(api_mod=api_mod, node_id=node_id, ssh_pass=ssh_pass)

            wait_sec = int(os.environ.get("SSH_READY_WAIT_SEC", "30"))
            t0 = time.time()
            while time.time() - t0 < wait_sec:
                if is_tcp_open(host, port, timeout=3.0):
                    emit("ssh_enable_done", ok=True, wait_sec=round(time.time() - t0, 2), attempt=a, force=force_enable)
                    return True
                time.sleep(2)
            emit("ssh_enable_done", ok=False, wait_sec=wait_sec, attempt=a, force=force_enable)
        except Exception as e:
            last_err = str(e)
            emit("ssh_enable_error", attempt=a, error=last_err, force=force_enable)
        time.sleep(2)

    emit("ssh_not_ready", host=host, port=port, reason="enable_failed", error=last_err, force=force_enable)
    return False


def ensure_cpe_ready_first_cycle() -> int:
    if not _parse_bool(os.environ.get("CPE_READY_CHECK", "1"), True):
        emit("cpe_ready_skip", reason="CPE_READY_CHECK=0")
        return 0

    status_cmd = os.environ.get("CPE_INFO_STATUS_CMD", "cpe_info -status")
    max_retries = _env_int("CPE_READY_MAX_RETRIES", 5)
    interval = _env_float("CPE_READY_RETRY_INTERVAL_SEC", 3)
    require_cloud = _parse_bool(os.environ.get("CPE_READY_REQUIRE_CLOUD", "1"), True)
    timeout = _env_float("CPE_READY_TIMEOUT_SEC", 60)

    def _check(attempt: int) -> bool:
        rc, out, err = _run_cmd(status_cmd, timeout=timeout)
        text = (out + "\n" + err).strip()
        internet_ok, cloud_ok = _parse_cpe_status(text)
        ready = internet_ok and (cloud_ok if require_cloud else True)
        emit(
            "cpe_ready_check",
            attempt=attempt,
            cmd=status_cmd,
            rc=rc,
            internet_ok=internet_ok,
            cloud_ok=cloud_ok,
            require_cloud=require_cloud,
            ready=ready,
        )
        return ready

    # initial + retries
    for attempt in range(1, max_retries + 1):
        if _check(attempt):
            return 0
        if attempt < max_retries:
            time.sleep(interval)

    # PDU reset once
    if not _parse_bool(os.environ.get("PDU_RESET_ON_NOT_READY", "1"), True):
        emit("precondition_fail", reason="cpe_not_ready_no_pdu_reset")
        return 2

    pdu_script = os.environ.get("PDU_SCRIPT", "/home/da40/charter/tools/pdu_outlet1.py")
    action = os.environ.get("PDU_RESET_ACTION", "reset")
    python_bin = os.environ.get("TOOLS_PYTHON", "python3")
    pdu_cmd = f"{python_bin} {shlex.quote(pdu_script)} {shlex.quote(action)}"

    emit("pdu_reset_start", cmd=pdu_cmd, timeout=timeout)
    try:
        rc, out, err = _run_cmd(pdu_cmd, timeout=timeout)
        emit("pdu_reset_done", rc=rc, stdout=(out or "")[-200:], stderr=(err or "")[-200:])
    except Exception as e:
        emit("pdu_reset_error", error=str(e))
        return 2

    wait_sec = _env_float("PDU_RESET_WAIT_SEC", 120)
    emit("pdu_reset_wait", secs=wait_sec)
    if wait_sec > 0:
        time.sleep(wait_sec)

    for attempt in range(1, max_retries + 1):
        if _check(attempt):
            emit("cpe_ready_after_pdu", ready=True)
            return 0
        if attempt < max_retries:
            time.sleep(interval)

    emit("precondition_fail", reason="cpe_not_ready_after_pdu")
    return 2


def _resolve_entry(entry: str):
    """Resolve ORIGINAL_ENTRY to a callable.

    IMPORTANT: Prefer loading from the script directory to avoid importing a stale module
    from elsewhere on sys.path (this has caused false negatives in the harness).

    Supported forms:
      - main_impl_orig.py:run
      - main_impl_orig:run
    """
    if not entry:
        raise ValueError("Empty ORIGINAL_ENTRY")
    if ":" not in entry:
        raise ValueError(f"Bad ORIGINAL_ENTRY format: {entry!r}")

    mod_name, func_name = entry.split(":", 1)
    here = os.path.dirname(__file__)

    # If user specified a .py file, load that exact file from this directory.
    if mod_name.endswith('.py'):
        mod_path = os.path.join(here, mod_name)
        if not os.path.exists(mod_path):
            raise FileNotFoundError(mod_path)
        import importlib.util
        spec = importlib.util.spec_from_file_location(mod_name[:-3], mod_path)
        if spec is None or spec.loader is None:
            raise RuntimeError(f"Cannot load spec for {mod_path}")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        func = getattr(mod, func_name)
        return func

    # If a matching .py exists next to this wrapper, load by file path too.
    candidate = os.path.join(here, mod_name + '.py')
    if os.path.exists(candidate):
        import importlib.util
        spec = importlib.util.spec_from_file_location(mod_name, candidate)
        if spec is None or spec.loader is None:
            raise RuntimeError(f"Cannot load spec for {candidate}")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        func = getattr(mod, func_name)
        return func

    # Fallback: normal module import
    if mod_name.endswith(".py"):
        mod_name = mod_name[:-3]
    mod = importlib.import_module(mod_name)
    func = getattr(mod, func_name)
    return func


def run() -> int:
    cycles = int(os.environ.get("CYCLES", "1"))
    interval = int(os.environ.get("CYCLE_INTERVAL", "30"))
    stop_on_fail = _parse_bool(os.environ.get("STOP_ON_FAIL", "1"), default=True)
    entry = os.environ.get("ORIGINAL_ENTRY", "main_impl_orig.py:run")

    try:
        func = _resolve_entry(entry)
    except Exception as e:
        emit("entry_resolve_error", entry=entry, error=str(e))
        return 1

    overall_rc = 0
    host_lan = os.environ.get("SSH_HOST_LAN", "192.168.1.1")
    ssh_attempts = _env_int("SSH_ENABLE_ATTEMPTS", 2)

    for i in range(cycles):
        emit("cycle_start", cycle=i + 1, total=cycles)

        if i == 0:
            pre_rc = ensure_cpe_ready_first_cycle()
            if int(pre_rc) != 0:
                overall_rc = int(pre_rc)
                emit("cycle_end", cycle=i + 1, rc=overall_rc)
                break

            # Precondition: ensure SSH ready once at cycle #1
            if _parse_bool(os.environ.get("REQUIRE_SSH_READY", "1"), True):
                if not ensure_ssh_ready(host_lan, force_enable=False, attempts=ssh_attempts):
                    overall_rc = 2
                    emit("cycle_end", cycle=i + 1, rc=overall_rc)
                    break

        # Before every cycle: port-scan + enable if needed
        if _parse_bool(os.environ.get("REQUIRE_SSH_READY", "1"), True):
            if not is_tcp_open(host_lan, 22, timeout=3.0):
                ensure_ssh_ready(host_lan, force_enable=True, attempts=ssh_attempts)

        rc = 1
        try:
            rc = func()
        except SystemExit as se:
            rc = int(se.code or 0)
        except BaseException as e:
            emit("cycle_exception", cycle=i + 1, error=str(e), traceback=traceback.format_exc())
            rc = 1

        try:
            rc = int(rc)
        except Exception:
            rc = 1

        emit("cycle_end", cycle=i + 1, rc=rc)
        if rc != 0:
            overall_rc = rc
            if stop_on_fail:
                break

        if i < cycles - 1 and interval > 0:
            time.sleep(interval)

    emit("all_cycles_done", rc=overall_rc)
    return overall_rc


if __name__ == "__main__":
    sys.exit(run())
