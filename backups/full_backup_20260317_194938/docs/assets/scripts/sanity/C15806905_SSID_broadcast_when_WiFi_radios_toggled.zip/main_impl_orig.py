#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""C15806905 — SSID broadcast when WiFi radios toggled via NOC.

全程只用 NOC API + SSH，不使用 serial/console。

Test flow (high level):
  1) Ensure WiFi enabled via NOC
  2) Verify VIF enabled via SSH (Wifi_VIF_State)
  3) WiFi client scan -> SSID present
  4) WiFi client connect -> got IPv4 (+ optional ping)
  5) Disable WiFi via NOC
  6) Wait: VIF disabled + SSID absent + client disconnected
  7) Enable WiFi via NOC
  8) Wait: SSID present + client connect ok

Return code:
  0 = PASS
  1 = FAIL
"""

import json
import os
import re
import subprocess
import time
import sys
from typing import Any, Dict, List, Optional, Tuple

import requests

# In-process cache for WiFi creds across cycles (cycle_wrapper runs multiple cycles in same interpreter)
_WIFI_CREDS_CACHE = {"ssid": "", "psk": "", "source": ""}

# -------------------------------------------------
# Load tools modules (noc_api_cli) by TOOLS_PATH
# -------------------------------------------------
TOOLS_PATH = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
if TOOLS_PATH and TOOLS_PATH not in sys.path:
    sys.path.insert(0, TOOLS_PATH)

try:
    import noc_api_cli as api  # type: ignore
except Exception as e:
    api = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "noc_api_cli", "error": str(e)}), flush=True)


# ---------------- helpers ----------------

def _getenv(name: str, default: str = "") -> str:
    v = os.environ.get(name)
    if v is None:
        return default
    return str(v)



def _bool_env(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    v = v.strip().lower()
    if v in ("1", "true", "yes", "on", "y"):
        return True
    if v in ("0", "false", "no", "off", "n"):
        return False
    return default


def _clean_manifest_val(v: str) -> str:
    """Best-effort cleanup for RG manifest env parsing.

    Some runners pass inline comments literally (e.g. "''  # comment").
    We strip trailing comments and common empty markers.
    """
    s = (v or "").strip()
    if '#' in s:
        s = s.split('#', 1)[0].strip()
    if s in ("''", '""'):
        return ""
    return s


def _load_noc_profile(profile_name: str) -> Optional[Dict[str, Any]]:
    path = (
        os.environ.get("PROFILES_FILE")
        or os.environ.get("NOC_PROFILES_PATH")
        or os.path.expanduser("~/.secrets/noc_profiles.json")
    )

    if os.environ.get("NOC_PROFILES_PATH") and not os.environ.get("PROFILES_FILE"):
        print(json.dumps({"event": "deprecated_env", "name": "NOC_PROFILES_PATH", "use": "PROFILES_FILE", "path": path}))

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print(json.dumps({"event": "noc-profile-load-error", "profile": profile_name, "path": path, "error": str(e)}))
        return None

    prof = data.get(profile_name) or data.get(profile_name.upper())
    if not prof:
        print(json.dumps({"event": "noc-profile-load-error", "profile": profile_name, "path": path, "error": "profile not found"}))
        return None

    return {
        "base": str(prof.get("base") or ""),
        "email": str(prof.get("email") or ""),
        "password": str(prof.get("password") or ""),
        "customer_id": str(prof.get("customer_id") or prof.get("customerId") or ""),
        "bearer": bool(prof.get("bearer", False)),
        "insecure": bool(prof.get("insecure", False)),
    }


def _run_cmd_json(cmd: List[str], timeout: int) -> Dict[str, Any]:
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)
    out = (proc.stdout or "").strip()
    try:
        return json.loads(out)
    except Exception:
        return {"ok": False, "rc": proc.returncode, "raw": out, "cmd": cmd}


def _sudo_prefix() -> List[str]:
    return ["sudo", "-n"]


def _wifi_iwd_cmd(tools_path: str, args: List[str], timeout: int) -> Dict[str, Any]:
    tool = os.path.join(tools_path, "wifi_iwd.py")
    cmd = _sudo_prefix() + ["python3", tool, "--json"] + args
    return _run_cmd_json(cmd, timeout=timeout)



def _restart_iwd() -> None:
    # Best-effort restart iwd to recover from empty scan results.
    # Do not hard-fail if restart is unavailable.
    try:
        cmd = _sudo_prefix() + ['systemctl', 'restart', 'iwd']
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10)
        print(json.dumps({'step': 'iwd-restart', 'ok': True}))
        time.sleep(2.0)
    except Exception as e:
        print(json.dumps({'step': 'iwd-restart', 'ok': False, 'error': str(e)}))


def _ip_link_cycle(iface: str) -> None:
    """Best-effort cycle link (down/up) to recover iwd/driver stuck states."""
    try:
        subprocess.run(_sudo_prefix() + ["ip", "link", "set", iface, "down"],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
        time.sleep(1.0)
        subprocess.run(_sudo_prefix() + ["ip", "link", "set", iface, "up"],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
        time.sleep(1.0)
        print(json.dumps({"step": "ip-link-cycle", "ok": True, "iface": iface}))
    except Exception as e:
        # Do not fail the test on link cycle failures.
        print(json.dumps({"step": "ip-link-cycle", "ok": False, "iface": iface, "error": str(e)}))


def _cpe_ssh_cmd(tools_path: str, host: str, user: str, password: str, cmd_name: str, timeout: int) -> Dict[str, Any]:
    tool = os.path.join(tools_path, "cpe_ssh.py")
    cmd = ["python3", tool, "--host", host, "--user", user, "--password", password, "--timeout", str(timeout), "--cmd", cmd_name, "--json"]
    return _run_cmd_json(cmd, timeout=timeout + 10)


def _cpe_info_node_id(tools_path: str) -> str:
    # Keep compatible with C00000003/C00000001 manifests.
    tool = os.environ.get("CPE_INFO_TOOL") or os.path.join(tools_path, "cpe_info")

    def _norm(s: str) -> str:
        s = (s or "").strip().lower().replace(":", "")
        if len(s) == 12 and all(c in "0123456789abcdef" for c in s):
            return s
        return ""

    last = ""
    for attempt in range(1, int(_getenv("NODE_ID_MAX_RETRIES", "3")) + 1):
        for extra in (["--node-id"], ["--node-id", "--value"]):
            cmd = ([tool] if os.path.exists(tool) else ["cpe_info"]) + extra
            try:
                p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=20)
                last = (p.stdout or "").strip()
                nid = _norm(last.splitlines()[-1] if last else "")
                if nid:
                    print(json.dumps({"step": "node-id", "attempt": attempt, "ok": True, "node_id": nid}))
                    return nid
            except Exception as e:
                print(json.dumps({"step": "node-id", "attempt": attempt, "ok": False, "error": str(e)}))
        time.sleep(float(_getenv("NODE_ID_RETRY_INTERVAL_SEC", "2")))

    raise RuntimeError(f"node-id not found (last={last[:120]})")


def _wifi_enabled_from_vifs(vif_json: Dict[str, Any]) -> Optional[bool]:
    if not isinstance(vif_json, dict) or not vif_json.get("ok"):
        return None
    rows = vif_json.get("rows")
    if not isinstance(rows, list) or not rows:
        return None
    enabled_bools: List[bool] = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        eb = r.get("enabled_bool")
        if isinstance(eb, bool):
            enabled_bools.append(eb)
        else:
            en = str(r.get("enabled", "")).strip().lower()
            if en in ("true", "1", "yes", "on"):
                enabled_bools.append(True)
            elif en in ("false", "0", "no", "off"):
                enabled_bools.append(False)
    if not enabled_bools:
        return None
    return any(enabled_bools)


def _ssid_broadcast_from_vifs(vif_json: Dict[str, Any]) -> Optional[bool]:
    if not isinstance(vif_json, dict) or not vif_json.get("ok"):
        return None
    rows = vif_json.get("rows")
    if not isinstance(rows, list) or not rows:
        return None
    flags: List[bool] = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        sb = r.get("ssid_broadcast_bool")
        if isinstance(sb, bool):
            flags.append(sb)
        else:
            s = str(r.get("ssid_broadcast", "")).strip().lower()
            if s in ("enabled", "true", "1"):
                flags.append(True)
            elif s in ("disabled", "false", "0"):
                flags.append(False)
    if not flags:
        return None
    return any(flags)


def _wifi_enabled_flag(status: object) -> Optional[bool]:
    if isinstance(status, dict):
        if "enabled" in status:
            return bool(status.get("enabled"))
        wn = status.get("wifiNetwork")
        if isinstance(wn, dict) and "enabled" in wn:
            return bool(wn.get("enabled"))
        wns = status.get("wifiNetworks")
        if isinstance(wns, list) and wns and isinstance(wns[0], dict) and "enabled" in wns[0]:
            return bool(wns[0].get("enabled"))
    return None


def _route_dev_for_host(host: str) -> str:
    """Return the Linux route device for reaching host (best-effort)."""
    try:
        p = subprocess.run(["ip", "-4", "route", "get", host], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=5)
        out = (p.stdout or "").strip()
        # example: "192.168.1.1 dev wlx6cb0ce1ff230 src 192.168.1.228 uid 0"
        toks = out.split()
        for i, t in enumerate(toks):
            if t == "dev" and i + 1 < len(toks):
                return toks[i + 1]
    except Exception:
        pass
    return ""



def _extract_wifi_creds_from_noc(status: object) -> tuple[Optional[str], Optional[str]]:
    """Best-effort extract SSID/PSK from NOC wifiNetwork response.

    Expected fields (common):
      - ssid
      - encryptionKey (PSK)

    Response might be:
      - {"enabled": true, "ssid": "...", "encryptionKey": "..."}
      - {"wifiNetwork": { ... }}
      - {"wifiNetworks": [ { ... } ]}

    Returns: (ssid, psk)
    """
    def _pick(d: dict) -> tuple[Optional[str], Optional[str]]:
        ssid = d.get('ssid')
        psk = d.get('encryptionKey')
        if isinstance(ssid, str):
            ssid = ssid.strip() or None
        else:
            ssid = None
        if isinstance(psk, str):
            psk = psk.strip() or None
        else:
            psk = None
        return ssid, psk

    if isinstance(status, dict):
        # direct
        ssid, psk = _pick(status)
        if ssid or psk:
            return ssid, psk

        wn = status.get('wifiNetwork')
        if isinstance(wn, dict):
            ssid, psk = _pick(wn)
            if ssid or psk:
                return ssid, psk

        wns = status.get('wifiNetworks')
        if isinstance(wns, list) and wns:
            for it in wns:
                if isinstance(it, dict):
                    ssid, psk = _pick(it)
                    if ssid or psk:
                        return ssid, psk

    # unknown
    return None, None


def _choose_wifi_creds(creds: dict, band: str, prefer: str = "current") -> Optional[Dict[str, str]]:
    """Pick {ssid, psk, source} from cpe_ssh --cmd wifi-creds output (same logic as C00000003)."""
    band = (band or "").strip().lower()
    if band in ("2.4", "2.4g", "2g", "24g"):
        band = "2g"
    elif band in ("5", "5g"):
        band = "5g"
    elif band in ("6", "6g"):
        band = "6g"

    prefer = (prefer or "current").strip().lower()
    if prefer not in ("current", "default"):
        prefer = "current"

    def _from_default() -> Optional[Dict[str, str]]:
        d = creds.get("default") or {}
        if not isinstance(d, dict):
            return None
        order: List[str] = [band] if band else []
        for b in ("5g", "2g", "6g"):
            if b not in order:
                order.append(b)
        for b in order:
            item = d.get(b)
            if isinstance(item, dict):
                ssid = (item.get("ssid") or "").strip()
                psk = (item.get("psk") or "").strip()
                if ssid and psk:
                    return {"ssid": ssid, "psk": psk, "source": f"default:{b}"}
        return None

    def _infer_band_from_ifname(ifname: str) -> Optional[str]:
        s = (ifname or "").strip().lower()
        if s.endswith("0"):
            return "2g"
        if s.endswith("1"):
            return "5g"
        if s.endswith("2"):
            return "6g"
        return None

    def _from_current() -> Optional[Dict[str, str]]:
        c = creds.get("current") or {}
        if not isinstance(c, dict):
            return None
        vifs = c.get("vifs") or []
        if not isinstance(vifs, list):
            return None

        if band:
            for v in vifs:
                if not isinstance(v, dict):
                    continue
                ssid = (v.get("ssid") or "").strip()
                psk = (v.get("psk") or "").strip()
                ifname = (v.get("if_name") or "").strip()
                vb = _infer_band_from_ifname(ifname)
                if ssid and psk and vb == band:
                    return {"ssid": ssid, "psk": psk, "source": f"current:{ifname or vb or 'vif'}"}

        for v in vifs:
            if not isinstance(v, dict):
                continue
            ssid = (v.get("ssid") or "").strip()
            psk = (v.get("psk") or "").strip()
            ifname = (v.get("if_name") or "").strip()
            if ssid and psk:
                return {"ssid": ssid, "psk": psk, "source": f"current:{ifname or 'vif'}"}
        return None

    if prefer == "current":
        return _from_current() or _from_default()
    return _from_default() or _from_current()


def _api_call(fn, retries: int, backoff_sec: float, *args, **kwargs):
    last = None
    for attempt in range(1, retries + 2):
        try:
            return fn(*args, **kwargs)
        except (requests.Timeout, requests.ConnectionError, requests.ReadTimeout) as e:
            last = e
            print(json.dumps({"event": "noc-retry", "attempt": attempt, "error": str(e)}))
            if attempt <= retries:
                time.sleep(backoff_sec * attempt)
                continue
            raise
    raise last  # pragma: no cover


def _wait_until(desc: str, timeout_sec: int, interval_sec: int, predicate):
    t0 = time.time()
    last = None
    while True:
        if time.time() - t0 > timeout_sec:
            raise RuntimeError(f"timeout waiting for {desc}; last={last}")
        try:
            ok, val = predicate()
            last = val
            if ok:
                print(json.dumps({"step": "wait", "what": desc, "ok": True, "sec": round(time.time()-t0, 1), "val": val}))
                return val
            print(json.dumps({"step": "wait", "what": desc, "ok": False, "sec": round(time.time()-t0, 1), "val": val}))
        except Exception as e:
            last = f"exception: {e}"
            print(json.dumps({"step": "wait", "what": desc, "ok": False, "sec": round(time.time()-t0, 1), "error": str(e)}))
        time.sleep(interval_sec)


def _purge_iface_defaults(iface: str) -> None:
    """Best-effort cleanup: remove any default route that references this iface.

    Note: `ip route del` does NOT accept some display-only flags like `linkdown`.
    So we delete using stable forms (by dev, and by via+dev when available).
    """
    for af in ("-4", "-6"):
        # 1) Generic delete by dev (handles "default dev IFACE" and "default via GW dev IFACE")
        try:
            subprocess.run(
                _sudo_prefix() + ["ip", af, "route", "del", "default", "dev", iface],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=5,
            )
        except Exception:
            pass

        # 2) Also enumerate defaults and delete via+dev (covers cases where kernel keeps a default with extra attrs)
        try:
            proc = subprocess.run(["ip", af, "route", "show", "default"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=5)
            lines = (proc.stdout or "").splitlines()
        except Exception:
            lines = []

        for ln in lines:
            if f" dev {iface}" not in ln:
                continue
            toks = ln.split()
            gw = None
            for i, t in enumerate(toks):
                if t == "via" and i + 1 < len(toks):
                    gw = toks[i + 1]
                    break
            try:
                if gw:
                    subprocess.run(
                        _sudo_prefix() + ["ip", af, "route", "del", "default", "via", gw, "dev", iface],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                        text=True,
                        timeout=5,
                    )
                print(json.dumps({"event": "route-del", "af": af, "line": ln, "gw": gw}))
            except Exception as e:
                print(json.dumps({"event": "route-del-fail", "af": af, "line": ln, "gw": gw, "error": str(e)}))


def run() -> int:
    try:
        if api is None:
            raise RuntimeError("noc_api_cli not importable")

        # --- env ---
        profile = _clean_manifest_val(_getenv("NOC_PROFILE", ""))
        base = _clean_manifest_val(_getenv("NOC_BASE", "") or _getenv("BASE", ""))
        email = _clean_manifest_val(_getenv("NOC_EMAIL", "") or _getenv("EMAIL", ""))
        pw = _clean_manifest_val(_getenv("NOC_PASSWORD", "") or _getenv("PASSWORD", ""))
        customer_id = _clean_manifest_val(_getenv("CUSTOMER_ID", "") or _getenv("NOC_CUSTOMER_ID", ""))

        bearer_env_present = ("NOC_BEARER" in os.environ) or ("BEARER" in os.environ)
        insecure_env_present = ("NOC_INSECURE" in os.environ) or ("INSECURE" in os.environ)
        bearer = _bool_env("NOC_BEARER", _bool_env("BEARER", False))
        insecure = _bool_env("NOC_INSECURE", _bool_env("INSECURE", False))

        try:
            api.DEFAULT_TIMEOUT = int(_getenv("NOC_TIMEOUT_SEC", "20"))
        except Exception:
            pass
        if profile:
            prof = _load_noc_profile(profile)
            if not prof:
                raise RuntimeError(f"NOC_PROFILE '{profile}' not found")
            base = (prof.get("base") or base)
            email = (prof.get("email") or email)
            pw = (prof.get("password") or pw)
            if not customer_id:
                customer_id = str(prof.get("customer_id") or "").strip()
            if not bearer_env_present and isinstance(prof.get("bearer"), bool):
                bearer = bool(prof.get("bearer"))
            if not insecure_env_present and isinstance(prof.get("insecure"), bool):
                insecure = bool(prof.get("insecure"))

        if not (base and email and pw and customer_id):
            raise RuntimeError("missing NOC env: need CUSTOMER_ID and (NOC_PROFILE or NOC_BASE/NOC_EMAIL/NOC_PASSWORD)")

        ssh_host = _getenv("SSH_HOST_LAN", "192.168.1.1")
        cpe_user = _getenv("SSH_USER", _getenv("CPE_USER", "operator"))
        cpe_pass = _getenv("SSH_PASSWORD", _getenv("CPE_PASSWORD", ""))
        cpe_ssh_timeout = int(_getenv("CPE_SSH_TIMEOUT_SEC", "25"))

        # Prefer platform-provided WIFI_IFACE (systemd). Manifest can provide fallback.
        if not str(os.environ.get("WIFI_IFACE", "")).strip():
            print(json.dumps({"step": "wifi-iface-hint", "ok": True, "hint": "Platform should set WIFI_IFACE (systemd). Using fallback/default from manifest/script."}))
        wifi_iface = _getenv("WIFI_IFACE", "wlx6cb0ce1ff230")
        wifi_ssid = _clean_manifest_val(_getenv("WIFI_SSID", ""))
        wifi_psk = _clean_manifest_val(_getenv("WIFI_PSK", ""))
        wifi_psk_env = _clean_manifest_val(_getenv("WIFI_PSK_ENV", ""))
        if wifi_psk_env and not wifi_psk:
            wifi_psk = os.environ.get(wifi_psk_env, "")

        wifi_band = _clean_manifest_val(_getenv("WIFI_BAND", "")) or None
        dhcp_timeout = int(_getenv("WIFI_DHCP_TIMEOUT_SEC", "35"))

        no_main_default = _bool_env("WIFI_NO_MAIN_DEFAULT", True)
        pbr_table = int(_getenv("WIFI_PBR_TABLE", "101")) if _getenv("WIFI_PBR_TABLE", "") else None
        pbr_from_ip = _bool_env("WIFI_PBR_FROM_IP", True)

        poll_interval = int(_getenv("POLL_INTERVAL_SEC", "5"))
        noc_state_timeout = int(_getenv("WIFI_NOC_STATE_TIMEOUT_SEC", "180"))
        vif_state_timeout = int(_getenv("WIFI_VIF_STATE_TIMEOUT_SEC", "180"))
        scan_timeout = int(_getenv("WIFI_SCAN_TIMEOUT_SEC", "120"))

        ping_target = _getenv("PING_TARGET", "192.168.1.1")
        ping_count = int(_getenv("PING_COUNT", "2"))

        noc_retries = int(_getenv("NOC_RETRIES", "3"))

        # --- start ---
        print(json.dumps({"event": "start", "ssid": (wifi_ssid or "<auto>"), "iface": wifi_iface}))

        # cleanup wifi iface routes first
        _purge_iface_defaults(wifi_iface)
        # disconnect best-effort
        _wifi_iwd_cmd(TOOLS_PATH, ["disconnect", "--iface", wifi_iface], timeout=30)
        _purge_iface_defaults(wifi_iface)

        # NOC login
        token = _api_call(api.login, noc_retries, 5.0, base, email, pw, bearer=bearer, insecure=insecure)

        # NOC auth header mode can differ by backend.
        # Some accept raw token in Authorization; others require 'Bearer <token>'.
        # To match existing scripts (e.g. C00000003 family) and avoid hard failures,
        # we auto-flip on the first HTTP 401 and retry once.
        bearer_mode = bearer

        def noc_call(fn, *args, **kwargs):
            nonlocal bearer_mode
            kwargs.setdefault('token', token)
            kwargs['bearer'] = bearer_mode
            kwargs['insecure'] = insecure
            try:
                return _api_call(fn, noc_retries, 5.0, *args, **kwargs)
            except requests.HTTPError as e:
                r = getattr(e, 'response', None)
                sc = getattr(r, 'status_code', None)
                if sc == 401:
                    bearer_mode = not bearer_mode
                    print(json.dumps({'event': 'noc-auth-flip', 'bearer': bearer_mode}))
                    kwargs['bearer'] = bearer_mode
                    return _api_call(fn, noc_retries, 5.0, *args, **kwargs)
                raise

        print(json.dumps({"step": "login", "ok": True}))

        node_id = _cpe_info_node_id(TOOLS_PATH)
        location_id = noc_call(api.get_location_id, base, customer_id, node_id)
        print(json.dumps({"step": "location", "ok": True, "node_id": node_id, "location_id": location_id}))

        # Ensure WiFi ON (NOC)
        st0 = noc_call(api.wifi_status, base, customer_id, location_id)
        en0 = _wifi_enabled_flag(st0)
        print(json.dumps({"step": "wifi-status-initial", "enabled": en0, "resp": st0}))

        # -------------------------------------------------
        # Precondition (ref C00000003): fetch WiFi SSID/PSK from CPE via SSH (wifi-creds)
        # -------------------------------------------------
        wifi_prefer = _clean_manifest_val(_getenv("WIFI_CRED_PREFER", "current")) or "current"

        # A) In-process cache across cycles (avoid flakiness when SSH creds fetch times out on later cycles)
        if (not wifi_ssid) and _WIFI_CREDS_CACHE.get("ssid"):
            wifi_ssid = str(_WIFI_CREDS_CACHE.get("ssid") or "").strip()
        if (not wifi_psk) and _WIFI_CREDS_CACHE.get("psk"):
            wifi_psk = str(_WIFI_CREDS_CACHE.get("psk") or "").strip()
        if wifi_ssid and wifi_psk and (_WIFI_CREDS_CACHE.get("ssid") and _WIFI_CREDS_CACHE.get("psk")):
            print(json.dumps({"step": "wifi-creds", "ok": True, "source": "cache", "picked": {"source": _WIFI_CREDS_CACHE.get("source") or "cached"}}))

        # If user didn't override SSID/PSK (and cache not available), prefer reading from CPE (same as C00000003).
        if (not wifi_ssid) or (not wifi_psk):
            try:
                j_creds = _cpe_ssh_cmd(TOOLS_PATH, ssh_host, cpe_user, cpe_pass, "wifi-creds", timeout=max(20, cpe_ssh_timeout))
                if isinstance(j_creds, dict) and j_creds.get("ok"):
                    chosen = _choose_wifi_creds(j_creds, wifi_band or "", prefer=wifi_prefer)
                    print(json.dumps({
                        "step": "wifi-creds",
                        "ok": True,
                        "source": "cpe",
                        "picked": {"source": (chosen or {}).get("source")} if chosen else None,
                    }))
                    if chosen:
                        if not wifi_ssid:
                            wifi_ssid = chosen.get("ssid", "").strip()
                        if not wifi_psk:
                            wifi_psk = chosen.get("psk", "").strip()
                else:
                    print(json.dumps({"step": "wifi-creds", "ok": False, "source": "cpe", "error": "cpe_ssh wifi-creds not ok"}))
            except Exception as e:
                print(json.dumps({"step": "wifi-creds", "ok": False, "source": "cpe", "error": str(e)}))

        # Fallback: NOC wifiNetwork may contain ssid/encryptionKey (best effort)
        st0_for_creds = st0
        ssid_noc, psk_noc = _extract_wifi_creds_from_noc(st0_for_creds)
        if not wifi_ssid and ssid_noc:
            wifi_ssid = ssid_noc
            print(json.dumps({"step": "wifi-creds", "source": "noc", "field": "ssid", "ok": True, "ssid": wifi_ssid}))
        if not wifi_psk and psk_noc:
            wifi_psk = psk_noc
            print(json.dumps({"step": "wifi-creds", "source": "noc", "field": "psk", "ok": True, "psk": "<redacted>"}))

        if not wifi_ssid or not wifi_psk:
            raise RuntimeError("missing WIFI SSID/PSK; ensure CPE SSH wifi-creds works or set WIFI_SSID/WIFI_PSK")

        # Cache for later cycles (cycle2+)
        try:
            _WIFI_CREDS_CACHE["ssid"] = wifi_ssid
            _WIFI_CREDS_CACHE["psk"] = wifi_psk
            # best-effort: record last known source (cpe/noc/cache/manual)
            if not _WIFI_CREDS_CACHE.get("source"):
                _WIFI_CREDS_CACHE["source"] = "runtime"
        except Exception:
            pass

        print(json.dumps({"event": "precondition", "ok": True, "ssid": wifi_ssid, "psk": "<redacted>"}))

        wifi_was_disabled = (en0 is not True)
        if wifi_was_disabled:
            noc_call(api.wifi_set_enabled, base, customer_id, location_id, True)
            print(json.dumps({"step": "wifi-enable", "ok": True}))

        def _pred_noc_on():
            st = noc_call(api.wifi_status, base, customer_id, location_id)
            return (_wifi_enabled_flag(st) is True, {"enabled": _wifi_enabled_flag(st)})

        _wait_until("noc-wifi-enabled", noc_state_timeout, poll_interval, _pred_noc_on)

        # Step3 equivalent: verify VIF enabled/broadcast via SSH
        def _pred_vif_on():
            j = _cpe_ssh_cmd(TOOLS_PATH, ssh_host, cpe_user, cpe_pass, "wifi-vif-state", timeout=cpe_ssh_timeout)
            return (_wifi_enabled_from_vifs(j) is True and _ssid_broadcast_from_vifs(j) is True, {
                "vif_enabled": _wifi_enabled_from_vifs(j),
                "ssid_broadcast": _ssid_broadcast_from_vifs(j),
            })

        _wait_until("ssh-vif-enabled", vif_state_timeout, poll_interval, _pred_vif_on)

        # Scan should see SSID

        # Track consecutive empty scan results to trigger recovery.
        empty_scan_streak = [0]

        def _pred_scan_has_ssid():
            j = _wifi_iwd_cmd(TOOLS_PATH, ['scan', '--iface', wifi_iface], timeout=60)
            aps = j.get('aps') if isinstance(j, dict) else None
            found = False
            ssids = []
            if isinstance(aps, list):
                for ap in aps:
                    if not isinstance(ap, dict):
                        continue
                    s = str(ap.get('ssid') or ap.get('Name') or '').strip()
                    if s:
                        ssids.append(s)
                    if s == wifi_ssid:
                        found = True
                        break

            # If scan returns empty repeatedly (count=0 and no ssids), try recovery.
            try:
                cnt = j.get('count') if isinstance(j, dict) else None
                empty = (cnt == 0) or (isinstance(aps, list) and len(aps) == 0) or (len(ssids) == 0)
                if empty:
                    empty_scan_streak[0] += 1
                else:
                    empty_scan_streak[0] = 0
                thresh = int(_getenv('WIFI_EMPTY_SCAN_RECOVER_THRESHOLD', '3'))
                if empty_scan_streak[0] == thresh:
                    print(json.dumps({'step': 'wifi-scan-empty-recover', 'ok': True, 'streak': empty_scan_streak[0]}))
                    _restart_iwd()
                    _ip_link_cycle(wifi_iface)
            except Exception:
                pass

            return (
                found,
                {
                    'found': found,
                    'count': j.get('count') if isinstance(j, dict) else None,
                    'target': wifi_ssid,
                    'ssids_sample': ssids[:10],
                },
            )

        _wait_until("scan-ssid-present", scan_timeout, poll_interval, _pred_scan_has_ssid)

        # After enabling radios from an "off" state, the SSID may show up in scans
        # before the preferred band is fully ready for association. Add a small grace.
        if wifi_was_disabled:
            grace = float(_getenv("WIFI_POST_ENABLE_GRACE_SEC", "6"))
            if grace > 0:
                print(json.dumps({"step": "wait", "what": "post-enable-grace", "sec": grace}))
                time.sleep(grace)

        # Connect as WiFi client (robust): try preferred band first, then fallback to any band.
        # Also allow increasing iwctl timeout (wifi_iwd --timeout) to avoid false timeouts.
        iwd_timeout = int(_getenv("WIFI_IWD_TIMEOUT_SEC", "90"))
        connect_retries = int(_getenv("WIFI_CONNECT_RETRIES", "3"))
        takeover_on_retry = _bool_env("WIFI_TAKEOVER_ON_RETRY", True)
        fallback_any_band = _bool_env("WIFI_FALLBACK_ANY_BAND", True)

        def _build_ensure_args(band: Optional[str], takeover: bool) -> List[str]:
            args = [
                "ensure",
                "--iface",
                wifi_iface,
                "--ssid",
                wifi_ssid,
                "--password",
                wifi_psk,
                "--timeout",
                str(iwd_timeout),
                "--dhcp-timeout",
                str(dhcp_timeout),
            ]
            if band:
                args += ["--band", band]
            if takeover:
                args += ["--takeover"]
            if no_main_default:
                args += ["--no-main-default"]
            if pbr_table is not None:
                args += ["--pbr-table", str(pbr_table)]
            if pbr_from_ip:
                args += ["--pbr-from-ip"]
            return args

        def _already_connected_ok() -> Optional[Dict[str, Any]]:
            st = _wifi_iwd_cmd(TOOLS_PATH, ["status", "--iface", wifi_iface], timeout=25)
            if isinstance(st, dict) and st.get("ok") and str(st.get("ssid") or "") == wifi_ssid and st.get("ip4"):
                return {"ok": True, "status": st}
            return None

        plan: List[Tuple[Optional[str], bool]] = []
        if wifi_band:
            plan.append((wifi_band, False))
            if fallback_any_band:
                plan.append((None, False))
        else:
            plan.append((None, False))

        # Extra retries: use takeover to avoid iwd/NM races, and cycle link best-effort.
        while len(plan) < max(1, connect_retries):
            plan.append((None if fallback_any_band else wifi_band, True))

        j_conn: Dict[str, Any] = {"ok": False, "error": "not attempted"}
        for attempt, (band_try, takeover_try) in enumerate(plan[:connect_retries], start=1):
            pre = _already_connected_ok()
            if pre:
                j_conn = pre
                print(json.dumps({"step": "wifi-connect", "attempt": attempt, "ok": True, "note": "already-connected"}))
                break

            # Best-effort cleanup between attempts
            _wifi_iwd_cmd(TOOLS_PATH, ["disconnect", "--iface", wifi_iface], timeout=25)
            if attempt >= 2:
                _ip_link_cycle(wifi_iface)
                if takeover_on_retry:
                    takeover_try = True

            ensure_args = _build_ensure_args(band_try, takeover_try)
            print(json.dumps({
                "step": "wifi-connect-attempt",
                "attempt": attempt,
                "band": band_try or "<any>",
                "takeover": takeover_try,
                "iwd_timeout": iwd_timeout,
            }))

            j_conn = _wifi_iwd_cmd(TOOLS_PATH, ensure_args, timeout=max(120, iwd_timeout + dhcp_timeout + 40))
            ok = bool(isinstance(j_conn, dict) and j_conn.get("ok"))
            print(json.dumps({"step": "wifi-connect", "attempt": attempt, "ok": ok, "resp": j_conn}))
            if ok:
                break

            raw = str(j_conn.get("raw") or j_conn.get("error") or "")
            retryable = ("TimeoutExpired" in raw) or ("timed out" in raw.lower())
            if attempt < connect_retries and retryable:
                # small backoff before retry
                time.sleep(float(_getenv("WIFI_CONNECT_RETRY_WAIT_SEC", "3")))
                continue
            if attempt < connect_retries:
                time.sleep(float(_getenv("WIFI_CONNECT_RETRY_WAIT_SEC", "3")))

        if not bool(isinstance(j_conn, dict) and j_conn.get("ok")):
            raise RuntimeError(f"wifi connect failed after {connect_retries} attempt(s): {j_conn}")

        st_conn = j_conn.get("status") if isinstance(j_conn, dict) else None
        ip4 = (st_conn or {}).get("ip4") if isinstance(st_conn, dict) else None
        if not ip4:
            raise RuntimeError(f"no IPv4 on wifi iface after connect (status={st_conn})")

        # Optional ping to CPE
        try:
            p = subprocess.run(["ping", "-I", wifi_iface, "-c", str(ping_count), ping_target], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=15)
            print(json.dumps({"step": "ping", "ok": (p.returncode == 0), "target": ping_target, "rc": p.returncode}))
        except Exception as e:
            print(json.dumps({"step": "ping", "ok": False, "error": str(e)}))

        # NOTE: after we disable WiFi radios, a WLAN client may lose reachability to the CPE
        # (including SSH to 192.168.1.1). Record which interface the host currently uses.
        ssh_route_dev = _route_dev_for_host(ssh_host)
        print(json.dumps({"step": "ssh-route", "host": ssh_host, "dev": ssh_route_dev or None}))

        # Disable WiFi radios via NOC
        noc_call(api.wifi_set_enabled, base, customer_id, location_id, False)
        print(json.dumps({"step": "wifi-disable", "ok": True}))

        # A) After disabling radios, WiFi default route may become "linkdown" but still poison routing.
        # Purge any defaults referencing the WiFi iface before we keep polling NOC over the Internet.
        try:
            _purge_iface_defaults(wifi_iface)
            print(json.dumps({"event": "route-purge-after-wifi-disable", "ok": True, "iface": wifi_iface}))
        except Exception as e:
            print(json.dumps({"event": "route-purge-after-wifi-disable", "ok": False, "iface": wifi_iface, "error": str(e)}))

        def _pred_noc_off():
            st = noc_call(api.wifi_status, base, customer_id, location_id)
            return (_wifi_enabled_flag(st) is False, {"enabled": _wifi_enabled_flag(st)})

        _wait_until("noc-wifi-disabled", noc_state_timeout, poll_interval, _pred_noc_off)

        # Router-side VIF check after WiFi disable:
        # If SSH path to the CPE is via the same WiFi iface, SSH will likely become unreachable once radios are disabled.
        # In that case, we treat the router-side check as optional (default), and rely on client disconnect + scan absent.
        require_ssh_vif_off = (_getenv("REQUIRE_SSH_VIF_OFF", "0").strip() == "1")

        def _pred_vif_off():
            j = _cpe_ssh_cmd(TOOLS_PATH, ssh_host, cpe_user, cpe_pass, "wifi-vif-state", timeout=cpe_ssh_timeout)
            vif_en = _wifi_enabled_from_vifs(j)
            sb = _ssid_broadcast_from_vifs(j)
            return (vif_en is False or sb is False, {"vif_enabled": vif_en, "ssid_broadcast": sb, "ssh_ok": bool(j.get("ok"))})

        if (not require_ssh_vif_off) and (not ssh_route_dev or ssh_route_dev == wifi_iface):
            print(json.dumps({
                "step": "ssh-vif-disabled-skip",
                "ok": True,
                "reason": "ssh-to-cpe routed via wifi iface; expected unreachable after wifi disable",
                "dev": ssh_route_dev or None,
                "wifi_iface": wifi_iface,
            }))
        else:
            _wait_until("ssh-vif-disabled", vif_state_timeout, poll_interval, _pred_vif_off)

        # Client should disconnect + scan should not see SSID
        def _pred_client_disconnected():
            st = _wifi_iwd_cmd(TOOLS_PATH, ["status", "--iface", wifi_iface], timeout=25)
            ssid = (st.get("ssid") if isinstance(st, dict) else None) or ""
            ip4_now = st.get("ip4") if isinstance(st, dict) else ""
            ok = (ssid.strip() == "")
            return (ok, {"ssid": ssid, "ip4": ip4_now})

        def _pred_scan_no_ssid():
            j = _wifi_iwd_cmd(TOOLS_PATH, ["scan", "--iface", wifi_iface], timeout=60)
            aps = j.get("aps") if isinstance(j, dict) else None
            found = False
            match = None
            if isinstance(aps, list):
                for ap in aps:
                    if not isinstance(ap, dict):
                        continue
                    ss = str(ap.get("ssid") or ap.get("Name") or "").strip()
                    if ss == wifi_ssid:
                        found = True
                        # include more fields to detect scan caching / stale entries
                        match = {
                            "ssid": ss,
                            "bssid": ap.get("bssid") or ap.get("BSSID") or ap.get("Address"),
                            "freq": ap.get("freq") or ap.get("Frequency"),
                            "signal": ap.get("signal") or ap.get("Signal") or ap.get("RSSI"),
                            "raw_keys": sorted(list(ap.keys()))[:20],
                        }
                        break
            return (not found, {"found": found, "count": j.get("count") if isinstance(j, dict) else None, "match": match})

        # More robust order: once radios are disabled, SSID should disappear from scan.
        # Client-side iwd status may lag; use scan-ssid-absent first, then force disconnect.
        _wait_until("scan-ssid-absent", scan_timeout, poll_interval, _pred_scan_no_ssid)

        # Force client disconnect (best-effort) then verify status shows disconnected.
        _wifi_iwd_cmd(TOOLS_PATH, ["disconnect", "--iface", wifi_iface], timeout=30)
        _wait_until("client-disconnected", 60, poll_interval, _pred_client_disconnected)

        # Enable WiFi radios via NOC
        noc_call(api.wifi_set_enabled, base, customer_id, location_id, True)
        print(json.dumps({"step": "wifi-enable-again", "ok": True}))

        _wait_until("noc-wifi-enabled-again", noc_state_timeout, poll_interval, _pred_noc_on)
        _wait_until("ssh-vif-enabled-again", vif_state_timeout, poll_interval, _pred_vif_on)
        _wait_until("scan-ssid-present-again", scan_timeout, poll_interval, _pred_scan_has_ssid)

        j_conn2 = _wifi_iwd_cmd(TOOLS_PATH, ensure_args, timeout=120)
        print(json.dumps({"step": "wifi-reconnect", "ok": bool(j_conn2.get("ok")), "resp": j_conn2}))
        if not j_conn2.get("ok"):
            raise RuntimeError(f"wifi reconnect failed: {j_conn2}")

        st2 = j_conn2.get("status") if isinstance(j_conn2, dict) else None
        if not isinstance(st2, dict) or not st2.get("ip4"):
            raise RuntimeError(f"no IPv4 on wifi iface after reconnect (status={st2})")

        print(json.dumps({"event": "pass"}))
        return 0

    except Exception as e:
        print(json.dumps({"event": "fail", "error": str(e)}), flush=True)
        return 1
    finally:
        # best-effort cleanup
        try:
            wifi_iface = _getenv("WIFI_IFACE", "wlx6cb0ce1ff230")
            _wifi_iwd_cmd(TOOLS_PATH, ["disconnect", "--iface", wifi_iface], timeout=30)
            _purge_iface_defaults(wifi_iface)
        except Exception:
            pass
