# C15806905_SSID_broadcast_when_WiFi_radios_toggled

## 1) 目的 / 覆蓋範圍
- 驗證 Wi‑Fi SSID 廣播、client 連線或 radio toggle 行為。

## 2) 前置條件 / 環境
- 需有可用 WLAN client，且腳本指定的 SSID/頻段在環境中存在。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'20'

## 5) PASS/FAIL 判定
- PASS：SSID/連線/radio 狀態符合預期。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15806905 (Design/Automation) — SSID broadcast when WiFi radios are toggled via NOC

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'20'

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15806905 (Design/Automation) — SSID broadcast when WiFi radios are toggled via NOC

這支腳本自動化以下流程（全程只用 **NOC API + SSH**，不使用 serial/console）：

1. 確認 WiFi radios 為 Enabled（必要時用 NOC API 開啟）
2. 透過 SSH 讀取 `Wifi_VIF_State`，判斷 VIF enabled / SSID broadcast 狀態
3. WLAN NIC 進行 scan，確認目標 SSID 有被 broadcast
4. WLAN NIC 連線到 CPE SSID，確認取得 IPv4（可選：ping CPE LAN IP）
5. 用 NOC API 關閉 WiFi radios
6. 等待 VIF disabled + scan 看不到 SSID + client 斷線
7. 用 NOC API 開啟 WiFi radios
8. 等待 SSID 回來並再次連線成功

## 重要說明
- 本腳本依賴 `/home/da40/charter/tools` 內的：
  - `noc_api_cli.py`
  - `cpe_ssh.py`
  - `cpe_info`
  - `wifi_iwd.py`
- WiFi client 連線動作使用 `sudo -n`，請確保 runner 有 non-interactive sudo 權限。

## 常用 env
- NOC：`NOC_PROFILE` + `PROFILES_FILE`（建議），或 `NOC_BASE/NOC_EMAIL/NOC_PASSWORD`
- CPE：`CUSTOMER_ID`、`SSH_HOST_LAN`、`CPE_USER`、`CPE_PASSWORD`
- WiFi Client：`WIFI_IFACE`；SSID/PSK 預設會透過 NOC `wifiNetwork` 查詢（參考 C00000003）。
  - 可用 `WIFI_SSID` 覆蓋 SSID（通常不需要）
  - PSK 可用 `WIFI_PSK` 或 `WIFI_PSK_ENV` 覆蓋（若 NOC 未回傳 encryptionKey 時需要）
- Timeouts：`NOC_TIMEOUT_SEC`、`WIFI_NOC_STATE_TIMEOUT_SEC`、`WIFI_VIF_STATE_TIMEOUT_SEC`


## SSID/PSK 取得方式（同 C00000003 precondition）
- 若未設定 `WIFI_SSID/WIFI_PSK`，腳本會在登入 NOC、取得 `location_id` 後呼叫 `wifi-status`（GET /wifiNetwork）
  取得 `ssid` / `encryptionKey` 作為 WiFi client 連線資訊。
- 若 NOC 回傳只含 SSID，腳本會再呼叫 `wifiNetwork/ssid` 取得 SSID；PSK 若仍缺則再 best-effort 嘗試 `cpe_ssh.py --cmd wifi-creds`，最後才要求你用 env 提供。
```

```
