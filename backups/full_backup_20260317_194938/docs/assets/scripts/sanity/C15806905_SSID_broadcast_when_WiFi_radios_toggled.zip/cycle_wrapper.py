#!/usr/bin/env python3
"""cycle_wrapper

Generic cycle wrapper for C00000001.

Env:
  - CYCLES
  - CYCLE_INTERVAL
  - STOP_ON_FAIL
  - ORIGINAL_ENTRY (e.g. "main_impl_orig.py:run")

Precondition (first cycle only):
  - CPE_READY via `cpe_info -status` (+ optional single PDU reset + console mute)
  - SSH_ENABLE + SSH_READY via NOC + LAN SSH check
"""

import os
import time
import importlib
import sys
import json


def _parse_bool(val, default=False):
    if val is None:
        return default
    s = str(val).strip().lower()
    return s in ("1", "true", "yes", "on", "y")


def _resolve_entry(entry: str):
    if not entry:
        raise ValueError("Empty ORIGINAL_ENTRY")
    if ":" not in entry:
        raise ValueError(f"Bad ORIGINAL_ENTRY format: {entry!r}")
    mod_name, func_name = entry.split(":", 1)
    if mod_name.endswith(".py"):
        mod_name = mod_name[:-3]
    mod = importlib.import_module(mod_name)
    func = getattr(mod, func_name)
    return func


import socket
import subprocess
import shlex


# ================================================================
# Precondition: first-cycle CPE_READY + SSH_ENABLE/READY
# - CPE_READY: `cpe_info -status` (Internet+Cloud) retry N times
#              if still not ready => console mute + single PDU reset => wait => re-check
# - SSH: enable via NOC + check LAN TCP/22 + run a lightweight SSH command via tools/cpe_ssh.py
# ================================================================


# ---- console mute helpers (avoid serial/console lock during reboot/pdu cycles) ----
_MUTE_FILE = "/home/da40/charter/var/serial.mute"
_MUTE_LOCK_FILE = "/home/da40/charter/var/serial.mute.lock"


def _set_perms(path: str) -> None:
    try:
        os.chmod(path, 0o664)
    except Exception:
        pass


def _console_mute_fallback(secs: int, reason: str = "mute") -> dict:
    """Fallback mute: write /home/da40/charter/var/serial.mute as epoch seconds."""
    try:
        secs = int(secs)
    except Exception:
        secs = 0
    secs = max(0, secs)
    now = time.time()
    until = int(now + secs) if secs > 0 else 0

    try:
        os.makedirs(os.path.dirname(_MUTE_FILE), exist_ok=True)
        if until > 0:
            with open(_MUTE_FILE, "w") as f:
                f.write(str(until))
            _set_perms(_MUTE_FILE)
    except Exception as e:
        return {"ok": False, "mute_secs": secs, "until": until, "reason": reason, "error": str(e)}

    # Optional lock marker (some environments use it to block console readers)
    with_lock = _parse_bool(os.environ.get("REBOOT_MUTE_WITH_LOCK", "0"), default=False)
    if with_lock and until > 0:
        try:
            with open(_MUTE_LOCK_FILE, "w") as f:
                f.write(str(until))
            _set_perms(_MUTE_LOCK_FILE)
        except Exception:
            pass

    return {"ok": True, "mute_secs": secs, "until": until, "reason": reason, "with_lock": bool(with_lock)}


def _console_mute(secs: int, reason: str = "mute") -> dict:
    """Preferred mute: tools/serial_mute.py --set <secs> ; fallback to file-based mute."""
    tools_path = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
    tool = os.path.join(tools_path, "serial_mute.py")
    pybin = os.environ.get("PYTHON", "python3")
    if os.path.exists(tool):
        try:
            cp = subprocess.run([pybin, tool, "--set", str(int(secs))], capture_output=True, text=True, timeout=20)
            ok = (cp.returncode == 0)
            return {
                "ok": ok,
                "mute_secs": int(secs),
                "reason": reason,
                "method": "serial_mute.py",
                "rc": cp.returncode,
                "out": (cp.stdout or "")[-2000:],
                "err": (cp.stderr or "")[-2000:],
            }
        except Exception as e:
            # fall through
            return {**_console_mute_fallback(secs, reason=reason), "method": "file", "warn": str(e)}
    return {**_console_mute_fallback(secs, reason=reason), "method": "file"}


def _cpe_ready_run_cmd(cmd, timeout=30):
    # Run command and return (rc, combined_output).
    try:
        cp = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=timeout,
        )
        return cp.returncode, (cp.stdout or "")
    except Exception as e:
        return 99, f"ERROR: cmd failed: {cmd!r} ({e})"


def _cpe_ready_parse_status(output: str):
    internet = None
    cloud = None
    for line in (output or "").splitlines():
        if ":" not in line:
            continue
        k, v = line.split(":", 1)
        k = k.strip().lower()
        v = v.strip()
        if k == "internet status":
            internet = v
        elif k == "cloud status":
            cloud = v
    return internet, cloud


def _cpe_ready_is_connected(val: str) -> bool:
    return val is not None and val.strip().lower() == "connected"


def _probe_cpe_ready(phase: str) -> bool:
    """Probe CPE readiness by parsing `cpe_info -status`.

    Logs:
      {"step":"cpe-ready-probe","attempt":..,"internet":..,"cloud":..,"ready":..,"phase":..}
    """
    status_cmd = os.environ.get("CPE_INFO_STATUS_CMD", "cpe_info -status")
    retries = int(os.environ.get("CPE_READY_MAX_RETRIES", "10"))
    interval = float(os.environ.get("CPE_READY_RETRY_INTERVAL_SEC", "3"))
    require_cloud = _parse_bool(os.environ.get("CPE_READY_REQUIRE_CLOUD", "1"), default=True)

    for attempt in range(1, retries + 1):
        rc, out = _cpe_ready_run_cmd(shlex.split(status_cmd), timeout=20)
        internet, cloud = _cpe_ready_parse_status(out)
        ready = _cpe_ready_is_connected(internet) and ((not require_cloud) or _cpe_ready_is_connected(cloud))
        print(json.dumps({
            "step": "cpe-ready-probe",
            "attempt": attempt,
            "cmd_rc": rc,
            "internet": internet,
            "cloud": cloud,
            "ready": ready,
            "phase": phase,
        }, ensure_ascii=False), flush=True)
        if ready:
            return True
        if attempt < retries and interval > 0:
            time.sleep(interval)
    return False


# ---- node-id ready probe (ref C00000003/C00000001 style: use cpe_info, no serial) ----

def _norm_node_id(val: str) -> str:
    s = (val or "").strip().lower().replace(":", "")
    if len(s) == 12 and all(c in "0123456789abcdef" for c in s):
        return s
    return ""


def _ensure_node_id_ready() -> dict:
    """Ensure we can fetch node-id via cpe_info.

    Env:
      - NODE_ID_READY_CHECK (default 1)
      - NODE_ID_MAX_RETRIES / NODE_ID_RETRY_INTERVAL_SEC
      - CPE_INFO_TOOL (optional)
    """
    if not _parse_bool(os.environ.get("NODE_ID_READY_CHECK", "1"), default=True):
        return {"ok": True, "skipped": True, "node_id": None}

    tool = os.environ.get("CPE_INFO_TOOL") or "cpe_info"
    retries = int(os.environ.get("NODE_ID_MAX_RETRIES", "10"))
    interval = float(os.environ.get("NODE_ID_RETRY_INTERVAL_SEC", "3"))

    last_out = ""
    for attempt in range(1, retries + 1):
        node_id = ""
        for extra in (["--node-id"], ["--node-id", "--value"]):
            argv = ([tool] if os.path.exists(tool) else ["cpe_info"]) + extra
            rc, out = _cpe_ready_run_cmd(argv, timeout=20)
            last_out = (out or "").strip()
            cand = _norm_node_id(last_out.splitlines()[-1] if last_out else "")
            print(json.dumps({
                "step": "node-id-ready-probe",
                "attempt": attempt,
                "cmd": " ".join(argv),
                "rc": rc,
                "node_id": cand or None,
            }, ensure_ascii=False), flush=True)
            if cand:
                node_id = cand
                break
        if node_id:
            os.environ["NODE_ID"] = node_id
            return {"ok": True, "node_id": node_id, "attempt": attempt}
        if attempt < retries and interval > 0:
            time.sleep(interval)

    return {"ok": False, "failed_step": "node-id-ready", "error": f"node-id not ready (last={last_out[:120]})"}


def _ensure_cpe_ready() -> dict:
    """Ensure CPE ready, with optional single PDU reset workaround."""
    if not _parse_bool(os.environ.get("CPE_READY_CHECK", "1"), default=True):
        return {"ok": True, "skipped": True}

    if _probe_cpe_ready("initial"):
        return {"ok": True, "pdu_reset_used": False}

    if not _parse_bool(os.environ.get("PDU_RESET_ON_NOT_READY", "1"), default=True):
        return {"ok": False, "failed_step": "cpe-ready", "error": "cpe not ready"}

    # ---- single PDU reset ----
    # follow spec: PDU_RESET_SCRIPT first, then PDU_SCRIPT
    pdu_script = os.environ.get("PDU_RESET_SCRIPT") or os.environ.get("PDU_SCRIPT") or "/home/da40/charter/tools/pdu_outlet1.py"
    pdu_action = os.environ.get("PDU_RESET_ACTION", "reset")
    pdu_timeout = int(os.environ.get("PDU_RESET_TIMEOUT_SEC", "120"))
    pdu_wait = int(os.environ.get("PDU_RESET_WAIT_SEC", "120"))
    post_stab = int(os.environ.get("POST_PDU_STABILIZE_SEC", "40"))
    pdu_outlet_id = os.environ.get("PDU_OUTLET_ID")
    pybin = os.environ.get("PYTHON", "python3")

    try:
        mute_secs = int(os.environ.get("REBOOT_MUTE_SECS", "60"))
    except Exception:
        mute_secs = 60

    mute_res = _console_mute(mute_secs, reason="pdu_reset")
    print(json.dumps({
        "event": "console-mute",
        "ok": bool(mute_res.get("ok")),
        "mute_secs": mute_res.get("mute_secs"),
        "method": mute_res.get("method"),
        "rc": mute_res.get("rc"),
        "error": mute_res.get("error"),
    }, ensure_ascii=False), flush=True)

    prc, pout = _cpe_ready_run_cmd([pybin, pdu_script, pdu_action], timeout=pdu_timeout)
    pdu_ok = (prc == 0)
    print(json.dumps({
        "event": "pdu-reset",
        "ok": pdu_ok,
        "script": pdu_script,
        "action": pdu_action,
        "outlet_id": pdu_outlet_id,
        "rc": prc,
        "output_tail": (pout or "")[-2000:],
        "timeout_sec": pdu_timeout,
    }, ensure_ascii=False), flush=True)
    if not pdu_ok:
        return {"ok": False, "failed_step": "pdu-reset", "error": f"pdu reset failed rc={prc}"}

    total_wait = max(0, pdu_wait) + max(0, post_stab)
    if total_wait > 0:
        print(json.dumps({"event": "post-pdu-wait", "wait_sec": total_wait}, ensure_ascii=False), flush=True)
        if pdu_wait > 0:
            time.sleep(pdu_wait)
        if post_stab > 0:
            time.sleep(post_stab)

    if _probe_cpe_ready("after-pdu"):
        return {"ok": True, "pdu_reset_used": True}

    return {"ok": False, "failed_step": "cpe-ready", "error": "cpe not ready after single pdu reset", "pdu_reset_used": True}


def _tcp_port_open(host: str, port: int, timeout_sec: float = 2.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout_sec):
            return True
    except Exception:
        return False


def _ssh_cmd_check(host: str, user: str, password: str, cmd: str) -> dict:
    """Run a lightweight SSH command using tools/cpe_ssh.py; return {ok, rc, out/json} dict."""
    tool = os.environ.get("CPE_SSH_TOOL", "/home/da40/charter/tools/cpe_ssh.py")
    pybin = os.environ.get("PYTHON", "python3")
    timeout_sec = int(os.environ.get("SSH_TOOL_TIMEOUT", "15"))
    argv = [pybin, tool, "--host", host, "--user", user, "--password", password, "--cmd", cmd]

    try:
        cp = subprocess.run(argv, capture_output=True, text=True, timeout=timeout_sec)
        out = (cp.stdout or "")
        err = (cp.stderr or "")
        payload = None
        ok = (cp.returncode == 0)
        try:
            payload = json.loads(out) if out.strip().startswith("{") else None
            if isinstance(payload, dict) and "ok" in payload:
                ok = bool(payload.get("ok"))
        except Exception:
            payload = None
        return {
            "ok": ok,
            "rc": cp.returncode,
            "out": out[-2000:],
            "err": err[-2000:],
            "json": payload,
        }
    except Exception as e:
        return {"ok": False, "rc": 99, "error": str(e)}


def _ensure_ssh_ready(impl_mod) -> dict:
    """Enable SSH via NOC and verify SSH ready over LAN.

    Notes:
    - 必須避免依賴 console/serial；node-id 由 precondition 的 cpe_info ready probe 提供（env: NODE_ID）。
    - NOC profile 的讀取邏輯沿用各腳本的 _load_noc_profile（如 C00000003）。
    """

    enable_ssh_flow = _parse_bool(os.environ.get("ENABLE_SSH_FLOW", "1"), default=True)
    if not enable_ssh_flow:
        return {"ok": True, "skipped": True, "ssh_ready": False}

    ssh_action = (os.environ.get("SSH_ACTION", "enable") or "enable").strip().lower()
    if ssh_action not in ("enable", "disable", "both"):
        return {"ok": False, "failed_step": "ssh-action", "error": f"bad SSH_ACTION={ssh_action}"}

    # Only verify ready when enabling
    require_ready = _parse_bool(os.environ.get("REQUIRE_SSH_READY", "1"), default=True)
    if ssh_action not in ("enable", "both"):
        return {"ok": True, "ssh_ready": False, "skipped": True}

    node_id = (os.environ.get("NODE_ID") or "").strip()
    if not node_id:
        return {"ok": False, "failed_step": "node-id", "error": "NODE_ID missing (cpe_info --node-id)"}

    # ---------------- NOC config (profile preferred) ----------------
    profile_name = (os.environ.get("NOC_PROFILE") or "").strip()
    base = (os.environ.get("NOC_BASE") or "").strip()
    email = (os.environ.get("NOC_EMAIL") or "").strip()
    password = (os.environ.get("NOC_PASSWORD") or "").strip()
    customer_id = (os.environ.get("CUSTOMER_ID") or "").strip()

    if profile_name and hasattr(impl_mod, "_load_noc_profile"):
        try:
            prof = impl_mod._load_noc_profile(profile_name)  # type: ignore[attr-defined]
        except Exception:
            prof = None
        if prof:
            base = (prof.get("base") or base).strip()
            email = (prof.get("email") or email).strip()
            password = (prof.get("password") or password).strip()
            customer_id = (prof.get("customer_id") or customer_id).strip()
            print(
                json.dumps(
                    {
                        "event": "noc-profile-applied",
                        "profile": profile_name,
                        "base": base,
                        "email": bool(email),
                        "password": bool(password),
                        "customer_id": bool(customer_id),
                        "where": "cycle_wrapper.precondition",
                    },
                    ensure_ascii=False,
                ),
                flush=True,
            )
        else:
            print(
                json.dumps(
                    {"event": "noc-profile-not-applied", "profile": profile_name, "where": "cycle_wrapper.precondition"},
                    ensure_ascii=False,
                ),
                flush=True,
            )

    if not base:
        return {"ok": False, "failed_step": "noc-config", "error": "missing NOC_BASE (or profile not loaded)"}
    if not email or not password:
        return {"ok": False, "failed_step": "noc-config", "error": "missing NOC_EMAIL/NOC_PASSWORD (or profile not loaded)"}
    if not customer_id:
        return {"ok": False, "failed_step": "noc-config", "error": "missing CUSTOMER_ID (or profile not loaded)"}

    bearer = _parse_bool(os.environ.get("BEARER", "0"), default=False)
    insecure = _parse_bool(os.environ.get("INSECURE", "0"), default=False)

    # Optional knobs
    noc_timeout = int(os.environ.get("NOC_TIMEOUT_SEC", "30"))
    noc_retries = int(os.environ.get("NOC_RETRIES", "3"))

    # SSH settings
    ssh_user = (os.environ.get("SSH_USER") or "operator").strip()
    ssh_pass = (os.environ.get("SSH_PASSWORD") or "").strip()
    ssh_timeout_min = int(os.environ.get("SSH_TIMEOUT_MIN", "120"))
    if not ssh_pass:
        return {"ok": False, "failed_step": "ssh-config", "error": "missing SSH_PASSWORD"}

    # Import tools/noc_api_cli dynamically
    tools_path = (os.environ.get("TOOLS_PATH") or "/home/da40/charter/tools").strip()
    if tools_path and tools_path not in sys.path:
        sys.path.insert(0, tools_path)
    try:
        import noc_api_cli as api  # type: ignore
        import requests
    except Exception as e:
        return {"ok": False, "failed_step": "noc-import", "error": f"import noc_api_cli failed: {e}"}

    # Apply timeout
    try:
        api.DEFAULT_TIMEOUT = max(5, noc_timeout)
    except Exception:
        pass

    # ---------------- NOC auth + enable SSH ----------------
    location_id = ""
    token = ""

    def _do_noc_sequence(use_bearer: bool) -> tuple[str, str]:
        tok = api.login(base, email, password, bearer=use_bearer, insecure=insecure)
        loc = api.get_location_id(base, customer_id, node_id, token=tok, bearer=use_bearer, insecure=insecure)
        api.ssh_enable(
            base,
            customer_id,
            loc,
            node_id,
            ssh_pass,
            ssh_timeout_min,
            token=tok,
            bearer=use_bearer,
            insecure=insecure,
        )
        return tok, loc

    last_err = None
    # Retry for transient network/timeouts
    for attempt in range(1, noc_retries + 1):
        try:
            # Try bearer mode; if 401 -> flip once (same run)
            try:
                token, location_id = _do_noc_sequence(bearer)
            except requests.HTTPError as e:
                r = getattr(e, "response", None)
                code = getattr(r, "status_code", None)
                if code == 401:
                    bearer = not bearer
                    os.environ["BEARER"] = "1" if bearer else "0"
                    print(json.dumps({"event": "noc-auth-flip", "bearer": bearer}, ensure_ascii=False), flush=True)
                    token, location_id = _do_noc_sequence(bearer)
                else:
                    raise

            os.environ["PRECOND_SSH_ENABLED"] = "1"
            break
        except (requests.Timeout, requests.ConnectionError) as e:
            last_err = e
            if attempt < noc_retries:
                time.sleep(min(5.0 * attempt, 20.0))
                continue
            return {"ok": False, "failed_step": "ssh-enable", "error": f"NOC timeout/connection after retries: {e}"}
        except Exception as e:
            last_err = e
            return {
                "ok": False,
                "failed_step": "ssh-enable",
                "error": str(e),
                "node_id": node_id,
                "location_id": location_id or None,
                "token_present": bool(token),
            }

    # If we reach here with no token, treat as failure
    if not token or not location_id:
        return {"ok": False, "failed_step": "ssh-enable", "error": f"NOC ssh_enable failed: {last_err}"}

    if not require_ready:
        return {"ok": True, "ssh_ready": True, "node_id": node_id, "location_id": location_id, "token_present": True}

    # ---------------- Wait SSH port + basic cmd ----------------
    host = (os.environ.get("SSH_HOST_LAN") or "192.168.1.1").strip()
    ready_cmd = (os.environ.get("SSH_READY_CMD") or "health").strip()
    ready_retry = int(os.environ.get("SSH_READY_RETRY", "40"))
    ready_wait = float(os.environ.get("SSH_READY_WAIT_SEC", "3"))

    # Fast path: already open
    for attempt in range(1, ready_retry + 1):
        port_open = _tcp_port_open(host, 22, timeout_sec=2.0)
        print(
            json.dumps(
                {"event": "ssh-port-check", "attempt": attempt, "open": port_open, "host": host, "port": 22},
                ensure_ascii=False,
            ),
            flush=True,
        )

        if port_open:
            chk = _ssh_cmd_check(host, ssh_user, ssh_pass, ready_cmd)
            print(
                json.dumps(
                    {
                        "event": "ssh-cmd-check",
                        "attempt": attempt,
                        "cmd": ready_cmd,
                        "ok": bool(chk.get("ok")),
                        "rc": chk.get("rc"),
                    },
                    ensure_ascii=False,
                ),
                flush=True,
            )
            if chk.get("ok"):
                return {"ok": True, "ssh_ready": True, "node_id": node_id, "location_id": location_id, "token_present": True}

        # Best-effort re-enable again if still not open
        if attempt < ready_retry:
            try:
                api.ssh_enable(
                    base,
                    customer_id,
                    location_id,
                    node_id,
                    ssh_pass,
                    ssh_timeout_min,
                    token=token,
                    bearer=bearer,
                    insecure=insecure,
                )
            except Exception:
                pass
            if ready_wait > 0:
                time.sleep(ready_wait)

    return {
        "ok": False,
        "failed_step": "ssh-ready",
        "error": "ssh not ready after retries",
        "node_id": node_id,
        "location_id": location_id,
        "token_present": True,
    }

def precondition(entry_module) -> dict:
    """Unified precondition: CPE_READY + SSH_ENABLE/READY (first cycle)."""
    nid_res = _ensure_node_id_ready()
    if not nid_res.get("ok"):
        return {
            "ok": False,
            "failed_step": nid_res.get("failed_step", "node-id-ready"),
            "error": nid_res.get("error", "node-id not ready"),
            "node_id": nid_res.get("node_id"),
        }

    cpe_res = _ensure_cpe_ready()
    if not cpe_res.get("ok"):
        return {"ok": False, "failed_step": cpe_res.get("failed_step", "cpe-ready"), "error": cpe_res.get("error", "cpe not ready"), "cpe_ready": False}

    ssh_res = _ensure_ssh_ready(entry_module)
    if not ssh_res.get("ok"):
        return {
            "ok": False,
            "failed_step": ssh_res.get("failed_step", "ssh"),
            "error": ssh_res.get("error", "ssh precondition failed"),
            "cpe_ready": True,
            "ssh_ready": False,
            "node_id": nid_res.get("node_id") or ssh_res.get("node_id"),
            "location_id": ssh_res.get("location_id"),
            "token_present": bool(ssh_res.get("token_present")),
        }

    return {
        "ok": True,
        "cpe_ready": True,
        "ssh_ready": bool(ssh_res.get("ssh_ready")),
        "node_id": nid_res.get("node_id") or ssh_res.get("node_id"),
        "location_id": ssh_res.get("location_id"),
        "token_present": bool(ssh_res.get("token_present")),
        "pdu_reset_used": bool(cpe_res.get("pdu_reset_used", False)),
    }

def run() -> int:
    cycles = int(os.environ.get("CYCLES", "1"))
    interval = int(os.environ.get("CYCLE_INTERVAL", "30"))
    stop_on_fail = _parse_bool(os.environ.get("STOP_ON_FAIL", "1"), default=True)
    entry = os.environ.get("ORIGINAL_ENTRY", "main_impl_orig.py:run")

    try:
        func = _resolve_entry(entry)
    except Exception as e:
        print(json.dumps({"event": "entry_resolve_error", "entry": entry, "error": str(e)}))
        return 1

    # Import entry module object for precondition helpers
    try:
        mod_name = entry.split(":", 1)[0]
        if mod_name.endswith(".py"):
            mod_name = mod_name[:-3]
        entry_mod = importlib.import_module(mod_name)
    except Exception as e:
        print(json.dumps({"event": "entry_module_import_error", "entry": entry, "error": str(e)}))
        return 1

    overall_rc = 0
    for i in range(cycles):
        # Precondition: only on first cycle
        if i == 0:
            pre = precondition(entry_mod)
            print(json.dumps({"event": "precondition", "result": pre}, ensure_ascii=False), flush=True)
            if not pre.get("ok"):
                print(json.dumps({
                    "event": "precondition_fail",
                    "cycle": 1,
                    "rc": 2,
                    "failed_step": pre.get("failed_step"),
                    "error": pre.get("error"),
                    "last": pre,
                }, ensure_ascii=False), flush=True)
                return 2

        print(json.dumps({"event": "cycle_start", "cycle": i + 1, "total": cycles}))
        try:
            rc = func()
        except SystemExit as se:
            rc = int(se.code or 0)
        except Exception as e:
            print(json.dumps({"event": "cycle_exception", "cycle": i + 1, "error": str(e)}))
            rc = 1

        try:
            rc = int(rc)
        except Exception:
            rc = 1

        print(json.dumps({"event": "cycle_end", "cycle": i + 1, "rc": rc}))
        if rc != 0:
            overall_rc = rc
            if stop_on_fail:
                break

        if i < cycles - 1 and interval > 0:
            time.sleep(interval)

    print(json.dumps({"event": "all_cycles_done", "rc": overall_rc}))
    return overall_rc


if __name__ == "__main__":
    sys.exit(run())

