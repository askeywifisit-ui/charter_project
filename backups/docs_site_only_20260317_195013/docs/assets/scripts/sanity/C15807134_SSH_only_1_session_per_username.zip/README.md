# C15807134_SSH_only_1_session_per_username

## 1) 目的 / 覆蓋範圍
- 驗證 SSH 可用性與安全策略（允許/拒絕、port 限制、帳密錯誤等）。

## 2) 前置條件 / 環境
- 需具備對應 client 位置（LAN/WAN）與連線條件。
- 若需 NOC enable SSH，請用 `.secrets`/`PROFILES_FILE`。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- （manifest 未包含常見 env 或解析不到；可直接查看 zip 內 manifest.yaml）

## 5) PASS/FAIL 判定
- PASS：SSH 行為符合預期策略。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807134 - SSH is enabled for only 1 session per username

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807134 - SSH is enabled for only 1 session per username

## Summary
This test verifies that only **one** simultaneous SSH management session is allowed per username.
When one SSH session is active for the same username, the second SSH session should **not** be established.

## Manual Test Plan Intent (T4625128) vs Automation
The manual plan uses two clients:
1) Client-1 logs in successfully with `operator`
2) Client-2 attempts to log in with the same username and must be rejected

In automation, we simulate these two clients from the worker by opening two concurrent SSH
connections (two Paramiko clients) using the same credentials.

## Preconditions (Automation)
1. NOC login (get access token)
2. Get node_id via serial metrics (with retry handling)
3. Get location_id via NOC API
4. Enable SSH Manager (SSHM) via kvConfigs PATCH (set sshAuthPasswd / timeout)

## Test Flow (Automation)
1. Enable SSH via SSHM (kvConfigs PATCH).
2. Establish SSH Session-1 to DUT LAN IPv4 using `operator`, and keep it alive (sleep for `SSH_HOLD_SEC` seconds).
   - Expected: Session-1 login is successful.
3. While Session-1 is still active, attempt to establish SSH Session-2 (same username `operator`) to DUT LAN IPv4.
   - Expected: Session-2 is rejected (connection/auth/channel failure). Messages such as
     `PTY allocation request failed on channel 0` / `shell request failed on channel 0`
     / timeout / connection closed are all treated as **DENY/PASS**.
4. Cleanup: close Session-1.

## Expected Result
- Exactly one active SSH session per username is allowed; the second simultaneous session must not be established.

## Notes
- WAN-side steps in the manual plan are intentionally deferred (MAP-T/environment dependent).
- This script focuses on LAN IPv4 session concurrency behavior.
```

```
