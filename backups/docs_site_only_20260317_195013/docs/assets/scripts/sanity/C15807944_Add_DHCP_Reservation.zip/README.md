# C15807944_Add_DHCP_Reservation

## 1) 目的 / 覆蓋範圍
- 驗證 DHCP reservation 的新增/更新/刪除或 reset 後行為。

## 2) 前置條件 / 環境
- 需可透過平台/工具對 DHCP reservation API 操作。
- 注意：若目標 IP 已被占用，可能回 422（例如 used by Netgear）。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- （manifest 未包含常見 env 或解析不到；可直接查看 zip 內 manifest.yaml）

## 5) PASS/FAIL 判定
- PASS：reservation 操作成功且驗證點符合預期。
- FAIL：422/衝突或驗證點不符（需看 log）。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807944_Add_DHCP_Reservation

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807944_Add_DHCP_Reservation

## Purpose
Create a DHCP reservation (MAC → IPv4) and validate end-to-end:
- NOC API reservation is set
- CPE runtime reflects it (reserved + leased tables)
- A LAN client renews and obtains the reserved IPv4

## Topology
Control PC (this runner) ↔ LAN (wired) ↔ CPE (router)

## Key dependencies (external tools)
- `cpe_info` : cloud readiness + node-id
- `noc_api_cli.py` : NOC ssh-enable + DHCP reservation APIs
- `cpe_ssh.py` : query DHCP tables from CPE over SSH
- `lan_macvlan.py` : create isolated LAN client, renew DHCP, report IPv4

## Precondition behavior (cycle #1 only)
1. `cpe_info --cloud` retry until timeout (`CLOUD_READY_TIMEOUT_SEC`)
2. If still not ready → PDU reset once (`PDU_SCRIPT` + `PDU_OUTLET_ID`) → retry cloud check
3. Resolve node-id via `cpe_info --node-id`
4. Ensure SSH is ready:
   - scan port 22
   - if closed: NOC `ssh-enable` (attempts=`SSH_ENABLE_ATTEMPTS`) + wait + re-check
   - probe via `cpe_ssh.py` using `SSH_READY_CMD` (default: uptime)

## Test steps

### Test Plan step alignment (naming only)
This automation validates the same intent as the manual Test Plan, but:
- UI navigation steps are replaced by NOC API calls.
- Serial-console `ovsh s DHCP_*` checks are replaced by SSH (`cpe_ssh.py --cmd dhcp`).

To make reviews easier, JSON logs are enriched with:
- `tp_step`: `0` (meta/preconditions) or `1..6` aligned to the Test Plan step numbers
- `tp_event`: a step-aligned readable event id (does **not** change execution logic)

### Automated steps (mapped to Test Plan)
- **TP Step 1** (Power on + claimed/ready): `cpe_info --cloud` + optional PDU reset + `cpe_info --node-id` + ensure SSH ready
- **TP Step 4** (Enter static IP / create reservation): cleanup + set reservation via NOC API
- **TP Step 5** (Disconnect/reconnect + connectivity): renew LAN client (macvlan) and optional ping
- **TP Step 6** (Verify reserved/leased tables): read DHCP tables from CPE over SSH and assert reserved/leased match

### Script flow
1. Cleanup any existing reservation for `LAN_TEST_MAC` (best effort)
2. Add reservation for `LAN_TEST_MAC` → `TEST_RESERVED_IP` with `TEST_HOSTNAME`
3. Verify CPE reserved/leased tables match (`cpe_ssh.py --cmd dhcp`)
4. Renew a LAN client with `LAN_TEST_MAC` and verify obtained IPv4 equals `TEST_RESERVED_IP`

## Pass/Fail
- PASS if all verifications succeed in the current cycle
- FAIL otherwise (script prints DHCP dumps + lan_macvlan JSON in logs)

## Notes
- Do not store secrets in the script zip. Provide NOC/CPE passwords via `PROFILES_FILE` or environment variables.
- For `lan_macvlan.py`, prefer `LAN_TEST_IFACE=auto` to avoid interface-name collisions on the control PC
  (e.g. when a previous run crashed before cleanup or when jobs run concurrently).


## Secrets
- Set SSH_PASSWORD (operator SSH password) in your PROFILES_FILE profile or environment.
```

```
