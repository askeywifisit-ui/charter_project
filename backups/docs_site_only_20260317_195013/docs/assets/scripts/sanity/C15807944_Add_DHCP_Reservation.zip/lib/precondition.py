# -*- coding: utf-8 -*-
import os, time
from typing import Optional
from .util import jlog, run_cmd, q
from .ssh import ensure_ssh_ready
from .profile import load_profile

def _tools_path() -> str:
    return os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")

def precondition() -> str:
    """
    Run once at cycle #1.
    Returns node_id.
    """
    tools = _tools_path().rstrip("/")
    cpe_info = f"{q(tools + '/cpe_info')}"
    pdu_script = os.environ.get("PDU_SCRIPT", f"{tools}/pdu_outlet1.py")
    outlet = os.environ.get("PDU_OUTLET_ID", "1")
    cloud_timeout = float(os.environ.get("CLOUD_READY_TIMEOUT_SEC", "30"))
    cloud_interval = float(os.environ.get("CLOUD_READY_INTERVAL_SEC", "3"))

    # 1) cpe_info --cloud retry
    def cloud_check() -> bool:
        cmd = f"{cpe_info} --cloud"
        rc, out, err, sec = run_cmd(cmd, timeout=cloud_interval + 5)
        ok = ("Connected" in out) and (rc == 0)
        jlog("cpe_cloud_check", ok=ok, rc=rc, sec=sec, out=out.strip()[:120])
        return ok

    start = time.time()
    ok = False
    while time.time() - start < cloud_timeout:
        if cloud_check():
            ok = True
            break
        time.sleep(max(0.1, cloud_interval))
    if not ok:
        # 2) PDU reset once
        jlog("pdu_reset_start", script=pdu_script, outlet=outlet)
        env = os.environ.copy()
        env["PDU_OUTLET_ID"] = str(outlet)
        cmd = f"python3 {q(pdu_script)} reset"
        rc, out, err, sec = run_cmd(cmd, timeout=120, env=env)
        jlog("pdu_reset_end", rc=rc, sec=sec)
        time.sleep(5)

        # retry cloud check again (same window)
        start2 = time.time()
        while time.time() - start2 < cloud_timeout:
            if cloud_check():
                ok = True
                break
            time.sleep(max(0.1, cloud_interval))
        if not ok:
            raise RuntimeError("cloud_not_ready_after_pdu_reset")

    # 3) node-id
    cmd = f"{cpe_info} --node-id"
    rc, out, err, sec = run_cmd(cmd, timeout=15)
    node_id = out.strip().splitlines()[-1].strip() if out.strip() else ""
    if rc != 0 or not node_id:
        jlog("node_id_error", rc=rc, out=out.strip()[:120], err=err.strip()[:120])
        raise RuntimeError("node_id_missing")
    jlog("node_id", node_id=node_id)

    # expose for other helpers
    os.environ["NODE_ID"] = node_id

    # 4) ensure ssh ready
    ok_ssh = ensure_ssh_ready(node_id)
    if not ok_ssh:
        raise RuntimeError("ssh_not_ready")
    return node_id
