# -*- coding: utf-8 -*-
"""NOC DHCP reservation helpers (script-local).

This script previously called tools/noc_api_cli.py, but in some INT
environments the endpoint:

  GET /api/Customers/{customerId}/nodes/{nodeId}

may return HTTP 404 with a LoopBack message like:

  "Shared class \"Customer\" has no method handling GET /nodes/<nodeId>"

That breaks locationId auto-resolution.

To keep the test stable, we implement a tiny HTTP client here and add a
fallback resolver:

  - try GET /Customers/{cid}/nodes/{nodeId}
  - if not supported, try GET /Customers/{cid}/nodes?filter=... (id==nodeId)
  - if still not supported, try GET /Customers/{cid}/nodes (list) and search

You can always override by setting env NOC_LOCATION_ID (recommended if your
backend has none of the node endpoints).
"""

from __future__ import annotations

import json
import os
import re
import time
import urllib.parse
from typing import Any, Dict, Optional

import requests

from .profile import load_profile
from .util import jlog


def _bool_env(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return str(v).strip().lower() in ("1", "true", "yes", "y", "on")


def _noc_params() -> Dict[str, Any]:
    prof = load_profile() or {}
    bearer_default = bool(prof.get("bearer", False))
    insecure_default = bool(prof.get("insecure", False))
    return {
        "base": (prof.get("base") or os.environ.get("NOC_BASE") or os.environ.get("BASE") or "").rstrip("/"),
        "customer_id": (prof.get("customer_id") or prof.get("customerId") or os.environ.get("NOC_CUSTOMER_ID") or os.environ.get("CUSTOMER_ID") or "").strip(),
        "email": (prof.get("email") or os.environ.get("NOC_EMAIL") or os.environ.get("EMAIL") or "").strip(),
        "password": (prof.get("password") or os.environ.get("NOC_PASSWORD") or os.environ.get("PASSWORD") or "").strip(),
        "bearer": _bool_env("NOC_BEARER", bearer_default),
        "insecure": _bool_env("NOC_INSECURE", insecure_default),
        "timeout": int(os.environ.get("NOC_TIMEOUT_SEC", "20")),
        "retry_412": int(os.environ.get("NOC_RETRY_412", os.environ.get("RETRY_412", "0")) or "0"),
        "retry_wait": float(os.environ.get("NOC_RETRY_WAIT", os.environ.get("RETRY_WAIT", "10")) or "10"),
    }


def _api(base: str, path: str) -> str:
    if not path.startswith("/"):
        path = "/" + path
    return f"{base}/api{path}"


def _auth_headers(token: str, bearer: bool) -> Dict[str, str]:
    if not token:
        return {}
    return {"Authorization": (f"Bearer {token}" if bearer else token)}


def _login(base: str, email: str, password: str, *, bearer: bool, insecure: bool, timeout: int) -> str:
    url = _api(base, "/Customers/login")
    r = requests.post(
        url,
        json={"email": email, "password": password},
        headers={"Content-Type": "application/json"},
        timeout=timeout,
        verify=not insecure,
    )
    if r.status_code >= 400:
        raise RuntimeError(f"noc_login_failed http={r.status_code} body={r.text[:200]}")
    j = r.json() if r.text else {}
    tok = j.get("id")
    if not tok:
        raise RuntimeError("noc_login_ok_but_token_missing")
    return str(tok)


def _req_retry_412(method: str, url: str, *, headers: Dict[str, str], data: Any = None, timeout: int,
                   insecure: bool, retry_412: int, retry_wait: float) -> requests.Response:
    last = None
    for i in range(retry_412 + 1):
        r = requests.request(method, url, headers=headers, data=data, timeout=timeout, verify=not insecure)
        if r.status_code != 412:
            return r
        last = r
        if i < retry_412:
            time.sleep(retry_wait)
    return last if last is not None else r


def _try_get_json(url: str, *, headers: Dict[str, str], timeout: int, insecure: bool) -> tuple[int, Any, str]:
    r = requests.get(url, headers=headers, timeout=timeout, verify=not insecure)
    txt = r.text or ""
    if r.status_code >= 400:
        return r.status_code, None, txt
    try:
        return r.status_code, r.json(), txt
    except Exception:
        return r.status_code, None, txt


def resolve_location_id(node_id: str, *, base: str, customer_id: str, token: str, bearer: bool,
                        insecure: bool, timeout: int) -> str:
    # Explicit override (best practice when backend changes)
    loc_override = (os.environ.get("NOC_LOCATION_ID") or os.environ.get("LOCATION_ID") or "").strip()
    if loc_override:
        jlog("noc_location_override", location_id=loc_override)
        return loc_override

    h = _auth_headers(token, bearer)

    # 1) Preferred: GET /Customers/{cid}/nodes/{nodeId}
    url1 = _api(base, f"/Customers/{customer_id}/nodes/{node_id}")
    sc, j, txt = _try_get_json(url1, headers=h, timeout=timeout, insecure=insecure)
    if sc < 400 and isinstance(j, dict) and j.get("locationId"):
        return str(j["locationId"])

    # 2) Fallback: GET /Customers/{cid}/nodes?filter=... (id==nodeId)
    flt = urllib.parse.quote(json.dumps({"where": {"id": node_id}}))
    url2 = _api(base, f"/Customers/{customer_id}/nodes?filter={flt}")
    sc2, j2, txt2 = _try_get_json(url2, headers=h, timeout=timeout, insecure=insecure)
    if sc2 < 400 and isinstance(j2, list) and j2:
        loc = (j2[0] or {}).get("locationId")
        if loc:
            jlog("noc_location_resolved", method="nodes_filter_id", location_id=loc)
            return str(loc)

    # 3) Fallback: list all nodes then search
    url3 = _api(base, f"/Customers/{customer_id}/nodes")
    sc3, j3, txt3 = _try_get_json(url3, headers=h, timeout=timeout, insecure=insecure)
    if sc3 < 400 and isinstance(j3, list):
        for it in j3:
            if not isinstance(it, dict):
                continue
            nid = str(it.get("id") or it.get("nodeId") or "")
            if nid == node_id:
                loc = it.get("locationId")
                if loc:
                    jlog("noc_location_resolved", method="nodes_list", location_id=loc)
                    return str(loc)

    # If we reached here, show a short diagnostic
    diag = {
        "try1": {"url": url1, "status": sc, "body": (txt[:120] if txt else "")},
        "try2": {"url": url2, "status": sc2, "body": (txt2[:120] if txt2 else "")},
        "try3": {"url": url3, "status": sc3, "body": (txt3[:120] if txt3 else "")},
    }
    raise RuntimeError(f"cannot_resolve_location_id node_id={node_id} diag={diag}")


def _ensure_session(node_id: str) -> Dict[str, Any]:
    p = _noc_params()
    base = p["base"]
    customer_id = p["customer_id"]
    if not base or not customer_id:
        raise RuntimeError(f"noc_params_missing base='{base}' customer_id='{customer_id}'")
    if not p["email"] or not p["password"]:
        raise RuntimeError("noc_credentials_missing (email/password). put them in PROFILES_FILE")

    token = _login(base, p["email"], p["password"], bearer=p["bearer"], insecure=p["insecure"], timeout=p["timeout"])
    loc = resolve_location_id(
        node_id,
        base=base,
        customer_id=customer_id,
        token=token,
        bearer=p["bearer"],
        insecure=p["insecure"],
        timeout=p["timeout"],
    )
    return {"base": base, "customer_id": customer_id, "token": token, "location_id": loc, **p}


def dhcp_resv_set(node_id: str, mac: str, ip: str, host_name: str = "") -> None:
    s = _ensure_session(node_id)
    url = _api(s["base"], f"/Customers/{s['customer_id']}/locations/{s['location_id']}/networkConfiguration/dhcpReservations/{urllib.parse.quote(mac.lower(), safe='')}" )
    headers = _auth_headers(s["token"], s["bearer"])
    headers["Content-Type"] = "application/x-www-form-urlencoded"
    data = {"ip": str(ip)}
    if host_name:
        data["hostName"] = str(host_name)

    t0 = time.time()
    r = _req_retry_412(
        "PUT",
        url,
        headers=headers,
        data=data,
        timeout=s["timeout"],
        insecure=s["insecure"],
        retry_412=s["retry_412"],
        retry_wait=s["retry_wait"],
    )
    sec = time.time() - t0
    ok = r.status_code < 400
    jlog("dhcp_resv_set", ok=ok, http=r.status_code, sec=sec, mac=mac, ip=ip, host_name=host_name, location_id=s["location_id"])
    if not ok:
        # Common INT failure: target IP is already reserved by another MAC.
        # Backend sometimes returns a helpful message like:
        #   "This IP address is currently reserved by 02:aa:bb:cc:dd:ee."
        # We can clear that conflicting reservation and retry once.
        do_clear = int(os.environ.get("CLEAR_CONFLICTING_IP_RESERVATION", "1") or "1") == 1
        if r.status_code == 422 and do_clear:
            m = re.search(r"reserved\s+by\s+([0-9a-fA-F:]{17})", r.text or "")
            if m:
                owner = m.group(1).lower()
                if owner and owner != mac.lower():
                    jlog("dhcp_resv_set_retry", reason="ip_reserved_by_other_mac", owner_mac=owner, desired_mac=mac, ip=ip)
                    try:
                        dhcp_resv_del(node_id, owner)
                    except Exception as e:
                        jlog("dhcp_resv_set_retry_clear_failed", owner_mac=owner, ip=ip, error=str(e))
                    else:
                        # retry once
                        t1 = time.time()
                        r2 = _req_retry_412(
                            "PUT",
                            url,
                            headers=headers,
                            data=data,
                            timeout=s["timeout"],
                            insecure=s["insecure"],
                            retry_412=s["retry_412"],
                            retry_wait=s["retry_wait"],
                        )
                        sec2 = time.time() - t1
                        ok2 = r2.status_code < 400
                        jlog("dhcp_resv_set_retry_result", ok=ok2, http=r2.status_code, sec=sec2, mac=mac, ip=ip, host_name=host_name)
                        if ok2:
                            return
        raise RuntimeError(f"dhcp_resv_set_http_failed http={r.status_code} body={r.text[:200]}")


def dhcp_resv_list(node_id: str) -> Any:
    """List DHCP reservations for this location.

    Endpoint is location scoped:
      GET /Customers/{cid}/locations/{locationId}/networkConfiguration/dhcpReservations

    Return JSON (usually a list).
    """
    s = _ensure_session(node_id)
    url = _api(
        s["base"],
        f"/Customers/{s['customer_id']}/locations/{s['location_id']}/networkConfiguration/dhcpReservations",
    )
    headers = _auth_headers(s["token"], s["bearer"])
    t0 = time.time()
    r = _req_retry_412(
        "GET",
        url,
        headers=headers,
        timeout=s["timeout"],
        insecure=s["insecure"],
        retry_412=s["retry_412"],
        retry_wait=s["retry_wait"],
    )
    sec = time.time() - t0
    ok = r.status_code < 400
    j = None
    if ok:
        try:
            j = r.json() if r.text else None
        except Exception:
            j = None
    jlog(
        "dhcp_resv_list",
        ok=ok,
        http=r.status_code,
        sec=sec,
        location_id=s["location_id"],
        count=(len(j) if isinstance(j, list) else None),
    )
    if not ok:
        raise RuntimeError(f"dhcp_resv_list_http_failed http={r.status_code} body={r.text[:200]}")
    return j


def _extract_reservations(j: Any) -> list[dict]:
    """Best-effort normalize list response to list of dict."""
    if j is None:
        return []
    if isinstance(j, list):
        return [x for x in j if isinstance(x, dict)]
    # sometimes wrapped
    if isinstance(j, dict):
        for k in ("reservations", "items", "data"):
            v = j.get(k)
            if isinstance(v, list):
                return [x for x in v if isinstance(x, dict)]
    return []


def find_owner_mac_by_ip(node_id: str, ip: str) -> Optional[str]:
    """Return MAC that currently reserves ip (if any) via NOC list API."""
    ip = str(ip).strip()
    if not ip:
        return None
    j = dhcp_resv_list(node_id)
    for it in _extract_reservations(j):
        it_ip = str(it.get("ip") or it.get("reservedIp") or it.get("reserved_ip") or "").strip()
        if it_ip != ip:
            continue
        mac = str(it.get("mac") or it.get("id") or it.get("deviceMac") or "").strip().lower()
        if mac:
            return mac
    return None


def dhcp_resv_del(node_id: str, mac: str) -> None:
    """Delete a DHCP reservation by MAC (raise on failure)."""
    s = _ensure_session(node_id)
    url = _api(
        s["base"],
        f"/Customers/{s['customer_id']}/locations/{s['location_id']}/networkConfiguration/dhcpReservations/{urllib.parse.quote(mac.lower(), safe='')}",
    )
    headers = _auth_headers(s["token"], s["bearer"])
    t0 = time.time()
    r = _req_retry_412(
        "DELETE",
        url,
        headers=headers,
        timeout=s["timeout"],
        insecure=s["insecure"],
        retry_412=s["retry_412"],
        retry_wait=s["retry_wait"],
    )
    sec = time.time() - t0
    ok = r.status_code < 400
    jlog("dhcp_resv_del", http=r.status_code, sec=sec, mac=mac, location_id=s["location_id"])
    if not ok:
        raise RuntimeError(f"dhcp_resv_del_http_failed http={r.status_code} body={r.text[:200]}")


def ensure_ip_not_reserved(node_id: str, ip: str, desired_mac: str) -> Optional[str]:
    """If ip is reserved by another MAC, delete that reservation (best-effort).

    Return conflicting owner MAC if found.
    Controlled by env:
      - CLEAR_CONFLICTING_IP_RESERVATION (default: 1)
    """
    desired_mac = (desired_mac or "").strip().lower()
    try:
        owner = find_owner_mac_by_ip(node_id, ip)
    except Exception as e:
        jlog("dhcp_resv_conflict_check_failed", ip=ip, error=str(e))
        return None

    if owner and owner != desired_mac:
        do_clear = int(os.environ.get("CLEAR_CONFLICTING_IP_RESERVATION", "1") or "1") == 1
        jlog(
            "dhcp_resv_ip_conflict",
            ip=ip,
            owner_mac=owner,
            desired_mac=desired_mac,
            will_clear=do_clear,
        )
        if do_clear:
            try:
                dhcp_resv_del(node_id, owner)
                jlog("dhcp_resv_ip_conflict_cleared", ip=ip, owner_mac=owner)
            except Exception as e:
                jlog("dhcp_resv_ip_conflict_clear_failed", ip=ip, owner_mac=owner, error=str(e))
        return owner
    return None


def dhcp_resv_del_best_effort(node_id: str, mac: str) -> None:
    try:
        s = _ensure_session(node_id)
    except Exception as e:
        jlog("dhcp_resv_del_skip", reason="noc_session_failed", error=str(e), mac=mac)
        return

    url = _api(s["base"], f"/Customers/{s['customer_id']}/locations/{s['location_id']}/networkConfiguration/dhcpReservations/{urllib.parse.quote(mac.lower(), safe='')}" )
    headers = _auth_headers(s["token"], s["bearer"])

    t0 = time.time()
    r = _req_retry_412(
        "DELETE",
        url,
        headers=headers,
        timeout=s["timeout"],
        insecure=s["insecure"],
        retry_412=s["retry_412"],
        retry_wait=s["retry_wait"],
    )
    sec = time.time() - t0
    jlog("dhcp_resv_del", http=r.status_code, sec=sec, mac=mac, location_id=s["location_id"])
    # best effort: ignore failures
    return


def dhcp_resv_clear_all_best_effort(node_id: str, *, hostname_prefix: str = "") -> dict:
    """List all DHCP reservations in this location and delete them (best-effort).

    WARNING:
      This affects the entire location. Use only in a dedicated lab location.

    Args:
      hostname_prefix: if provided, only delete reservations whose hostname starts with this prefix.

    Returns:
      {"total": N, "matched": M, "deleted": D}
    """
    hostname_prefix = (hostname_prefix or "").strip()

    try:
        s = _ensure_session(node_id)
    except Exception as e:
        jlog("dhcp_resv_clear_all_skip", reason="noc_session_failed", error=str(e))
        return {"total": 0, "matched": 0, "deleted": 0}

    # 1) list
    try:
        j = dhcp_resv_list(node_id)
    except Exception as e:
        jlog("dhcp_resv_clear_all_list_failed", error=str(e))
        return {"total": 0, "matched": 0, "deleted": 0}

    items = _extract_reservations(j)
    total = len(items)

    def _host(it: dict) -> str:
        return str(it.get("hostname") or it.get("host_name") or it.get("hostName") or "").strip()

    def _mac(it: dict) -> str:
        return str(it.get("mac") or it.get("id") or it.get("deviceMac") or "").strip().lower()

    targets: list[tuple[str, str]] = []  # (mac, hostname)
    for it in items:
        mac = _mac(it)
        if not mac:
            continue
        host = _host(it)
        if hostname_prefix and not host.startswith(hostname_prefix):
            continue
        targets.append((mac, host))

    matched = len(targets)
    jlog(
        "dhcp_resv_clear_all_start",
        total=total,
        matched=matched,
        hostname_prefix=hostname_prefix or None,
        location_id=s.get("location_id"),
    )

    # 2) delete
    deleted = 0
    headers = _auth_headers(s["token"], s["bearer"])
    for mac, host in targets:
        url = _api(
            s["base"],
            f"/Customers/{s['customer_id']}/locations/{s['location_id']}/networkConfiguration/dhcpReservations/{urllib.parse.quote(mac.lower(), safe='')}",
        )
        t0 = time.time()
        try:
            r = _req_retry_412(
                "DELETE",
                url,
                headers=headers,
                timeout=s["timeout"],
                insecure=s["insecure"],
                retry_412=s["retry_412"],
                retry_wait=s["retry_wait"],
            )
            sec = time.time() - t0
            ok = r.status_code < 400
            if ok:
                deleted += 1
            jlog(
                "dhcp_resv_clear_item",
                ok=ok,
                http=r.status_code,
                sec=sec,
                mac=mac,
                hostname=host,
                location_id=s.get("location_id"),
            )
        except Exception as e:
            sec = time.time() - t0
            jlog(
                "dhcp_resv_clear_item",
                ok=False,
                http=None,
                sec=sec,
                mac=mac,
                hostname=host,
                error=str(e),
                location_id=s.get("location_id"),
            )

    jlog(
        "dhcp_resv_clear_all_end",
        total=total,
        matched=matched,
        deleted=deleted,
        hostname_prefix=hostname_prefix or None,
        location_id=s.get("location_id"),
    )
    return {"total": total, "matched": matched, "deleted": deleted}
