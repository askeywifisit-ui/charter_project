# -*- coding: utf-8 -*-
import os
import time
from typing import Any, Dict, List
from .util import jlog, run_cmd, parse_last_json, q

def _tools_path() -> str:
    return os.environ.get("TOOLS_PATH", "/home/da40/charter/tools").rstrip("/")

def _cpe_ssh_cli() -> str:
    return f"python3 {q(_tools_path() + '/cpe_ssh.py')}"

def _lan_macvlan_cli() -> str:
    return f"python3 {q(_tools_path() + '/lan_macvlan.py')}"

def get_dhcp_tables() -> Dict[str, Any]:
    host = os.environ.get("CPE_HOST", "192.168.1.1")
    user = os.environ.get("CPE_SSH_USER", "operator")
    pw = os.environ.get("CPE_SSH_PASSWORD") or os.environ.get("SSH_PASSWORD") or os.environ.get("SSH_PASSWORD_DEFAULT") or "123456789"
    timeout = float(os.environ.get("CPE_SSH_TIMEOUT_SEC", "30"))

    dump_retries = int(os.environ.get("DHCP_DUMP_RETRIES", "3"))
    dump_wait = float(os.environ.get("DHCP_DUMP_RETRY_WAIT_SEC", "2"))

    cmd = f"python3 {q(_tools_path() + '/cpe_ssh.py')} --host {q(host)} --user {q(user)} --password {q(pw)} --timeout {q(str(timeout))} --cmd dhcp"

    def _run_once():
        rc, out, err, sec = run_cmd(cmd, timeout=timeout + 20)
        obj = parse_last_json(out) or parse_last_json(err) or {}
        ok = (rc == 0) and isinstance(obj, dict) and bool(obj.get("ok", True))
        jlog(
            "dhcp_dump",
            ok=ok,
            rc=rc,
            sec=sec,
            stderr=(err or "").strip()[-200:],
        )
        if not ok:
            jlog(
                "dhcp_dump_diag",
                rc=rc,
                out_tail=(out or "").strip()[-200:],
                err_tail=(err or "").strip()[-200:],
            )
            raise RuntimeError(f"dhcp_dump_failed rc={rc}")
        return obj

    last_err = None
    for i in range(1, dump_retries + 1):
        try:
            return _run_once()
        except Exception as e:
            last_err = e
            jlog("dhcp_dump_retry", attempt=i, attempts=dump_retries, error=str(e))
            if i < dump_retries:
                time.sleep(max(0.2, dump_wait))

    node_id = (os.environ.get("NODE_ID") or "").strip()
    if node_id:
        try:
            from .ssh import ensure_ssh_ready
            jlog("dhcp_dump_reensure_ssh", node_id=node_id)
            ensure_ssh_ready(node_id)
            return _run_once()
        except Exception as e:
            last_err = e
            jlog("dhcp_dump_reensure_ssh_failed", error=str(e), node_id=node_id)

    raise last_err if last_err else RuntimeError("dhcp_dump_failed")


def _extract_tables(data: Dict[str, Any]) -> tuple[list, list]:
    reserved = data.get("reserved") or data.get("dhcp", {}).get("reserved") or []
    leased = data.get("leased") or data.get("dhcp", {}).get("leased") or []
    return reserved, leased


def assert_reserved(mac: str, ip: str, hostname: str) -> None:
    """Reservation should appear immediately after dhcp-resv-set.

    Note: leased table may NOT contain the client until the LAN client renews.
    """
    data = get_dhcp_tables()
    reserved, _leased = _extract_tables(data)

    def norm(x: str) -> str:
        return (x or "").strip().lower()

    mac_n = norm(mac)
    ip_n = (ip or "").strip()
    host_n = (hostname or "").strip()

    rmatch = [r for r in reserved if norm(r.get("hw_addr") or r.get("mac") or "") == mac_n and str(r.get("ip_addr") or r.get("ip") or "") == ip_n]
    if host_n:
        rmatch = [r for r in rmatch if str(r.get("hostname") or r.get("hostName") or "") == host_n]
    if not rmatch:
        jlog("assert_reserved_fail", target_mac=mac, target_ip=ip, reserved=reserved[:20])
        raise RuntimeError("reserved_not_found")


    jlog("assert_reserved_ok", mac=mac, ip=ip, hostname=hostname)


def wait_for_lease(mac: str, ip: str) -> None:
    """After client renew, lease should appear (eventually consistent)."""
    timeout = int(float(os.environ.get("LEASE_WAIT_TIMEOUT_SEC", "60")))
    interval = float(os.environ.get("LEASE_WAIT_INTERVAL_SEC", "5"))
    t0 = time.time()

    def norm(x: str) -> str:
        return (x or "").strip().lower()

    mac_n = norm(mac)
    ip_n = (ip or "").strip()

    attempt = 0
    last_leased: List[Dict[str, Any]] = []
    while time.time() - t0 < timeout:
        attempt += 1
        data = get_dhcp_tables()
        _reserved, leased = _extract_tables(data)
        last_leased = leased or []
        lmatch = [
            l
            for l in last_leased
            if norm(l.get("hw_addr") or l.get("hwaddr") or l.get("mac") or "") == mac_n
            and str(l.get("ip_addr") or l.get("inet_addr") or l.get("ip") or "") == ip_n
        ]
        if lmatch:
            jlog("assert_leased_ok", mac=mac, ip=ip, attempt=attempt)
            return
        jlog("lease_wait", ok=False, attempt=attempt, elapsed_sec=round(time.time()-t0, 2))
        time.sleep(max(0.5, interval))

    jlog("assert_leased_fail", target_mac=mac, target_ip=ip, leased=last_leased[:20])
    raise RuntimeError("leased_not_found_after_renew")

def lan_renew_and_assert_ip(mac: str, expected_ip: str) -> None:
    """Renew DHCP for a simulated LAN client (macvlan netns) and assert it gets expected_ip.

    Observed in shared INT labs:
      - reservation is created successfully but enforcement can be slightly delayed
      - target IP might still be leased to another MAC from a previous run

    To improve stability, we retry renew a few times (default 3) before failing,
    and emit a DHCP table snapshot on mismatch.
    """
    parent = (os.environ.get("LAN_PARENT_IFACE") or "").strip()
    # IMPORTANT:
    #   The macvlan interface name is created on the host namespace first.
    #   Using a fixed name (e.g. "lan_test0") can collide if a previous run
    #   crashed before cleanup or when multiple jobs run concurrently.
    #   Support "auto" to let tools/lan_macvlan.py generate a unique ifname.
    iface = (os.environ.get("LAN_TEST_IFACE") or "auto").strip()
    ping = (os.environ.get("LAN_PING_TARGET") or "").strip()
    timeout = float(os.environ.get("LAN_RENEW_TIMEOUT_SEC", "120"))

    attempts = int(os.environ.get("LAN_RENEW_ATTEMPTS", "3") or "3")
    retry_wait = float(os.environ.get("LAN_RENEW_RETRY_WAIT_SEC", "5") or "5")

    # Build command. If parent is empty, let lan_macvlan auto-detect.
    base = f"{_lan_macvlan_cli()} --iface {q(iface)} --mac {q(mac)} --renew --json"
    if parent:
        cmd0 = f"{_lan_macvlan_cli()} --parent {q(parent)} --iface {q(iface)} --mac {q(mac)} --renew --json"
    else:
        cmd0 = base
    if ping:
        cmd0 += f" --ping {q(ping)}"

    last = {"rc": None, "out": "", "err": "", "sec": 0.0, "obj": {}, "ipv4": None, "iface": iface}

    for attempt in range(1, max(1, attempts) + 1):
        jlog(
            "lan_renew_start",
            attempt=attempt,
            attempts=attempts,
            cmd=cmd0,
            parent=parent or None,
            iface_requested=iface,
            mac=mac,
            expected_ip=expected_ip,
            timeout_sec=timeout,
        )

        rc, out, err, sec = run_cmd(cmd0, timeout=timeout)

        # If parent iface was wrong, retry once without --parent (auto-detect)
        if rc != 0 and parent and ("parent iface not found" in (out + err).lower() or "no parent iface found" in (out + err).lower()):
            cmd2 = base + (f" --ping {q(ping)}" if ping else "")
            jlog("lan_renew_retry", attempt=attempt, attempts=attempts, reason="bad_parent_iface", cmd=cmd2)
            rc, out, err, sec = run_cmd(cmd2, timeout=timeout)

        obj = parse_last_json(out) or parse_last_json(err) or {}

        ipv4 = None
        try:
            ipv4 = (obj.get("dhcp") or {}).get("ipv4")
        except Exception:
            ipv4 = None

        actual_iface = (obj.get("iface") or "").strip() or iface

        ok = (rc == 0) and (ipv4 == expected_ip)
        jlog(
            "lan_renew",
            attempt=attempt,
            attempts=attempts,
            rc=rc,
            sec=sec,
            ok=ok,
            iface=actual_iface,
            iface_requested=iface,
            got_ip=ipv4,
            expected_ip=expected_ip,
            stderr_sample=(err.strip().splitlines()[-1] if err.strip() else ""),
        )

        last = {"rc": rc, "out": out, "err": err, "sec": sec, "obj": obj, "ipv4": ipv4, "iface": actual_iface}

        if ok:
            return

        if attempt < attempts:
            time.sleep(max(0.2, retry_wait))

    # Final diagnostic: include DHCP table snapshot (reserved/leased) to explain mismatch.
    snap = None
    try:
        snap = get_dhcp_tables()
    except Exception as e:
        snap = {"ok": False, "error": str(e)}

    # Reduce log size: keep only entries that mention either the MAC or expected IP.
    try:
        reserved, leased = _extract_tables(snap if isinstance(snap, dict) else {})
        mac_n = (mac or "").strip().lower()
        ip_n = (expected_ip or "").strip()
        def _nm(x: str) -> str:
            return (x or "").strip().lower()
        r2 = [r for r in (reserved or []) if _nm(r.get("hw_addr") or r.get("mac") or "") == mac_n or str(r.get("ip_addr") or r.get("ip") or "") == ip_n]
        l2 = [l for l in (leased or []) if _nm(l.get("hw_addr") or l.get("hwaddr") or l.get("mac") or "") == mac_n or str(l.get("ip_addr") or l.get("inet_addr") or l.get("ip") or "") == ip_n]
        snap_small = {"reserved_hit": r2[:10], "leased_hit": l2[:10]}
    except Exception:
        snap_small = {"snapshot": snap}

    jlog(
        "lan_renew_diag",
        out_tail=(last.get("out") or "").splitlines()[-10:],
        err_tail=(last.get("err") or "").splitlines()[-10:],
        result=(last.get("obj") or {}),
        dhcp_snapshot=snap_small,
    )
    raise RuntimeError(f"lan_ip_mismatch_or_renew_failed got={last.get('ipv4')} expected={expected_ip} rc={last.get('rc')}")
