#!/usr/bin/env python3
import sys
from main_impl import run
if __name__=='__main__':
    sys.exit(run())
