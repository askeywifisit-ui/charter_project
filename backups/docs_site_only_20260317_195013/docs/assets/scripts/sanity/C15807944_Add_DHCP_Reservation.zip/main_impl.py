#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import secrets
import time
import re

from lib.util import jlog, run_cmd, q
from lib.precondition import precondition as _precondition
from lib.dhcp_api import (
    dhcp_resv_set,
    dhcp_resv_del_best_effort,
    ensure_ip_not_reserved,
    dhcp_resv_clear_all_best_effort,
)
from lib.dhcp_verify import (
    assert_reserved,
    lan_renew_and_assert_ip,
    wait_for_lease,
    get_dhcp_tables,
)

_NODE_ID = None


def gen_laa_mac() -> str:
    """Generate a locally-administered, unicast MAC (02:xx:xx:xx:xx:xx)."""
    b = bytearray(secrets.token_bytes(6))
    b[0] = 0x02  # locally administered + unicast
    return ":".join(f"{x:02x}" for x in b)


def ensure_test_mac() -> str:
    """Ensure a MAC is available for this run."""
    mac = (os.environ.get("LAN_TEST_MAC") or os.environ.get("TEST_MAC") or "").strip()
    if not mac:
        mac = gen_laa_mac()
        os.environ["LAN_TEST_MAC"] = mac
        os.environ["TEST_MAC"] = mac
    return mac


def _used_ips_from_dhcp_tables(data: dict) -> set:
    """Collect IPs in use from CPE DHCP reserved/leased tables."""
    reserved = data.get("reserved") or data.get("dhcp", {}).get("reserved") or []
    leased = data.get("leased") or data.get("dhcp", {}).get("leased") or []

    used = set()
    for r in reserved:
        ip = str(r.get("ip_addr") or r.get("ip") or "").strip()
        if ip:
            used.add(ip)
    for l in leased:
        ip = str(l.get("inet_addr") or l.get("ip_addr") or l.get("ip") or "").strip()
        if ip:
            used.add(ip)
    return used


def pick_free_ip(preferred_ip: str, used: set) -> str:
    """Pick a free IP in the same /24 by scanning upward, then wrapping.

    This avoids the common lab issue: cloud reservation changes do NOT clear old
    DHCP leases on the CPE, so the preferred IP may still be leased to an old MAC.
    """
    preferred_ip = (preferred_ip or "").strip()
    if not preferred_ip or preferred_ip not in used:
        return preferred_ip

    parts = preferred_ip.split(".")
    if len(parts) != 4:
        return preferred_ip

    base = ".".join(parts[:3])
    try:
        start = int(parts[3])
    except Exception:
        return preferred_ip

    def cand(n: int) -> str:
        return f"{base}.{n}"

    # upward scan
    for n in range(start + 1, 255):
        if n in (0, 1, 255):
            continue
        ip = cand(n)
        if ip not in used:
            return ip

    # wrap
    for n in range(2, max(2, start)):
        if n in (0, 1, 255):
            continue
        ip = cand(n)
        if ip not in used:
            return ip

    return preferred_ip

def _local_ipv4(iface: str) -> str:
    """Best-effort: return IPv4 address of a local interface (no CIDR)."""
    iface = (iface or "").strip()
    if not iface:
        return ""
    cmd = f"ip -4 -o addr show dev {q(iface)}"
    rc, out, err, sec = run_cmd(cmd, timeout=5)
    m = re.search(r"\binet\s+(\d+\.\d+\.\d+\.\d+)/", out or "")
    return m.group(1) if m else ""


def _is_ip_in_use_error(e: Exception) -> bool:
    s = str(e) or ""
    # Example: ... http=422 body={"error":{"message":"This IP address is currently used by chartertester."...}}
    return ("http=422" in s) and ("IP address is currently used" in s or "currently used by" in s)


def dhcp_resv_set_with_retry(node_id: str, mac: str, ip: str, host_name: str) -> str:
    """Set reservation, auto-picking a new IP if backend reports the IP is currently in use."""
    max_try = int(os.environ.get("IP_IN_USE_RETRY_MAX", "10") or "10")
    used: set = set()

    # Prefer CPE-used IPs if available (best-effort)
    try:
        data = get_dhcp_tables()
        used |= _used_ips_from_dhcp_tables(data or {})
    except Exception:
        pass

    # Also avoid the test runner's own IPv4 to prevent self-collision
    for k in ("LAN_PARENT_IFACE", "PING_IFACE"):
        lip = _local_ipv4(os.environ.get(k, ""))
        if lip:
            used.add(lip)

    tried = set()
    cur = (ip or "").strip()
    for attempt in range(1, max_try + 1):
        tried.add(cur)
        try:
            ensure_ip_not_reserved(node_id, cur, mac)
            dhcp_resv_set(node_id, mac, cur, host_name)
            return cur
        except Exception as e:
            if _is_ip_in_use_error(e) and attempt < max_try:
                jlog("dhcp_resv_set_retry_ip_in_use", attempt=attempt, ip=cur, error=str(e)[:200])
                used.add(cur)
                nxt = pick_free_ip(cur, used)
                if not nxt or nxt == cur or nxt in tried:
                    # last-resort: walk upward in the same /24
                    parts = cur.split(".")
                    if len(parts) == 4 and parts[3].isdigit():
                        base = ".".join(parts[:3])
                        start = int(parts[3])
                        found = ""
                        for n in range(start + 1, 255):
                            cand = f"{base}.{n}"
                            if cand in used or cand in tried or n in (0, 1, 255):
                                continue
                            found = cand
                            break
                        nxt = found or nxt or cur
                cur = nxt
                os.environ["TEST_RESERVED_IP"] = cur
                continue
            raise

    raise RuntimeError(f"no_free_ip_found: preferred={ip} attempts={max_try} last={cur}")



def _local_ipv4(iface: str) -> str:
    """Best-effort: return IPv4 address of a local interface (no CIDR)."""
    iface = (iface or "").strip()
    if not iface:
        return ""
    cmd = f"ip -4 -o addr show dev {q(iface)}"
    rc, out, err, sec = run_cmd(cmd, timeout=5)
    m = re.search(r"inet\s+(\d+\.\d+\.\d+\.\d+)/", out or "")
    return m.group(1) if m else ""


def _is_ip_in_use_error(e: Exception) -> bool:
    s = str(e) or ""
    # Example: ... http=422 body={"error":{"message":"This IP address is currently used by chartertester."...}}
    return ("http=422" in s) and ("IP address is currently used" in s or "currently used by" in s)


def dhcp_resv_set_with_retry(node_id: str, mac: str, ip: str, host_name: str) -> str:
    """Set reservation, auto-picking a new IP if backend reports the IP is currently in use."""
    max_try = int(os.environ.get("IP_IN_USE_RETRY_MAX", "10") or "10")
    used: set = set()

    # Prefer CPE-used IPs if available (best-effort)
    try:
        data = get_dhcp_tables()
        used |= _used_ips_from_dhcp_tables(data or {})
    except Exception:
        pass

    # Also avoid the test runner's own IPv4 to prevent self-collision
    for k in ("LAN_PARENT_IFACE", "PING_IFACE"):
        lip = _local_ipv4(os.environ.get(k, ""))
        if lip:
            used.add(lip)

    tried = set()
    cur = (ip or "").strip()
    for attempt in range(1, max_try + 1):
        tried.add(cur)
        try:
            ensure_ip_not_reserved(node_id, cur, mac)
            dhcp_resv_set(node_id, mac, cur, host_name)
            return cur
        except Exception as e:
            if _is_ip_in_use_error(e):
                jlog("dhcp_resv_set_retry_ip_in_use", attempt=attempt, ip=cur, error=str(e)[:200])
                used.add(cur)
                nxt = pick_free_ip(cur, used)
                if not nxt or nxt == cur or nxt in tried:
                    parts = cur.split(".")
                    if len(parts) == 4 and parts[3].isdigit():
                        base = ".".join(parts[:3])
                        start = int(parts[3])
                        found = ""
                        for n in range(start + 1, 255):
                            cand = f"{base}.{n}"
                            if cand in used or cand in tried or n in (0, 1, 255):
                                continue
                            found = cand
                            break
                        nxt = found or nxt or cur
                cur = nxt
                os.environ["TEST_RESERVED_IP"] = cur
                continue
            raise

    raise RuntimeError(f"no_free_ip_found: preferred={ip} attempts={max_try} last={cur}")



def precondition():
    global _NODE_ID
    _NODE_ID = _precondition()
    return {"node_id": _NODE_ID}


def run(cycle=None, total=None):
    """One cycle execution."""
    global _NODE_ID

    test_name = os.environ.get("TEST_NAME", "C15807944_Add_DHCP_Reservation")
    mac = ensure_test_mac()
    ip = os.environ.get("TEST_RESERVED_IP", "").strip()
    hostname = os.environ.get("TEST_HOSTNAME", "").strip()
    cleanup_after = int(os.environ.get("CLEANUP_AFTER_TEST", "0") or "0") == 1

    if not _NODE_ID:
        _NODE_ID = _precondition()

    jlog("test_start", test=test_name, cycle=cycle, total=total, mac=mac, ip=ip, hostname=hostname)

    if not mac or not ip or not hostname:
        raise RuntimeError("missing_env: require LAN_TEST_MAC (or TEST_MAC), TEST_RESERVED_IP, TEST_HOSTNAME")

    # 0) (Optional) Clear ALL cloud DHCP reservations in this location (best-effort)
    #    This does NOT clear DHCP leases on the CPE.
    if int(os.environ.get("CLEAR_ALL_NOC_DHCP_RESERVATIONS", "0") or "0") == 1:
        prefix = (os.environ.get("CLEAR_ALL_NOC_DHCP_RESERVATIONS_HOSTNAME_PREFIX") or "").strip()
        dhcp_resv_clear_all_best_effort(_NODE_ID, hostname_prefix=prefix)

    # 0.1) (Optional) If preferred IP is already in-use (leased/reserved on CPE), pick a free one
    if int(os.environ.get("AUTO_PICK_FREE_IP", "0") or "0") == 1:
        try:
            data = get_dhcp_tables()
            used = _used_ips_from_dhcp_tables(data or {})
            new_ip = pick_free_ip(ip, used)
            if new_ip and new_ip != ip:
                jlog(
                    "ip_autopick",
                    preferred_ip=ip,
                    chosen_ip=new_ip,
                    reason="ip_in_use_on_cpe",
                    used_count=len(used),
                )
                ip = new_ip
                os.environ["TEST_RESERVED_IP"] = ip
        except Exception as e:
            jlog("ip_autopick_skip", error=str(e))

    # 1) cleanup best-effort (by this run's MAC)
    dhcp_resv_del_best_effort(_NODE_ID, mac)

    # 2) ensure target IP is not reserved by another MAC (best-effort)
    ensure_ip_not_reserved(_NODE_ID, ip, mac)

    # 3) add reservation
    ip = dhcp_resv_set_with_retry(_NODE_ID, mac, ip, hostname)
    os.environ["TEST_RESERVED_IP"] = ip
    # 4) verify reservation exists on CPE (lease may not exist until client renew)
    assert_reserved(mac, ip, hostname)

    wait_after_set = float(os.environ.get("WAIT_AFTER_RESERVATION_SET_SEC", "5") or "5")
    if wait_after_set > 0:
        jlog("wait_after_reservation_set", seconds=wait_after_set)
        time.sleep(wait_after_set)

    if int(os.environ.get("SKIP_LAN_RENEW", "0") or "0") == 1:
        jlog("skip_lan_renew", reason="SKIP_LAN_RENEW=1")
        if cleanup_after:
            jlog("cleanup_reservation_start", mac=mac)
            dhcp_resv_del_best_effort(_NODE_ID, mac)
            jlog("cleanup_reservation_end", mac=mac)
        jlog("test_end", test=test_name, ok=True)
        return 0

    # 5) renew LAN client and assert IP (end-to-end)
    lan_renew_and_assert_ip(mac, ip)

    # 6) verify leased table eventually reflects the client
    wait_for_lease(mac, ip)


    if cleanup_after:
        jlog("cleanup_reservation_start", mac=mac)
        dhcp_resv_del_best_effort(_NODE_ID, mac)
        jlog("cleanup_reservation_end", mac=mac)
    jlog("test_end", test=test_name, ok=True)
    return 0


if __name__ == "__main__":
    import sys

    sys.exit(run())
