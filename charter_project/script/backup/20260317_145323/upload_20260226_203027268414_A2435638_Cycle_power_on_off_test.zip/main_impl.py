#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""A2435638 — Cycle power on/off test (customer-safe).

Key points (對齊你要的行為):
- 不再用 serial console 做 ready/ping（客戶端常常會 timeout / 被 mute / tty 不存在）
- SSH 失敗時會 *自動* 走 NOC ssh-enable（同 C00000001 流程）
- ping probe 使用 tools/cpe_ssh.py 的 --cmd ping

Readiness gates (no console):
  1) cpe_info --cloud 看到 "Cloud Status: Connected"
  2) SSH ready:
      - 掃 port 22
      - 如果 port 22 沒開：NOC ssh-enable + wait
      - 如果 port 22 有開但 SSH 指令還是失敗：也會 NOC ssh-enable + wait
  3) SSH uptime probe：cpe_ssh.py --cmd uptime (成功會輸出短字串並 exit 0)

Controls (manifest/env):
- READY_RETRIES / READY_INTERVAL_MS
- REQUIRE_SSH_READY (default 1)
- AUTO_SSH_ENABLE (default 1) + NOC_PROFILE/PROFILES_FILE + SSH_PASSWORD
- SSH_READY_WAIT_SEC / SSH_TIMEOUT_MIN
- CPE_PING1 / RETRIES / INTERVAL_SEC / STRICT_PING
"""

from __future__ import annotations

import json
import os
import shlex
import socket
import subprocess
import sys
import time
from typing import Any, Dict, Tuple

TOOLS_PATH = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
CPE_SSH_TOOL = os.environ.get("CPE_SSH_TOOL", f"{TOOLS_PATH}/cpe_ssh.py")

if TOOLS_PATH and TOOLS_PATH not in sys.path:
    sys.path.insert(0, TOOLS_PATH)

API_IMPORT_ERROR = ""
try:
    import noc_api_cli as api  # /home/da40/charter/tools/noc_api_cli.py
except Exception as e:
    api = None  # type: ignore
    API_IMPORT_ERROR = f"{type(e).__name__}: {e}"


def q(s: str) -> str:
    return shlex.quote(str(s))


def env_get(name: str, default: str = "") -> str:
    return os.environ.get(name, default)


def log(msg: str) -> None:
    print(msg, flush=True)


def emit(event: str, **k: Any) -> None:
    k["event"] = event
    print(json.dumps(k), flush=True)


def run_local(cmd: str, timeout: float = 20.0) -> Tuple[int, str]:
    t0 = time.time()
    p = subprocess.run(
        cmd,
        shell=True,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
    )
    dt = time.time() - t0
    out = p.stdout or ""
    log(f"[runner] $ {cmd}\n{out.strip()}\n[runner] (rc={p.returncode}, {dt:.2f}s)")
    return p.returncode, out


def is_tcp_open(host: str, port: int = 22, timeout: float = 3.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except Exception:
        return False


def _load_profile(profiles_file: str, profile_name: str) -> Dict[str, Any]:
    j = json.load(open(profiles_file, "r", encoding="utf-8"))
    p = j.get(profile_name) or (j.get("profiles", {}) or {}).get(profile_name)
    if not isinstance(p, dict):
        raise RuntimeError(f"NOC profile not found: {profile_name}")
    return p


def _get_node_id(cpe_info: str) -> str:
    for _ in range(3):
        try:
            out = subprocess.check_output([cpe_info, "--node-id"], text=True, timeout=15).strip()
            if out:
                return out
        except Exception:
            time.sleep(2)
    raise RuntimeError("cpe_info --node-id failed")


def _noc_ssh_enable(node_id: str) -> None:
    """Enable SSH via NOC API using env SSH_PASSWORD. (C00000001 style)"""
    if api is None:
        raise RuntimeError("noc_api_cli not available")

    profiles_file = env_get("PROFILES_FILE", "")
    profile_name = env_get("NOC_PROFILE", "")
    if not profiles_file or not profile_name:
        raise RuntimeError("missing PROFILES_FILE / NOC_PROFILE")

    p = _load_profile(profiles_file, profile_name)

    # C00000001 對齊：profile 主要提供 base/email/password；customer_id 優先取 env，沒有就用 tools/noc_api_cli 的預設。
    base = (
        p.get('base')
        or p.get('NOC_BASE')
        or env_get('BASE', '')
        or getattr(api, 'DEFAULT_BASE', '')
    )

    customer_id = (
        env_get('CUSTOMER_ID', '')
        or env_get('NOC_CUSTOMER_ID', '')
        or p.get('customer_id')
        or p.get('customerId')
        or p.get('NOC_CUSTOMER_ID')
        or getattr(api, 'DEFAULT_CUSTOMER_ID', '')
    )

    email = (
        p.get('email')
        or p.get('NOC_EMAIL')
        or env_get('NOC_EMAIL', '')
        or env_get('EMAIL', '')
    )

    password = (
        p.get('password')
        or p.get('NOC_PASSWORD')
        or env_get('NOC_PASSWORD', '')
        or env_get('PASSWORD', '')
    )

    missing = [k for k,v in {'base': base, 'customer_id': customer_id, 'email': email, 'password': password}.items() if not str(v).strip()]
    if missing:
        raise RuntimeError('profile/env missing: ' + ','.join(missing))

    ssh_pass = env_get("SSH_PASSWORD", "")
    if not ssh_pass:
        raise RuntimeError("missing SSH_PASSWORD")

    token = api.login(
        base,
        email,
        password,
        bearer=bool(p.get("bearer", False)),
        insecure=bool(p.get("insecure", False)),
    )
    location_id = api.get_location_id(
        base,
        customer_id,
        node_id,
        token=token,
        bearer=bool(p.get("bearer", False)),
        insecure=bool(p.get("insecure", False)),
    )
    timeout_min = int(env_get("SSH_TIMEOUT_MIN", "120"))

    emit("ssh_enable_start", node_id=node_id, location_id=location_id)
    api.ssh_enable(
        base,
        customer_id,
        location_id,
        node_id,
        ssh_pass,
        timeout_min,
        token=token,
        bearer=bool(p.get("bearer", False)),
        insecure=bool(p.get("insecure", False)),
    )


def ensure_ssh_ready(host: str, *, force_enable: bool = False) -> bool:
    """Ensure SSH is usable.

    - If port 22 closed => enable via NOC (if allowed) then wait.
    - If force_enable=True => even if port 22 open, still do NOC ssh-enable (used when SSH cmd failed).
    """
    port = int(env_get("SSH_PORT", "22"))

    if (not force_enable) and is_tcp_open(host, port):
        return True

    if env_get("AUTO_SSH_ENABLE", "1").strip().lower() not in ("1", "true", "yes", "y"):
        emit("ssh_not_ready", host=host, port=port, reason="auto_disabled", force=force_enable)
        return False

    if api is None:
        emit(
            "ssh_not_ready",
            host=host,
            port=port,
            reason="noc_api_cli_not_available",
            import_error=API_IMPORT_ERROR,
            force=force_enable,
        )
        return False

    try:
        node_id = _get_node_id(env_get("CPE_INFO_TOOL", f"{TOOLS_PATH}/cpe_info"))
        _noc_ssh_enable(node_id)

        wait_sec = int(env_get("SSH_READY_WAIT_SEC", "30"))
        t0 = time.time()
        while time.time() - t0 < wait_sec:
            if is_tcp_open(host, port):
                emit("ssh_enable_done", ok=True, wait_sec=round(time.time() - t0, 2), force=force_enable)
                return True
            time.sleep(2)
        emit("ssh_enable_done", ok=False, wait_sec=wait_sec, force=force_enable)
        return False
    except Exception as e:
        emit("ssh_enable_error", error=str(e), force=force_enable)
        return False


def ssh_uptime_probe(host: str, timeout: int = 30) -> Tuple[bool, str]:
    """Run cpe_ssh.py --cmd uptime.

    Note: tools/cpe_ssh.py uptime 成功時會輸出純字串 (不是 JSON)，並 exit 0。
    """
    cmd = [sys.executable, CPE_SSH_TOOL, "--host", host, "--cmd", "uptime", "--timeout", str(timeout)]
    try:
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout + 15)
        out = (p.stdout or "").strip()
        ok = (p.returncode == 0) and bool(out)
        sample = out if out else (p.stderr or "").strip()[:200]
        return ok, sample
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


def wait_ms(ms: int) -> None:
    if ms > 0:
        time.sleep(ms / 1000.0)


def step_power_off() -> bool:
    off_cmd = env_get("POWER_OFF_CMD", "").strip()
    pdu_script = env_get("PDU_SCRIPT", "").strip()
    timeout = float(env_get("POWER_CMD_TIMEOUT_SEC", "20"))

    if off_cmd:
        emit("step_start", name="power_off", cmd=off_cmd)
        rc, _ = run_local(off_cmd, timeout=timeout)
    elif pdu_script:
        cmd = f"python3 {q(pdu_script)} off"
        emit("step_start", name="power_off", cmd=cmd)
        rc, _ = run_local(cmd, timeout=timeout)
    else:
        emit("step_skip", name="power_off", reason="no POWER_OFF_CMD or PDU_SCRIPT")
        return True

    ok = (rc == 0)
    emit("step_end", name="power_off", ok=ok)
    return ok


def step_power_on() -> bool:
    on_cmd = env_get("POWER_ON_CMD", "").strip()
    pdu_script = env_get("PDU_SCRIPT", "").strip()
    timeout = float(env_get("POWER_CMD_TIMEOUT_SEC", "20"))

    if on_cmd:
        emit("step_start", name="power_on", cmd=on_cmd)
        rc, _ = run_local(on_cmd, timeout=timeout)
    elif pdu_script:
        cmd = f"python3 {q(pdu_script)} on"
        emit("step_start", name="power_on", cmd=cmd)
        rc, _ = run_local(cmd, timeout=timeout)
    else:
        emit("step_skip", name="power_on", reason="no POWER_ON_CMD or PDU_SCRIPT")
        return True

    ok = (rc == 0)
    emit("step_end", name="power_on", ok=ok)
    return ok


def step_wait_cpe_ready() -> bool:
    """Wait until CPE is ready (cloud connected + SSH usable)."""
    retries = int(env_get("READY_RETRIES", "60"))
    interval_ms = int(env_get("READY_INTERVAL_MS", "1000"))
    cpe_info = env_get("CPE_INFO_TOOL", f"{TOOLS_PATH}/cpe_info")

    # 1) cloud connected
    emit("step_start", name="cpe_ready_cloud", retries=retries, interval_ms=interval_ms, cmd=f"{cpe_info} --cloud")
    ok_cloud = False
    for i in range(1, retries + 1):
        try:
            proc = subprocess.run([cpe_info, "--cloud"], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=30)
            out = proc.stdout or ""
            ok = (proc.returncode == 0) and ("Cloud Status: Connected" in out)
            emit("step_progress", name="cpe_ready_cloud", try_no=i, ok=ok, rc=proc.returncode, sample=out.strip().splitlines()[:3])
            if ok:
                ok_cloud = True
                break
        except subprocess.TimeoutExpired:
            emit("step_progress", name="cpe_ready_cloud", try_no=i, ok=False, timeout=True)
        except Exception as e:
            emit("step_progress", name="cpe_ready_cloud", try_no=i, ok=False, error=str(e))
        wait_ms(interval_ms)

    emit("step_end", name="cpe_ready_cloud", ok=ok_cloud)
    if not ok_cloud:
        return False

    # 2) SSH ready + 3) uptime probe
    require_ssh = int(env_get("REQUIRE_SSH_READY", "1"))
    host = env_get("SSH_HOST_LAN", "192.168.1.1")
    if not require_ssh:
        return True

    emit("step_start", name="cpe_ready_ssh", host=host)

    # First ensure port 22 (enable if closed)
    if not ensure_ssh_ready(host, force_enable=False):
        emit("step_end", name="cpe_ready_ssh", ok=False, reason="port22_not_ready")
        return False

    # uptime probe (if fails, treat as SSH fail => NOC enable once and retry)
    ok_uptime, sample = ssh_uptime_probe(host, timeout=30)
    emit("step_progress", name="cpe_ready_ssh", stage="uptime_probe", ok=ok_uptime, sample=sample)
    if not ok_uptime:
        # SSH command failed although port open => force enable via NOC then retry
        if ensure_ssh_ready(host, force_enable=True):
            ok_uptime2, sample2 = ssh_uptime_probe(host, timeout=30)
            emit("step_progress", name="cpe_ready_ssh", stage="uptime_retry", ok=ok_uptime2, sample=sample2)
            ok_uptime, sample = ok_uptime2, sample2

    emit("step_end", name="cpe_ready_ssh", ok=ok_uptime)
    return ok_uptime


def step_ping_probe() -> bool:
    """Ping from CPE via SSH (cpe_ssh.py --cmd ping). SSH fail => NOC enable then retry."""
    target = env_get("CPE_PING1", "").strip()
    if not target:
        emit("step_skip", name="ping_probe", reason="CPE_PING1 not set")
        return True

    tries = int(env_get("RETRIES", "2"))
    interval = float(env_get("INTERVAL_SEC", "1"))
    host = env_get("SSH_HOST_LAN", "192.168.1.1")
    require_ssh = int(env_get("REQUIRE_SSH_READY", "1"))

    emit("step_start", name="ping_probe", target=target, retries=tries, interval_sec=interval, host=host)

    for i in range(1, tries + 1):
        if require_ssh:
            if not ensure_ssh_ready(host, force_enable=False):
                emit("step_progress", name="ping_probe", try_no=i, ok=False, reason="port22_not_ready")
                time.sleep(interval)
                continue

            # 如果 SSH 指令本身不通（uptime probe fail），就 force enable 一次
            ok_uptime, sample = ssh_uptime_probe(host, timeout=20)
            emit("step_progress", name="ping_probe", try_no=i, stage="uptime_probe", ok=ok_uptime, sample=sample)
            if not ok_uptime:
                if ensure_ssh_ready(host, force_enable=True):
                    ok_uptime2, sample2 = ssh_uptime_probe(host, timeout=20)
                    emit("step_progress", name="ping_probe", try_no=i, stage="uptime_retry", ok=ok_uptime2, sample=sample2)
                    ok_uptime = ok_uptime2
                if not ok_uptime:
                    time.sleep(interval)
                    continue

        # Ping (via cpe_ssh.py)
        cmd = [
            sys.executable,
            CPE_SSH_TOOL,
            "--host",
            host,
            "--cmd",
            "ping",
            "--target",
            target,
            "--count",
            "1",
            "--timeout",
            "30",
        ]
        emit("step_progress", name="ping_probe", try_no=i, stage="ping", ok=None, cmd="cpe_ssh.py ping")

        try:
            p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=45)
            out = (p.stdout or "").strip()
            j = json.loads(out) if out else {}
            ok = (p.returncode == 0) and bool(j.get("ok"))
            emit(
                "step_progress",
                name="ping_probe",
                try_no=i,
                stage="ping_result",
                ok=ok,
                rc=p.returncode,
                loss_pct=j.get("loss_pct"),
                sample={k: j.get(k) for k in ("ok", "loss_pct") if k in j},
            )
            if ok:
                emit("step_end", name="ping_probe", ok=True)
                return True

            # ping 不通時，再做一次 uptime 看 SSH 是否還活著。
            # 如果 uptime 也失敗 => 視為 SSH fail => force enable 一次 (下一輪 try 會用到)
            ok_uptime, sample = ssh_uptime_probe(host, timeout=20)
            if not ok_uptime:
                emit("step_progress", name="ping_probe", try_no=i, stage="post_ping_uptime_fail", ok=False, sample=sample)
                ensure_ssh_ready(host, force_enable=True)

        except Exception as e:
            emit("step_progress", name="ping_probe", try_no=i, ok=False, error=str(e))

        time.sleep(interval)

    emit("step_end", name="ping_probe", ok=False)
    return False


def run() -> int:
    # Delays: combine modern + legacy
    wait_off_ms = int(env_get("WAIT_AFTER_POWER_OFF_MS", "0"))
    power_off_sec = int(env_get("POWER_OFF_SEC", "0"))  # legacy: duration while power is cut
    wait_on_ms = int(env_get("WAIT_AFTER_POWER_ON_MS", "0"))
    settle_sec = int(env_get("SETTLE_SEC", "0"))  # legacy: post-ON wait

    log("[runner] Step 1 — POWER OFF")
    if not step_power_off():
        return 1

    if wait_off_ms > 0:
        log(f"[runner] wait after OFF: {wait_off_ms}ms")
        wait_ms(wait_off_ms)

    if power_off_sec > 0:
        log(f"[runner] power cut duration: {power_off_sec}s")
        time.sleep(power_off_sec)

    log("[runner] Step 2 — POWER ON")
    if not step_power_on():
        return 1

    if settle_sec > 0:
        log(f"[runner] settle wait: {settle_sec}s")
        time.sleep(settle_sec)
    elif wait_on_ms > 0:
        log(f"[runner] wait after ON: {wait_on_ms}ms")
        wait_ms(wait_on_ms)

    log("[runner] Step 3 — Wait CPE ready")
    if not step_wait_cpe_ready():
        return 1

    log("[runner] Step 4 — (optional) ping probe")
    if not step_ping_probe():
        strict = int(env_get("STRICT_PING", "0"))
        if strict:
            return 1

    return 0


if __name__ == "__main__":
    sys.exit(run())
