#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Shim main that delegates to cycle_wrapper.run so GUI triggers go through the wrapper.
"""
def run():
    from cycle_wrapper import run as wrapper_run
    return wrapper_run()

if __name__ == "__main__":
    import sys
    sys.exit(run())
