# A2435638_Cycle_power_on_off_test

## 1) 目的 / 覆蓋範圍
- 穩定性/壓力：反覆 reboot/power cycle 並確認系統恢復。

## 2) 前置條件 / 環境
- 會觸發 reboot；需定義 ready 判定與 retry/backoff。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`stability`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'10'
- CYCLE_INTERVAL：'60'

## 5) PASS/FAIL 判定
- PASS：每次 reboot 後都能恢復到 ready 狀態。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# A2435638_Cycle_power_on_off_test (WAN-arch aligned)

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`stability`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'10'
- CYCLE_INTERVAL：'60'

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# A2435638_Cycle_power_on_off_test (WAN-arch aligned)

**Entry:** `cycle_wrapper.py:run`

This package aligns the *power cycle* script with the `C15807060_WAN_IPv4_Connectivity` architecture:

- `manifest.yaml`: centralizes all defaults (wrapper, CPE serial, timings, power control)
- `cycle_wrapper.py`: uniform loop controller with `CYCLES / CYCLE_INTERVAL / STOP_ON_FAIL / ORIGINAL_ENTRY`
- `main_impl.py`: env-driven steps for OFF → wait → ON → wait → READY → optional ping, with JSON step events
- `main.py`: shim that always executes the wrapper (so GUI calls to `main.py` still loop)

## How to use
1. Fill in `POWER_OFF_CMD` and `POWER_ON_CMD` in `manifest.yaml` (e.g. curl to PDU, GPIO script).
2. Zip and upload. The GUI will run `main.py`, which delegates to the wrapper.
3. Observe `[runner]` logs and JSON events (`runner_start`, `cycle_start`, `cycle_end`, `wrapper_end`).

## Notes

- This script relies on `/home/da40/charter/tools/noc_api_cli.py` for NOC SSH enablement.
  `noc_api_cli.py` imports `requests`, so `requests` must be present in the script venv.
  (This is why `requirements.txt` includes `requests>=2.31.0`.)
- READY check does **NOT** use serial console in customer env. It gates on:
  1) `cpe_info --cloud` == Connected
  2) SSH ready (port 22 scan; on failure auto NOC `ssh-enable`)
  3) SSH uptime probe via `cpe_ssh.py --cmd uptime`
- SSH failures will trigger NOC ssh-enable automatically (same idea as C00000001).
- Optional ping probe can be made strict via `STRICT_PING=1` to gate pass/fail.
- Env is restored between cycles to avoid leakage; summary is emitted at the end.
```

```
