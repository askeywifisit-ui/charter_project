#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os, json, time, re, socket, subprocess, shlex, datetime

def _g(name, default=None, as_int=False):
    v = os.environ.get(name)
    if v is None:
        return int(default) if (as_int and default is not None) else default
    if as_int:
        try: return int(v)
        except Exception: return int(default) if default is not None else 0
    return v

def _get_ssh_password():
    v = os.environ.get("SSH_PASSWORD")
    if v and str(v).strip().lower() not in ("", "none", "null"):
        return v
    for k in ("CPE_SSH_PASSWORD", "CPE_PASSWORD"):
        vv = os.environ.get(k)
        if vv and str(vv).strip().lower() not in ("", "none", "null"):
            return vv
    return ""

def _emit(event, **kw):
    d = {"event": event}; d.update(kw); print(json.dumps(d))

def _run_cmd(cmd, timeout=60):
    try:
        p = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return p.returncode, (p.stdout or ""), (p.stderr or "")
    except Exception as e:
        return 1, "", str(e)

def _ssh_port_scan(host, port, overall_timeout, per_try_timeout, interval):
    start = time.time(); _emit("ssh-scan-start", host=host, port=port, timeout_sec=overall_timeout, per_try_timeout_sec=per_try_timeout, interval_sec=interval)
    while True:
        remaining = overall_timeout - (time.time() - start)
        if remaining <= 0: _emit("ssh-scan-timeout", host=host, port=port); return False
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(min(per_try_timeout, remaining)); s.connect((host, port))
                _emit("ssh-scan-ok", host=host, port=port); return True
        except Exception:
            time.sleep(min(interval, max(0.05, remaining))); continue

def _parse_linux_uptime_seconds(text):
    s = text.strip().replace("\n"," ")
    m = re.search(r"\bup\s+(\d+)\s+days?,\s*(\d+):(\d+)\b", s)
    if m: return int(m.group(1))*86400 + int(m.group(2))*3600 + int(m.group(3))*60
    m = re.search(r"\bup\s*(\d+):(\d+)\b", s)
    if m: return int(m.group(1))*3600 + int(m.group(2))*60
    m = re.search(r"\bup\s*(\d+)\s*min\b", s)
    if m: return int(m.group(1))*60
    m = re.search(r"\b(\d+)\s*min\b", s)
    if m: return int(m.group(1))*60
    m = re.search(r"\b(?:up\s*)?(\d+)\s*sec\b", s)
    if m: return int(m.group(1))
    return None

def _profile_bootstrap():
    prof = (_g("NOC_PROFILE","") or "").strip()
    path = (_g("PROFILES_FILE","") or "").strip()
    if not prof or not path:
        return False
    try:
        import json as _json
        with open(path, "r", encoding="utf-8") as f:
            data = _json.load(f)
        p = data.get(prof) or {}
        applied = {}
        for k_env, k_json in [
            ("NOC_BASE","base"), ("NOC_EMAIL","email"), ("NOC_PASSWORD","password"),
            ("CUSTOMER_ID","customer_id"), ("LOCATION_ID","location_id"),
            ("BEARER","bearer"), ("INSECURE","insecure")
        ]:
            if k_json in p and (not os.environ.get(k_env) or str(os.environ.get(k_env)).strip()==""):
                os.environ[k_env] = str(p[k_json]); applied[k_env]=True
        _emit("noc-profile-loaded", profile=prof, applied=sorted(list(applied.keys())))
        return True
    except FileNotFoundError:
        _emit("noc-profile-missing-file", profile=prof, path=path); return False
    except Exception as e:
        _emit("noc-profile-load-error", profile=prof, path=path, error=str(e)); return False

def _pre_scan_enable_ssh_via_noc():
    if _g("ENABLE_SSH_PRE_SCAN",1,as_int=True) != 1: return
    try:
        import main_impl_orig as o
        base=_g("NOC_BASE","https://piranha-int.tau.dev-charter.net")
        email=_g("NOC_EMAIL",""); password=_g("NOC_PASSWORD","")
        bearer=str(_g("BEARER","0")).lower() in ("1","true","yes")
        insecure=str(_g("INSECURE","0")).lower() in ("1","true","yes")
        customer_id=_g("CUSTOMER_ID","")
        metrics_tool=_g("METRICS_TOOL","/home/da40/charter/tools/cpe_metrics_agent_serial.py")
        dev=_g("CPE_DEV","/dev/ttyUSB0"); baud=_g("CPE_BAUD",115200,True)
        cpe_user=_g("CPE_USER","root"); cpe_password=_g("CPE_PASSWORD","")
        if str(cpe_password).strip().lower() in ("none","null","nil"): cpe_password=""
        if not cpe_password:
            cpe_info_tool=_g("CPE_INFO_TOOL","/home/da40/charter/tools/cpe_info")
            rc,out,err=_run_cmd(f"{shlex.quote(cpe_info_tool)} --password", timeout=15)
            if rc==0 and out.strip():
                for line in out.strip().splitlines():
                    line=line.strip()
                    if line: cpe_password = line; break
        token=o._login(base, email, password, bearer, insecure)
        node_id=o._node_id(metrics_tool, dev, baud, cpe_user, cpe_password)
        location_id=_g("LOCATION_ID","") or o._location_id(base, customer_id, node_id, token, bearer, insecure)
        ssh_pass = _get_ssh_password()
        ssh_timeout_min = _g("SSH_TIMEOUT_MIN",120,as_int=True)
        o._ssh_enable(base, customer_id, location_id, node_id, ssh_pass, ssh_timeout_min, token, bearer, insecure)
        _emit("ssh-enable-pre-scan-ok")
        wait_after=_g("WAIT_AFTER_SSH_ENABLE_SEC",60,as_int=True)
        if wait_after>0: _emit("ssh-enable-wait", seconds=wait_after); time.sleep(wait_after)
    except Exception as e:
        _emit("ssh-enable-pre-scan-failed", error=str(e))

def _get_cpe_uptime_seconds():
    host=_g("CPE_HOST","192.168.1.1"); port=_g("CPE_SSH_PORT",22,True)
    scan_to=_g("SSH_SCAN_TIMEOUT_SEC",60,True); scan_iv=_g("SSH_SCAN_INTERVAL_SEC",2,True)
    scan_try=_g("SSH_SCAN_PER_TRY_TIMEOUT_SEC",2,True)
    _pre_scan_enable_ssh_via_noc()
    if not _ssh_port_scan(host, port, scan_to, scan_try, scan_iv): return None
    py=_g("PYTHON_BIN","python3"); tool=_g("CPE_SSH_TOOL","/home/da40/charter/tools/cpe_ssh.py")
    cmd=_g("CPE_UPTIME_CMD","uptime"); tmo=_g("CPE_SSH_TIMEOUT_SEC",30,True)
    user = (_g("CPE_SSH_USER") or _g("CPE_USER","")) or "operator"
    pwd  = _get_ssh_password()
    base=f"{shlex.quote(py)} {shlex.quote(tool)} --host {shlex.quote(host)} --cmd {shlex.quote(cmd)}"
    if _g("CPE_SSH_TOOL_SUPPORTS_PORT",0,True)==1: base+=f" --port {port}"
    if user: base+=f" --user {shlex.quote(user)}"
    if pwd and str(pwd).lower()!="none": base+=f" --password {shlex.quote(pwd)}"
    rc,out,err=_run_cmd(base, timeout=tmo); measured_at=int(time.time())
    if rc!=0:
        base_retry = base + " --no-ssh-quiet"
        rc,out,err = _run_cmd(base_retry, timeout=tmo)
        measured_at=int(time.time())
    if rc!=0: _emit("cpe-ssh-uptime-failed", rc=rc, err=(err or "").strip()); return None
    sec=_parse_linux_uptime_seconds(out)
    if sec is None:
        _emit("uptime-parse-failed", sample=(out or "").strip()[:120])
        base2=f"{shlex.quote(py)} {shlex.quote(tool)} --host {shlex.quote(host)} --cmd {shlex.quote('cat /proc/uptime')}"
        if _g("CPE_SSH_TOOL_SUPPORTS_PORT",0,True)==1: base2+=f" --port {port}"
        if user: base2+=f" --user {shlex.quote(user)}"
        if pwd and str(pwd).lower()!="none": base2+=f" --password {shlex.quote(pwd)}"
        rc2,out2,err2=_run_cmd(base2, timeout=tmo); measured_at=int(time.time())
        if rc2==0 and out2.strip():
            try: sec=int(float(out2.strip().split()[0]))
            except Exception: sec=None
        else:
            _emit("uptime-fallback-failed", rc=rc2, err=(err2 or "").strip()); return None
    return {"sec": sec, "t": measured_at}

def _parse_iso_to_epoch(iso_str):
    try:
        s=iso_str.strip().replace("Z","+00:00"); dt=datetime.datetime.fromisoformat(s)
        if dt.tzinfo is None: dt = dt.replace(tzinfo=datetime.timezone.utc)
        return int(dt.timestamp())
    except Exception:
        return None

def _get_cloud_uptime_seconds(ref_now=None):
    try:
        import main_impl_orig as o
        base=_g("NOC_BASE","https://piranha-int.tau.dev-charter.net")
        email=_g("NOC_EMAIL",""); password=_g("NOC_PASSWORD","")
        bearer=str(_g("BEARER","0")).lower() in ("1","true","yes")
        insecure=str(_g("INSECURE","0")).lower() in ("1","true","yes")
        customer_id=_g("CUSTOMER_ID","")
        metrics_tool=_g("METRICS_TOOL","/home/da40/charter/tools/cpe_metrics_agent_serial.py")
        dev=_g("CPE_DEV","/dev/ttyUSB0"); baud=_g("CPE_BAUD",115200,True)
        cpe_user=_g("CPE_USER","root"); cpe_password=_g("CPE_PASSWORD","")
        if str(cpe_password).strip().lower() in ("none","null","nil"): cpe_password=""
        if not cpe_password:
            cpe_info_tool=_g("CPE_INFO_TOOL","/home/da40/charter/tools/cpe_info")
            rc,out,err=_run_cmd(f"{shlex.quote(cpe_info_tool)} --password", timeout=15)
            if rc==0 and out.strip():
                for line in out.strip().splitlines():
                    line=line.strip()
                    if line: cpe_password = line; break
        token=o._login(base, email, password, bearer, insecure)
        node_id=o._node_id(metrics_tool, dev, baud, cpe_user, cpe_password)
        location_id=_g("LOCATION_ID","") or o._location_id(base, customer_id, node_id, token, bearer, insecure)
        py=_g("PYTHON_BIN","python3"); cli=_g("NOC_API_CLI","/home/da40/charter/tools/noc_api_cli.py")
        tmo=_g("NOC_API_CLI_TIMEOUT_SEC",30,True)
        cmd=f'{shlex.quote(py)} {shlex.quote(cli)} --token {shlex.quote(token)} node-status --node-id {shlex.quote(node_id)} --location-id {shlex.quote(location_id)}'
        rc,out,err=_run_cmd(cmd, timeout=tmo)
        measured_at=int(time.time()) if ref_now is None else int(ref_now)
        if rc!=0 or not out.strip(): _emit("cloud-uptime-fetch-failed", rc=rc, err=(err or "").strip()); return None
        bootAt=None; connAt=None
        try:
            data=json.loads(out); bootAt=data.get("bootAt"); connAt=data.get("connectionStateChangeAt")
        except Exception:
            m1=re.search(r'"bootAt"\s*:\s*"([^"]+)"', out); m2=re.search(r'"connectionStateChangeAt"\s*:\s*"([^"]+)"', out)
            bootAt=m1.group(1) if m1 else None; connAt=m2.group(1) if m2 else None
        mode=(_g("CLOUD_UPTIME_MODE","bootAt") or "bootAt").lower()
        if mode.startswith("conn"):
            ref_epoch=_parse_iso_to_epoch(connAt) if connAt else None; ref_field="connectionStateChangeAt"
        else:
            ref_epoch=_parse_iso_to_epoch(bootAt) if bootAt else None; ref_field="bootAt"
        if ref_epoch is None: _emit("cloud-uptime-parse-failed", mode=mode, bootAt=bootAt, connectionStateChangeAt=connAt); return None
        static_lag=_g("CLOUD_STATIC_LAG_SEC", 0, True)
        cloud_uptime=max(0, measured_at - ref_epoch - static_lag)
        _emit("cloud-uptime-sec", mode=mode, ref_field=ref_field, value=cloud_uptime, static_lag=static_lag)
        return {"sec": cloud_uptime, "t": measured_at}
    except Exception as e:
        _emit("cloud-uptime-exception", error=str(e)); return None

def _detect_run_dir():
    try:
        return os.getcwd()
    except Exception:
        return "/tmp"

def _fail_pull_logs(reason="unknown"):
    if _g("FAIL_PULL_ENABLED",1,True) != 1:
        return
    wait_pre = _g("FAIL_WAIT_BEFORE_PULL_SEC",60,True)
    if wait_pre>0:
        _emit("fail-pull-wait", seconds=wait_pre, reason=reason); time.sleep(wait_pre)

    run_dir = _detect_run_dir()
    out_dir = os.path.join(run_dir, "cpe_log")
    try: os.makedirs(out_dir, exist_ok=True)
    except Exception: pass

    host=_g("CPE_HOST","192.168.1.1"); port=_g("CPE_SSH_PORT",22,True)
    if not _ssh_port_scan(host, port, _g("FAIL_PULL_SSH_SCAN_TIMEOUT_SEC",60,True), _g("SSH_SCAN_PER_TRY_TIMEOUT_SEC",2,True), _g("SSH_SCAN_INTERVAL_SEC",2,True)):
        _emit("fail-pull-ssh-scan-timeout"); return

    py=_g("PYTHON_BIN","python3")
    tool=_g("CPE_SSH_TOOL","/home/da40/charter/tools/cpe_ssh.py")
    user=(_g("CPE_SSH_USER") or _g("CPE_USER","")) or "operator"
    pwd=_get_ssh_password()
    latest_dir = _g("FAIL_PULL_LATEST_DIR","/tmp/logpull")
    pattern = _g("FAIL_PULL_PATTERN","*.tar.gz")
    tmo = _g("FAIL_PULL_TIMEOUT_SEC",300,True)

    argv = [
        shlex.quote(py), shlex.quote(tool),
        "--host", shlex.quote(host),
        "--user", shlex.quote(user),
        "--cmd", "pull-log",
        "--dest", shlex.quote(out_dir),
        "--latest-from-dir", shlex.quote(latest_dir),
        "--pattern", shlex.quote(pattern),
        "--logpull-timeout", str(int(tmo)),
        "--rename-with-node-id",
        "--no-ssh-quiet",
        "--pre-logpull"
    ]
    if _g("CPE_SSH_TOOL_SUPPORTS_PORT",0,True)==1:
        argv += ["--port", str(int(port))]
    if pwd and str(pwd).lower()!="none":
        argv += ["--password", shlex.quote(pwd)]
    if _g("FAIL_PULL_DELETE_REMOTE",0,True)==1:
        argv.append("--delete-remote")

    cmd = " ".join(argv)
    rc,out,err = _run_cmd(cmd, timeout=int(tmo)+30)
    _emit("fail-pull-exec", rc=rc, ok=bool(rc==0), out=(out or "").strip()[:1000], err=(err or "").strip()[:400])

    if _g("FAIL_PULL_CLOUD_ENABLED",1,True) == 1:
        snap = _get_cloud_uptime_seconds(ref_now=int(time.time()))
        if snap is None:
            _emit("fail-pull-cloud-failed")
        else:
            _emit("fail-pull-cloud-ok", cloud_uptime=snap["sec"])

    post_delay=_g("FAIL_AFTER_PULL_DELAY_SEC",5,True)
    if post_delay>0: _emit("fail-pull-post-delay", seconds=post_delay); time.sleep(post_delay)

def run():
    import main_impl_orig as orig
    try:
        rc=int(orig.run())
    except SystemExit as e:
        rc=int(e.code) if e.code is not None else 1
    except Exception as e:
        _emit("orig-exception", error=str(e))
        _fail_pull_logs("orig-exception")
        return 1
    if rc!=0:
        _fail_pull_logs("original-nonzero")
        return rc

    _profile_bootstrap()

    local = _get_cpe_uptime_seconds() if _g("ENABLE_UPTIME_LOCAL_CHECK",1,True)==1 else None
    if local is None and _g("ENABLE_UPTIME_LOCAL_CHECK",1,True)==1:
        _emit("local-uptime-missing")
        _fail_pull_logs("local-uptime-missing")
        return 1
    if local is not None:
        _emit("local-uptime-sec", value=local["sec"], measured_at=local["t"])

    if _g("ENABLE_UPTIME_COMPARE",1,True)==1:
        cloud=_get_cloud_uptime_seconds(ref_now=local["t"] if local else None)
        if cloud is None:
            _emit("cloud-uptime-missing")
            _fail_pull_logs("cloud-uptime-missing")
            return 1
        local_at_cloud = local["sec"] + (cloud["t"] - local["t"]) if local else None
        tol=_g("UPTIME_TOLERANCE_SEC",120,True)
        diff = abs(local_at_cloud - cloud["sec"]) if local_at_cloud is not None else None
        ok = (diff is not None and diff <= tol)
        _emit("uptime-compare", local=local["sec"], local_at_cloud=local_at_cloud,
              cloud=cloud["sec"], dt=cloud["t"]-local["t"], diff=diff, tolerance=tol, ok=bool(ok))
        if not ok:
            _fail_pull_logs("uptime-compare-failed")
            return 1

    return 0

if __name__ == "__main__":
    import sys; sys.exit(run())
