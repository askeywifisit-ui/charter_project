#!/usr/bin/env python3
"""
Generic cycle wrapper for C001_SSH_Enable.

讀 env：
  - CYCLES
  - CYCLE_INTERVAL
  - STOP_ON_FAIL
  - ORIGINAL_ENTRY  (e.g. "main_impl_orig.py:run")

然後每個 cycle 呼叫一次 entry function。
"""

import os
import time
import importlib
import sys
import json


def _parse_bool(val, default=False):
    if val is None:
        return default
    s = str(val).strip().lower()
    return s in ("1", "true", "yes", "y")


def _resolve_entry(entry: str):
    if not entry:
        raise ValueError("Empty ORIGINAL_ENTRY")
    if ":" not in entry:
        raise ValueError(f"Bad ORIGINAL_ENTRY format: {entry!r}")
    mod_name, func_name = entry.split(":", 1)
    if mod_name.endswith(".py"):
        mod_name = mod_name[:-3]
    mod = importlib.import_module(mod_name)
    func = getattr(mod, func_name)
    return func


# ================================================================
# Precondition: first-cycle CPE readiness check + optional PDU reset
# - check `cpe_info -status` (Internet+Cloud) retry N times
# - if still not ready => `python3 pdu_outlet1.py reset` => wait => re-check
# ================================================================
import subprocess  # safe even if already imported
import shlex       # safe even if already imported


def _cpe_ready_run_cmd(cmd, timeout=30):
    # Run command and return (rc, combined_output).
    try:
        cp = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=timeout,
        )
        return cp.returncode, (cp.stdout or "")
    except Exception as e:
        return 99, f"ERROR: cmd failed: {cmd!r} ({e})"


def _cpe_ready_parse_status(output: str):
    internet = None
    cloud = None
    for line in (output or "").splitlines():
        if ":" not in line:
            continue
        k, v = line.split(":", 1)
        k = k.strip().lower()
        v = v.strip()
        if k == "internet status":
            internet = v
        elif k == "cloud status":
            cloud = v
    return internet, cloud


def _cpe_ready_is_connected(val: str) -> bool:
    return val is not None and val.strip().lower() == "connected"


def _ensure_cpe_ready_first_cycle() -> bool:
    # Return True when CPE is ready (Internet Connected and, optionally, Cloud Connected).
    if not _parse_bool(os.environ.get("CPE_READY_CHECK", "1"), default=True):
        return True

    status_cmd = os.environ.get("CPE_INFO_STATUS_CMD", "cpe_info -status")
    retries = int(os.environ.get("CPE_READY_MAX_RETRIES", "5"))
    interval = float(os.environ.get("CPE_READY_RETRY_INTERVAL_SEC", "3"))
    require_cloud = _parse_bool(os.environ.get("CPE_READY_REQUIRE_CLOUD", "1"), default=True)

    def _probe(tag: str) -> bool:
        for attempt in range(1, retries + 1):
            rc, out = _cpe_ready_run_cmd(shlex.split(status_cmd), timeout=20)
            internet, cloud = _cpe_ready_parse_status(out)
            ready = _cpe_ready_is_connected(internet) and ((not require_cloud) or _cpe_ready_is_connected(cloud))
            print(json.dumps({
                "event": tag,
                "attempt": attempt,
                "cmd_rc": rc,
                "internet": internet,
                "cloud": cloud,
                "ready": ready,
            }, ensure_ascii=False), flush=True)
            if ready:
                return True
            if attempt < retries and interval > 0:
                time.sleep(interval)
        return False

    if _probe("cpe_ready_check"):
        return True

    if _parse_bool(os.environ.get("PDU_RESET_ON_NOT_READY", "1"), default=True):
        pdu_script = os.environ.get("PDU_RESET_SCRIPT", "/home/da40/charter/tools/pdu_outlet1.py")
        pdu_action = os.environ.get("PDU_RESET_ACTION", "reset")
        pdu_timeout = int(os.environ.get("PDU_RESET_TIMEOUT_SEC", "600"))
        pdu_wait = int(os.environ.get("PDU_RESET_WAIT_SEC", "120"))
        pybin = os.environ.get("PYTHON", "python3")

        print(json.dumps({
            "event": "pdu_reset_start",
            "script": pdu_script,
            "action": pdu_action,
        }, ensure_ascii=False), flush=True)

        prc, pout = _cpe_ready_run_cmd([pybin, pdu_script, pdu_action], timeout=pdu_timeout)
        print(json.dumps({
            "event": "pdu_reset_end",
            "rc": prc,
            "output_tail": (pout or "")[-2000:],
        }, ensure_ascii=False), flush=True)

        if pdu_wait > 0:
            print(json.dumps({"event": "pdu_reset_wait", "secs": pdu_wait}, ensure_ascii=False), flush=True)
            time.sleep(pdu_wait)

        if _probe("cpe_ready_recheck_after_pdu"):
            return True

    return False

def run() -> int:
    cycles = int(os.environ.get("CYCLES", "1"))
    interval = int(os.environ.get("CYCLE_INTERVAL", "30"))
    stop_on_fail = _parse_bool(os.environ.get("STOP_ON_FAIL", "1"), default=True)
    entry = os.environ.get("ORIGINAL_ENTRY", "main_impl_orig.py:run")

    try:
        func = _resolve_entry(entry)
    except Exception as e:
        print(json.dumps({"event": "entry_resolve_error", "entry": entry, "error": str(e)}))
        return 1

    overall_rc = 0
    for i in range(cycles):
        # Precondition: CPE ready check only on first cycle
        if i == 0:
            if not _ensure_cpe_ready_first_cycle():
                print(json.dumps({'event': 'precondition_fail', 'cycle': 1, 'rc': 2, 'reason': 'cpe_not_ready'}, ensure_ascii=False), flush=True)
                return 2

        print(json.dumps({"event": "cycle_start", "cycle": i + 1, "total": cycles}))
        try:
            rc = func()
        except SystemExit as se:
            rc = int(se.code or 0)
        except Exception as e:
            print(json.dumps({"event": "cycle_exception", "cycle": i + 1, "error": str(e)}))
            rc = 1

        try:
            rc = int(rc)
        except Exception:
            rc = 1

        print(json.dumps({"event": "cycle_end", "cycle": i + 1, "rc": rc}))
        if rc != 0:
            overall_rc = rc
            if stop_on_fail:
                break

        if i < cycles - 1 and interval > 0:
            time.sleep(interval)

    print(json.dumps({"event": "all_cycles_done", "rc": overall_rc}))
    return overall_rc


if __name__ == "__main__":
    sys.exit(run())

