#!/usr/bin/env python3
import cycle_wrapper

def run():
    return cycle_wrapper.run()

def main():
    return run()

if __name__ == '__main__':
    raise SystemExit(run())
