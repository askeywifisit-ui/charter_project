# C15807844_UPnP_State_Changed_From_Disabled_To_Enabled

## 1) 目的 / 覆蓋範圍
- 驗證 UPnP enable/disable 狀態切換與 SSDP/IGD 行為。

## 2) 前置條件 / 環境
- LAN client 需可發 SSDP M-SEARCH（常用介面 `eno2`）。
- 若流程可能觸發 reboot：建議 serial mute + retry。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'70'
- TOOLS_PATH：/home/da40/charter/tools
- SSH_HOST_LAN：192.168.1.1
- PING_IFACE：eno2
- REBOOT_MUTE_SECS：60
- REBOOT_MUTE_WITH_LOCK：1
- ENABLE_NOC_API_TESTS：1
- ENABLE_SPEEDTEST：1
- ENABLE_WIFI_TEST：0
- ENABLE_LTE_TEST：0
- PROFILES_FILE：/home/da40/charter/.secrets/noc_profiles.json
- NOC_PROFILE：SPECTRUM_INT
- CUSTOMER_ID：682d4e5179b80027cd6fb27e

## 5) PASS/FAIL 判定
- ON：SSDP/IGD discovery present=true。
- OFF：SSDP M-SEARCH present=false。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807844_UPnP_State_Changed_From_Disabled_To_Enabled

## 1) 目的 / 覆蓋範圍
- 驗證 UPnP 狀態切換（Enable/Disable）與 IGD/SSDP 行為。
- 在可能觸發 reboot 的情境下，加入 serial mute + retry，提升穩定性。

## 2) 前置條件 / 環境
- LAN client 端需可進行 SSDP M-SEARCH（常用介面 `eno2`）。
- 若腳本包含 reboot：建議 `REBOOT_MUTE_SECS=120` 且保留 lock（`REBOOT_MUTE_WITH_LOCK=1`）。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'70'
- TOOLS_PATH：/home/da40/charter/tools
- SSH_HOST_LAN：192.168.1.1
- WAN_*_REQUIRED：1
- LAN_*_REQUIRED：1
- REBOOT_MUTE_SECS：60
- REBOOT_MUTE_WITH_LOCK：1

## 5) PASS/FAIL 判定
- ON：能找到 IGD / SSDP M-SEARCH `present=true`。
- OFF：SSDP M-SEARCH `present=false`。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807844_Verify_UPnP_State_Changed_From_Disabled_To_Enabled (v5)

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'70'
- TOOLS_PATH：/home/da40/charter/tools

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807844_Verify_UPnP_State_Changed_From_Disabled_To_Enabled (v5)

This script is derived from **C24532530_UPNP_enable_disable_longrun** structure.

## What it does
Precondition:
1. Resolve console password (cpe_info --password) if CPE_PASSWORD is null.
2. Read node_id via serial metrics tool.
3. NOC login -> location_id.
4. Enable SSH via NOC API (best-effort).

Main:
- If current UPNP is not Disabled, it will disable first (may reboot CPE).
- Then it enables UPNP (may reboot CPE).
- Verify via:
  - NOC API upnp_status (enabled/mode)
  - cpe_ssh.py upnp-ps (pass must be true)
  - cpe_ssh.py upnp-log (pass must be true)

Exit:
- 0 on PASS, 1 on FAIL.

```

```
```
