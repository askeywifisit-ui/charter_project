#!/usr/bin/env python3
"""
PBR-free wrapper
- Loads and runs main_impl_orig.run() with proper rc mapping
- No policy-based routing setup/teardown
"""
import os, importlib.util, runpy, traceback

def _normalize_rc(mod, rc):
    # If rc is an int, respect it; otherwise use LOOP_FAIL to decide
    if isinstance(rc, int):
        return rc
    lf = False
    try:
        lf = bool(getattr(mod, "LOOP_FAIL", False))
    except Exception:
        pass
    try:
        return int(rc)
    except Exception:
        return 1 if lf else 0

def run():
    base = os.path.dirname(__file__)
    orig = os.path.join(base, "main_impl_orig.py")

    # Try to import as module and call run()
    try:
        spec = importlib.util.spec_from_file_location("main_impl_orig", orig)
        mod = importlib.util.module_from_spec(spec)  # type: ignore
        assert spec and spec.loader, "Cannot load spec for main_impl_orig.py"
        spec.loader.exec_module(mod)  # type: ignore
        if hasattr(mod, "run") and callable(getattr(mod, "run")):
            try:
                rc = getattr(mod, "run")()
            except SystemExit as e:
                try:
                    rc = int(e.code)  # type: ignore
                except Exception:
                    rc = 0
            return _normalize_rc(mod, rc)
    except SystemExit as e:
        try:
            return int(e.code)
        except Exception:
            return 0
    except Exception:
        # Fallback to running as a script
        try:
            runpy.run_path(orig, run_name="__main__")
            # No way to see LOOP_FAIL here; assume success
            return 0
        except SystemExit as e:
            try:
                return int(e.code)
            except Exception:
                return 0
        except Exception:
            traceback.print_exc()
            return 1

if __name__ == "__main__":
    import sys
    sys.exit(run())
