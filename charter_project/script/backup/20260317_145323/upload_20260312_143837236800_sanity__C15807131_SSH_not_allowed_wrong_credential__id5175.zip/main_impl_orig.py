#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
C15807128 - SSH should be allowed to local IP from LAN Client

Preconditions (script-enforced):
  1) NOC login (token)
  2) serial metrics -> node_id (with retry)
  3) NOC API -> location_id
  4) kvConfigs PATCH -> enable SSHM + set sshAuthPasswd

Validations:
  - SSH to LAN IPv4: ALLOW
  - SSH to LAN Global IPv6: ALLOW (if present)
  - SSH to LAN Link-local IPv6: NOT allowed (if present)
"""

import os
import sys
import json
import time
import re
import subprocess
import shlex
from typing import Dict, Optional, Tuple

TOOLS_PATH = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
if TOOLS_PATH and TOOLS_PATH not in sys.path:
    sys.path.insert(0, TOOLS_PATH)

try:
    import noc_api_cli as api  # type: ignore
except Exception as e:
    api = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "noc_api_cli", "error": str(e)}))

try:
    import cpe_ssh  # type: ignore
except Exception as e:
    cpe_ssh = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "cpe_ssh", "error": str(e)}))



# ------------------------------
# Quiet stdout: marker wrapper
# ------------------------------
MARK_BEGIN = "__RG_BEGIN__"
MARK_END   = "__RG_END__"

def _wrap_cmd(cmd: str) -> str:
    """Wrap remote cmd with markers so we can extract output even if SSH server prints banners."""
    wrapped = f"echo {MARK_BEGIN}; {cmd}; echo {MARK_END}"
    return "sh -lc " + shlex.quote(wrapped)

def _extract_marked(stdout: str) -> str:
    if not stdout:
        return ""
    b = stdout.find(MARK_BEGIN)
    e = stdout.find(MARK_END)
    if b == -1 or e == -1 or e < b:
        return stdout.strip()
    b2 = b + len(MARK_BEGIN)
    return stdout[b2:e].strip("\n\r ")

def _ssh_exec_marked(host: str, user: str, pw: str, cmd: str, timeout: float, login_shell: bool = True):
    """Return (rc, extracted_stdout, raw_stdout, stderr, sec)."""
    if cpe_ssh is None:
        raise RuntimeError("cpe_ssh not available")
    wrapped = _wrap_cmd(cmd)
    rc, out, err, sec = cpe_ssh.ssh_exec(host, user, pw, wrapped, timeout=timeout, login_shell=login_shell)
    return rc, _extract_marked(out), out, err, sec
_CACHE: Dict[str, object] = {}


def _getenv(name: str, default: str = "") -> str:
    v = os.environ.get(name, default)
    return default if v is None else str(v)


def _bool_env(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "on", "y")


def _run(cmd, timeout: float = 60.0) -> Tuple[int, str, str]:
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout)
    return p.returncode, p.stdout or "", p.stderr or ""


def _load_noc_profile(profile_name: str) -> Optional[Dict[str, str]]:
    path = (
        os.environ.get("NOC_PROFILES_PATH")
        or os.environ.get("PROFILES_FILE")
        or os.path.expanduser("~/.secrets/noc_profiles.json")
    )
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print(json.dumps({"event": "noc-profile-load-error", "profile": profile_name, "path": path, "error": str(e)}))
        return None

    prof = data.get(profile_name) or data.get(profile_name.upper())
    if not prof:
        print(json.dumps({"event": "noc-profile-load-error", "profile": profile_name, "path": path, "error": "profile not found"}))
        return None

    return {"base": prof.get("base"), "email": prof.get("email"), "password": prof.get("password")}


def _noc_creds() -> Tuple[str, str, str]:
    """Priority:
      1) NOC_BASE/NOC_EMAIL/NOC_PASSWORD if provided (and not "<fill>")
      2) NOC_PROFILE from profiles file
    """
    base = _getenv("NOC_BASE", "").strip()
    email = _getenv("NOC_EMAIL", "").strip()
    password = _getenv("NOC_PASSWORD", "").strip()

    if base and email and password and "<fill>" not in (base + email + password):
        return base, email, password

    prof_name = _getenv("NOC_PROFILE", "").strip()
    if prof_name:
        prof = _load_noc_profile(prof_name)
        if prof and prof.get("base") and prof.get("email") and prof.get("password"):
            return prof["base"], prof["email"], prof["password"]

    raise RuntimeError("NOC credentials missing: fill NOC_BASE/NOC_EMAIL/NOC_PASSWORD or provide NOC_PROFILE + profiles file")


def _login() -> str:
    if "token" in _CACHE:
        return _CACHE["token"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available")

    base, email, password = _noc_creds()
    bearer = _bool_env("NOC_BEARER", False)
    insecure = _bool_env("NOC_INSECURE", False)

    tok = api.login(base, email, password, bearer=bearer, insecure=insecure)
    _CACHE["token"] = tok
    print(json.dumps({"step": "login", "ok": True}))
    return tok


def _node_id() -> str:
    if "node_id" in _CACHE:
        return _CACHE["node_id"]  # type: ignore[return-value]

    metrics_tool = _getenv("METRICS_TOOL", "/home/da40/charter/tools/cpe_metrics_agent_serial.py")
    dev = _getenv("CPE_DEV", "/dev/ttyUSB0")
    baud = int(_getenv("CPE_BAUD", "115200"))
    user = _getenv("CPE_USER", "root")
    password = _getenv("CPE_PASSWORD", "null")

    max_retries = int(_getenv("NODE_ID_MAX_RETRIES", "10"))
    interval = float(_getenv("NODE_ID_RETRY_INTERVAL_SEC", "5"))

    last = ""
    for attempt in range(1, max_retries + 1):
        cmd = [metrics_tool, "--device", dev, "--baud", str(baud), "--user", user, "--cmd", "node-id"]

        pw_raw = (password or "").strip()
        pw_head = pw_raw.split()[0] if pw_raw else ""
        pw_head_l = pw_head.lower()
        is_error_like = (
            pw_head_l.startswith("curl:")
            or "connection timed out" in pw_raw.lower()
            or "error:" in pw_raw.lower()
            or "cannot fetch index.cgi" in pw_raw.lower()
        )
        if (not pw_raw) or (pw_head_l in ("null", "none")) or is_error_like:
            cmd += ["--password", "null"]
        else:
            cmd += ["--password", pw_head]

        print(json.dumps({"step": "node-id-cmd", "attempt": attempt, "cmd": cmd}))
        try:
            rc, out, err = _run(cmd, timeout=90.0)
        except Exception as e:
            last = str(e)
            print(json.dumps({"step": "node-id-exception", "attempt": attempt, "error": last}))
            time.sleep(interval)
            continue

        out_s = out.strip()
        print(json.dumps({"step": "node-id-raw", "attempt": attempt, "rc": rc, "out": out_s[:400]}))
        if rc == 0 and out_s:
            try:
                node_id = api.parse_node_id_from_text(out_s) if api else ""
            except Exception:
                node_id = ""
            node_id = (node_id or "").strip()
            if node_id:
                _CACHE["node_id"] = node_id
                print(json.dumps({"step": "node-id", "ok": True, "node_id": node_id}))
                return node_id

        last = (err or out).strip()
        print(json.dumps({"step": "node-id-retry", "attempt": attempt, "error": last[-200:]}))
        time.sleep(interval)

    # Fallback: derive node_id from WAN MAC via cpe_info
    cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
    try:
        rc2, out2, err2 = _run([cpe_info_tool, "--node-id", "--value"], timeout=20.0)
        raw2 = ((out2 or "") or (err2 or "")).strip()
        nid2 = raw2.replace(":", "").strip().lower()
        ok2 = (rc2 == 0 and bool(nid2))
        print(json.dumps({"step": "node-id-fallback-cpe_info", "ok": ok2, "rc": rc2, "raw": raw2[:200], "node_id": nid2 if ok2 else ""}))
        if ok2:
            _CACHE["node_id"] = nid2
            return nid2
    except Exception as e:
        print(json.dumps({"step": "node-id-fallback-cpe_info-exception", "error": str(e)}))

    raise RuntimeError(f"node-id failed: {last}")


def _location_id(token: str, node_id: str) -> str:
    if "location_id" in _CACHE:
        return _CACHE["location_id"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available")

    base, _, _ = _noc_creds()
    customer_id = _getenv("CUSTOMER_ID")
    bearer = _bool_env("NOC_BEARER", False)
    insecure = _bool_env("NOC_INSECURE", False)

    loc = api.get_location_id(base, customer_id, node_id, token=token, bearer=bearer, insecure=insecure)
    _CACHE["location_id"] = loc
    print(json.dumps({"step": "location-id", "ok": True, "location_id": loc}))
    return loc


def _enable_ssh(token: str, node_id: str, location_id: str) -> str:
    if api is None:
        raise RuntimeError("noc_api_cli not available")

    base, _, _ = _noc_creds()
    customer_id = _getenv("CUSTOMER_ID")
    passwd = _getenv("SSH_PASSWORD", "123456789")
    timeout_min = int(_getenv("SSH_TIMEOUT_MIN", "120"))
    bearer = _bool_env("NOC_BEARER", False)
    insecure = _bool_env("NOC_INSECURE", False)

    resp = api.ssh_enable(
        base,
        customer_id,
        location_id,
        node_id,
        passwd,
        timeout_min,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({"step": "ssh-enable", "ok": True, "resp": resp}))
    return passwd


def _parse_ipv6_addrs(ip6_addr_output: str) -> Tuple[Optional[str], Optional[str]]:
    g = None
    ll = None
    for line in (ip6_addr_output or "").splitlines():
        line = line.strip()
        m = re.search(r"\binet6\s+([0-9a-fA-F:]+)/\d+", line)
        if not m:
            continue
        ip = m.group(1).lower()
        if ip.startswith("fe80:"):
            ll = ip
        else:
            g = ip
    return g, ll


def _lan_iface_for(dst_ip: str) -> Optional[str]:
    try:
        rc, out, _ = _run(["sh", "-lc", f"ip route get {dst_ip}"], timeout=3.0)
        if rc != 0:
            return None
        m = re.search(r"\bdev\s+(\S+)", out)
        return m.group(1) if m else None
    except Exception:
        return None


def _ssh_exec(host: str, user: str, pw: str, cmd: str, timeout: float):
    """Execute remote cmd with marker wrapping; returns (rc, extracted, raw_out, err, sec)."""
    return _ssh_exec_marked(host, user, pw, cmd, timeout=timeout, login_shell=True)


def _expect_allow(host: str, user: str, pw: str, cmd: str, timeout: float) -> None:
    rc, extracted, raw_out, err, sec = _ssh_exec(host, user, pw, cmd, timeout)
    print(json.dumps({
        "step": "ssh-allow-check",
        "host": host,
        "rc": rc,
        "sec": sec,
        "stdout": extracted[-200:],
        "raw_stdout_tail": raw_out[-200:],
        "stderr": err[-200:],
    }))
    if rc != 0:
        raise RuntimeError(f"ssh expected ALLOW but failed rc={rc}: {err.strip()}")


def _expect_deny(host: str, user: str, pw: str, cmd: str, timeout: float) -> None:
    rc, extracted, raw_out, err, sec = _ssh_exec(host, user, pw, cmd, timeout)
    print(json.dumps({
        "step": "ssh-deny-check",
        "host": host,
        "rc": rc,
        "sec": sec,
        "stdout": extracted[-200:],
        "raw_stdout_tail": raw_out[-200:],
        "stderr": err[-200:],
    }))
    if rc == 0:
        raise RuntimeError("ssh expected DENY but succeeded")




def run() -> int:
    lan_ip = _getenv("SSH_HOST_LAN", "192.168.1.1")
    bad_user = _getenv("SSH_BAD_USER", "root")
    # Use the SSHM password value (even if correct) - access must still be denied for wrong username
    ssh_passwd = _getenv("SSH_AUTH_PASSWD", "123456789")
    timeout_sec = float(_getenv("SSH_CONNECT_TIMEOUT_SEC", "12"))

    token = _login()
    node_id = _node_id()
    location_id = _location_id(token, node_id)
    _enable_ssh(token, node_id, location_id)

    # Negative test: wrong/unauthorized username must be denied
    _expect_deny(lan_ip, bad_user, ssh_passwd, "echo SHOULD_NOT_RUN", timeout_sec)

    print(json.dumps({"ok": True, "case": "C15807131"}))
    return 0


if __name__ == "__main__":
    raise SystemExit(run())
