# A2435637_Continuously_executing_FactoryReset

## 1) 目的 / 覆蓋範圍
- 穩定性/長跑：重複 Factory Reset，並在每個 cycle 後驗證基本服務恢復。

## 2) 前置條件 / 環境
- 會觸發 reboot；建議 `REBOOT_MUTE_SECS=120` 並考慮 lock（避免 boot load lock）。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`stability`
- entrypoint：`cycle_wrapper.py:run`
- （manifest 未包含常見 env 或解析不到；可直接查看 zip 內 manifest.yaml）

## 5) PASS/FAIL 判定
- PASS：每 cycle reset 後 CPE ready 且驗證點通過。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# A2435637_Continuously_executing_FactoryReset

## 1) 目的 / 覆蓋範圍
- 穩定性/長跑：重複執行 Factory Reset 並驗證復原後關鍵服務可用。

## 2) 前置條件 / 環境
- 會觸發 reboot/重置，建議設定 serial mute 以避免 console/serial lock。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`stability`
- entrypoint：`cycle_wrapper.py:run`

## 5) PASS/FAIL 判定
- 每個 cycle 完成 reset 後，CPE ready 且驗證點通過。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# A2435637_Continuously_executing_FactoryReset

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`stability`
- entrypoint：`cycle_wrapper.py:run`

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
v6: precondition sets wifi once + verify; cycles only factory-reset + verify; keeps console mute.


## v7p3
- Redact secrets in wrapper cmd logs and ssh-enable responses
- Retry wifi-ssid after factory reset on backend 404; refresh location-id
```

```
```
