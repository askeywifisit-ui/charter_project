#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import os
import subprocess
import sys
import time
import fcntl
import hashlib
from contextlib import contextmanager
from typing import Any, Dict, Tuple


def _redact_obj(obj):
    secret_keys = {"password","passphrase","sshpass","ssh_pass","ssh-pass","sshpassword","ssh_password","token","bearer","authorization",
                   "sshAuthPasswd","ssh_passwd","sshAuthPassword"}
    if isinstance(obj, dict):
        out = {}
        for k,v in obj.items():
            if str(k) in secret_keys:
                out[k] = "***"
            else:
                out[k] = _redact_obj(v)
        return out
    if isinstance(obj, list):
        return [_redact_obj(x) for x in obj]
    return obj

def _redact_json_text(s: str) -> str:
    # best-effort redact json string; if parse fails, return original
    try:
        obj = json.loads(s)
        return json.dumps(_redact_obj(obj), ensure_ascii=False)
    except Exception:
        return s

_SETUP_DONE = False
_CTX: Dict[str, Any] = {}
_CPE_SSH_MOD = None


@contextmanager
def _serial_lock(dev: str, timeout_sec: int = 30):
    """Best-effort process lock for shared serial device.

    We use a file lock so multiple scripts/daemons won't open the same /dev/ttyUSBx
    at the same time. This is *not* a "kill" mechanism; it just waits.

    Lock file path:
      - if SERIAL_LOCK_PATH is set, use it
      - else use /tmp/charter_serial_<hash>.lock (per device)
    """
    lock_path = os.environ.get("SERIAL_LOCK_PATH", "").strip()
    if not lock_path:
        h = hashlib.sha256((dev or "").encode("utf-8")).hexdigest()[:12]
        lock_path = f"/tmp/charter_serial_{h}.lock"

    t0 = time.time()
    f = None
    try:
        os.makedirs(os.path.dirname(lock_path), exist_ok=True)
        f = open(lock_path, "a+")
        while True:
            try:
                fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                _log("serial_lock", ok=True, lock=lock_path, dev=dev)
                break
            except BlockingIOError:
                if (time.time() - t0) >= float(timeout_sec):
                    _log("serial_lock", ok=False, lock=lock_path, dev=dev, timeout_sec=timeout_sec)
                    break
                time.sleep(0.2)
        yield
    finally:
        try:
            if f is not None:
                try:
                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)
                except Exception:
                    pass
                f.close()
        except Exception:
            pass


def _env(name: str, default: str = "", required: bool = False) -> str:
    v = os.environ.get(name, default)
    if required and (v is None or str(v) == ""):
        raise RuntimeError(f"Missing required env: {name}")
    return str(v) if v is not None else ""


def _env_int(name: str, default: int) -> int:
    v = _env(name, "")
    if v == "":
        return default
    try:
        return int(v)
    except Exception:
        return default


def _env_bool(name: str, default: bool) -> bool:
    v = _env(name, "")
    if v == "":
        return default
    return v.strip().lower() in ("1", "true", "yes", "y")


def _log(event: str, **kw) -> None:
    d = {"event": event}
    d.update(kw)
    print(json.dumps(d, ensure_ascii=False), flush=True)

# --- serial mute helpers (avoid stale / clear on exit) ---
def _serial_mute_path() -> str:
    return os.environ.get('SERIAL_MUTE_FILE', '/home/da40/charter/var/serial.mute').strip() or '/home/da40/charter/var/serial.mute'

def _serial_mute_read_until(path: str) -> int:
    try:
        s = open(path, 'r', encoding='utf-8').read().strip()
        if not s:
            return 0
        return int(float(s))
    except FileNotFoundError:
        return 0
    except Exception:
        # bad file => remove to avoid leaving weird state
        try:
            os.remove(path)
        except Exception:
            pass
        return 0

def _serial_mute_cleanup_stale(cycle: int, where: str) -> None:
    path = _serial_mute_path()
    now = int(time.time())
    until = _serial_mute_read_until(path)
    if until and until > now:
        _log('serial_mute_stale_skip', cycle=cycle, where=where, path=path, until_ts=until, left_sec=max(0, until-now))
        return
    if until == 0:
        # no file / empty / already cleaned
        _log('serial_mute_stale_none', cycle=cycle, where=where, path=path)
        return
    try:
        os.remove(path)
        _log('serial_mute_stale_cleared', cycle=cycle, where=where, path=path, until_ts=until)
    except FileNotFoundError:
        _log('serial_mute_stale_none', cycle=cycle, where=where, path=path)
    except Exception as e:
        _log('serial_mute_stale_clear_error', cycle=cycle, where=where, path=path, until_ts=until, error=str(e))

def _serial_mute_clear(cycle: int, where: str, expected_until: int | None = None, force: bool = False) -> None:
    path = _serial_mute_path()
    cur = _serial_mute_read_until(path)
    if expected_until and (cur != int(expected_until)) and (not force):
        _log('serial_mute_clear_skip', cycle=cycle, where=where, path=path, expected_until=int(expected_until), current_until=cur)
        return
    try:
        os.remove(path)
        _log('serial_mute_clear', cycle=cycle, where=where, path=path, expected_until=expected_until, current_until=cur, force=force, ok=True)
    except FileNotFoundError:
        _log('serial_mute_clear', cycle=cycle, where=where, path=path, expected_until=expected_until, current_until=cur, force=force, ok=True, note='already_missing')
    except Exception as e:
        _log('serial_mute_clear', cycle=cycle, where=where, path=path, expected_until=expected_until, current_until=cur, force=force, ok=False, error=str(e))


def _run_cmd(cmd, timeout: int = 300, env=None) -> Tuple[int, str, str]:
    try:
        p = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
            env=env,
        )
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or "") if isinstance(getattr(e, 'stdout', ''), str) else ""
        err = (e.stderr or "") if isinstance(getattr(e, 'stderr', ''), str) else ""
        if not err:
            err = f"timeout after {timeout}s"
        return 124, out, err


def _parse_node_id(s: str) -> str:
    s = (s or "").strip().lower()
    if not s:
        return ""
    import re
    m = re.search(r"\b([0-9a-f]{10,})\b", s)
    return (m.group(1) if m else "").lower()


def _serial_node_id(timeout: int = 60) -> Tuple[int, str, str, str]:
    """Query node-id directly via serial (cpe_metrics_agent_serial.py).

    Why: After factory-reset, the CPE may be cloud-connected earlier than the serial
    console is fully ready. NOC CLI commands often auto-resolve node-id via serial
    and can hit a hard 30s timeout. We probe first and retry.
    """
    cmd = [
        _CTX["py"],
        os.path.join(_CTX["tools_path"], "cpe_metrics_agent_serial.py"),
        "--device",
        _CTX["cpe_dev"],
        "--baud",
        _CTX["cpe_baud"],
        "--user",
        "root",
        "--cmd",
        "node-id",
    ]
    lock_timeout = _env_int("SERIAL_LOCK_TIMEOUT_SEC", 30)
    with _serial_lock(_CTX["cpe_dev"], timeout_sec=lock_timeout):
        rc, out, err = _run_cmd(cmd, timeout=timeout)
    nid = _parse_node_id(out or "" )
    if not nid:
        nid = _parse_node_id(err or "")
    return rc, out, err, nid


def _wait_serial_node_id(cycle: int, where: str) -> Tuple[bool, str]:
    # Default OFF: avoid touching serial/console unless explicitly enabled.
    if not _env_bool("WAIT_SERIAL_NODE_ID", False):
        _log("serial_node_id_wait_skip", cycle=cycle, where=where)
        return True, ""

    retries = _env_int("SERIAL_NODE_ID_RETRIES", 30)
    interval = _env_int("SERIAL_NODE_ID_INTERVAL_SEC", 5)
    cmd_timeout = _env_int("SERIAL_NODE_ID_TIMEOUT_SEC", 30)

    last_err = ""
    for attempt in range(1, retries + 1):
        rc, out, err, nid = _serial_node_id(timeout=cmd_timeout)
        if rc == 0 and nid:
            _log("serial_node_id_ok", cycle=cycle, where=where, attempt=attempt, node_id=nid)
            _CTX["node_id"] = nid
            return True, ""

        last_err = (err or "").strip() or (out or "").strip()
        _log(
            "serial_node_id_retry",
            cycle=cycle,
            where=where,
            attempt=attempt,
            retries=retries,
            interval_sec=interval,
            timeout_sec=cmd_timeout,
            rc=rc,
            stderr=(err or "")[-300:],
        )
        if attempt < retries:
            time.sleep(interval)

    # Fallback: serial metrics may fail due to console lock. In that case, try to
    # derive node_id from WAN MAC via cpe_info.
    # cpe_info --node-id --value prints WAN MAC without colons in lowercase.
    try:
        rc2, out2, err2 = _run_cmd([_CTX.get("cpe_info", "cpe_info"), "--node-id", "--value"], timeout=20)
        nid2 = _parse_node_id(out2 or "") or _parse_node_id(err2 or "")
        if rc2 == 0 and nid2:
            _CTX["node_id"] = nid2
            _log("node_id_fallback_cpe_info_ok", cycle=cycle, where=where, rc=rc2, node_id=nid2)
            return True, ""
        _log(
            "node_id_fallback_cpe_info_fail",
            cycle=cycle,
            where=where,
            rc=rc2,
            stdout=(out2 or "")[-300:],
            stderr=(err2 or "")[-300:],
        )
    except Exception as e:
        _log("node_id_fallback_cpe_info_exception", cycle=cycle, where=where, error=str(e))

    return False, f"serial_node_id_{where}_timeout"



def _fail(cycle: int, reason: str, **kw) -> int:
    _log("cycle_fail", cycle=cycle, reason=reason, **kw)
    msg = f"fail cycle: {cycle} ; root cause : {reason}"
    if kw:
        msg += " ; " + json.dumps(kw, ensure_ascii=False)
    print(msg)
    return 1


def _load_noc_profile() -> Tuple[str, str, str]:
    base_env = _env("NOC_BASE", "")
    email_env = _env("NOC_EMAIL", "")
    pass_env = _env("NOC_PASSWORD", "")
    if base_env and email_env and pass_env:
        return base_env, email_env, pass_env

    profiles_path = _env("PROFILES_FILE", "")
    if not profiles_path:
        profiles_path = _env("NOC_PROFILES_PATH", "/home/da40/charter/.secrets/noc_profiles.json", required=True)

    profile_name = _env("NOC_PROFILE", "")
    if not profile_name:
        profile_name = _env("NOC_PROFILE_NAME", "SPECTRUM_INT", required=True)

    with open(profiles_path, "r", encoding="utf-8") as f:
        profiles = json.load(f)

    prof = profiles.get(profile_name)
    if not isinstance(prof, dict):
        raise RuntimeError(f"Profile {profile_name!r} not found in {profiles_path}")

    base = str(prof.get("base") or "")
    email = str(prof.get("email") or "")
    password = str(prof.get("password") or "")
    if not (base and email and password):
        raise RuntimeError(f"Incomplete profile {profile_name!r} in {profiles_path}")
    return base, email, password


def _noc_common_args() -> list:
    serial_metrics = _env("SERIAL_METRICS", "", required=True)
    return [
        "--serial-metrics", serial_metrics,
        "--serial-device", _CTX["cpe_dev"],
        "--serial-baud", _CTX["cpe_baud"],
    ]


def _noc_global_args_token() -> list:
    """Global NOC CLI args that do *not* touch serial.

    IMPORTANT: --token is used so each command won't login again.
    """
    tok = str(_CTX.get("noc_token") or "").strip()
    if not tok:
        raise RuntimeError("noc_token not initialized")
    return [
        "--base", _CTX["noc_base"],
        "--customer-id", _CTX["noc_customer"],
        "--token", tok,
    ]


def _noc_login_token(timeout: int = 60) -> str:
    """Login once and cache token in _CTX."""
    tok = str(_CTX.get("noc_token") or "").strip()
    if tok:
        return tok

    cmd = [
        _CTX["py"],
        _CTX["noc_cli"],
        "--base", _CTX["noc_base"],
        "--email", _CTX["noc_email"],
        "--password", _CTX["noc_password"],
        "login",
    ]
    rc, out, err = _run_cmd(cmd, timeout=timeout)
    if rc != 0:
        raise RuntimeError(f"noc login failed rc={rc}: {err}")
    tok = (out or "").strip().splitlines()[-1].strip()
    if not tok:
        raise RuntimeError("noc login returned empty token")
    _CTX["noc_token"] = tok
    return tok


def _ensure_node_and_location_ids() -> None:
    """Resolve node_id (via cpe_info) and location_id (via API).

    After this, all noc_api_cli commands should use --token and --location-id / --node-id,
    so they won't auto-probe serial again.

    NOTE: We intentionally avoid serial/console here to prevent console lock contention.
    """
    if _CTX.get("node_id") and _CTX.get("location_id") and _CTX.get("noc_token"):
        return

    # 1) login once
    _noc_login_token(timeout=_env_int("NOC_LOGIN_TIMEOUT_SEC", 60))

    # 2) node-id via cpe_info (no serial)
    nid = ""
    retries = _env_int("NODE_ID_CPE_INFO_RETRIES", 5)
    interval = _env_int("NODE_ID_CPE_INFO_INTERVAL_SEC", 2)
    timeout = _env_int("NODE_ID_CPE_INFO_TIMEOUT_SEC", 20)
    for attempt in range(1, retries + 1):
        rc1, out1, err1 = _run_cmd([_CTX.get("cpe_info", "cpe_info"), "--node-id"], timeout=timeout)
        nid = _parse_node_id(out1 or "") or _parse_node_id(err1 or "")
        if rc1 == 0 and nid:
            _CTX["node_id"] = nid
            _log("node_id_cpe_info_ok", attempt=attempt, retries=retries, node_id=nid)
            break
        _log(
            "node_id_cpe_info_retry",
            attempt=attempt,
            retries=retries,
            rc=rc1,
            stdout=(out1 or "")[-200:],
            stderr=(err1 or "")[-200:],
        )
        if attempt < retries:
            time.sleep(interval)

    # Optional serial fallback (explicitly enabled only)
    if not nid and _env_bool("WAIT_SERIAL_NODE_ID", False):
        ok, _ = _wait_serial_node_id(cycle=0, where="setup")
        if ok:
            nid = str(_CTX.get("node_id") or "").strip()

    # 3) location-id via API (no serial)
    nid = str(nid or _CTX.get("node_id") or "").strip()
    if not nid:
        raise RuntimeError("failed to obtain node_id (cpe_info)")

    cmd = [
        _CTX["py"],
        _CTX["noc_cli"],
        *_noc_global_args_token(),
        "get-location",
        "--node-id", nid,
    ]
    rc, out, err = _run_cmd(cmd, timeout=_env_int("NOC_GET_LOCATION_TIMEOUT_SEC", 60))
    if rc != 0:
        raise RuntimeError(f"get-location failed rc={rc}: {err}")
    loc = (out or "").strip().splitlines()[-1].strip()
    if not loc:
        raise RuntimeError("get-location returned empty location_id")
    _CTX["location_id"] = loc


def _refresh_location_id(where: str = "") -> bool:
    # Re-resolve location-id via API (use existing node_id + token). Useful after factory reset.
    try:
        _noc_login_token(timeout=_env_int("NOC_LOGIN_TIMEOUT_SEC", 60))
        nid = str(_CTX.get("node_id") or "").strip()
        if not nid:
            return False
        cmd = [
            _CTX["py"],
            _CTX["noc_cli"],
            *_noc_global_args_token(),
            "get-location",
            "--node-id", nid,
        ]
        rc, out, err = _run_cmd(cmd, timeout=_env_int("NOC_GET_LOCATION_TIMEOUT_SEC", 60))
        if rc != 0:
            _log("refresh_location_id_fail", where=where, rc=rc, stderr=(err or "")[-300:])
            return False
        loc = (out or "").strip().splitlines()[-1].strip()
        if not loc:
            _log("refresh_location_id_fail", where=where, rc=rc, stderr="empty location_id")
            return False
        old = _CTX.get("location_id")
        _CTX["location_id"] = loc
        _log("refresh_location_id_ok", where=where, old=old, new=loc)
        return True
    except Exception as e:
        _log("refresh_location_id_exception", where=where, error=str(e))
        return False


def _import_cpe_ssh_module(tools_path: str):
    global _CPE_SSH_MOD
    if _CPE_SSH_MOD is not None:
        return _CPE_SSH_MOD

    if tools_path not in sys.path:
        sys.path.insert(0, tools_path)
    try:
        import cpe_ssh  # type: ignore
        _CPE_SSH_MOD = cpe_ssh
        return _CPE_SSH_MOD
    except Exception as e:
        _log("import_warning", module="cpe_ssh", error=str(e))
        _CPE_SSH_MOD = None
        return None


def _maybe_console_mute(tag: str) -> None:
    mute_secs = _env_int("RESET_MUTE_SECS", 0)
    # Default OFF: keep console mute but do NOT use console lock.
    use_lock = _env_bool("RESET_MUTE_WITH_LOCK", False)
    if mute_secs <= 0:
        return

    mod = _CPE_SSH_MOD
    if mod is None:
        _log("console_mute_skip", reason="cpe_ssh_import_failed", tag=tag, mute_secs=mute_secs)
        return

    fn = getattr(mod, "set_console_mute", None)
    if fn is None:
        _log("console_mute_skip", reason="set_console_mute_not_found", tag=tag, mute_secs=mute_secs)
        return

    # Console lock retry mechanism:
    # Some runs may fail because another process holds the console lock.
    # We retry until CONSOLE_LOCK_RETRY_TIMEOUT_SEC is reached.
    lock_timeout = _env_int("CONSOLE_LOCK_TIMEOUT_SEC", 5)
    retry_timeout = _env_int("CONSOLE_LOCK_RETRY_TIMEOUT_SEC", 60)
    retry_interval = _env_int("CONSOLE_LOCK_RETRY_INTERVAL_SEC", 3)

    t0 = time.time()
    attempt = 0
    last_err = None

    while True:
        attempt += 1
        try:
            until_ts = fn(mute_secs, use_lock=use_lock, lock_timeout=lock_timeout)  # type: ignore[misc]
            try:
                _CTX['reset_mute_until_ts'] = int(until_ts or 0)
            except Exception:
                _CTX['reset_mute_until_ts'] = 0
            _CTX['reset_mute_tag'] = tag
            _log(
                "console_mute_ok",
                tag=tag,
                mute_secs=mute_secs,
                until_ts=until_ts,
                use_lock=use_lock,
                lock_timeout=lock_timeout,
                attempt=attempt,
            )
            return
        except Exception as e:
            last_err = e
            elapsed = time.time() - t0
            if elapsed >= retry_timeout:
                _log(
                    "console_mute_fail",
                    tag=tag,
                    mute_secs=mute_secs,
                    use_lock=use_lock,
                    lock_timeout=lock_timeout,
                    attempts=attempt,
                    retry_timeout=retry_timeout,
                    last_error=str(e),
                )
                return

            _log(
                "console_mute_retry",
                tag=tag,
                mute_secs=mute_secs,
                use_lock=use_lock,
                lock_timeout=lock_timeout,
                attempt=attempt,
                retry_in_sec=retry_interval,
                elapsed_sec=round(elapsed, 3),
                error=str(e),
            )
            time.sleep(retry_interval)

def _wifi_ssid(timeout: int = 60) -> Tuple[int, str, str, str]:
    # Ensure node_id/location_id are resolved ONCE. After that, Wi-Fi calls
    # should never auto-probe serial again.
    _ensure_node_and_location_ids()

    cmd = [
        _CTX["py"],
        _CTX["noc_cli"],
        *_noc_global_args_token(),
        "wifi-ssid",
        "--location-id",
        _CTX["location_id"],
    ]
    rc, out, err = _run_cmd(cmd, timeout=timeout)
    ssid = ""
    if rc == 0:
        try:
            ssid = (json.loads(out or "{}") or {}).get("ssid", "")
        except Exception:
            ssid = ""
    return rc, out, err, ssid


def _wifi_config_set(ssid: str, psk: str, timeout: int = 300) -> Tuple[int, str, str]:
    _ensure_node_and_location_ids()

    cmd = [
        _CTX["py"],
        _CTX["noc_cli"],
        *_noc_global_args_token(),
        "wifi-config-set",
        "--location-id",
        _CTX["location_id"],
        "--ssid",
        ssid,
        "--passphrase",
        psk,
    ]
    return _run_cmd(cmd, timeout=timeout)

def _setup_once() -> bool:
    global _SETUP_DONE, _CTX
    if _SETUP_DONE:
        return True

    tools_path = _env("TOOLS_PATH", "/home/da40/charter/tools")
    py = _env("TOOLS_PYTHON", "python3")

    noc_customer = _env("CUSTOMER_ID", "") or _env("NOC_CUSTOMER_ID", "")
    if not noc_customer:
        raise RuntimeError("CUSTOMER_ID (or NOC_CUSTOMER_ID) is required")
    noc_base, noc_email, noc_password = _load_noc_profile()

    cpe_dev = _env("CPE_DEV", required=True)
    cpe_baud = _env("CPE_BAUD", "115200")
    cpe_ip = _env("CPE_IP", required=True)
    ssh_user = _env("SSH_USER", required=True)
    ssh_pass = _env("SSH_PASSWORD", required=True)
    default_prefix = _env("DEFAULT_SSID_PREFIX", "")

    noc_cli = os.path.join(tools_path, "noc_api_cli.py")
    cpe_info = os.path.join(tools_path, "cpe_info")
    cpe_ssh_cli = os.path.join(tools_path, "cpe_ssh.py")

    _CTX = dict(
        tools_path=tools_path,
        py=py,
        noc_cli=noc_cli,
        cpe_info=cpe_info,
        cpe_ssh_cli=cpe_ssh_cli,
        noc_base=noc_base,
        noc_customer=noc_customer,
        noc_email=noc_email,
        noc_password=noc_password,
        cpe_dev=cpe_dev,
        cpe_baud=str(cpe_baud),
        cpe_ip=cpe_ip,
        ssh_user=ssh_user,
        ssh_pass=ssh_pass,
        default_prefix=default_prefix,
    )

    _import_cpe_ssh_module(tools_path)

    # Resolve NOC token + node_id (serial ONCE) + location_id (API ONCE).
    # After this point, NOC CLI calls should not touch serial anymore.
    try:
        _ensure_node_and_location_ids()
    except Exception as e:
        _log("setup_error", step="resolve_node_location", error=str(e))
        return False

    rc, out, err, baseline_ssid = _wifi_ssid()
    if rc == 0:
        _CTX["baseline_ssid"] = baseline_ssid
        _log("baseline_wifi_ssid", ssid=baseline_ssid)
    else:
        _log("baseline_wifi_ssid_error", rc=rc, stderr=err)

    # Enable SSH via NOC (NO serial). We pass --node-id/--location-id to avoid auto-resolve.
    cmd = [
        py,
        noc_cli,
        *_noc_global_args_token(),
        "ssh-enable",
        "--node-id",
        _CTX["node_id"],
        "--location-id",
        _CTX["location_id"],
        "--ssh-pass",
        ssh_pass,
    ]
    rc, out, err = _run_cmd(cmd)
    if rc != 0:
        _log("setup_error", step="ssh_enable", rc=rc, stderr=err, stdout=out)
        return False
    _log("ssh_enable_ok", raw=(out or "").strip())

    _SETUP_DONE = True
    _log("setup_done")
    return True


def _precond_set_wifi_each_cycle(cycle: int) -> Tuple[bool, str]:
    """Set Wi-Fi SSID/PSK as a per-cycle precondition.

    This is intentionally done *every* cycle so the subsequent factory-reset
    validation can reliably detect whether the reset restored defaults.
    """
    if not _env_bool("PRECOND_SET_WIFI", True):
        _log("precond_wifi_skip", cycle=cycle, reason="PRECOND_SET_WIFI_disabled")
        return True, ""

    test_ssid = _env("TEST_SSID", required=True)
    test_psk = _env("TEST_PSK", required=True)

    timeout_sec = _env_int("PRECOND_WIFI_CONFIG_SET_TIMEOUT_SEC", 60)
    retries = _env_int("PRECOND_WIFI_CONFIG_SET_RETRIES", 3)
    retry_interval = _env_int("PRECOND_WIFI_CONFIG_SET_RETRY_INTERVAL_SEC", 3)

    rc = 1
    out = ""
    err = ""
    for attempt in range(1, retries + 1):
        rc, out, err = _wifi_config_set(test_ssid, test_psk, timeout=timeout_sec)
        if rc == 0:
            break
        # Required/expected event name (for log inspection)
        _log(
            "precond_wifi_config_set_error",
            cycle=cycle,
            attempt=attempt,
            retries=retries,
            timeout_sec=timeout_sec,
            rc=rc,
            stderr=err,
        )
        if attempt < retries:
            time.sleep(retry_interval)
    if rc != 0:
        return False, "precond_wifi_config_set"
    _log("wifi_config_set_ok", cycle=cycle)

    rc, out, err, ssid_after = _wifi_ssid()
    if rc != 0:
        _log("precond_wifi_error", cycle=cycle, step="wifi_ssid_after_set_rc", rc=rc, stderr=err)
        return False, "precond_wifi_ssid_after_set_rc"

    # Required event format for test log inspection.
    _log("wifi_ssid_after_set", cycle=cycle, ssid=ssid_after)

    if ssid_after != test_ssid:
        _log("precond_wifi_error", cycle=cycle, step="wifi_ssid_mismatch", expected=test_ssid, actual=ssid_after)
        return False, "precond_wifi_ssid_mismatch"

    return True, ""


def _cloud_connected(cycle: int, where: str) -> Tuple[bool, str]:
    rc, out, err = _run_cmd([_CTX["cpe_info"], "--cloud"])
    if rc != 0:
        return False, f"cloud_{where}_rc"
    if "Cloud Status: Connected" not in (out or ""):
        _log("cloud_not_connected", cycle=cycle, where=where, stdout=out, stderr=err)
        return False, f"cloud_{where}_not_connected"
    _log("cloud_connected", cycle=cycle, where=where)
    return True, ""


def _health(cycle: int, where: str) -> Tuple[bool, str]:
    cmd = [
        _CTX["py"], _CTX["cpe_ssh_cli"],
        "--host", _CTX["cpe_ip"],
        "--user", _CTX["ssh_user"],
        "--password", _CTX["ssh_pass"],
        "--cmd", "health",
    ]
    rc, out, err = _run_cmd(cmd, timeout=300)
    if rc != 0:
        _log("health_rc_error", cycle=cycle, where=where, rc=rc, stderr=err)
        return False, f"health_{where}_rc"
    try:
        data = json.loads(out or "{}") or {}
    except Exception:
        _log("health_parse_error", cycle=cycle, where=where, raw=out)
        return False, f"health_{where}_parse"
    _log("health_result", cycle=cycle, where=where, result=data)
    if not bool(data.get("ok", False)):
        return False, f"health_{where}_bad"
    overall = str(data.get("overall", "")).upper()
    if overall and overall != "GOOD":
        return False, f"health_{where}_bad"
    return True, ""




def _get_cycle() -> int:
    # Prefer wrapper-provided CYCLE_INDEX; fallback to legacy CURRENT_CYCLE
    v = _env("CYCLE_INDEX", "")
    if v.strip() == "":
        v = _env("CURRENT_CYCLE", "0")
    try:
        return int(v.strip() or "0")
    except Exception:
        return 0


def _pdu_reset(cycle: int, where: str) -> bool:
    script = os.environ.get("PDU_SCRIPT", "").strip()
    outlet = os.environ.get("PDU_OUTLET_ID", "").strip()
    if not script:
        _log("pdu_reset_skip", cycle=cycle, where=where, reason="PDU_SCRIPT not set")
        return False

    args_style = os.environ.get("PDU_SCRIPT_ARGS_STYLE", "").strip().lower()
    timeout = _env_int("PDU_RESET_TIMEOUT_SEC", 600)

    # Some PDU tools read host from env (PDU_IP/PDU_HOST).
    env = dict(os.environ)
    host = env.get("PDU_IP", "").strip() or env.get("PDU_HOST", "").strip()
    if host:
        env.setdefault("PDU_IP", host)
        env.setdefault("PDU_HOST", host)

    cmd = [_CTX.get("py", sys.executable), script, "reset"]
    if args_style in ("with_outlet_id", "need_outlet_id", "outlet_id") and outlet:
        cmd.append(outlet)

    rc, out, err = _run_cmd(cmd, timeout=timeout, env=env)
    _log("pdu_reset", cycle=cycle, where=where, rc=rc, stdout=(out or "")[-300:], stderr=(err or "")[-300:], cmd=cmd)

    # If tool didn't need outlet_id, allow a one-time fallback try (only if first attempt failed).
    if rc != 0 and outlet and (args_style == ""):
        cmd2 = [_CTX.get("py", sys.executable), script, "reset", outlet]
        rc2, out2, err2 = _run_cmd(cmd2, timeout=timeout, env=env)
        _log("pdu_reset_retry", cycle=cycle, where=where, rc=rc2, stdout=(out2 or "")[-300:], stderr=(err2 or "")[-300:], cmd=cmd2)
        rc, out, err = rc2, out2, err2

    return rc == 0


def _wait_cloud_connected(cycle: int, where: str, retries: int, interval: int) -> bool:
    for _ in range(retries):
        ok, _ = _cloud_connected(cycle, where)
        if ok:
            return True
        time.sleep(interval)
    return False

def run() -> int:
    if not _setup_once():
        return 1

    cycle = _get_cycle()

    test_ssid = _env("TEST_SSID", required=True)
    default_prefix = _env("DEFAULT_SSID_PREFIX", "")
    enable_baseline_health = _env_bool("ENABLE_BASELINE_HEALTH", True)
    reset_wait = _env_int("RESET_WAIT_SEC", 90)
    ready_retries = _env_int("READY_RETRIES", 120)
    ready_interval = _env_int("READY_INTERVAL_SEC", 5)


    # reset per-cycle mute context
    _CTX.pop('reset_mute_until_ts', None)
    _CTX.pop('reset_mute_tag', None)

    # precondition: clear stale/expired mute flag (avoid affecting this cycle)
    _serial_mute_cleanup_stale(cycle, where='precondition')

    clear_on_exit = _env_bool('CLEAR_SERIAL_MUTE_ON_EXIT', True)
    force_clear = _env_bool('CLEAR_SERIAL_MUTE_FORCE', False)
    try:
        ok, reason = _cloud_connected(cycle, "before")
        if not ok:
            return _fail(cycle, reason)

        if enable_baseline_health:
            ok, reason = _health(cycle, "baseline")
            if not ok:
                return _fail(cycle, reason)

        # Per-cycle precondition: set SSID/PSK to a known value so we can verify
        # factory-reset actually restored defaults.
        ok, reason = _precond_set_wifi_each_cycle(cycle)
        if not ok:
            return _fail(cycle, reason)

        # Cycle: factory reset (NO serial).
        # Use cached node_id/location_id + token so noc_api_cli will NOT auto-probe serial again.
        _ensure_node_and_location_ids()
        cmd = [
            _CTX["py"], _CTX["noc_cli"],
            *_noc_global_args_token(),
            "factory-reset",
            "--node-id",
            _CTX["node_id"],
            "--location-id",
            _CTX["location_id"],
        ]
        rc, out, err = _run_cmd(cmd)
        if rc != 0:
            return _fail(cycle, "factory_reset_api_error", rc=rc, stderr=err)
        _log("factory_reset_triggered", cycle=cycle, raw=(out or "").strip())

        _maybe_console_mute(tag="after_factory_reset")
        time.sleep(reset_wait)

        # Wait for cloud reconnect after factory reset.
        ready = _wait_cloud_connected(cycle, "after", ready_retries, ready_interval)
        if not ready and _env_bool("PDU_RESET_ON_CLOUD_TIMEOUT_AFTER_RESET", True):
            # One-time recovery attempt: power-cycle via PDU, then re-check cloud.
            if _pdu_reset(cycle, where="after_reset_cloud_timeout"):
                wait_sec = _env_int("PDU_RESET_WAIT_SEC_AFTER_RESET", _env_int("PDU_RESET_WAIT_SEC", 120))
                if wait_sec > 0:
                    _log("sleep", cycle=cycle, name="after_pdu_reset", seconds=wait_sec, where="after_reset")
                    time.sleep(wait_sec)
                extra_retries = _env_int("READY_RETRIES_AFTER_PDU", ready_retries)
                extra_interval = _env_int("READY_INTERVAL_SEC_AFTER_PDU", ready_interval)
                ready = _wait_cloud_connected(cycle, "after_pdu", extra_retries, extra_interval)

        if not ready:
            return _fail(cycle, "cloud_not_connected_after_reset_timeout", retries=ready_retries, interval=ready_interval)

        # Re-confirm node-id via cpe_info and refresh location-id (no serial/console lock).
        try:
            nid_new = ""
            nr = _env_int("NODE_ID_CPE_INFO_RETRIES_AFTER_RESET", _env_int("NODE_ID_CPE_INFO_RETRIES", 5))
            ni = _env_int("NODE_ID_CPE_INFO_INTERVAL_SEC_AFTER_RESET", _env_int("NODE_ID_CPE_INFO_INTERVAL_SEC", 2))
            nt = _env_int("NODE_ID_CPE_INFO_TIMEOUT_SEC_AFTER_RESET", _env_int("NODE_ID_CPE_INFO_TIMEOUT_SEC", 20))
            for attempt in range(1, nr + 1):
                rc_n, out_n, err_n = _run_cmd([_CTX.get("cpe_info", "cpe_info"), "--node-id"], timeout=nt)
                nid_new = _parse_node_id(out_n or "") or _parse_node_id(err_n or "")
                if rc_n == 0 and nid_new:
                    old_nid = str(_CTX.get("node_id") or "").strip()
                    _CTX["node_id"] = nid_new
                    _log("node_id_after_reset", cycle=cycle, attempt=attempt, node_id=nid_new, old_node_id=old_nid)
                    _refresh_location_id(where="after_reset")
                    break
                _log(
                    "node_id_after_reset_retry",
                    cycle=cycle,
                    attempt=attempt,
                    retries=nr,
                    rc=rc_n,
                    stdout=(out_n or "")[-200:],
                    stderr=(err_n or "")[-200:],
                )
                if attempt < nr:
                    time.sleep(ni)
            if not nid_new:
                _log("node_id_after_reset_fail", cycle=cycle, note="keep_cached", node_id=str(_CTX.get("node_id") or ""))
        except Exception as e:
            _log("node_id_after_reset_exception", cycle=cycle, error=str(e))
        # verify SSID after reset (retry on backend 404 while device re-provisions)
        ssid_retries = _env_int("WIFI_SSID_AFTER_RESET_RETRIES", 30)
        ssid_interval = _env_int("WIFI_SSID_AFTER_RESET_INTERVAL_SEC", 10)
        last_err = ""
        rc = 0
        ssid_after_reset = ""
        for attempt in range(1, ssid_retries + 1):
            rc, out, err, ssid_after_reset = _wifi_ssid()
            if rc == 0 and ssid_after_reset:
                break
            last_err = (err or "").strip() or (out or "").strip()
            # common backend transient after factory reset
            if "WifiNetwork not found" in last_err or "\"statusCode\": 404" in last_err or "404 Not Found" in last_err:
                _refresh_location_id(where="after_reset")
            _log("wifi_ssid_after_reset_retry", cycle=cycle, attempt=attempt, retries=ssid_retries,
                 interval_sec=ssid_interval, rc=rc, stderr=last_err[-300:])
            if attempt < ssid_retries:
                time.sleep(ssid_interval)

        if rc != 0:
            return _fail(cycle, "wifi_ssid_after_reset_rc", rc=rc, stderr=last_err)
        _log("wifi_ssid_after_reset", cycle=cycle, ssid=ssid_after_reset, baseline_ssid=_CTX.get("baseline_ssid", ""))
        if ssid_after_reset == test_ssid:
            return _fail(cycle, "wifi_ssid_not_reset_same_as_test", ssid=ssid_after_reset)

        if default_prefix and not ssid_after_reset.startswith(default_prefix):
            return _fail(cycle, "wifi_ssid_not_match_default_prefix", ssid=ssid_after_reset, prefix=default_prefix)

        ok, reason = _health(cycle, "after_reset")
        if not ok:
            return _fail(cycle, reason)

        _log("cycle_pass", cycle=cycle, ssid_after_reset=ssid_after_reset)
        print(f"cycle {cycle} PASS ; ssid_after_reset={ssid_after_reset}")
        return 0
    finally:
        if clear_on_exit:
            expected = _CTX.get('reset_mute_until_ts')
            if expected:
                _serial_mute_clear(cycle, where='postcondition', expected_until=int(expected), force=force_clear)
            else:
                _serial_mute_cleanup_stale(cycle, where='postcondition')
