#!/usr/bin/env python3
import cycle_wrapper

if __name__ == "__main__":
    raise SystemExit(cycle_wrapper.run())
