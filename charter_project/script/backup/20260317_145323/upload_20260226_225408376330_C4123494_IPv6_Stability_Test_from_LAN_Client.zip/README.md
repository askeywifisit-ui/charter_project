# C4123494_IPv6_Stability_Test_from_LAN_Client

## 1) 目的 / 覆蓋範圍
- （待補：此腳本驗證的功能點/場景）

## 2) 前置條件 / 環境
- （待補：環境/拓撲/前置條件）

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`stability`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'60'

## 5) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C4123494_IPv6_Stability_Test_from_LAN_Client

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`stability`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'60'

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
C4123494 - IPv6 Stability Test from LAN Client (v2)

This zip is importable by RG platform (manifest entrypoint: cycle_wrapper.py:run).

Highlights:
- precondition() runs once in cycle #1:
  * cpe_info --cloud retry -> optional PDU reset once -> retry
  * ensure SSH ready (scan 22 + optional NOC ssh-enable)
  * ensure LAN interface (PING_IFACE) has IPv4 + IPv6(global) and v6 default route
- every cycle:
  * ensure SSH ready (same scan/enable flow)
  * ping IPv6 target from LAN client (bind interface)
  * if loss >= LOSS_TRIGGER_PCT or consecutive fails >= CONSEC_FAIL_TRIGGER_N => logpull

Fixes vs v1:
- manifest.yaml is valid YAML (no '...' document end marker)
- ORIGINAL_ENTRY contains no inline comment
- cycle_wrapper prints exception traces (cycle_exception/runner_exception) so failures are diagnosable

Defaults:
- PING_IFACE=ens19
- LAN_IPV6_TARGET=2001:4860:4860::8888
- LOSS_TRIGGER_PCT=10
```

```
