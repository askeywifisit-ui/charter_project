#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''
cycle_wrapper.py - RG stability runner wrapper

- Parses manifest.yaml (env + cycle controls)
- Applies env into os.environ (doesn't overwrite existing vars with empty values)
- Runs precondition() once in cycle #1 if PRECONDITION_FIRST_CYCLE=1
- Runs ORIGINAL_ENTRY (default: main_impl.py:run) each cycle
- Emits JSON events + plain logs
- IMPORTANT: prints exception traces (so failures are diagnosable)
'''
from __future__ import annotations

import importlib.util
import json
import os
import pathlib
import sys
import time
import traceback
from typing import Any, Dict

try:
    import yaml  # type: ignore
except Exception:
    yaml = None  # type: ignore


def log(msg: str) -> None:
    print(msg, flush=True)


def _emit(event: str, **fields: Any) -> None:
    payload = {"event": event, **fields}
    try:
        print(json.dumps(payload, ensure_ascii=False), flush=True)
    except Exception:
        safe = {"event": event}
        for k, v in fields.items():
            try:
                json.dumps(v)
                safe[k] = v
            except Exception:
                safe[k] = repr(v)
        print(json.dumps(safe, ensure_ascii=False), flush=True)


def _load_manifest() -> Dict[str, Any]:
    here = pathlib.Path(__file__).resolve().parent
    mp = here / "manifest.yaml"
    if not mp.exists():
        mp = here / "manifest.yml"
    if not mp.exists():
        return {}
    if yaml is None:
        raise RuntimeError("PyYAML is required but not installed")
    return yaml.safe_load(mp.read_text(encoding="utf-8")) or {}


def _apply_env(env_overlay: Dict[str, Any]) -> Dict[str, str | None]:
    backup: Dict[str, str | None] = {}
    for k, v in (env_overlay or {}).items():
        key = str(k)
        backup[key] = os.environ.get(key)
        if v is None:
            continue
        sval = str(v)
        if sval.strip() == "" and os.environ.get(key) is not None:
            continue
        os.environ[key] = sval
    return backup


def _restore_env(backup: Dict[str, str | None]) -> None:
    for k, prev in (backup or {}).items():
        if prev is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = prev


def _resolve_entry(entry_str: str):
    entry_str = (entry_str or "").split("#", 1)[0].strip()  # ignore accidental inline comments
    if not entry_str:
        entry_str = "main_impl.py:run"
    mod_file, _, func_name = entry_str.partition(":")
    if not func_name:
        func_name = "run"

    here = pathlib.Path(__file__).resolve().parent
    mod_path = here / mod_file
    if not mod_path.exists():
        raise FileNotFoundError(f"entry module not found: {mod_path}")

    spec = importlib.util.spec_from_file_location("script_entry", str(mod_path))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load module from {mod_path}")
    mod = importlib.util.module_from_spec(spec)  # type: ignore
    spec.loader.exec_module(mod)  # type: ignore

    fn = getattr(mod, func_name, None)
    if not callable(fn):
        raise AttributeError(f"entry function not found: '{entry_str}'")
    return mod, fn


def _parse_int(name: str, default: int) -> int:
    try:
        return int(str(os.environ.get(name, str(default))).strip())
    except Exception:
        return default


def _parse_float(name: str, default: float) -> float:
    try:
        return float(str(os.environ.get(name, str(default))).strip())
    except Exception:
        return default


def run() -> int:
    man = _load_manifest()
    env_overlay = dict(man.get("env") or {})
    env_backup = _apply_env(env_overlay)

    name = str(man.get("name") or "unnamed")
    entrypoint = str(man.get("entrypoint") or "cycle_wrapper.py:run")

    cycles = _parse_int("CYCLES", _parse_int("CYCLE_TOTAL", 1))
    interval = _parse_float("CYCLE_INTERVAL", _parse_float("CYCLE_INTERVAL_SEC", 0.0))
    stop_on_fail = _parse_int("STOP_ON_FAIL", 0)

    original_entry = os.environ.get("ORIGINAL_ENTRY", "main_impl.py:run").split("#", 1)[0].strip()
    precond_first = _parse_int("PRECONDITION_FIRST_CYCLE", 1)

    _emit("runner_start", name=name)
    log(f"[runner] START  {name}")
    log(f"[runner]        cycles={cycles} interval={interval:.1f}s stop_on_fail={stop_on_fail} "
        f"original_entry={original_entry} (manifest_entry={entrypoint})")

    overall_rc = 0
    per_cycle: list[dict[str, Any]] = []

    try:
        mod, fn = _resolve_entry(original_entry)
        precond_fn = getattr(mod, "precondition", None)

        for i in range(1, cycles + 1):
            _emit("cycle_start", i=i, cycle=i, total=cycles)
            log(f"[runner] Cycle #{i} — invoking {original_entry}")

            t0 = time.time()
            err = None
            rc = 0

            backup_cycle = {"CYCLE_INDEX": os.environ.get("CYCLE_INDEX"), "CYCLE_TOTAL": os.environ.get("CYCLE_TOTAL")}
            os.environ["CYCLE_INDEX"] = str(i)
            os.environ["CYCLE_TOTAL"] = str(cycles)

            try:
                if i == 1 and precond_first == 1 and callable(precond_fn):
                    log("[runner] Precondition() — running once in cycle #1")
                    pre_rc = precond_fn()
                    if pre_rc is None:
                        pre_rc = 0
                    pre_rc = int(pre_rc)
                    if pre_rc != 0:
                        raise RuntimeError(f"precondition failed rc={pre_rc}")

                rc_val = fn()
                if rc_val is None:
                    rc = 0
                else:
                    rc = int(rc_val)

            except SystemExit as e:
                rc = int(e.code) if isinstance(e.code, int) else 1
                err = f"SystemExit({e.code!r})"

            except BaseException as e:
                rc = 1
                err = repr(e)
                tb = traceback.format_exc()
                _emit("cycle_exception", i=i, error=err, trace=tb.splitlines()[-120:])  # tail only

            finally:
                if backup_cycle["CYCLE_INDEX"] is None:
                    os.environ.pop("CYCLE_INDEX", None)
                else:
                    os.environ["CYCLE_INDEX"] = backup_cycle["CYCLE_INDEX"]  # type: ignore
                if backup_cycle["CYCLE_TOTAL"] is None:
                    os.environ.pop("CYCLE_TOTAL", None)
                else:
                    os.environ["CYCLE_TOTAL"] = backup_cycle["CYCLE_TOTAL"]  # type: ignore

            dur = round(time.time() - t0, 3)
            ok = (rc == 0)
            per_cycle.append({"i": i, "ok": ok, "rc": rc, "dur_sec": dur, "err": err})
            _emit("cycle_end", i=i, ok=ok, rc=rc, dur_sec=dur)
            log(f"[runner] Cycle #{i} {'✓ PASS' if ok else '✗ FAIL'} rc={rc} ({dur:.2f}s)")

            overall_rc = max(overall_rc, 0 if ok else 1)

            if not ok and stop_on_fail:
                log("[runner] STOP_ON_FAIL=1 — aborting further cycles")
                break

            if i < cycles and interval > 0:
                time.sleep(interval)

    except BaseException as e:
        overall_rc = 1
        tb = traceback.format_exc()
        _emit("runner_exception", error=repr(e), trace=tb.splitlines()[-160:])
        log(f"[runner] EXCEPTION: {e!r}")

    finally:
        _emit("runner_end", name=name, ok=(overall_rc == 0), rc=overall_rc, cycles=per_cycle)
        log(f"[runner] END    {name} rc={overall_rc}")
        _restore_env(env_backup)

    return int(overall_rc)


if __name__ == "__main__":
    sys.exit(run())
