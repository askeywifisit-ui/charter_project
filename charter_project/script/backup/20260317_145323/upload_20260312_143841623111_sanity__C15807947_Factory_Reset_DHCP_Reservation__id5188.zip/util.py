# -*- coding: utf-8 -*-
import os, json, time, shlex, subprocess, re
from typing import Any, Dict, Optional, Tuple, List

def jlog(event: str, **fields: Any) -> None:
    obj = {"event": event}
    obj.update(fields)
    print(json.dumps(obj, ensure_ascii=False), flush=True)

def slog(msg: str) -> None:
    print(msg, flush=True)

def q(s: str) -> str:
    return shlex.quote(str(s))

def run_cmd(cmd: str, timeout: float = 30.0, env: Optional[Dict[str, str]] = None) -> Tuple[int, str, str, float]:
    """
    Run shell command locally. Returns (rc, stdout, stderr, sec).
    """
    t0 = time.time()
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
    try:
        out, err = p.communicate(timeout=timeout)
        rc = p.returncode
    except subprocess.TimeoutExpired:
        p.kill()
        out, err = p.communicate()
        rc = 124
    sec = time.time() - t0
    return rc, out.decode(errors="ignore"), err.decode(errors="ignore"), sec

_JSON_RE = re.compile(r'\{.*\}', re.S)

def parse_last_json(text: str) -> Optional[Dict[str, Any]]:
    """
    Find and parse the last JSON object in text.
    """
    # common case: whole stdout is json
    s = text.strip()
    if s.startswith("{") and s.endswith("}"):
        try:
            return json.loads(s)
        except Exception:
            pass
    # fallback: search for last {...}
    matches = list(_JSON_RE.finditer(text))
    for m in reversed(matches):
        chunk = m.group(0)
        try:
            return json.loads(chunk)
        except Exception:
            continue
    return None

def retry(fn, attempts: int, wait_sec: float, on_fail_event: str, **ctx):
    last = None
    for i in range(1, attempts+1):
        try:
            return fn(i)
        except Exception as e:
            last = e
            jlog(on_fail_event, attempt=i, attempts=attempts, error=str(e), **ctx)
            if i < attempts and wait_sec > 0:
                time.sleep(wait_sec)
    if last:
        raise last
    raise RuntimeError("retry failed")
