# C15807947_Factory_Reset_DHCP_Reservation

## 1) 目的 / 覆蓋範圍
- 驗證 DHCP reservation 的新增/更新/刪除或 reset 後行為。

## 2) 前置條件 / 環境
- 需可透過平台/工具對 DHCP reservation API 操作。
- 注意：若目標 IP 已被占用，可能回 422（例如 used by Netgear）。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- （manifest 未包含常見 env 或解析不到；可直接查看 zip 內 manifest.yaml）

## 5) PASS/FAIL 判定
- PASS：reservation 操作成功且驗證點符合預期。
- FAIL：422/衝突或驗證點不符（需看 log）。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807947_Factory_Reset_DHCP_Reservation

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807947_Factory_Reset_DHCP_Reservation

This script implements the testcase core flow (UI + serial steps are replaced by API/SSH):
1) Set DHCP reservation (MAC -> IP) via **NOC API**
2) Verify the reservation is present on the CPE via SSH (reads `DHCP_reserved_IP` via `tools/cpe_ssh.py --cmd dhcp`)
3) Trigger **factory reset** via NOC API
4) Verify the reservation is removed (both **NOC** + **CPE**)

**WiFi connect / client DHCP renew** is intentionally skipped.

## Required environment variables

### NOC
- `PROFILES_FILE` + `NOC_PROFILE` (recommended)  
  or directly set:
  - `NOC_BASE`, `CUSTOMER_ID`, `NOC_EMAIL`, `NOC_PASSWORD`

### CPE
- `CPE_HOST` (default: 192.168.1.1)
- `CPE_SSH_USER` (default: operator)
- `SSH_PASSWORD` or `CPE_SSH_PASSWORD` (default fallback: 123456789)

### Test data
- `LAN_TEST_MAC` (or `TEST_MAC`) : MAC address to reserve
- `TEST_RESERVED_IP`            : Reserved IP to set
- `TEST_HOSTNAME`               : Optional hostname label

## Optional tuning
- `RESERVED_WAIT_TIMEOUT_SEC` (default: 180)
- `RESERVED_WAIT_INTERVAL_SEC` (default: 5)
- `RESERVED_REQUIRE_HOSTNAME` (default: 0)

### Factory reset
- `DO_FACTORY_RESET` (default: 1)
- `FACTORY_RESET_MODE`:
  - `full` (default): full factory reset (all flags True)
  - `network_only`: only reset networkConfiguration
  - `empty`: send empty payload
- `POST_RESET_CLOUD_TIMEOUT_SEC` (default: 600)
- `POST_RESET_NO_RESV_TIMEOUT_SEC` (default: 600)



### Serial mute (recommended in automation environments)
To reduce the risk of *any local serial agent* logging in during factory reset / boot window, you can enable a best-effort serial mute flag:
- `RESET_MUTE_SECS` (default: 300, set to 0 to disable)
- `SERIAL_MUTE_STRICT` (default: 0, set to 1 to fail the test if serial_mute tool invocation fails)

This writes `/home/da40/charter/var/serial.mute` via `tools/serial_mute.py`.

### IP conflict handling (recommended)
If `TEST_RESERVED_IP` is already reserved by another MAC, NOC returns HTTP 422.
Set:
- `ON_IP_CONFLICT`:
  - `pick_free` (default): auto-pick an unused IP from the same /24
  - `steal`: delete the conflicting MAC reservation, then continue using the requested IP
  - `fail`: stop and report the conflict
- `RESERVED_IP_POOL_START` (default: 200)
- `RESERVED_IP_POOL_END` (default: 250)

## Notes
- The script runs `precondition()` once (cycle #1): cloud check -> node-id -> ensure SSH ready.
- Each cycle starts by re-checking SSH readiness; if port 22 is closed it will issue `ssh-enable` via NOC (attempts=2) then probe `uptime`.
```

```
