#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""C15807947_Factory_Reset_DHCP_Reservation

This script focuses on the core requirement:
1) Set DHCP reservation via NOC API
2) Verify reservation appears on CPE (ovsh DHCP_reserved_IP via tools/cpe_ssh.py)
3) Factory reset (via NOC API)
4) Verify the reservation is removed (both NOC + CPE)

NOTE:
- WiFi connect / client renew is intentionally skipped (tools.zip wifi-connect known issue).
"""

import os
import time
from util import jlog, run_cmd, q
from profile import load_profile
from precondition import precondition as _precondition
from ssh_ready import ensure_ssh_ready
from dhcp_api import (
    dhcp_resv_set,
    dhcp_resv_del_best_effort,
    dhcp_resv_list,
    dhcp_resv_find_by_mac,
    find_resv_by_ip,
    factory_reset,
)
from dhcp_verify import wait_for_reserved, wait_for_no_reserved

_NODE_ID = None

def precondition():
    global _NODE_ID
    load_profile()  # populate NOC_BASE/CUSTOMER_ID convenience if profiles are used
    _NODE_ID = _precondition()
    return {"node_id": _NODE_ID}

def run(cycle=None, total=None):
    global _NODE_ID
    load_profile()

    test_name = os.environ.get("TEST_NAME", "C15807947_Factory_Reset_DHCP_Reservation")
    mac = (os.environ.get("LAN_TEST_MAC") or os.environ.get("TEST_MAC") or "").strip()
    ip = (os.environ.get("TEST_RESERVED_IP") or "").strip()
    hostname = (os.environ.get("TEST_HOSTNAME") or os.environ.get("TEST_HOST") or "lan_test0").strip()

    on_conflict = (os.environ.get("ON_IP_CONFLICT") or "pick_free").strip().lower()
    pool_start = int(os.environ.get("RESERVED_IP_POOL_START", "200") or "200")
    pool_end = int(os.environ.get("RESERVED_IP_POOL_END", "250") or "250")

    if not mac or not ip:
        jlog("config_error", mac=mac, ip=ip, hint="Set LAN_TEST_MAC/TEST_MAC and TEST_RESERVED_IP")
        return 2

    if not _NODE_ID:
        _NODE_ID = _precondition()

    # Per-cycle: ensure ssh still reachable; if not, try NOC ssh-enable (attempts=2) then probe uptime.
    ok = ensure_ssh_ready(_NODE_ID)
    if not ok:
        jlog("ssh_not_ready", node_id=_NODE_ID)
        return 3

    jlog("test_start", test=test_name, cycle=cycle, total=total, node_id=_NODE_ID, mac=mac, ip=ip, hostname=hostname)

    # Best-effort cleanup (avoid 'already exists' / stale for OUR MAC)
    dhcp_resv_del_best_effort(_NODE_ID, mac)

    # If requested IP is already reserved by another MAC, handle according to ON_IP_CONFLICT:
    #   - fail: stop with clear message
    #   - steal: delete the other MAC reservation then continue using requested IP
    #   - pick_free: pick an unused IP from the same /24 pool (default)
    try:
        resv = dhcp_resv_list(_NODE_ID)
    except Exception as e:
        jlog("dhcp_resv_list_warn", error=str(e))
        resv = []

    conflict_mac = find_resv_by_ip(resv, ip)
    if conflict_mac and conflict_mac.lower() != mac.lower():
        jlog("ip_conflict", requested_ip=ip, requested_mac=mac, conflict_mac=conflict_mac, mode=on_conflict)
        if on_conflict == "steal":
            dhcp_resv_del_best_effort(_NODE_ID, conflict_mac)
        elif on_conflict == "pick_free":
            # pick free ip in same /24 (based on requested ip prefix)
            parts = ip.split(".")
            prefix = ".".join(parts[:3]) if len(parts) == 4 else "192.168.1"
            used = set((it.get("ip") or "").strip() for it in (resv or []))
            picked = None
            for last in range(pool_start, pool_end + 1):
                cand = f"{prefix}.{last}"
                if cand not in used:
                    picked = cand
                    break
            if not picked:
                raise RuntimeError(f"no_free_ip_in_pool prefix={prefix} start={pool_start} end={pool_end} used={len(used)}")
            jlog("ip_picked_free", old_ip=ip, new_ip=picked, pool_start=pool_start, pool_end=pool_end)
            ip = picked
        else:
            raise RuntimeError(f"requested_ip_conflict ip={ip} conflict_mac={conflict_mac} (set ON_IP_CONFLICT=pick_free or steal)")

    # Set reservation via NOC API
    dhcp_resv_set(_NODE_ID, mac, ip, host_name=hostname)

    # Verify reservation shows up on CPE (eventual consistency)
    wait_for_reserved(mac=mac, ip=ip, hostname=hostname)

    # Factory reset + verify cleared
    do_reset = (os.environ.get("DO_FACTORY_RESET", "1").strip().lower() in ("1","true","yes","y","on"))
    if do_reset:
        _factory_reset_and_verify_cleared(node_id=_NODE_ID, mac=mac)
    else:
        jlog("factory_reset_skipped", reason="DO_FACTORY_RESET=0")

    jlog("test_end", test=test_name, ok=True)
    return 0


def _cpe_info_cli() -> str:
    tools = (os.environ.get("TOOLS_PATH", "/home/da40/charter/tools") or "").rstrip("/")
    return q(tools + "/cpe_info")


def _serial_mute_cli() -> str:
    tools = (os.environ.get("TOOLS_PATH", "/home/da40/charter/tools") or "").rstrip("/")
    return q(tools + "/serial_mute.py")


def _maybe_serial_mute(stage: str) -> None:
    """Best-effort: set a global serial mute flag to avoid any local serial agent
    from logging in during factory reset / boot window.

    This does NOT prevent a human from manually opening a serial session.
    """
    secs_s = (os.environ.get("RESET_MUTE_SECS", os.environ.get("SERIAL_MUTE_SECS", "300")) or "300").strip()
    try:
        secs = int(float(secs_s))
    except Exception:
        secs = 300

    if secs <= 0:
        # 0 disables mute
        return

    cmd = f"{_serial_mute_cli()} --set {secs}"
    rc, out, err, sec = run_cmd(cmd, timeout=10)
    jlog(
        "serial_mute",
        stage=stage,
        secs=secs,
        rc=rc,
        sec=sec,
        out=(out or "").strip()[:80],
        err=(err or "").strip()[:120],
    )

    strict = (os.environ.get("SERIAL_MUTE_STRICT", "0").strip().lower() in ("1", "true", "yes", "y", "on"))
    if strict and rc != 0:
        raise RuntimeError(f"serial_mute_failed rc={rc} cmd={cmd}")


def _wait_cloud_connected() -> None:
    timeout = float(os.environ.get("POST_RESET_CLOUD_TIMEOUT_SEC", os.environ.get("CLOUD_AFTER_RESET_TIMEOUT_SEC", "600")) or "600")
    interval = float(os.environ.get("POST_RESET_CLOUD_INTERVAL_SEC", "5") or "5")

    cmd = f"{_cpe_info_cli()} --cloud"
    t0 = time.time()
    attempt = 0
    while time.time() - t0 < timeout:
        attempt += 1
        rc, out, err, sec = run_cmd(cmd, timeout=min(interval + 10, 30))
        ok = (rc == 0) and ("Connected" in (out or ""))
        jlog("cloud_after_reset_poll", attempt=attempt, ok=ok, rc=rc, sec=sec, out=(out or "").strip()[:120])
        if ok:
            return
        time.sleep(max(0.2, interval))
    raise RuntimeError("cloud_not_connected_after_factory_reset")


def _wait_noc_no_reservation(node_id: str, mac: str) -> None:
    timeout = float(os.environ.get("POST_RESET_NO_RESV_TIMEOUT_SEC", "600") or "600")
    interval = float(os.environ.get("POST_RESET_NO_RESV_INTERVAL_SEC", "10") or "10")
    t0 = time.time()
    attempt = 0
    last = None
    while time.time() - t0 < timeout:
        attempt += 1
        try:
            resv = dhcp_resv_list(node_id)
            last = resv
            found = dhcp_resv_find_by_mac(resv or [], mac)
            gone = (found is None)
            jlog("noc_no_resv_poll", attempt=attempt, gone=gone, mac=mac, sample=(resv or [])[:5])
            if gone:
                jlog("assert_noc_no_resv_ok", mac=mac)
                return
        except Exception as e:
            jlog("noc_no_resv_poll_warn", attempt=attempt, error=str(e))
        time.sleep(max(0.2, interval))

    jlog("assert_noc_no_resv_fail", mac=mac, sample=(last or [])[:10])
    raise RuntimeError("reservation_still_present_on_noc_after_reset")


def _factory_reset_and_verify_cleared(*, node_id: str, mac: str) -> None:
    # Choose reset mode
    mode = (os.environ.get("FACTORY_RESET_MODE", "full") or "full").strip().lower()
    if mode in ("network", "network_only", "networkconfiguration"):
        options = {"networkConfiguration": True}
    elif mode in ("empty", "none"):
        options = {}
    else:
        options = None  # full

    jlog("step_start", name="factory_reset", mode=mode)
    _maybe_serial_mute("before_factory_reset")
    factory_reset(node_id, options=options)
    jlog("step_end", name="factory_reset", ok=True)

    # Wait for device to come back
    jlog("step_start", name="post_reset_wait")
    _wait_cloud_connected()
    ok_ssh = ensure_ssh_ready(node_id)
    if not ok_ssh:
        raise RuntimeError("ssh_not_ready_after_factory_reset")
    jlog("step_end", name="post_reset_wait", ok=True)

    # Verify reservation removed from both NOC + CPE
    jlog("step_start", name="post_reset_verify_no_reservation")
    _wait_noc_no_reservation(node_id, mac)
    wait_for_no_reserved(mac)
    jlog("step_end", name="post_reset_verify_no_reservation", ok=True)

if __name__ == "__main__":
    import sys
    sys.exit(run())
