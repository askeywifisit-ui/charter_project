# -*- coding: utf-8 -*-
"""NOC DHCP reservation helpers (script-local).

This script previously called tools/noc_api_cli.py, but in some INT
environments the endpoint:

  GET /api/Customers/{customerId}/nodes/{nodeId}

may return HTTP 404 with a LoopBack message like:

  "Shared class \"Customer\" has no method handling GET /nodes/<nodeId>"

That breaks locationId auto-resolution.

To keep the test stable, we implement a tiny HTTP client here and add a
fallback resolver:

  - try GET /Customers/{cid}/nodes/{nodeId}
  - if not supported, try GET /Customers/{cid}/nodes?filter=... (id==nodeId)
  - if still not supported, try GET /Customers/{cid}/nodes (list) and search

You can always override by setting env NOC_LOCATION_ID (recommended if your
backend has none of the node endpoints).
"""

from __future__ import annotations

import json
import os
import time
import urllib.parse
from typing import Any, Dict, Optional

import requests

from profile import load_profile
from util import jlog


def _bool_env(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return str(v).strip().lower() in ("1", "true", "yes", "y", "on")


def _noc_params() -> Dict[str, Any]:
    prof = load_profile() or {}
    bearer_default = bool(prof.get("bearer", False))
    insecure_default = bool(prof.get("insecure", False))
    return {
        "base": (prof.get("base") or os.environ.get("NOC_BASE") or os.environ.get("BASE") or "").rstrip("/"),
        "customer_id": (prof.get("customer_id") or prof.get("customerId") or os.environ.get("NOC_CUSTOMER_ID") or os.environ.get("CUSTOMER_ID") or "").strip(),
        "email": (prof.get("email") or os.environ.get("NOC_EMAIL") or os.environ.get("EMAIL") or "").strip(),
        "password": (prof.get("password") or os.environ.get("NOC_PASSWORD") or os.environ.get("PASSWORD") or "").strip(),
        "bearer": _bool_env("NOC_BEARER", bearer_default),
        "insecure": _bool_env("NOC_INSECURE", insecure_default),
        "timeout": int(os.environ.get("NOC_TIMEOUT_SEC", "20")),
        "retry_412": int(os.environ.get("NOC_RETRY_412", os.environ.get("RETRY_412", "0")) or "0"),
        "retry_wait": float(os.environ.get("NOC_RETRY_WAIT", os.environ.get("RETRY_WAIT", "10")) or "10"),
    }


def _api(base: str, path: str) -> str:
    if not path.startswith("/"):
        path = "/" + path
    return f"{base}/api{path}"


def _auth_headers(token: str, bearer: bool) -> Dict[str, str]:
    if not token:
        return {}
    return {"Authorization": (f"Bearer {token}" if bearer else token)}


def _login(base: str, email: str, password: str, *, bearer: bool, insecure: bool, timeout: int) -> str:
    url = _api(base, "/Customers/login")
    r = requests.post(
        url,
        json={"email": email, "password": password},
        headers={"Content-Type": "application/json"},
        timeout=timeout,
        verify=not insecure,
    )
    if r.status_code >= 400:
        raise RuntimeError(f"noc_login_failed http={r.status_code} body={r.text[:200]}")
    j = r.json() if r.text else {}
    tok = j.get("id")
    if not tok:
        raise RuntimeError("noc_login_ok_but_token_missing")
    return str(tok)


def _req_retry_412(
    method: str,
    url: str,
    *,
    headers: Dict[str, str],
    data: Any = None,
    json_data: Any = None,
    timeout: int,
    insecure: bool,
    retry_412: int,
    retry_wait: float,
) -> requests.Response:
    last = None
    for i in range(retry_412 + 1):
        r = requests.request(
            method,
            url,
            headers=headers,
            data=data,
            json=json_data,
            timeout=timeout,
            verify=not insecure,
        )
        if r.status_code != 412:
            return r
        last = r
        if i < retry_412:
            time.sleep(retry_wait)
    return last if last is not None else r


def _try_get_json(url: str, *, headers: Dict[str, str], timeout: int, insecure: bool) -> tuple[int, Any, str]:
    r = requests.get(url, headers=headers, timeout=timeout, verify=not insecure)
    txt = r.text or ""
    if r.status_code >= 400:
        return r.status_code, None, txt
    try:
        return r.status_code, r.json(), txt
    except Exception:
        return r.status_code, None, txt


def resolve_location_id(node_id: str, *, base: str, customer_id: str, token: str, bearer: bool,
                        insecure: bool, timeout: int) -> str:
    # Explicit override (best practice when backend changes)
    loc_override = (os.environ.get("NOC_LOCATION_ID") or os.environ.get("LOCATION_ID") or "").strip()
    if loc_override:
        jlog("noc_location_override", location_id=loc_override)
        return loc_override

    h = _auth_headers(token, bearer)

    # 1) Preferred: GET /Customers/{cid}/nodes/{nodeId}
    url1 = _api(base, f"/Customers/{customer_id}/nodes/{node_id}")
    sc, j, txt = _try_get_json(url1, headers=h, timeout=timeout, insecure=insecure)
    if sc < 400 and isinstance(j, dict) and j.get("locationId"):
        return str(j["locationId"])

    # 2) Fallback: GET /Customers/{cid}/nodes?filter=... (id==nodeId)
    flt = urllib.parse.quote(json.dumps({"where": {"id": node_id}}))
    url2 = _api(base, f"/Customers/{customer_id}/nodes?filter={flt}")
    sc2, j2, txt2 = _try_get_json(url2, headers=h, timeout=timeout, insecure=insecure)
    if sc2 < 400 and isinstance(j2, list) and j2:
        loc = (j2[0] or {}).get("locationId")
        if loc:
            jlog("noc_location_resolved", method="nodes_filter_id", location_id=loc)
            return str(loc)

    # 3) Fallback: list all nodes then search
    url3 = _api(base, f"/Customers/{customer_id}/nodes")
    sc3, j3, txt3 = _try_get_json(url3, headers=h, timeout=timeout, insecure=insecure)
    if sc3 < 400 and isinstance(j3, list):
        for it in j3:
            if not isinstance(it, dict):
                continue
            nid = str(it.get("id") or it.get("nodeId") or "")
            if nid == node_id:
                loc = it.get("locationId")
                if loc:
                    jlog("noc_location_resolved", method="nodes_list", location_id=loc)
                    return str(loc)

    # If we reached here, show a short diagnostic
    diag = {
        "try1": {"url": url1, "status": sc, "body": (txt[:120] if txt else "")},
        "try2": {"url": url2, "status": sc2, "body": (txt2[:120] if txt2 else "")},
        "try3": {"url": url3, "status": sc3, "body": (txt3[:120] if txt3 else "")},
    }
    raise RuntimeError(f"cannot_resolve_location_id node_id={node_id} diag={diag}")


def _ensure_session(node_id: str) -> Dict[str, Any]:
    p = _noc_params()
    base = p["base"]
    customer_id = p["customer_id"]
    if not base or not customer_id:
        raise RuntimeError(f"noc_params_missing base='{base}' customer_id='{customer_id}'")
    if not p["email"] or not p["password"]:
        raise RuntimeError("noc_credentials_missing (email/password). put them in PROFILES_FILE")

    token = _login(base, p["email"], p["password"], bearer=p["bearer"], insecure=p["insecure"], timeout=p["timeout"])
    loc = resolve_location_id(
        node_id,
        base=base,
        customer_id=customer_id,
        token=token,
        bearer=p["bearer"],
        insecure=p["insecure"],
        timeout=p["timeout"],
    )
    return {"base": base, "customer_id": customer_id, "token": token, "location_id": loc, **p}


def dhcp_resv_set(node_id: str, mac: str, ip: str, host_name: str = "") -> None:
    s = _ensure_session(node_id)
    url = _api(s["base"], f"/Customers/{s['customer_id']}/locations/{s['location_id']}/networkConfiguration/dhcpReservations/{urllib.parse.quote(mac.lower(), safe='')}" )
    headers = _auth_headers(s["token"], s["bearer"])
    headers["Content-Type"] = "application/x-www-form-urlencoded"
    data = {"ip": str(ip)}
    if host_name:
        data["hostName"] = str(host_name)

    t0 = time.time()
    r = _req_retry_412(
        "PUT",
        url,
        headers=headers,
        data=data,
        json_data=None,
        timeout=s["timeout"],
        insecure=s["insecure"],
        retry_412=s["retry_412"],
        retry_wait=s["retry_wait"],
    )
    sec = time.time() - t0
    ok = r.status_code < 400
    jlog("dhcp_resv_set", ok=ok, http=r.status_code, sec=sec, mac=mac, ip=ip, host_name=host_name, location_id=s["location_id"])
    if not ok:
        raise RuntimeError(f"dhcp_resv_set_http_failed http={r.status_code} body={r.text[:200]}")


def dhcp_resv_list(node_id: str) -> list[dict]:
    """GET location-scoped DHCP reservations.

    Expected endpoint:
      GET /Customers/{cid}/locations/{locationId}/networkConfiguration/dhcpReservations

    Return a normalized list of dicts with keys: mac, ip, hostName.
    """
    s = _ensure_session(node_id)
    url = _api(s["base"], f"/Customers/{s['customer_id']}/locations/{s['location_id']}/networkConfiguration/dhcpReservations")
    headers = _auth_headers(s["token"], s["bearer"])
    t0 = time.time()
    r = _req_retry_412(
        "GET",
        url,
        headers=headers,
        data=None,
        json_data=None,
        timeout=s["timeout"],
        insecure=s["insecure"],
        retry_412=s["retry_412"],
        retry_wait=s["retry_wait"],
    )
    sec = time.time() - t0
    ok = r.status_code < 400
    jlog("dhcp_resv_list", ok=ok, http=r.status_code, sec=sec, location_id=s["location_id"])
    if not ok:
        raise RuntimeError(f"dhcp_resv_list_failed http={r.status_code} body={r.text[:200]}")

    try:
        data = r.json() if r.text else []
    except Exception:
        data = []

    out: list[dict] = []
    # Common forms:
    # 1) list of objects: [{"mac": "..", "ip": "..", "hostName": ".."}, ...]
    # 2) dict keyed by mac: {"02:..": {"ip": "..", "hostName": ".."}, ...}
    if isinstance(data, list):
        for it in data:
            if not isinstance(it, dict):
                continue
            mac = (it.get("mac") or it.get("id") or "").strip()
            ip = (it.get("ip") or it.get("ipAddress") or "").strip()
            hn = (it.get("hostName") or it.get("hostname") or "").strip()
            if mac or ip or hn:
                out.append({"mac": mac.lower(), "ip": ip, "hostName": hn})
    elif isinstance(data, dict):
        for k, v in data.items():
            mac = str(k).strip().lower()
            if isinstance(v, dict):
                ip = (v.get("ip") or v.get("ipAddress") or "").strip()
                hn = (v.get("hostName") or v.get("hostname") or "").strip()
            else:
                ip, hn = "", ""
            out.append({"mac": mac, "ip": ip, "hostName": hn})
    return out


def dhcp_resv_get(node_id: str, mac: str) -> tuple[int, Optional[dict]]:
    """Get a single DHCP reservation by MAC.

    Returns (http_status, data_or_none).
    - 200: returns normalized dict {mac, ip, hostName}
    - 404: not found
    - others: raises
    """
    s = _ensure_session(node_id)
    url = _api(
        s["base"],
        f"/Customers/{s['customer_id']}/locations/{s['location_id']}/networkConfiguration/dhcpReservations/{urllib.parse.quote(mac.lower(), safe='')}"
    )
    headers = _auth_headers(s["token"], s["bearer"])
    t0 = time.time()
    r = _req_retry_412(
        "GET",
        url,
        headers=headers,
        timeout=s["timeout"],
        insecure=s["insecure"],
        retry_412=s["retry_412"],
        retry_wait=s["retry_wait"],
    )
    sec = time.time() - t0
    if r.status_code == 404:
        jlog("dhcp_resv_get", ok=True, http=404, sec=sec, mac=mac, location_id=s["location_id"], note="not_found")
        return 404, None
    ok = r.status_code < 400
    jlog("dhcp_resv_get", ok=ok, http=r.status_code, sec=sec, mac=mac, location_id=s["location_id"])
    if not ok:
        raise RuntimeError(f"dhcp_resv_get_failed http={r.status_code} body={r.text[:200]}")

    try:
        data = r.json() if r.text else {}
    except Exception:
        data = {}

    if isinstance(data, dict):
        ip = (data.get("ip") or data.get("ipAddress") or "").strip()
        hn = (data.get("hostName") or data.get("hostname") or "").strip()
        return 200, {"mac": mac.lower(), "ip": ip, "hostName": hn}
    return 200, {"mac": mac.lower(), "ip": "", "hostName": ""}


def find_resv_by_ip(resv_list: list[dict], ip: str) -> Optional[str]:
    """Return MAC (lowercase) that currently reserves the IP, if any."""
    ip = (ip or "").strip()
    for it in resv_list or []:
        if not isinstance(it, dict):
            continue
        if (it.get("ip") or "").strip() == ip:
            mac = (it.get("mac") or "").strip().lower()
            if mac:
                return mac
    return None


def dhcp_resv_del_best_effort(node_id: str, mac: str) -> None:
    try:
        s = _ensure_session(node_id)
    except Exception as e:
        jlog("dhcp_resv_del_skip", reason="noc_session_failed", error=str(e), mac=mac)
        return

    url = _api(s["base"], f"/Customers/{s['customer_id']}/locations/{s['location_id']}/networkConfiguration/dhcpReservations/{urllib.parse.quote(mac.lower(), safe='')}" )
    headers = _auth_headers(s["token"], s["bearer"])

    t0 = time.time()
    r = _req_retry_412(
        "DELETE",
        url,
        headers=headers,
        data=None,
        json_data=None,
        timeout=s["timeout"],
        insecure=s["insecure"],
        retry_412=s["retry_412"],
        retry_wait=s["retry_wait"],
    )
    sec = time.time() - t0
    jlog("dhcp_resv_del", http=r.status_code, sec=sec, mac=mac, location_id=s["location_id"])
    # best effort: ignore failures
    return


def factory_reset(node_id: str, *, options: Optional[dict] = None) -> None:
    """Trigger factory reset via NOC API.

    Endpoint:
      DELETE /Customers/{customerId}/locations/{locationId}/factoryReset

    options behavior aligns with tools/noc_api_cli.py:
      - options is None  → full reset (all flags True)
      - options is {}    → empty payload
      - options has keys → reset only those True fields
    """
    s = _ensure_session(node_id)
    url = _api(s["base"], f"/Customers/{s['customer_id']}/locations/{s['location_id']}/factoryReset")
    headers = _auth_headers(s["token"], s["bearer"])
    headers["Content-Type"] = "application/json"

    if options is None:
        payload = {
            "persons": True,
            "onboardingCheckpoints": True,
            "devices": True,
            "networkConfiguration": True,
            "wifiNetwork": True,
            "secondaryNetworks": True,
            "deviceFreeze": True,
            "deviceNicknames": True,
            "managers": True,
            "wanConfiguration": True,
        }
    else:
        payload = options

    t0 = time.time()
    r = _req_retry_412(
        "DELETE",
        url,
        headers=headers,
        json_data=payload,
        timeout=s["timeout"],
        insecure=s["insecure"],
        retry_412=s["retry_412"],
        retry_wait=s["retry_wait"],
    )
    sec = time.time() - t0
    ok = r.status_code < 400
    jlog("factory_reset", ok=ok, http=r.status_code, sec=sec, location_id=s["location_id"], options=list((payload or {}).keys()))
    if not ok:
        raise RuntimeError(f"factory_reset_failed http={r.status_code} body={r.text[:200]}")


def dhcp_resv_find_by_mac(resv_list: list[dict], mac: str) -> Optional[dict]:
    mac_n = (mac or "").strip().lower()
    for it in resv_list or []:
        if not isinstance(it, dict):
            continue
        if (it.get("mac") or "").strip().lower() == mac_n:
            return it
    return None
