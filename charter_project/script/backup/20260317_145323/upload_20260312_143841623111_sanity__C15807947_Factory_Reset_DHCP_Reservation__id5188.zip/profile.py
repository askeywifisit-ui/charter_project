# -*- coding: utf-8 -*-
import os, json
from typing import Any, Dict, Optional
from util import jlog

def load_profile() -> Optional[Dict[str, Any]]:
    """
    Load NOC profile from PROFILES_FILE and NOC_PROFILE.

    Recommended JSON format:
      {
        "SPECTRUM_INT": {
          "base": "https://...",
          "customer_id": "...",
          "email": "...",
          "password": "...",
          "ssh_password": "...",          # SSH password to set via NOC (and often equals operator password)
          "cpe_ssh_password": "..."       # optional explicit CPE operator password
        }
      }
    """
    path = os.environ.get("PROFILES_FILE") or os.environ.get("NOC_PROFILES_PATH") or os.path.expanduser("~/.secrets/noc_profiles.json")
    prof_name = (os.environ.get("NOC_PROFILE", "") or "SPECTRUM_INT").strip()
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        jlog("noc_profile_load_error", path=path, profile=prof_name, error=str(e))
        return None

    prof = data.get(prof_name) or data.get(prof_name.upper()) or data.get(prof_name.lower())
    if not prof:
        jlog("noc_profile_not_found", path=path, profile=prof_name, keys=list(data.keys())[:20])
        return None

    # best-effort export for downstream tools
    base = prof.get("base") or ""
    customer_id = prof.get("customer_id") or prof.get("customerId") or ""
    if base and not os.environ.get("NOC_BASE"):
        os.environ["NOC_BASE"] = str(base)
    if customer_id and not os.environ.get("NOC_CUSTOMER_ID"):
        os.environ["NOC_CUSTOMER_ID"] = str(customer_id)

    # CPE SSH password convenience
    cpe_pwd = os.environ.get("CPE_SSH_PASSWORD", "")
    if not cpe_pwd:
        cpe_pwd = prof.get("cpe_ssh_password") or prof.get("ssh_password") or prof.get("ssh_pass") or ""
        if cpe_pwd:
            os.environ["CPE_SSH_PASSWORD"] = str(cpe_pwd)

    return prof
