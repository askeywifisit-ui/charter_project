# -*- coding: utf-8 -*-
"""SSH readiness helpers (script-local).

Why this exists:
- tools.zip provides CLIs (cpe_ssh.py / noc_api_cli.py / cpe_info), but not a
  ready-to-use 'ensure ssh ready' helper.
- We keep the control logic (scan+enable+probe) inside each script zip for
  reproducibility and easier debugging.

Flow (aligned with the proven A2435638_Cycle_power_on_off_test_ssh logic):
1) Determine SSH password:
   - SSH_PASSWORD / CPE_SSH_PASSWORD / CPE_PASSWORD / CPE_PASS
   - else SSH_PASSWORD_DEFAULT (defaults to 123456789)
   - else cpe_info --password
2) Wait for TCP port 22 (with timeout)
3) Probe login by running tools/cpe_ssh.py --cmd uptime
4) If not ready: run NOC ssh-enable (retries) then re-check

External tools used:
- tools/cpe_info
- tools/cpe_ssh.py
- tools/noc_api_cli.py
"""

import os
import time
import socket

from util import jlog, run_cmd, q, parse_last_json, retry
from profile import load_profile


def _tools_path() -> str:
    return os.environ.get("TOOLS_PATH", "/home/da40/charter/tools").rstrip("/")


def _cpe_info_cli() -> str:
    return q(_tools_path() + "/cpe_info")


def _cpe_ssh_cli() -> str:
    return f"python3 {q(_tools_path() + '/cpe_ssh.py')}"


def _noc_cli() -> str:
    return f"python3 {q(_tools_path() + '/noc_api_cli.py')}"


def _first_env(*keys: str) -> str:
    for k in keys:
        v = os.environ.get(k)
        if v is None:
            continue
        s = str(v).strip()
        if s and s.lower() not in ("none", "null"):
            return s
    return ""


def _sanitize_customer_id(val: str) -> str:
    """Normalize customer id from env/profile.

    The runner's env injection sometimes includes inline comments from manifest.yaml.
    Example: "''  # override if not in profile". We strip these safely.
    """
    if val is None:
        return ""
    s = str(val).strip()
    if not s:
        return ""
    # strip inline comments
    if "#" in s:
        s = s.split("#", 1)[0].strip()
    # strip wrapping quotes
    if (len(s) >= 2) and ((s[0] == s[-1]) and s[0] in ("'", '"')):
        s = s[1:-1].strip()
    if s in ("''", '""'):
        return ""
    if s.lower() in ("none", "null"):
        return ""
    return s


def _get_ssh_password() -> str:
    # Preferred sources
    pw = _first_env("SSH_PASSWORD", "CPE_SSH_PASSWORD", "CPE_PASSWORD", "CPE_PASS")
    if pw:
        return pw

    # Default lab password
    dflt = _first_env("SSH_PASSWORD_DEFAULT") or "123456789"
    if dflt:
        return dflt

    # Fallback: cpe_info --password
    cmd = f"{_cpe_info_cli()} --password"
    rc, out, err, sec = run_cmd(cmd, timeout=15)
    if rc == 0:
        for line in (out or "").splitlines():
            s = line.strip()
            if not s:
                continue
            if s.lower().startswith("curl:"):
                continue
            return s
    return ""


def _tcp_open(host: str, port: int, per_try_timeout: float = 2.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=per_try_timeout):
            return True
    except Exception:
        return False


def _tcp_wait(host: str, port: int, timeout_sec: int, interval_sec: float = 2.0) -> bool:
    t0 = time.time()
    while time.time() - t0 < timeout_sec:
        if _tcp_open(host, port, per_try_timeout=min(2.0, interval_sec)):
            return True
        time.sleep(max(0.2, interval_sec))
    return False


def _noc_creds():
    prof = load_profile() or {}
    base = prof.get("base") or os.environ.get("NOC_BASE") or os.environ.get("BASE") or ""
    email = prof.get("email") or os.environ.get("NOC_EMAIL") or os.environ.get("EMAIL") or ""
    password = prof.get("password") or os.environ.get("NOC_PASSWORD") or os.environ.get("PASSWORD") or ""
    customer_id_raw = (
        prof.get("customer_id")
        or prof.get("customerId")
        or os.environ.get("NOC_CUSTOMER_ID")
        or os.environ.get("CUSTOMER_ID")
        or ""
    )
    customer_id = _sanitize_customer_id(customer_id_raw)
    return base, email, password, customer_id


def _ssh_enable_via_noc(node_id: str, ssh_pass: str) -> bool:
    base, email, password, customer_id = _noc_creds()
    if not customer_id:
        jlog("ssh_enable", ok=False, error="CUSTOMER_ID not set (set env CUSTOMER_ID or profile customer_id)")
        return False

    # Let noc_api_cli resolve location id internally if it can; if not, it will error with clear logs.
    timeout_min = int(os.environ.get("SSH_ENABLE_TIMEOUT_MIN", "120"))

    cmd = (
        f"{_noc_cli()} --base {q(base)} --customer-id {q(customer_id)} "
        f"--email {q(email)} --password {q(password)} "
        f"ssh-enable --node-id {q(node_id)} --ssh-pass {q(ssh_pass)} --timeout-min {timeout_min}"
    )

    jlog(
        "ssh_enable_cmd",
        node_id=node_id,
        customer_id=customer_id,
        timeout_min=timeout_min,
        noc_base=base,
        have_email=bool(email),
        note="cmd_redacted"
    )
    rc, out, err, sec = run_cmd(cmd, timeout=90)
    ok = (rc == 0)
    jlog("ssh_enable_end", ok=ok, rc=rc, sec=sec, stdout=(out or "").strip()[:200], stderr=(err or "").strip()[:200])
    return ok


def ensure_ssh_ready(node_id: str) -> bool:
    host = os.environ.get("CPE_HOST", "192.168.1.1")
    port = int(os.environ.get("CPE_SSH_PORT", "22"))

    # Accept both old/new names
    scan_timeout = int(float(os.environ.get("SSH_SCAN_TIMEOUT_SEC", os.environ.get("SSH_SCAN_TIMEOUT", "60"))))
    scan_interval = float(os.environ.get("SSH_SCAN_INTERVAL_SEC", os.environ.get("SSH_SCAN_INTERVAL", "2")))

    enable_retries = int(os.environ.get("SSH_ENABLE_RETRIES", os.environ.get("SSH_ENABLE_ATTEMPTS", "2")))
    wait_after_enable = int(float(os.environ.get("WAIT_AFTER_SSH_ENABLE_SEC", os.environ.get("SSH_ENABLE_WAIT_SEC", "60"))))

    ssh_user = os.environ.get("CPE_SSH_USER", os.environ.get("CPE_USER", "operator")) or "operator"
    ssh_pass = _get_ssh_password()

    ssh_timeout = float(os.environ.get("CPE_SSH_TIMEOUT_SEC", "30"))

    jlog(
        "step_start",
        name="ssh_ready",
        host=host,
        port=port,
        scan_timeout_sec=scan_timeout,
        scan_interval_sec=scan_interval,
        user=ssh_user,
        have_password=bool(ssh_pass),
        node_id=node_id,
    )

    def _probe() -> bool:
        cmd = (
            f"{_cpe_ssh_cli()} --host {q(host)} --user {q(ssh_user)} --password {q(ssh_pass)} "
            f"--timeout {q(str(ssh_timeout))} --cmd {q('uptime')}"
        )
        jlog("ssh_probe_start", host=host, user=ssh_user, cmd="uptime")
        rc, out, err, sec = run_cmd(cmd, timeout=ssh_timeout + 15)
        # cpe_ssh sometimes prints JSON; parse if possible for richer debug
        obj = parse_last_json(out) or parse_last_json(err)
        ok = (rc == 0)
        if isinstance(obj, dict) and "ok" in obj:
            ok = ok and bool(obj.get("ok"))
        sample = (out or "").strip().splitlines()[-2:]
        jlog("ssh_probe", ok=ok, rc=rc, sec=sec, sample=sample, stderr=(err or "").strip()[:160])
        return ok

    for attempt in range(1, enable_retries + 1):
        port_ok = _tcp_wait(host, port, timeout_sec=scan_timeout, interval_sec=scan_interval)
        jlog("ssh_port", ok=port_ok, attempt=attempt)

        if port_ok and _probe():
            # Ensure other helpers (dhcp_verify, etc.) can reuse the same password.
            # Keep it process-local only (does not persist outside this run).
            if ssh_pass and not os.environ.get("CPE_SSH_PASSWORD"):
                os.environ["CPE_SSH_PASSWORD"] = ssh_pass
            jlog("step_end", name="ssh_ready", ok=True)
            return True

        if not node_id:
            jlog("ssh_enable_skip", ok=False, error="node_id not available")
            break

        if not ssh_pass:
            jlog("ssh_enable_skip", ok=False, error="ssh_password not available")
            break

        jlog("ssh_enable_start", attempt=attempt, attempts=enable_retries, node_id=node_id)
        ok = _ssh_enable_via_noc(node_id=node_id, ssh_pass=ssh_pass)
        if not ok:
            jlog("ssh_enable_attempt_failed", attempt=attempt)
            continue

        if wait_after_enable > 0:
            jlog("ssh_enable_wait", seconds=wait_after_enable, attempt=attempt)
            time.sleep(wait_after_enable)

    jlog("step_end", name="ssh_ready", ok=False)
    return False
