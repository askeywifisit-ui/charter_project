# -*- coding: utf-8 -*-
import os
import time
from typing import Any, Dict, List, Tuple, Optional

from util import jlog, run_cmd, parse_last_json, q

def _tools_path() -> str:
    return os.environ.get("TOOLS_PATH", "/home/da40/charter/tools").rstrip("/")

def _extract_reserved(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    # cpe_ssh.py may return {"dhcp":{"reserved":[...], "leased":[...]}} or top-level keys
    reserved = data.get("reserved") or data.get("dhcp", {}).get("reserved") or []
    if not isinstance(reserved, list):
        return []
    return reserved

def _norm_mac(x: str) -> str:
    return (x or "").strip().lower()

def _row_mac(row: Dict[str, Any]) -> str:
    return _norm_mac(
        row.get("mac")
        or row.get("hw_addr")
        or row.get("hwAddr")
        or row.get("hwaddr")
        or row.get("hw_address")
        or row.get("hwAddress")
        or ""
    )

def _row_ip(row: Dict[str, Any]) -> str:
    return str(row.get("ip") or row.get("ip_addr") or row.get("ipAddr") or row.get("inet_addr") or "").strip()

def _row_hostname(row: Dict[str, Any]) -> str:
    return str(row.get("hostname") or row.get("hostName") or row.get("host_name") or "").strip()

def get_dhcp_reserved() -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    host = os.environ.get("CPE_HOST", "192.168.1.1")
    user = os.environ.get("CPE_SSH_USER", "operator")
    pw = (
        os.environ.get("CPE_SSH_PASSWORD")
        or os.environ.get("SSH_PASSWORD")
        or os.environ.get("CPE_PASSWORD")
        or os.environ.get("CPE_PASS")
        or os.environ.get("SSH_PASSWORD_DEFAULT")
        or "123456789"
    )
    timeout = float(os.environ.get("CPE_SSH_TIMEOUT_SEC", "30"))

    dump_retries = int(os.environ.get("DHCP_DUMP_RETRIES", "3"))
    dump_wait = float(os.environ.get("DHCP_DUMP_RETRY_WAIT_SEC", "2"))

    cmd = (
        f"python3 {q(_tools_path() + '/cpe_ssh.py')} "
        f"--host {q(host)} --user {q(user)} --password {q(pw)} "
        f"--timeout {q(str(timeout))} --cmd dhcp"
    )

    last_obj: Dict[str, Any] = {}
    last_reserved: List[Dict[str, Any]] = []

    for attempt in range(1, dump_retries + 1):
        rc, out, err, sec = run_cmd(cmd, timeout=timeout + 20)
        obj = parse_last_json(out) or parse_last_json(err) or {}
        # 'ok' may be false when tables empty; treat rc==0 and dict as success
        ok = (rc == 0) and isinstance(obj, dict)
        reserved = _extract_reserved(obj) if ok else []
        jlog(
            "dhcp_dump",
            ok=ok,
            rc=rc,
            sec=sec,
            reserved_count=(len(reserved) if isinstance(reserved, list) else 0),
            stderr=(err or "").strip()[:200],
        )
        if ok:
            last_obj = obj
            last_reserved = reserved
            break
        if attempt < dump_retries:
            time.sleep(max(0.2, dump_wait))

    return last_reserved, last_obj

def wait_for_reserved(mac: str, ip: str, hostname: str = "") -> None:
    """Poll CPE DHCP_reserved_IP until a MAC->IP reservation appears."""
    timeout = float(os.environ.get("RESERVED_WAIT_TIMEOUT_SEC", "180"))
    interval = float(os.environ.get("RESERVED_WAIT_INTERVAL_SEC", "5"))
    require_hostname = os.environ.get("RESERVED_REQUIRE_HOSTNAME", "0").strip().lower() in ("1","true","yes","y")

    mac_n = _norm_mac(mac)
    ip_n = (ip or "").strip()
    host_n = (hostname or "").strip()

    t0 = time.time()
    attempt = 0
    last_sample: List[Dict[str, Any]] = []

    while time.time() - t0 < timeout:
        attempt += 1
        reserved, _obj = get_dhcp_reserved()
        last_sample = reserved[:10] if isinstance(reserved, list) else []
        matches = []
        for r in reserved:
            if _row_mac(r) == mac_n and _row_ip(r) == ip_n:
                if require_hostname and host_n:
                    if _row_hostname(r) == host_n:
                        matches.append(r)
                else:
                    # hostname is optional because some platforms won't persist it
                    matches.append(r)

        found = bool(matches)
        jlog(
            "reserved_poll",
            attempt=attempt,
            found=found,
            mac=mac,
            ip=ip,
            hostname=hostname,
            sample=last_sample,
        )
        if found:
            jlog("assert_reserved_ok", mac=mac, ip=ip, hostname=hostname)
            return
        time.sleep(max(0.2, interval))

    jlog("assert_reserved_fail", mac=mac, ip=ip, hostname=hostname, sample=last_sample)
    raise RuntimeError("reserved_not_found_on_cpe")


def wait_for_no_reserved(mac: str) -> None:
    """Poll CPE DHCP_reserved_IP until the MAC reservation disappears."""
    timeout = float(os.environ.get("NO_RESERVED_WAIT_TIMEOUT_SEC", os.environ.get("POST_RESET_NO_RESV_TIMEOUT_SEC", "600")))
    interval = float(os.environ.get("NO_RESERVED_WAIT_INTERVAL_SEC", os.environ.get("POST_RESET_NO_RESV_INTERVAL_SEC", "10")))

    mac_n = _norm_mac(mac)
    t0 = time.time()
    attempt = 0
    last_sample: List[Dict[str, Any]] = []

    while time.time() - t0 < timeout:
        attempt += 1
        reserved, _obj = get_dhcp_reserved()
        last_sample = reserved[:10] if isinstance(reserved, list) else []
        found = False
        for r in reserved:
            if _row_mac(r) == mac_n:
                found = True
                break

        jlog(
            "no_reserved_poll",
            attempt=attempt,
            gone=(not found),
            mac=mac,
            sample=last_sample,
        )
        if not found:
            jlog("assert_no_reserved_ok", mac=mac)
            return
        time.sleep(max(0.2, interval))

    jlog("assert_no_reserved_fail", mac=mac, sample=last_sample)
    raise RuntimeError("reserved_still_present_on_cpe")
