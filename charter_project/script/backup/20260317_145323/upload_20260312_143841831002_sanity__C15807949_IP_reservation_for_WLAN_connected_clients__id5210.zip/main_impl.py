#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""C15807949 - IP reservation for WLAN connected clients.

This automation treats the Control PC's Wi-Fi NIC as the WLAN client.

Manual Test Plan mapping:
- Step 1  : Connect to Wi-Fi and obtain an IP
- Step 4  : Create DHCP reservation (UI) -> replaced by NOC API reservation
- Step 5  : Disconnect/reconnect and verify the same (reserved) IP
- Step 6  : Serial-console ovsh DHCP tables -> replaced by SSH DHCP dump
- Step 7-9: Delete reservation and verify it is gone (reserved table clear)

Notes:
- Default requirement: TEST_RESERVED_IP should differ from the initial DHCP lease.
  If AUTO_PICK_FREE_IP=1, the script will auto-pick a free IP in the same /24.
  If ALLOW_SAME_IP=1, the script will allow reserving the current IP.
"""

from __future__ import annotations

import os
import time
from typing import Set

from lib.util import jlog
from lib.precondition import precondition as _precondition
from lib.dhcp_api import (
    dhcp_resv_set,
    dhcp_resv_del_strict,
    dhcp_resv_del_best_effort,
    ensure_ip_not_reserved,
    dhcp_resv_clear_all_best_effort,
)
from lib.dhcp_verify import (
    assert_reserved,
    wait_for_lease,
    get_dhcp_tables,
    wait_for_reserved_absent,
)
from lib.wifi_client import (
    connect_from_cpe_creds,
    reconnect_and_get_ip,
    disconnect_best_effort,
)

_NODE_ID: str | None = None


def _used_ips_from_dhcp_tables(data: dict) -> Set[str]:
    reserved = data.get("reserved") or data.get("dhcp", {}).get("reserved") or []
    leased = data.get("leased") or data.get("dhcp", {}).get("leased") or []

    used: Set[str] = set()
    for r in reserved:
        ip = str(r.get("ip_addr") or r.get("ip") or "").strip()
        if ip:
            used.add(ip)
    for l in leased:
        ip = str(l.get("inet_addr") or l.get("ip_addr") or l.get("ip") or "").strip()
        if ip:
            used.add(ip)
    return used


def pick_free_ip(preferred_ip: str, used: Set[str]) -> str:
    """Pick a free IP in the same /24 by scanning upward, then wrapping."""
    preferred_ip = (preferred_ip or "").strip()
    if not preferred_ip or preferred_ip not in used:
        return preferred_ip

    parts = preferred_ip.split(".")
    if len(parts) != 4:
        return preferred_ip

    base = ".".join(parts[:3])
    try:
        start = int(parts[3])
    except Exception:
        return preferred_ip

    def cand(n: int) -> str:
        return f"{base}.{n}"

    for n in range(start + 1, 255):
        if n in (0, 1, 255):
            continue
        ip = cand(n)
        if ip not in used:
            return ip

    for n in range(2, max(2, start)):
        if n in (0, 1, 255):
            continue
        ip = cand(n)
        if ip not in used:
            return ip

    return preferred_ip


def precondition():
    global _NODE_ID
    _NODE_ID = _precondition()
    return {"node_id": _NODE_ID}


def run(cycle=None, total=None):
    global _NODE_ID

    test_name = os.environ.get("TEST_NAME", "C15807949_IP_reservation_for_WLAN_connected_clients")

    if not _NODE_ID:
        _NODE_ID = _precondition()

    hostname = (os.environ.get("TEST_HOSTNAME") or "wifi_test0").strip()
    reserved_ip = (os.environ.get("TEST_RESERVED_IP") or "").strip()

    auto_pick = int(os.environ.get("AUTO_PICK_FREE_IP", "1") or "1") == 1
    allow_same = int(os.environ.get("ALLOW_SAME_IP", "0") or "0") == 1
    cleanup_on_fail = int(os.environ.get("CLEANUP_ON_FAIL", "1") or "1") == 1
    delete_at_end = int(os.environ.get("DELETE_RESERVATION_AT_END", "1") or "1") == 1

    if not reserved_ip:
        raise RuntimeError("missing_env: TEST_RESERVED_IP")

    jlog(
        "test_start",
        test=test_name,
        cycle=cycle,
        total=total,
        wifi_iface=os.environ.get("WIFI_IFACE"),
        reserved_ip=reserved_ip,
        hostname=hostname,
        node_id=_NODE_ID,
    )

    reservation_set = False
    reservation_deleted = False
    wifi_mac = ""
    initial_ip = ""

    try:
        # Optional: clear all NOC reservations (best-effort; affects entire location)
        if int(os.environ.get("CLEAR_ALL_NOC_DHCP_RESERVATIONS", "0") or "0") == 1:
            prefix = (os.environ.get("CLEAR_ALL_NOC_DHCP_RESERVATIONS_HOSTNAME_PREFIX") or "").strip()
            dhcp_resv_clear_all_best_effort(_NODE_ID, hostname_prefix=prefix)

        # TP Step 1: connect Wi-Fi, obtain IP
        info1 = connect_from_cpe_creds()
        wifi_mac = (info1.get("mac") or "").strip().lower()
        initial_ip = (info1.get("ipv4") or "").strip()

        if not wifi_mac:
            raise RuntimeError("wifi_mac_missing")
        if not initial_ip:
            raise RuntimeError("wifi_ipv4_missing")

        # If preferred reserved IP equals current lease, auto-pick a different free IP (TP Step 4 requirement).
        if (reserved_ip == initial_ip) and (not allow_same):
            if not auto_pick:
                raise RuntimeError(
                    f"reserved_ip_equals_current_ip (TEST_RESERVED_IP={reserved_ip}) set ALLOW_SAME_IP=1 or AUTO_PICK_FREE_IP=1"
                )

        # Auto-pick if IP is in-use on CPE (leased/reserved) or equals current IP (unless allow_same).
        if auto_pick:
            try:
                data = get_dhcp_tables()  # logs dhcp_dump
                used = _used_ips_from_dhcp_tables(data or {})
                used.add(initial_ip)
                chosen = pick_free_ip(reserved_ip, used)
                if not allow_same and chosen == initial_ip:
                    # If picked same as current, force pick from next in /24 by adding it to used.
                    used.add(chosen)
                    chosen = pick_free_ip(chosen, used)
                if chosen and chosen != reserved_ip:
                    jlog(
                        "ip_autopick",
                        preferred_ip=reserved_ip,
                        chosen_ip=chosen,
                        reason="ip_in_use_or_equals_current",
                        current_ip=initial_ip,
                        used_count=len(used),
                    )
                    reserved_ip = chosen
                    os.environ["TEST_RESERVED_IP"] = reserved_ip
            except Exception as e:
                jlog("ip_autopick_skip", error=str(e))

        # TP Step 4: create DHCP reservation
        dhcp_resv_del_best_effort(_NODE_ID, wifi_mac)
        ensure_ip_not_reserved(_NODE_ID, reserved_ip, wifi_mac)
        dhcp_resv_set(_NODE_ID, wifi_mac, reserved_ip, hostname)
        reservation_set = True

        # Verify reservation exists on CPE
        assert_reserved(wifi_mac, reserved_ip, hostname)

        wait_after_set = float(os.environ.get("WAIT_AFTER_RESERVATION_SET_SEC", "5") or "5")
        if wait_after_set > 0:
            jlog("wait_after_reservation_set", seconds=wait_after_set)
            time.sleep(wait_after_set)

        # TP Step 5: disconnect/reconnect and verify client gets reserved IP
        info2 = reconnect_and_get_ip(expected_ip=reserved_ip)

        # TP Step 6: leased table eventually reflects client
        wait_for_lease(wifi_mac, reserved_ip)

        # TP Step 7-9: delete reservation, verify removed
        if delete_at_end:
            dhcp_resv_del_strict(_NODE_ID, wifi_mac)  # strict (TP Step 7)
            reservation_deleted = True
            jlog("reservation_delete_api_ok", mac=wifi_mac, ip=reserved_ip, hostname=hostname)

            # Primary pass/fail gate: actual CPE reserved table must no longer contain this reservation.
            wait_for_reserved_absent(wifi_mac, reserved_ip)
            jlog("reservation_absent_on_cpe_ok", mac=wifi_mac, ip=reserved_ip)

            # Secondary evidence only: record current CPE reserved count after delete.
            try:
                snap = get_dhcp_tables()
                r = snap.get("reserved") or snap.get("dhcp", {}).get("reserved") or []
                jlog("dhcp_dump_after_delete", ok=True, reserved_count=len(r), reserved_sample=(r[:5] if isinstance(r, list) else []))
            except Exception as e:
                jlog("dhcp_dump_after_delete", ok=False, error=str(e))

            # Evidence only: NOC/backend list may lag after delete. Do not fail the test on this signal.
            try:
                from lib.dhcp_api import dhcp_resv_list
                noc_items = dhcp_resv_list(_NODE_ID)
                mac_n = wifi_mac.strip().lower()
                hits = []
                for item in (noc_items or []):
                    item_mac = str(item.get("hw_addr") or item.get("mac") or "").strip().lower()
                    item_ip = str(item.get("ip_addr") or item.get("ip") or "").strip()
                    if item_mac == mac_n:
                        hits.append({"mac": item_mac, "ip": item_ip, "raw": item})
                jlog(
                    "reservation_absent_on_noc_observed",
                    ok=(len(hits) == 0),
                    mac=wifi_mac,
                    ip=reserved_ip,
                    noc_count=len(noc_items or []),
                    hit_count=len(hits),
                    hit_sample=hits[:3],
                )
            except Exception as e:
                jlog("reservation_absent_on_noc_observed", ok=False, error=str(e), mac=wifi_mac, ip=reserved_ip)

        jlog(
            "test_end",
            test=test_name,
            ok=True,
            wifi_iface=info2.get("iface"),
            mac=wifi_mac,
            initial_ip=initial_ip,
            reserved_ip=reserved_ip,
        )
        return 0

    finally:
        # Best-effort cleanup on failures (avoid double-delete if already deleted)
        if cleanup_on_fail and reservation_set and delete_at_end and (not reservation_deleted):
            try:
                dhcp_resv_del_best_effort(_NODE_ID, wifi_mac)
            except Exception:
                pass

        if int(os.environ.get("WIFI_DISCONNECT_ON_EXIT", "1") or "1") == 1:
            try:
                iface = (os.environ.get("WIFI_IFACE") or "").strip()
                if iface:
                    disconnect_best_effort(iface)
            except Exception:
                pass


if __name__ == "__main__":
    import sys

    sys.exit(run())
