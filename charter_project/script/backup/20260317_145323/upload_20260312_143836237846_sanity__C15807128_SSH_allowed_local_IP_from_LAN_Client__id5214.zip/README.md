# C15807128_SSH_allowed_local_IP_from_LAN_Client

## 1) 目的 / 覆蓋範圍
- 驗證 SSH 可用性與安全策略（允許/拒絕、port 限制、帳密錯誤等）。

## 2) 前置條件 / 環境
- 需具備對應 client 位置（LAN/WAN）與連線條件。
- 若需 NOC enable SSH，請用 `.secrets`/`PROFILES_FILE`。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'70'

## 5) PASS/FAIL 判定
- PASS：SSH 行為符合預期策略。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# Phase-0: Get Token + Node-ID

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'70'

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text

# Phase-0: Get Token + Node-ID
- 目的：先驗證 API 帳密與序列 node-id 兩條通道沒問題。
- cycle_wrapper 會自動讀 manifest.yaml 的 env（若在本機直接 python3 main.py）。

## 依賴
- requests
- PyYAML  (wrapper 讀 manifest 用)

## 跑法（本機）
python3 main.py

## 常見錯誤
- 400 at /Customers/login → EMAIL/PASSWORD 未設定或錯誤
- node-id 抓不到 → 確認 SERIAL_* 參數、cpe_metrics_agent_serial.py 可執行且 --cmd node-id 正常

## Test Flow (Automation)

1. NOC login (get token)
2. Get node_id via serial metrics (with retry)
3. Get location_id via NOC API
4. Enable SSH Manager (SSHM) via kvConfigs PATCH (set sshAuthPasswd / timeout)
5. Validation
   - SSH to LAN IPv4 (br-home/BR_LAN IPv4): **ALLOW**
   - SSH to LAN Global IPv6 (br-home/BR_LAN global IPv6): **ALLOW**
   - SSH to LAN Link-local IPv6 (br-home/BR_LAN link-local IPv6): **DENY**

Notes:
- The DUT may print login banners (MOTD). This script wraps remote commands with markers and only parses output between markers.
```

```
