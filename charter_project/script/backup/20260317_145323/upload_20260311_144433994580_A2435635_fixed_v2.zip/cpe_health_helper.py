
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import subprocess
import time
from typing import Optional


def _env_bool(name: str, default: bool = False) -> bool:
    v = str(os.environ.get(name, "")).strip().lower()
    if not v:
        return default
    return v in ("1", "true", "yes", "y", "on")


def run_cpe_health_check(
    tools_path: Optional[str] = None,
    host: Optional[str] = None,
    user: Optional[str] = None,
    password: Optional[str] = None,
    timeout: int = 180,
) -> bool:
    """
    呼叫 cpe_ssh.py --cmd health 做一次 CPE health check。

    回傳值：
      True  -> overall == GOOD (rc=0)
      False -> 其它情況（health 失敗或無法取得結果）
    """

    # 環境變數可以關掉 health check（例如 debug 用途）
    if _env_bool("DISABLE_HEALTH_CHECK", False):
        print(json.dumps({
            "event": "health-check-skip",
            "reason": "DISABLE_HEALTH_CHECK",
        }))
        return True

    tools_path = tools_path or os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")

    host = host or os.environ.get("CPE_HEALTH_HOST", "192.168.1.1")
    user = user or os.environ.get("CPE_HEALTH_USER", "operator")
    password = password or os.environ.get("CPE_HEALTH_PASSWORD", "123456789")

    cpe_ssh = os.path.join(tools_path, "cpe_ssh.py")

    cmd = [
        "python3",
        cpe_ssh,
        "--host", host,
        "--user", user,
        "--password", password,
        "--cmd", "health",
    ]


    # Wait before running health check: prefer CPE_HEALTH_WAIT_SEC, then HEALTH_WAIT_SEC, default 15 seconds
    try:
        wait_raw = os.environ.get("CPE_HEALTH_WAIT_SEC") or os.environ.get("HEALTH_WAIT_SEC") or "15"
        wait_sec = int(wait_raw)
    except Exception:
        wait_sec = 15
    if wait_sec > 0:
        try:
            print(json.dumps({
                "event": "health-wait-before",
                "wait_sec": wait_sec,
            }))
        except Exception:
            pass
        time.sleep(wait_sec)

    print(json.dumps({
        "event": "health-check-start",
        "cmd": " ".join(cmd),
    }))

    try:
        proc = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        print(json.dumps({
            "event": "health-check-error",
            "error": "timeout",
            "timeout": timeout,
        }))
        return False
    except Exception as e:
        print(json.dumps({
            "event": "health-check-exception",
            "error": str(e),
        }))
        return False

    out = (proc.stdout or "").strip()
    err = (proc.stderr or "").strip()
    rc = proc.returncode

    print(json.dumps({
        "event": "health-check-raw",
        "rc": rc,
        "stdout_tail": out[-400:],
        "stderr_tail": err[-400:],
    }))

    if not out:
        print(json.dumps({
            "event": "health-check-parse-error",
            "reason": "empty_stdout",
        }))
        return False

    try:
        data = json.loads(out)
    except Exception as e:
        print(json.dumps({
            "event": "health-check-parse-error",
            "error": str(e),
        }))
        return False

    overall = data.get("overall")
    ok_flag = data.get("ok")
    fail_count = data.get("fail_count")
    skip_count = data.get("skip_count")

    print(json.dumps({
        "event": "health-check-result",
        "overall": overall,
        "ok": ok_flag,
        "fail_count": fail_count,
        "skip_count": skip_count,
        "rc": rc,
    }))

    # 依照 cpe_ssh.py 的邏輯，overall == "GOOD" 且 rc=0 代表 health OK
    return bool(overall == "GOOD" and rc == 0)
