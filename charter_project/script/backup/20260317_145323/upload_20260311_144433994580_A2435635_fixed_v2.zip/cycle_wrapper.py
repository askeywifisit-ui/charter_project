#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Generic cycle wrapper (WAN-arch compatible):
- entrypoint in manifest stays `cycle_wrapper.py:run` for the runner
- Each cycle executes the env's `ORIGINAL_ENTRY` (default: main_impl.py:run)
- Supports CYCLES, CYCLE_INTERVAL, STOP_ON_FAIL
- Emits machine-readable JSON events + human logs
"""
from __future__ import annotations

import importlib.util
import json
import os
import pathlib
import re
import subprocess
import sys
import time
from typing import Any, Dict, Tuple

def log(msg: str) -> None:
    print(msg, flush=True)

_RE_KV_TOP = re.compile(r"^([A-Za-z0-9_]+)\s*:\s*(.*?)\s*$")
_RE_KV_ENV = re.compile(r"^\s{2}([A-Za-z0-9_]+)\s*:\s*(.*?)\s*$")


def _strip_yaml_scalar(v: str) -> str:
    s = (v or "").strip()
    if s in ("~", "null", "Null", "NULL"):
        return ""
    # remove surrounding quotes
    if (len(s) >= 2) and ((s[0] == s[-1] == "'") or (s[0] == s[-1] == '"')):
        return s[1:-1]
    return s


def _parse_manifest_yaml(path: pathlib.Path) -> Dict[str, Any]:
    """Parse the limited manifest.yaml schema we use.

    We intentionally avoid PyYAML to eliminate pip/venv dependencies.
    Supported fields:
      - name: <str>
      - entrypoint: <str>
      - env: { KEY: VALUE, ... }  (2-space indented mapping)
    """
    man: Dict[str, Any] = {"env": {}}
    if not path.exists():
        return man

    in_env = False
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.rstrip("\n")
        if not line.strip() or line.lstrip().startswith("#"):
            continue

        if line.startswith("env:") and _RE_KV_TOP.match(line):
            # env: on its own line
            if line.strip() == "env:" or line.strip() == "env: {}":
                in_env = True
                continue

        if in_env:
            if not line.startswith("  "):
                in_env = False
            else:
                m = _RE_KV_ENV.match(line)
                if not m:
                    continue
                k, v = m.group(1), _strip_yaml_scalar(m.group(2))
                man["env"][k] = v
                continue

        m2 = _RE_KV_TOP.match(line)
        if not m2:
            continue
        k2, v2 = m2.group(1), _strip_yaml_scalar(m2.group(2))
        if k2 == "env" and v2 == "":
            in_env = True
            continue
        man[k2] = v2

    return man


def _load_manifest() -> Tuple[Dict[str, Any], Dict[str, str], str, str, int, float, int]:
    here = pathlib.Path(__file__).resolve().parent
    mp = here / "manifest.yaml"
    if not mp.exists():
        mp = here / "manifest.yml"

    man = _parse_manifest_yaml(mp)
    env = dict((man.get("env") or {}))

    # Runner-facing entrypoint (should be this wrapper); kept only for display/diagnostics
    manifest_entry = (man.get("entrypoint") or "main.py:run")

    # The real per-cycle entry we will execute:
    original_entry = env.get("ORIGINAL_ENTRY", os.environ.get("ORIGINAL_ENTRY", "main_impl.py:run"))
    if original_entry.strip() == "":
        original_entry = "main_impl.py:run"

    # Wrapper vars with defaults
    cycles = int(env.get("CYCLES", os.environ.get("CYCLES", "1")))
    interval = float(env.get("CYCLE_INTERVAL", os.environ.get("CYCLE_INTERVAL", "0")))
    stop_on_fail = int(env.get("STOP_ON_FAIL", os.environ.get("STOP_ON_FAIL", "0")))

    return man, env, manifest_entry, original_entry, cycles, interval, stop_on_fail

def _resolve_entry(entry_str: str):
    """
    entry_str format: 'file.py:func' relative to this directory
    """
    here = pathlib.Path(__file__).resolve().parent
    mod_file, _, func_name = entry_str.partition(":")
    if not func_name:
        func_name = "run"
    mod_path = here / mod_file
    if not mod_path.exists():
        raise FileNotFoundError(f"entry module not found: {mod_path}")
    spec = importlib.util.spec_from_file_location("script_entry", str(mod_path))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load module from {mod_path}")
    mod = importlib.util.module_from_spec(spec)  # type: ignore
    spec.loader.exec_module(mod)  # type: ignore
    fn = getattr(mod, func_name, None)
    if not callable(fn):
        raise AttributeError(f"entry function not found: {func_name} in {mod_file}")
    return mod, fn, str(mod_path), func_name

def _apply_env(env_overlay: Dict[str, str]) -> Dict[str, str | None]:
    backup: Dict[str, str | None] = {}
    for k, v in env_overlay.items():
        # Safety/compatibility: if manifest provides an empty value (""/null),
        # do NOT override an existing environment variable.
        # This prevents accidental clearing of secrets like NOC_PROFILE/PROFILES_FILE.
        if v is None:
            continue
        if isinstance(v, str) and v.strip() == "":
            continue
        backup[k] = os.environ.get(k)
        os.environ[k] = str(v)
    return backup

def _restore_env(backup: Dict[str, str | None]) -> None:
    for k, prev in backup.items():
        if prev is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = prev

def _run_final_cpe_info() -> bool:
    """Run final cpe_info --internet check.

    Timeout is controlled by env `CPE_INFO_TIMEOUT_SEC` (default: 60 seconds).

    Returns:
        bool: True if Internet Status is Connected, False otherwise.
    """
    tool = os.environ.get("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
    cmd = [tool, "--internet"]
    timeout_s = float(os.environ.get("CPE_INFO_TIMEOUT_SEC", "60"))
    log(f"[runner] Final CPE internet check: {' '.join(cmd)} (timeout={timeout_s}s)")
    t0 = time.time()
    try:
        proc = subprocess.run(
            cmd,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=timeout_s,
        )
        dt = time.time() - t0
        out = (proc.stdout or "")
        sample = out.strip().splitlines()[:3]
        ok = (proc.returncode == 0) and ("Internet Status: Connected" in out)
        event = {
            "event": "final_status",
            "tool": tool,
            "cmd": " ".join(cmd),
            "rc": proc.returncode,
            "ok": ok,
            "timeout": False,
            "sample": sample,
        }
        print(json.dumps(event), flush=True)
        log(out.strip())
        log(f"[runner] Final CPE internet check rc={proc.returncode}  ({dt:.2f}s)  ok={ok}")
        return ok
    except subprocess.TimeoutExpired as e:
        dt = time.time() - t0
        out = getattr(e, "stdout", "") or ""
        sample = out.strip().splitlines()[:3]
        event = {
            "event": "final_status",
            "tool": tool,
            "cmd": " ".join(cmd),
            "rc": None,
            "ok": False,
            "timeout": True,
            "sample": sample,
        }
        print(json.dumps(event), flush=True)
        log(f"[runner] Final CPE internet check TIMEOUT after {dt:.2f}s (limit={timeout_s}s)")
        return False
    except Exception as e:
        dt = time.time() - t0
        event = {
            "event": "final_status",
            "tool": tool,
            "cmd": " ".join(cmd),
            "rc": None,
            "ok": False,
            "timeout": False,
            "error": repr(e),
        }
        print(json.dumps(event), flush=True)
        log(f"[runner] Final CPE internet check EXCEPTION after {dt:.2f}s: {e!r}")
        return False



def run() -> int:
    man, menv, manifest_entry, original_entry, cycles, interval, stop_on_fail = _load_manifest()

    # Optional: run precondition() once in cycle #1 (inside the first cycle)
    try:
        precondition_first_cycle = int(menv.get("PRECONDITION_FIRST_CYCLE", os.environ.get("PRECONDITION_FIRST_CYCLE", "1")))
    except Exception:
        precondition_first_cycle = 1

    # Safety: avoid accidental recursion
    if original_entry.strip() == "cycle_wrapper.py:run":
        log("[wrapper] WARNING: ORIGINAL_ENTRY points to cycle_wrapper.py:run — overriding to main_impl.py:run to avoid recursion")
        original_entry = "main_impl.py:run"

    mod, fn, mod_path, func_name = _resolve_entry(original_entry)
    precond_fn = getattr(mod, "precondition", None)

    # Runner start event
    name = man.get("name") or "unnamed"
    print(json.dumps({"event": "runner_start", "name": name}), flush=True)
    log(f"[runner] START  {name}")
    log(f"          cycles={cycles}  interval={interval}s  stop_on_fail={stop_on_fail}  original_entry={original_entry}  (manifest_entry={manifest_entry})")

    overall_rc = 0
    per_cycle = []

    for i in range(1, cycles + 1):
        print(json.dumps({"event": "cycle_start", "i": i, "cycle": i, "total": cycles}), flush=True)
        log(f"[runner] Cycle #{i} — applying env & invoking {mod_path}:{func_name}")
        backup = _apply_env(menv)

        # Provide cycle index to the implementation (so it can log cycle context)
        backup_cycle = {"CYCLE_INDEX": os.environ.get("CYCLE_INDEX"), "CYCLE_TOTAL": os.environ.get("CYCLE_TOTAL")}
        os.environ["CYCLE_INDEX"] = str(i)
        os.environ["CYCLE_TOTAL"] = str(cycles)
        t0 = time.time()
        rc = 1
        err = None
        try:
            # Precondition runs once, at the start of cycle #1
            if i == 1 and precondition_first_cycle == 1 and callable(precond_fn):
                log("[runner] Precondition() — running once in cycle #1")
                pre_rc = int(precond_fn())
                if pre_rc != 0:
                    rc = pre_rc
                    raise RuntimeError(f"precondition failed rc={pre_rc}")
            rc = int(fn())  # entry returns int rc
        except SystemExit as e:
            rc = int(e.code) if isinstance(e.code, int) else 1
        except Exception as e:
            err = repr(e)
            rc = 1
        finally:
            # restore cycle vars
            if backup_cycle["CYCLE_INDEX"] is None:
                os.environ.pop("CYCLE_INDEX", None)
            else:
                os.environ["CYCLE_INDEX"] = backup_cycle["CYCLE_INDEX"]  # type: ignore
            if backup_cycle["CYCLE_TOTAL"] is None:
                os.environ.pop("CYCLE_TOTAL", None)
            else:
                os.environ["CYCLE_TOTAL"] = backup_cycle["CYCLE_TOTAL"]  # type: ignore
            _restore_env(backup)
        dur = time.time() - t0
        ok = (rc == 0)
        per_cycle.append({"i": i, "ok": ok, "rc": rc, "dur_sec": round(dur, 3), "err": err})

        print(json.dumps({"event": "cycle_end", "i": i, "ok": ok, "rc": rc, "dur_sec": round(dur, 3)}), flush=True)
        log(f"[runner] Cycle #{i} {'✓ PASS' if ok else '✗ FAIL'}  rc={rc}  ({dur:.2f}s)")

        if not ok and stop_on_fail:
            overall_rc = 1
            log("[runner] STOP_ON_FAIL=1 — aborting further cycles")
            break

        if i < cycles and interval > 0:
            time.sleep(interval)

        overall_rc = max(overall_rc, 0 if ok else 1)

        # Final internet status check (optional)
    final_internet_ok = None
    if os.environ.get("FINAL_STATUS_CHECK", "0") == "1":
        final_internet_ok = _run_final_cpe_info()

    # Summary
    passed = sum(1 for c in per_cycle if c["ok"])
    failed = len(per_cycle) - passed
    any_cycle_fail = failed > 0

    # Decide root cause
    root_cause = None
    if any_cycle_fail and final_internet_ok is False:
        root_cause = "power_cycle_and_internet"
    elif any_cycle_fail and (final_internet_ok is None or final_internet_ok is True):
        root_cause = "power_cycle"
    elif (not any_cycle_fail) and final_internet_ok is False:
        root_cause = "internet"

    # Overall rc: fail if any cycle failed OR final internet check failed
    overall_rc = 0
    if any_cycle_fail or final_internet_ok is False:
        overall_rc = 1

    summary = {
        "event": "wrapper_end",
        "cycles": len(per_cycle),
        "passed": passed,
        "failed": failed,
        "details": per_cycle,
        "final_internet_ok": final_internet_ok,
        "root_cause": root_cause,
    }
    print(json.dumps(summary), flush=True)
    log(f"[runner] SUMMARY: {passed}/{len(per_cycle)} passed; {failed} failed")
    if final_internet_ok is False:
        log("[runner] FINAL_STATUS_CHECK failed: internet is not connected")
    log(f"[runner] exit_code={'0' if overall_rc == 0 else '1'}")
    return overall_rc

if __name__ == "__main__":
    sys.exit(run())
