# -*- coding: utf-8 -*-
"""
log_style_shim.py
Wraps main_impl.run() and augments stdout with human-readable lines
matching C15807060 style, without touching original logic.
"""
import sys, os, json, importlib

from collections import deque
_DEDUP_QUEUE = deque()
_DEDUP_COUNTS = {}
_DEDUP_MAX = 200
def _dedupe_print(s: str):
    try:
        key = s.strip()
        # If JSON, compress to a stable key
        try:
            import json as _json
            obj = _json.loads(key)
            if isinstance(obj, dict):
                key = str(('json', obj.get('step'), obj.get('action'), obj.get('host'), obj.get('user'), obj.get('result'), obj.get('rc'), obj.get('awlan_id')))
        except Exception:
            pass
        if _DEDUP_COUNTS.get(key, 0) > 0:
            return
        print(s)
        _DEDUP_QUEUE.append(key)
        _DEDUP_COUNTS[key] = _DEDUP_COUNTS.get(key, 0) + 1
        while len(_DEDUP_QUEUE) > _DEDUP_MAX:
            old = _DEDUP_QUEUE.popleft()
            c = _DEDUP_COUNTS.get(old, 0)
            if c <= 1:
                _DEDUP_COUNTS.pop(old, None)
            else:
                _DEDUP_COUNTS[old] = c - 1
    except Exception:
        # Fallback: never block the log
        print(s)

class TeeStdout:
    def __init__(self, real):
        self.real = real
        self.buf = ""

    def write(self, s):
        self.buf += s
        while "\n" in self.buf:
            line, self.buf = self.buf.split("\n", 1)
            self.handle_line(line + "\n")

    def flush(self):
        if self.buf:
            self.handle_line(self.buf)
            self.buf = ""
        try:
            self.real.flush()
        except Exception:
            pass

    def handle_line(self, line: str):
        # always forward
        self.real.write(line)
        s = line.strip()
        if not (s.startswith("{") and s.endswith("}")):
            return
        try:
            obj = json.loads(s)
        except Exception:
            return

        # Map JSON events/steps to human-readable lines
        step = obj.get("step")
        if step == "login":
            print("[runner] Step 2 — SSH login (LAN/WAN)", flush=True)
            return

        if step == "ssh-login-lan":
            ok = obj.get("ok")
            host = obj.get("host","")
            user = obj.get("user","")
            dt = obj.get("elapsed_sec") or obj.get("dt_sec") or obj.get("dur_s") or 0.0
            try:
                dtf = float(dt)
            except Exception:
                dtf = 0.0
            rc = 0 if ok else 1
            print(f"  ↳ ssh login host={host} user={user} rc={rc} {dtf:.3f}s", flush=True)
            mark = "✓" if ok else "✗"
            tail = "" if not obj.get("err") else f" err={obj.get('err')}"
            print(f"  {mark} try #1: {'login ok' if ok else 'login fail'}{tail}", flush=True)
            return

        if step == "ssh-login-wan":
            ok = obj.get("ok")
            host = obj.get("host","")
            user = obj.get("user","")
            dt = obj.get("elapsed_sec") or obj.get("dt_sec") or obj.get("dur_s") or 0.0
            try:
                dtf = float(dt)
            except Exception:
                dtf = 0.0
            rc = 0 if ok else 1
            print(f"  ↳ ssh login host={host} user={user} rc={rc} {dtf:.3f}s", flush=True)
            mark = "✓" if ok else "✗"
            tail = "" if not obj.get("err") else f" err={obj.get('err')}"
            print(f"  {mark} try #1: {'login ok' if ok else 'login fail'}{tail}", flush=True)
            return

        if "result" in obj:
            rc = 0 if obj.get("result") == "OK" else 1
            print(f"[runner] exit_code={rc}", flush=True)
            return

def run() -> int:
    # Step 1 header (like C15807060)
    print("[runner] Step 1 — Read WAN IPv4 (expected: br-wan has IPv4; fallback eth0)", flush=True)

    # Import and call original run()
    _real = sys.stdout
    sys.path.insert(0, os.path.dirname(__file__))
    sys.stdout = TeeStdout(_real)
    try:
        mod = importlib.import_module("main_impl")
        if not hasattr(mod, "run"):
            raise RuntimeError("main_impl.run not found")
        rc = mod.run()
    finally:
        try:
            sys.stdout.flush()
        except Exception:
            pass
        sys.stdout = _real
    return rc
