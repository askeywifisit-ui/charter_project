#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os, sys, json, time, pathlib, importlib.util
from typing import Any, Dict, Tuple

try:
    import yaml  # requirements.txt 應已包含 PyYAML
except Exception:
    print("[wrapper] PyYAML not installed", flush=True)
    sys.exit(1)
import subprocess, shlex, re as _re
import socket

def _env_bool(name: str, default: bool) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    v = str(v).strip().lower()
    if v in ("1","true","yes","y","on"):
        return True
    if v in ("0","false","no","n","off"):
        return False
    return default

def _env_int(name: str, default: int) -> int:
    v = os.environ.get(name)
    if v is None:
        return default
    try:
        return int(str(v).strip())
    except Exception:
        return default

def _run_cmd(cmd: str, timeout: int) -> tuple[int,str,str]:
    args = shlex.split(cmd)
    p = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    return p.returncode, p.stdout or "", p.stderr or ""

def _cpe_info_tool() -> str:
    return (
        os.environ.get("CPE_INFO_BIN")
        or os.environ.get("CPE_INFO_TOOL")
        or "/home/da40/charter/tools/cpe_info"
    )

def _cloud_connected(text: str) -> bool:
    # Typical output contains "Cloud Status: Connected"
    # Be tolerant to minor format changes.
    t = (text or "").lower()
    if "cloud status" in t:
        # line-based check
        for line in (text or "").splitlines():
            if "cloud status" in line.lower():
                return "connected" in line.lower()
    # fallback: any "connected" without explicit "disconnected"
    return ("connected" in t) and ("disconnected" not in t) and ("not connected" not in t)

def _cpe_info_cloud_ok(timeout: int) -> tuple[bool, int, str]:
    cmd = f"{_cpe_info_tool()} --cloud"
    rc, out, err = _run_cmd(cmd, timeout=timeout)
    merged = (out + "\n" + err).strip()
    ok = (rc == 0) and _cloud_connected(merged)
    return ok, rc, merged

def _cpe_info_node_id(timeout: int = 15) -> str:
    try:
        tool = _cpe_info_tool()
        proc = subprocess.run(
            [tool, "--node-id", "--value"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=timeout,
        )
        raw = (proc.stdout or "").strip()
        nid = raw.replace(":", "").strip().lower()
        ok = (proc.returncode == 0 and bool(nid))
        print(json.dumps({"event":"node_id_cpe_info","ok":ok,"rc":proc.returncode,"raw":raw[-200:],"node_id":(nid if ok else "")}), flush=True)
        return nid if ok else ""
    except Exception as e:
        print(json.dumps({"event":"node_id_cpe_info_exception","error":str(e)}), flush=True)
        return ""

def _tcp_open(host: str, port: int, timeout_sec: float = 1.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout_sec):
            return True
    except Exception:
        return False

def _tcp_wait(host: str, port: int, timeout_sec: int, interval_sec: float) -> bool:
    deadline = time.time() + max(0, timeout_sec)
    while time.time() <= deadline:
        if _tcp_open(host, port, timeout_sec=min(1.0, max(0.2, interval_sec))):
            return True
        time.sleep(max(0.2, interval_sec))
    return False

def _noc_profiles() -> tuple[str, str, str]:
    # Env override first
    base_env = os.environ.get("NOC_BASE", "").strip()
    email_env = os.environ.get("NOC_EMAIL", "").strip()
    pass_env = os.environ.get("NOC_PASSWORD", "").strip()
    if base_env and email_env and pass_env:
        return base_env, email_env, pass_env

    profiles_path = os.environ.get("PROFILES_FILE", "").strip()
    if not profiles_path:
        profiles_path = os.environ.get("NOC_PROFILES_PATH", "/home/da40/charter/.secrets/noc_profiles.json").strip()

    profile_name = os.environ.get("NOC_PROFILE", "").strip() or os.environ.get("NOC_PROFILE_NAME", "SPECTRUM_INT").strip()

    with open(profiles_path, "r", encoding="utf-8") as f:
        profiles = json.load(f)
    prof = profiles.get(profile_name) if isinstance(profiles, dict) else None
    if not isinstance(prof, dict):
        raise RuntimeError(f"Profile {profile_name!r} not found in {profiles_path}")
    base = str(prof.get("base") or "").strip()
    email = str(prof.get("email") or "").strip()
    password = str(prof.get("password") or "").strip()
    if not (base and email and password):
        raise RuntimeError(f"Incomplete profile {profile_name!r} in {profiles_path}")
    return base, email, password

def _noc_cli_path() -> str:
    return os.environ.get("NOC_API_CLI", "/home/da40/charter/tools/noc_api_cli.py")

def _noc_get_location_id(py: str, base: str, customer_id: str, email: str, password: str, node_id: str) -> tuple[bool,str,str]:
    cmd = [
        py, _noc_cli_path(),
        "--base", base,
        "--customer-id", customer_id,
        "--email", email,
        "--password", password,
        "get-location",
        "--node-id", node_id,
    ]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=_env_int("GET_LOCATION_TIMEOUT_SEC", 60))
        out = (p.stdout or "").strip()
        err = (p.stderr or "").strip()
        ok = (p.returncode == 0 and bool(out))
        return ok, out, (err or "")
    except Exception as e:
        return False, "", str(e)

def _noc_ssh_enable(py: str, base: str, customer_id: str, email: str, password: str, location_id: str, node_id: str, ssh_pass: str) -> tuple[bool,int,str,str]:
    cmd = [
        py, _noc_cli_path(),
        "--base", base,
        "--customer-id", customer_id,
        "--email", email,
        "--password", password,
        "ssh-enable",
        "--location-id", location_id,
        "--node-id", node_id,
        "--ssh-pass", ssh_pass,
    ]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=_env_int("SSH_ENABLE_TIMEOUT_SEC", 60))
        return (p.returncode == 0), p.returncode, (p.stdout or ""), (p.stderr or "")
    except Exception as e:
        return False, 999, "", str(e)

def _cpe_ssh_tool() -> str:
    return os.environ.get("CPE_SSH_TOOL", "/home/da40/charter/tools/cpe_ssh.py")

def _ssh_uptime_probe(host: str, user: str, password: str) -> bool:
    py = os.environ.get("TOOLS_PYTHON", "python3")
    timeout = str(_env_int("CPE_SSH_TIMEOUT_SEC", 30))
    cmd = [
        py, _cpe_ssh_tool(),
        "--host", host,
        "--user", user,
        "--password", password,
        "--timeout", timeout,
        "--cmd", "uptime",
    ]
    t0 = time.time()
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=float(timeout) + 15)
        sec = round(time.time() - t0, 3)
        out = (p.stdout or "").strip()
        err = (p.stderr or "").strip()
        sample = (out.splitlines()[-2:] if out else []) or (err.splitlines()[-2:] if err else [])
        ok = (p.returncode == 0)
        print(json.dumps({"event":"ssh_probe","ok":ok,"rc":p.returncode,"sec":sec,"sample":sample}), flush=True)
        return ok
    except Exception as e:
        sec = round(time.time() - t0, 3)
        print(json.dumps({"event":"ssh_probe","ok":False,"rc":999,"sec":sec,"error":str(e)}), flush=True)
        return False

def ensure_ssh_ready_for_cycle(cycle_no: int) -> bool:
    if not _env_bool("SSH_READY_CHECK", True):
        print(json.dumps({"event":"ssh_ready_skip","cycle":cycle_no,"reason":"SSH_READY_CHECK=0"}), flush=True)
        return True

    host = os.environ.get("CPE_IP", "192.168.1.1").strip()
    port = _env_int("CPE_SSH_PORT", 22)
    user = os.environ.get("SSH_USER", "root").strip()
    ssh_pass = (os.environ.get("SSH_PASSWORD") or os.environ.get("CPE_SSH_PASSWORD") or "").strip()

    scan_timeout = _env_int("SSH_SCAN_TIMEOUT_SEC", 60)
    scan_interval = float(os.environ.get("SSH_SCAN_INTERVAL_SEC", "2") or "2")
    enable_retries = _env_int("SSH_ENABLE_RETRIES", 2)
    wait_after_enable = _env_int("WAIT_AFTER_SSH_ENABLE_SEC", 60)

    print(json.dumps({"event":"ssh_ready_start","cycle":cycle_no,"host":host,"port":port,"scan_timeout_sec":scan_timeout,"scan_interval_sec":scan_interval,"enable_retries":enable_retries}), flush=True)

    # attempt loop (align to A2435638: scan + (if needed) enable + wait)
    for attempt in range(1, enable_retries + 1):
        port_ok = _tcp_wait(host, port, timeout_sec=scan_timeout, interval_sec=scan_interval)
        print(json.dumps({"event":"ssh_port","cycle":cycle_no,"attempt":attempt,"ok":port_ok}), flush=True)

        if port_ok:
            # If port is open, do NOT enable SSH; just probe.
            if _ssh_uptime_probe(host, user, ssh_pass):
                print(json.dumps({"event":"ssh_ready_end","cycle":cycle_no,"ok":True}), flush=True)
                return True
            # If probe fails, allow a repair attempt via ssh-enable (same attempt loop)

        # port closed OR probe failed => do ssh-enable
        customer_id = (os.environ.get("CUSTOMER_ID") or os.environ.get("NOC_CUSTOMER_ID") or "").strip()
        if not customer_id:
            print(json.dumps({"event":"ssh_enable_skip","cycle":cycle_no,"attempt":attempt,"ok":False,"error":"CUSTOMER_ID not set"}), flush=True)
            break
        if not ssh_pass:
            print(json.dumps({"event":"ssh_enable_skip","cycle":cycle_no,"attempt":attempt,"ok":False,"error":"SSH_PASSWORD not set"}), flush=True)
            break

        node_id = _cpe_info_node_id(timeout=_env_int("CPE_INFO_NODE_ID_TIMEOUT_SEC", 15))
        if not node_id:
            print(json.dumps({"event":"ssh_enable_skip","cycle":cycle_no,"attempt":attempt,"ok":False,"error":"node_id not available"}), flush=True)
            break

        py = os.environ.get("TOOLS_PYTHON", "python3")
        try:
            base, email, noc_pass = _noc_profiles()
        except Exception as e:
            print(json.dumps({"event":"ssh_enable_end","cycle":cycle_no,"attempt":attempt,"ok":False,"error":str(e)}), flush=True)
            break

        # get location id
        ok_loc, loc_out, loc_err = _noc_get_location_id(py, base, customer_id, email, noc_pass, node_id)
        location_id = loc_out.strip().splitlines()[-1].strip() if ok_loc else ""
        if not location_id:
            print(json.dumps({"event":"ssh_enable_end","cycle":cycle_no,"attempt":attempt,"ok":False,"error":"get-location failed","stderr":loc_err[-200:]}), flush=True)
            continue

        print(json.dumps({"event":"ssh_enable_start","cycle":cycle_no,"attempt":attempt,"node_id":node_id,"location_id":location_id,"customer_id":customer_id,"timeout_min":_env_int("SSH_TIMEOUT_MIN",120),"base":base}), flush=True)
        ok_en, rc_en, out_en, err_en = _noc_ssh_enable(py, base, customer_id, email, noc_pass, location_id, node_id, ssh_pass)
        print(json.dumps({"event":"ssh_enable_end","cycle":cycle_no,"attempt":attempt,"ok":ok_en,"rc":rc_en,"stdout":(out_en or "")[-200:],"stderr":(err_en or "")[-200:]}), flush=True)
        if not ok_en:
            continue

        if wait_after_enable > 0:
            print(json.dumps({"event":"ssh_enable_wait","cycle":cycle_no,"attempt":attempt,"seconds":wait_after_enable}), flush=True)
            time.sleep(wait_after_enable)

    print(json.dumps({"event":"ssh_ready_end","cycle":cycle_no,"ok":False}), flush=True)
    return False

def ensure_cpe_ready_first_cycle() -> int:
    # Only for cycle#1 precondition
    if not _env_bool("CPE_READY_CHECK", True):
        print(json.dumps({"event":"cpe_ready_skip","reason":"CPE_READY_CHECK=0"}), flush=True)
        return 0

    max_retries = _env_int("CPE_READY_MAX_RETRIES", 10)
    sleep_sec = _env_int("CPE_READY_RETRY_SLEEP_SEC", 30)
    timeout = _env_int("CPE_INFO_TIMEOUT_SEC", 30)

    print(json.dumps({"event":"cpe_ready_start","max_retries":max_retries,"sleep_sec":sleep_sec,"tool":_cpe_info_tool()}), flush=True)

    for attempt in range(1, max_retries + 1):
        ok, rc, merged = _cpe_info_cloud_ok(timeout=timeout)
        sample = merged.splitlines()[:3]
        print(json.dumps({"event":"cpe_ready_try","try_no":attempt,"ok":ok,"rc":rc,"sample":sample}), flush=True)
        if ok:
            print(json.dumps({"event":"cpe_ready_end","ok":True}), flush=True)
            return 0
        if attempt < max_retries:
            time.sleep(sleep_sec)

    # not ready -> optional single PDU reset
    if not _env_bool("PDU_RESET_ON_NOT_READY", True):
        print(json.dumps({"event":"precondition_fail","reason":"cpe_not_ready_no_pdu_reset"}), flush=True)
        return 2

    pdu_script = os.environ.get("PDU_RESET_SCRIPT") or os.environ.get("PDU_SCRIPT") or "/home/da40/charter/tools/pdu_outlet1.py"
    action = os.environ.get("PDU_RESET_ACTION", "reset")
    python_bin = os.environ.get("TOOLS_PYTHON", "python3")
    pdu_cmd = f"{python_bin} {pdu_script} {action}"
    timeout = _env_int("PDU_RESET_TIMEOUT_SEC", 600)
    print(json.dumps({"event":"pdu_reset_start","cmd":pdu_cmd,"timeout":timeout}), flush=True)
    try:
        rc, out, err = _run_cmd(pdu_cmd, timeout=timeout)
        print(json.dumps({"event":"pdu_reset_done","rc":rc,"stdout":out[-200:],"stderr":err[-200:]}), flush=True)
    except Exception as e:
        print(json.dumps({"event":"pdu_reset_error","error":str(e)}), flush=True)
        return 2

    wait_sec = _env_int("PDU_RESET_WAIT_SEC", 120)
    print(json.dumps({"event":"pdu_reset_wait","secs":wait_sec}), flush=True)
    if wait_sec > 0:
        time.sleep(wait_sec)

    # re-check after reset
    for attempt in range(1, max_retries + 1):
        ok, rc, merged = _cpe_info_cloud_ok(timeout=timeout)
        sample = merged.splitlines()[:3]
        print(json.dumps({"event":"cpe_ready_try_after_pdu","try_no":attempt,"ok":ok,"rc":rc,"sample":sample}), flush=True)
        if ok:
            print(json.dumps({"event":"cpe_ready_after_pdu","ready":True}), flush=True)
            return 0
        if attempt < max_retries:
            time.sleep(sleep_sec)

    print(json.dumps({"event":"precondition_fail","reason":"cpe_not_ready_after_pdu"}), flush=True)
    return 2

def log(msg: str) -> None:
    print(msg, flush=True)

def _load_manifest() -> Tuple[Dict[str, Any], Dict[str, str], str, int, float]:
    """讀取 manifest.yaml，回傳 (data, env, original_entry, cycles, wait)"""
    here = pathlib.Path(__file__).resolve().parent
    mp = (here / "manifest.yaml")
    if not mp.exists():
        mp = (here / "manifest.yml")

    data: Dict[str, Any] = {}
    if mp.exists():
        data = yaml.safe_load(mp.read_text(encoding="utf-8")) or {}

    menv: Dict[str, str] = {}
    if isinstance(data.get("env"), dict):
        for k, v in data["env"].items():
            menv[str(k)] = "" if v is None else str(v)

    # cycles / wait：env 優先，其次 manifest 項
    def _to_int(x, d): 
        try: return int(str(x))
        except: return d
    def _to_float(x, d):
        try: return float(str(x))
        except: return d

    cycles = _to_int(menv.get("CYCLES", data.get("cycles", 1)), 1)
    wait   = _to_float(menv.get("CYCLE_INTERVAL", data.get("wait", 0.5)), 0.5)

    # ORIGINAL_ENTRY（預設 main_impl.py:run），也支援舊欄位 entrypoint/original_entry
    original_entry = menv.get("ORIGINAL_ENTRY") \
                     or data.get("original_entry") \
                     or data.get("entrypoint") \
                     or "main_impl.py:run"
    return data, menv, original_entry, cycles, wait

def _load_entry_callable(entry: str):
    """支援 'file.py:func' 或 'pkg.module:func'"""
    if ":" not in entry:
        raise ValueError(f"Invalid ORIGINAL_ENTRY: {entry} (expect 'target:func')")
    target, func = entry.split(":", 1)
    here = pathlib.Path(__file__).resolve().parent

    if target.endswith(".py"):
        fpath = (here / target).resolve()
        if not fpath.exists():
            raise FileNotFoundError(f"Entry file not found: {fpath}")
        mod_name = fpath.stem
        spec = importlib.util.spec_from_file_location(mod_name, str(fpath))
        if spec is None or spec.loader is None:
            raise ImportError(f"Cannot load spec from file: {fpath}")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)  # type: ignore
    else:
        mod = importlib.import_module(target)

    if not hasattr(mod, func):
        raise AttributeError(f"Function '{func}' not found in '{target}'")
    fn = getattr(mod, func)

    def _wrapped() -> int:
        rc = fn()
        try:
            return int(rc or 0)
        except Exception:
            return 0
    return _wrapped

def run() -> int:
    #log("[runner] entry: cycle_wrapper run")
    data, menv, original_entry, cycles, wait = _load_manifest()
    print(json.dumps({"event": "wrapper_start", "cycles": cycles, "wait": wait}), flush=True)

    # 將 manifest 的 env 寫入 os.environ（manifest 覆蓋 OS）
    backup: Dict[str, str | None] = {}
    for k, v in menv.items():
        backup[k] = os.environ.get(k)
        os.environ[k] = v

    child = _load_entry_callable(original_entry)

    overall_rc = 0
    for i in range(1, cycles + 1):
        print(json.dumps({"event": "wrapper_iter", "i": i, "of": cycles}), flush=True)
        if i == 1:
            pre_rc = ensure_cpe_ready_first_cycle()
            if pre_rc != 0:
                overall_rc = pre_rc
                break

        # 每個 cycle 開始前都確認 SSH/22；22 開著就不 enable，只有關閉/Probe 失敗才會走 NOC ssh-enable
        ssh_ok = ensure_ssh_ready_for_cycle(i)
        if not ssh_ok and _env_bool("SSH_READY_REQUIRED", True):
            overall_rc = 1
            print(json.dumps({"event":"ssh_ready_required_fail","cycle":i}), flush=True)
            if _env_bool("STOP_ON_FAIL", False):
                break

        try:
            rc = int(child() or 0)
            if rc != 0:
                overall_rc = 1    # 任一圈失敗 → 最終失敗
        except Exception as e:
            overall_rc = 1
            print(json.dumps({"event": "wrapper_error", "i": i, "error": str(e)}), flush=True)
        if i < cycles and wait > 0:
            time.sleep(wait)

    # 還原環境變數
    for k in menv.keys():
        if backup.get(k) is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = backup[k]  # type: ignore
    log("[runner] test done")                               # ← 放在這裡
    print(json.dumps({"event": "wrapper_end", "passed": (overall_rc == 0)}), flush=True)
    log(f"[runner] exit_code={overall_rc}")

    return overall_rc

if __name__ == "__main__":
    sys.exit(run())
