# C15807060_WAN_IPv4_Connectivity

## 1) 目的 / 覆蓋範圍
- 驗證 WAN IPv4 連通性。

## 2) 前置條件 / 環境
- 需有效 WAN uplink。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'70'

## 5) PASS/FAIL 判定
- PASS：IPv4 連通性檢查成功。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807060_WAN_IPv4_Connectivity

## 1) 目的 / 覆蓋範圍
- 驗證 WAN IPv4 連通性。

## 2) 前置條件 / 環境
- 需具備有效 WAN uplink。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'70'

## 5) PASS/FAIL 判定
- PASS：WAN IPv4 連通性檢查成功。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807060_WAN_IPv4_Connectivity

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'70'

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807060_WAN_IPv4_Connectivity
Entry: cycle_wrapper.py:run

- Parameters are read from manifest.yaml -> env: {"CYCLES","CYCLE_INTERVAL",...}
- Wrapper calls ORIGINAL_ENTRY (defaults to main.py:run) each cycle.

NOTE: This build includes shim main.py delegating to cycle_wrapper.


## Step1 WAN IPv4 method

This script supports `WAN_IPV4_METHOD`:
- `serial` (default): read WAN IPv4 via serial console.
- `ssh`: enable SSH via NOC precondition, then read WAN IPv4 via SSH (`cpe_ssh.py --cmd wan-ipv4`).
- `auto`: try serial first; if not found then try SSH.

When using `ssh/auto`, set `SSH_PASSWORD` (or `CPE_SSH_PASSWORD`) and provide NOC credentials via `CUSTOMER_ID`, `PROFILES_FILE`, and `NOC_PROFILE`.


## SSH WAN IPv4 mode
- Set `WAN_IPV4_METHOD: 'ssh'` to force Step1 via SSH (will run NOC ssh-enable precondition first).
- Set `WAN_IPV4_METHOD: 'auto'` to try serial first; if serial cannot find WAN IPv4 then it will run NOC ssh-enable and retry via SSH.


Backward compatibility: the script also accepts `NOC_CUSTOMER_ID` / `NOC_PROFILES_PATH` / `NOC_PROFILE_NAME` if the new keys are not set.
```

```
```
