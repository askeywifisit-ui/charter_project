#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RG cycle wrapper (sanity/stability compatible)

Goals (per user requirement):
  1) node_id only via `cpe_info --node-id` (no console/serial metrics tool)
  2) precondition() runs once (cycle #1):
        cpe_info --cloud retry -> if still fail: PDU reset once -> retry again
        then: scan port 22 -> if closed: NOC ssh-enable (attempt=2) -> wait -> rescan + SSH uptime probe
  3) before EVERY cycle: scan port 22 -> if closed: NOC ssh-enable (attempt=2) -> wait -> rescan + SSH uptime probe

Env (subset):
  - CYCLES, CYCLE_INTERVAL, STOP_ON_FAIL, ORIGINAL_ENTRY
  - CPE_INFO_TOOL (default /home/da40/charter/tools/cpe_info)
  - CPE_READY_MAX_RETRIES, CPE_READY_RETRY_INTERVAL_SEC
  - PDU_RESET_ON_NOT_READY, PDU_RESET_SCRIPT, PDU_RESET_ACTION, PDU_RESET_TIMEOUT_SEC, PDU_RESET_WAIT_SEC
  - SSH_HOST (default 192.168.1.1), SSH_USER, SSH_PASSWORD
  - SSH_PORT (default 22)
  - SSH_PORT_SCAN_TIMEOUT_SEC (default 60), SSH_PORT_SCAN_INTERVAL_SEC (default 2)
  - SSH_READY_CMD (default uptime), SSH_TIMEOUT_SEC (default 30)
  - ENABLE_SSH_VIA_NOC (default 1), SSH_ENABLE_ATTEMPTS (default 2), WAIT_AFTER_SSH_ENABLE_SEC (default 60)
  - NOC_PROFILE, PROFILES_FILE, NOC_BASE, NOC_EMAIL, NOC_PASSWORD, CUSTOMER_ID, BEARER, INSECURE
"""
from __future__ import annotations

import importlib
import json
import os
import socket
import re
import subprocess
import time
from typing import Any, Dict, Optional, Tuple


def _emit(event: str, tag: Optional[str] = None, **kwargs: Any) -> None:
    obj: Dict[str, Any] = {"event": event}
    if tag:
        obj["tag"] = tag
    obj.update(kwargs)
    print(json.dumps(obj, ensure_ascii=False), flush=True)


def _g(name: str, default: str = "") -> str:
    v = os.environ.get(name)
    if v is None:
        return str(default)
    return str(v)


def _gi(name: str, default: int) -> int:
    try:
        return int(str(os.environ.get(name, str(default))).strip())
    except Exception:
        return int(default)


def _gb(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    s = str(v).strip().lower()
    if s in ("1", "true", "yes", "y", "on"):
        return True
    if s in ("0", "false", "no", "n", "off"):
        return False
    return default


def _tool_cpe_info() -> str:
    p = _g("CPE_INFO_TOOL", "").strip()
    if p:
        return p
    # Prefer official tools path
    return "/home/da40/charter/tools/cpe_info"


def _tool_cpe_ssh() -> str:
    # Prefer official tools path
    return "/home/da40/charter/tools/cpe_ssh.py"


def _run(argv: list[str], timeout: float = 30.0) -> Tuple[int, str, float]:
    t0 = time.time()
    try:
        p = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)
        out = p.stdout or ""
        return int(p.returncode), out, time.time() - t0
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or "") + (e.stderr or "")
        return 124, out, time.time() - t0
    except Exception as e:
        return 1, str(e), time.time() - t0


def _cpe_cloud_connected(sample_lines: list[str]) -> bool:
    # Typical output: "Cloud Status: Connected"
    for ln in sample_lines:
        if "cloud status" in ln.lower():
            return "connected" in ln.lower()
    # Fallback: treat any "Connected" line as ok if --cloud returned only one line
    return any("connected" in ln.lower() for ln in sample_lines)


def _cpe_cloud_check(tag: str, phase: str) -> bool:
    tool = _tool_cpe_info()
    retries = _gi("CPE_READY_MAX_RETRIES", 5)
    sleep_sec = float(_g("CPE_READY_RETRY_INTERVAL_SEC", "3") or "3")
    _emit(
        "step_start",
        tag=tag,
        name="cpe_ready",
        phase=phase,
        max_retries=retries,
        sleep_sec=sleep_sec,
        tool=tool,
    )
    for i in range(1, retries + 1):
        rc, out, sec = _run([tool, "--cloud"], timeout=60.0)
        sample = [ln.strip() for ln in (out or "").splitlines() if ln.strip()][:5]
        ok = (rc == 0) and _cpe_cloud_connected(sample)
        _emit("cmd", tag=tag, ok=(rc == 0), rc=rc, sec=round(sec, 3), argv=[tool, "--cloud"], sample=sample[:3])
        _emit("step_progress", tag=tag, name="cpe_ready", phase=phase, try_no=i, ok=ok, sample=sample[:2])
        if ok:
            _emit("step_end", tag=tag, name="cpe_ready", phase=phase, ok=True)
            return True
        if i < retries and sleep_sec > 0:
            time.sleep(sleep_sec)
    _emit("step_end", tag=tag, name="cpe_ready", phase=phase, ok=False)
    return False


def _pdu_reset_once(tag: str) -> bool:
    if not _gb("PDU_RESET_ON_NOT_READY", True):
        return False
    script = _g("PDU_RESET_SCRIPT", "/home/da40/charter/tools/pdu_outlet1.py").strip()
    action = _g("PDU_RESET_ACTION", "reset").strip() or "reset"
    timeout_sec = float(_g("PDU_RESET_TIMEOUT_SEC", "600") or "600")
    wait_sec = float(_g("PDU_RESET_WAIT_SEC", "120") or "120")
    pybin = _g("PYTHON", "python3").strip() or "python3"

    _emit("pdu_reset_start", tag=tag, script=script, action=action)
    rc, out, sec = _run([pybin, script, action], timeout=timeout_sec)
    _emit("pdu_reset_end", tag=tag, rc=rc, sec=round(sec, 3), output_tail=(out or "")[-2000:])
    if rc != 0:
        return False
    if wait_sec > 0:
        _emit("pdu_reset_wait", tag=tag, seconds=wait_sec)
        time.sleep(wait_sec)
    return True


def _get_node_id(tag: str) -> Optional[str]:
    tool = _tool_cpe_info()
    # small retry because after reboot cloud may be up but node-id not ready
    retries = _gi("NODE_ID_MAX_RETRIES", 5)
    sleep_sec = float(_g("NODE_ID_RETRY_INTERVAL_SEC", "3") or "3")
    for i in range(1, retries + 1):
        rc, out, sec = _run([tool, "--node-id"], timeout=60.0)
        sample = [ln.strip() for ln in (out or "").splitlines() if ln.strip()][:3]
        _emit("cmd", tag=tag, ok=(rc == 0), rc=rc, sec=round(sec, 3), argv=[tool, "--node-id"], sample=sample[:1])
        node_id = (sample[0].strip() if (rc == 0 and sample) else "")
        ok = bool(re.match(r"^[0-9a-fA-F]{12}$", node_id))
        if ok:
            _emit("node_id", tag=tag, ok=True, node_id=node_id)
            return node_id.lower()
        if i < retries and sleep_sec > 0:
            time.sleep(sleep_sec)
    _emit("node_id", tag=tag, ok=False, error="node-id not available from cpe_info")
    return None


# ---------------- NOC helpers (match A2435638 v7 event names) ----------------

_NOC_MOD = None


def _tools_path() -> str:
    return _g("TOOLS_PATH", "/home/da40/charter/tools").strip() or "/home/da40/charter/tools"


def _get_noc_module():
    global _NOC_MOD
    if _NOC_MOD is not None:
        return _NOC_MOD
    tp = _tools_path()
    try:
        if tp and tp not in os.sys.path:
            os.sys.path.insert(0, tp)
        import noc_api_cli as _noc  # type: ignore
        _NOC_MOD = _noc
        return _NOC_MOD
    except Exception as e:
        _emit("noc_import_error", ok=False, tools_path=tp, error=str(e))
        _NOC_MOD = None
        return None


def _load_profile_into_env(tag: str) -> None:
    profile = _g("NOC_PROFILE", "").strip()
    if not profile:
        return
    path = _g("PROFILES_FILE", "").strip() or os.path.expanduser("~/.secrets/noc_profiles.json")
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        _emit("noc_profile_missing", tag=tag, profile=profile, path=path)
        return
    except Exception as e:
        _emit("noc_profile_load_error", tag=tag, profile=profile, path=path, error=str(e))
        return

    prof = data.get(profile) or data.get(profile.upper()) or {}
    if not prof:
        _emit("noc_profile_not_found", tag=tag, profile=profile, path=path)
        return

    applied = []
    mapping = {
        "NOC_BASE": "base",
        "NOC_EMAIL": "email",
        "NOC_PASSWORD": "password",
        "CUSTOMER_ID": "customer_id",
        "LOCATION_ID": "location_id",
        "BEARER": "bearer",
        "INSECURE": "insecure",
    }
    for env_k, json_k in mapping.items():
        if os.environ.get(env_k) and str(os.environ.get(env_k)).strip() != "":
            continue
        if json_k in prof and str(prof.get(json_k, "")).strip() != "":
            os.environ[env_k] = str(prof[json_k])
            applied.append(env_k)

    if applied:
        _emit("noc_profile_loaded", tag=tag, profile=profile, applied=applied)


def _noc_login(tag: str) -> Tuple[str, Dict[str, Any]]:
    noc = _get_noc_module()
    if noc is None:
        raise RuntimeError("noc_api_cli not importable")
    base = _g("NOC_BASE", "https://piranha-int.tau.dev-charter.net").strip()
    email = _g("NOC_EMAIL", "").strip()
    password = _g("NOC_PASSWORD", "").strip()
    bearer = _gb("BEARER", False)
    insecure = _gb("INSECURE", False)

    if not base or not email or not password:
        raise RuntimeError("missing NOC_BASE/NOC_EMAIL/NOC_PASSWORD")

    tok = noc.login(base, email, password, bearer=bearer, insecure=insecure)
    return tok, {"base": base, "bearer": bearer, "insecure": insecure}


def _noc_resolve_location(tag: str, base: str, token: str, node_id: str) -> str:
    noc = _get_noc_module()
    if noc is None:
        raise RuntimeError("noc_api_cli not importable")
    customer_id = _g("CUSTOMER_ID", "").strip()
    if not customer_id:
        raise RuntimeError("CUSTOMER_ID not set")
    bearer = _gb("BEARER", False)
    insecure = _gb("INSECURE", False)
    return noc.get_location_id(base, customer_id, node_id, token=token, bearer=bearer, insecure=insecure)


def _ssh_enable_via_noc(tag: str, node_id: str, ssh_password: str, attempt: int) -> bool:
    noc = _get_noc_module()
    if noc is None:
        _emit("ssh_enable_end", tag=tag, ok=False, attempt=attempt, error="noc_api_cli not importable")
        return False

    customer_id = _g("CUSTOMER_ID", "").strip()
    if not customer_id:
        _emit("ssh_enable_end", tag=tag, ok=False, attempt=attempt, error="CUSTOMER_ID not set")
        return False

    try:
        token, meta = _noc_login(tag=tag)
        base = meta["base"]
        bearer = bool(meta["bearer"])
        insecure = bool(meta["insecure"])
        location_id = _noc_resolve_location(tag, base, token, node_id)
        timeout_min = _gi("SSH_TIMEOUT_MIN", 120)

        _emit(
            "ssh_enable_start",
            tag=tag,
            attempt=attempt,
            node_id=node_id,
            location_id=location_id,
            customer_id=customer_id,
            timeout_min=timeout_min,
            base=base,
            bearer=bearer,
            insecure=insecure,
        )
        resp = noc.ssh_enable(
            base,
            customer_id,
            location_id,
            node_id,
            ssh_password,
            timeout_min,
            token=token,
            bearer=bearer,
            insecure=insecure,
        )
        _emit("ssh_enable_end", tag=tag, ok=True, attempt=attempt, resp=resp)
        return True
    except Exception as e:
        _emit("ssh_enable_end", tag=tag, ok=False, attempt=attempt, error=str(e))
        return False


# ---------------- SSH readiness ----------------

def _scan_ssh_port(tag: str, host: str, port: int, timeout_sec: float, interval_sec: float) -> Tuple[bool, int]:
    """Return (ok, attempts)"""
    t0 = time.time()
    attempt = 0
    while True:
        attempt += 1
        ok = False
        try:
            with socket.create_connection((host, port), timeout=3.0):
                ok = True
        except Exception:
            ok = False
        _emit("ssh_port", tag=tag, ok=ok, attempt=attempt)
        if ok:
            return True, attempt
        if time.time() - t0 >= timeout_sec:
            return False, attempt
        if interval_sec > 0:
            time.sleep(interval_sec)


def _ssh_uptime_probe(tag: str, host: str, user: str, password: str) -> bool:
    tool = _tool_cpe_ssh()
    ssh_timeout = float(_g("SSH_TIMEOUT_SEC", "30") or "30")
    cmd = (_g("SSH_READY_CMD", "uptime") or "uptime").strip()
    # sanitize: cpe_ssh.py expects a single token command (e.g., uptime)
    if not cmd or any(ch.isspace() for ch in cmd):
        cmd = "uptime"
    argv = ["python3", tool, "--host", host, "--user", user, "--password", password, "--timeout", str(ssh_timeout), "--cmd", cmd]
    rc, out, sec = _run(argv, timeout=ssh_timeout + 10.0)
    sample = [ln.strip() for ln in (out or "").splitlines() if ln.strip()][:3]
    _emit("cmd", tag=tag, ok=(rc == 0), rc=rc, sec=round(sec, 3), argv=argv, sample=sample[:1])
    _emit("ssh_probe", tag=tag, ok=(rc == 0), rc=rc, sec=round(sec, 3), sample=sample[:1])
    return rc == 0


def ensure_ssh_ready(tag: str, node_id: str) -> bool:
    host = (_g("SSH_HOST", "").strip() or _g("CPE_HOST", "").strip() or "192.168.1.1")
    port = _gi("SSH_PORT", 22)
    scan_timeout = float(_g("SSH_PORT_SCAN_TIMEOUT_SEC", "60") or "60")
    scan_interval = float(_g("SSH_PORT_SCAN_INTERVAL_SEC", "2") or "2")
    user = _g("SSH_USER", "operator").strip() or "operator"
    password = _g("SSH_PASSWORD", "").strip()
    have_password = bool(password)

    _emit(
        "step_start",
        tag=tag,
        name="ssh_ready",
        host=host,
        port=port,
        scan_timeout_sec=scan_timeout,
        scan_interval_sec=scan_interval,
        user=user,
        have_password=have_password,
        node_id=node_id,
    )

    ok, _ = _scan_ssh_port(tag, host, port, scan_timeout, scan_interval)
    if ok and have_password:
        if _ssh_uptime_probe(tag, host, user, password):
            _emit("step_end", tag=tag, name="ssh_ready", ok=True)
            return True

    if not _gb("ENABLE_SSH_VIA_NOC", True):
        _emit("step_end", tag=tag, name="ssh_ready", ok=False, error="ssh port closed and ENABLE_SSH_VIA_NOC=0")
        return False

    if not have_password:
        _emit("step_end", tag=tag, name="ssh_ready", ok=False, error="SSH_PASSWORD not set")
        return False

    # Attempt enable up to N times (default 2)
    attempts = _gi("SSH_ENABLE_ATTEMPTS", 2)
    wait_after = _gi("WAIT_AFTER_SSH_ENABLE_SEC", 60)

    for attempt in range(1, attempts + 1):
        _load_profile_into_env(tag)
        ok_enable = _ssh_enable_via_noc(tag, node_id=node_id, ssh_password=password, attempt=attempt)
        if not ok_enable:
            _emit("ssh_enable_attempt_failed", tag=tag, attempt=attempt)
        else:
            if wait_after > 0:
                _emit("ssh_enable_wait", tag=tag, seconds=wait_after, attempt=attempt)
                time.sleep(wait_after)
        # Re-scan + probe each attempt
        ok_port, _ = _scan_ssh_port(tag, host, port, scan_timeout, scan_interval)
        if ok_port and _ssh_uptime_probe(tag, host, user, password):
            _emit("step_end", tag=tag, name="ssh_ready", ok=True)
            return True

    _emit("step_end", tag=tag, name="ssh_ready", ok=False)
    return False


def precondition_once() -> bool:
    tag = "precondition"
    _load_profile_into_env(tag)
    # 1) cloud ready retry, with at most one PDU reset
    if not _cpe_cloud_check(tag, phase="initial"):
        did = _pdu_reset_once(tag)
        if not did:
            _emit("precondition_ok", ok=False, reason="cpe_ready_failed_no_pdu_reset")
            return False
        if not _cpe_cloud_check(tag, phase="after_pdu_reset"):
            _emit("precondition_ok", ok=False, reason="cpe_ready_failed_after_pdu_reset")
            return False

    node_id = _get_node_id(tag)
    if not node_id:
        _emit("precondition_ok", ok=False, reason="node_id_unavailable")
        return False

    if not ensure_ssh_ready(tag, node_id=node_id):
        _emit("precondition_ok", ok=False, reason="ssh_not_ready")
        return False

    _emit("precondition_ok", ok=True)
    return True


def _import_entry(entry: str):
    if ":" not in entry:
        raise ValueError(f"Bad ORIGINAL_ENTRY format: {entry!r}")
    mod_name, func_name = entry.split(":", 1)
    if mod_name.endswith(".py"):
        mod_name = mod_name[:-3]
    mod = importlib.import_module(mod_name)
    func = getattr(mod, func_name)
    return func


def run() -> int:
    cycles = _gi("CYCLES", 1)
    interval = float(_g("CYCLE_INTERVAL", "0") or "0")
    stop_on_fail = _gb("STOP_ON_FAIL", True)

    original_entry = _g("ORIGINAL_ENTRY", "main_impl.py:run").strip() or "main_impl.py:run"
    _emit(
        "runner_start",
        name="sanity_cycle",
        cycles=cycles,
        interval=interval,
        stop_on_fail=bool(stop_on_fail),
        original_entry=original_entry,
    )

    # Precondition only once
    if cycles >= 1:
        ok = precondition_once()
        if not ok:
            return 2

    func = _import_entry(original_entry)

    overall_rc = 0
    for i in range(1, cycles + 1):
        tag = f"cycle_{i}"
        _emit("cycle_start", i=i, cycle=i, total=cycles)
        # Per-cycle SSH gate
        node_id = _get_node_id(tag)
        if not node_id:
            overall_rc = 2
            _emit("cycle_end", cycle=i, rc=overall_rc)
            if stop_on_fail:
                break
            continue

        _load_profile_into_env(tag)
        if not ensure_ssh_ready(tag, node_id=node_id):
            overall_rc = 2
            _emit("cycle_end", cycle=i, rc=overall_rc)
            if stop_on_fail:
                break
            continue

        try:
            rc = func()
        except SystemExit as se:
            rc = int(se.code or 0)
        except Exception as e:
            _emit("cycle_exception", tag=tag, cycle=i, error=str(e))
            rc = 1

        try:
            rc = int(rc)
        except Exception:
            rc = 1

        _emit("cycle_end", cycle=i, rc=rc)
        if rc != 0:
            overall_rc = rc
            if stop_on_fail:
                break

        if i < cycles and interval > 0:
            time.sleep(interval)

    _emit("all_cycles_done", rc=overall_rc)
    return overall_rc


if __name__ == "__main__":
    raise SystemExit(run())
