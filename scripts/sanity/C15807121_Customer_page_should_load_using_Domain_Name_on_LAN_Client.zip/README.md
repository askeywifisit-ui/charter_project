# C15807121_Customer_page_should_load_using_Domain_Name_on_LAN_Client

## 1) 目的 / 覆蓋範圍
- 驗證特定 Web UI page 可在 LAN（IPv4/IPv6 link-local/Domain）載入。

## 2) 前置條件 / 環境
- 需 client 能存取 CPE Web UI（IPv4/IPv6/Domain 視腳本）。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`rg_cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'70'
- TOOLS_PATH：/home/da40/charter/tools
- PING_IFACE：eno2
- PROFILES_FILE：/home/da40/charter/.secrets/noc_profiles.json
- NOC_PROFILE：SPECTRUM_INT
- CUSTOMER_ID：682d4e5179b80027cd6fb27e

## 5) PASS/FAIL 判定
- PASS：HTTP/頁面載入成功（依腳本判定）。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807121 - Customer page should load using Domain Name on LAN Client

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`rg_cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'70'
- TOOLS_PATH：/home/da40/charter/tools

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807121 - Customer page should load using Domain Name on LAN Client

This script validates that a LAN client can reach the device Web UI using the **domain name** entry point, and that the UI shows consistent device identity.

## What it verifies (aligned to the test plan)
1. (Optional) Factory reset via NOC API, then waits for the device to come back (CPE ready).
2. (Optional) `myrouter` (and/or `MyRouter.lan`) resolves to the expected LAN IPv4 (with retries).
3. **Redirect behavior**:
   - `http://myrouter` must redirect and finally land on:
     - `https://myrouter/cgi-bin/index.cgi`
4. **Web UI field checks** (read from `index.cgi` via `cpe_info`):
   - WAN IPv4 (basic sanity: non-empty, IPv4 format)
   - Model
   - Serial Number
   - FW Version
5. **SSH field checks** (read from `ovsh s AWLAN_Node` via `cpe_ssh.py --cmd awlan-info`):
   - `serial_number`, `model`, `firmware_version`
6. **Compare Web UI vs SSH**:
   - Serial Number: exact match
   - Model: exact match
   - FW Version: configurable match mode (`FW_MATCH_MODE=contains|prefix|exact`)

## Tools used
- `cpe_info` (Web UI index parser)
- `cpe_ssh.py` (SSH helper; `awlan-info` reads SN/Model/FW in one command)
- NOC API CLI (optional factory reset / ssh-enable, if enabled in env)

## Notes
- This script forces IPv4 for the HTTP/HTTPS redirect checks (consistent with the test plan on LAN client).
- If your environment requires enabling SSH via NOC first, keep `ENABLE_SSH_VIA_NOC=1` in env.


## Defaults
- DO_FACTORY_RESET: 0 (disabled by default; set to 1 to enable factory reset)
- NODE_ID_RETRY_INTERVAL_SEC: 5


## v23 hardening
- Fix WAN_IPV4_MATCH / WAN_MAC_MATCH comparisons to use canonical wan_* keys.
- Add adapter aliases (ipv4/mac/ipv6) to br-wan SSH fields.
- Extend CLI non-JSON heuristics for iface-mac, macs, wan-ipv6-detail.
- Expand config_snapshot logging to include WAN match and ping flags.
```

```
