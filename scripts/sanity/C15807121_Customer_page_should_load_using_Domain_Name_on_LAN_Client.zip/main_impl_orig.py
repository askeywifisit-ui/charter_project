#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""C15807121 - Customer page should load using Domain Name on LAN Client

Test plan (updated):
  - Verify http://myrouter redirects to https://myrouter/cgi-bin/index.cgi
  - Read Web UI fields (WAN IPv4 / FW Version / Serial Number / Model) via cpe_info
  - SSH into CPE and read AWLAN_Node (serial_number/model/firmware_version)
  - Compare Web vs SSH values (configurable match mode)
"""

from __future__ import annotations

import json
import os
import re
import socket
import subprocess
import sys

# Avoid using stale __pycache__ in customer runners
sys.dont_write_bytecode = True
import time
import ipaddress
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse
import traceback



# --------------------------
# ANSI / bytes safe helpers
# --------------------------
_ANSI_RE = re.compile(r"\x1B\[[0-?]*[ -/]*[@-~]")

def strip_ansi_text(s) -> str:
    """Return text as str, decode bytes if needed, and remove ANSI escape sequences."""
    if s is None:
        return ""
    if isinstance(s, (bytes, bytearray)):
        try:
            s = s.decode("utf-8", errors="ignore")
        except Exception:
            s = str(s)
    else:
        s = str(s)
    return _ANSI_RE.sub("", s)
# -------------------------------------------------
# Load tools (noc_api_cli) from TOOLS_PATH
# -------------------------------------------------
TOOLS_PATH = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
if TOOLS_PATH and TOOLS_PATH not in sys.path:
    sys.path.insert(0, TOOLS_PATH)

try:
    import noc_api_cli as noc  # type: ignore
except Exception as e:
    noc = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "noc_api_cli", "error": str(e)}), flush=True)


LOOP_FAIL = True


# -------------------------------------------------
# helpers
# -------------------------------------------------

def _open_debug_log() -> Any:
    # Persist logs to a local file to survive stdout/stderr issues in some runners.
    path = os.environ.get("RG_DEBUG_LOG", "rg_debug.jsonl")
    try:
        return open(path, "a", encoding="utf-8")
    except Exception:
        return None


_DEBUG_FH = _open_debug_log()


def _file_write(line: str) -> None:
    try:
        if _DEBUG_FH:
            _DEBUG_FH.write(line + "\n")
            _DEBUG_FH.flush()
    except Exception:
        pass



# --- runtime summary (for quick failure visibility in runner logs) ---
_LAST_RESULT = {
    'state': None,   # 'pass' | 'fail'
    'reason': None,
    'error': None,
}

# Track the last intended exit code (so we can print a single summary line before returning)
_LAST_EXIT_CODE: Optional[int] = None

def _ret(code: int) -> int:
    """Record and return an exit code (used to guarantee result_summary without scanning run dir)."""
    global _LAST_EXIT_CODE
    _LAST_EXIT_CODE = int(code)
    return int(code)


_SUMMARY_EMITTED = False

def _emit_result_summary_now() -> None:
    """Emit a single summary line immediately (stdout + stderr best-effort)."""
    global _SUMMARY_EMITTED
    if _SUMMARY_EMITTED:
        return
    _SUMMARY_EMITTED = True
    try:
        state = _LAST_RESULT.get("state") or ("pass" if (_LAST_EXIT_CODE == 0) else "unknown")
        reason = _LAST_RESULT.get("reason") or ""
        err = _LAST_RESULT.get("error") or ""
        code = _LAST_EXIT_CODE
        if code is None:
            # Fallback mapping if the caller didn't use _ret()
            code = 0 if state == "pass" else 1
        summary = {
            "event": "result_summary",
            "state": state,
            "exit_code": int(code),
            "reason": reason,
            "error": err,
        }
        line = json.dumps(summary, ensure_ascii=False)
        _file_write(line)
        try:
            print(line, flush=True)
        except Exception:
            pass
        try:
            os.write(2, (line + "\n").encode("utf-8", errors="replace"))
        except Exception:
            pass
    except Exception:
        pass

def jlog(event: str, **kv: Any) -> None:
    """Structured logger: never crash the test due to logging."""
    payload: Dict[str, Any] = {"event": event}
    payload.update(kv)

    # Track last status for end-of-run summary
    try:
        if event == 'fail':
            _LAST_RESULT['state'] = 'fail'
            _LAST_RESULT['reason'] = str(kv.get('reason', '') or '')
        elif event == 'pass':
            _LAST_RESULT['state'] = 'pass'
            _LAST_RESULT['reason'] = ''
        elif event == 'error':
            _LAST_RESULT['error'] = str(kv.get('error', '') or '')
    except Exception:
        pass

    # Make JSON-safe
    safe: Dict[str, Any] = {}
    for k, v in payload.items():
        try:
            json.dumps(v, ensure_ascii=False)
            safe[k] = v
        except Exception:
            safe[k] = strip_ansi_text(v)

    try:
        line = json.dumps(safe, ensure_ascii=False)
    except Exception:
        line = json.dumps({k: str(v) for k, v in safe.items()}, ensure_ascii=False)

    # Always persist
    _file_write(line)

    # Also try stdout (may be closed)
    try:
        print(line, flush=True)
    except BrokenPipeError:
        return
    except Exception:
        return


# --- signal handlers (to reveal wrapper kills/timeouts) ---
try:
    import signal as _signal  # type: ignore

    def _sig_handler(signum, frame):
        # Best-effort: emit a signal event and exit.
        try:
            jlog("error", error="terminated_by_signal", signum=signum)
        except Exception:
            pass
        try:
            os.write(2, ("[signal] " + str(signum) + "\n").encode("utf-8", errors="replace"))
        except Exception:
            pass
        raise SystemExit(1)

    for _s in (
        getattr(_signal, "SIGTERM", None),
        getattr(_signal, "SIGINT", None),
        getattr(_signal, "SIGHUP", None),
    ):
        if _s is None:
            continue
        try:
            _signal.signal(_s, _sig_handler)
        except Exception:
            pass
except Exception:
    pass

# --- atexit result summary (avoid having to inspect run dir) ---
import atexit as _atexit


def _emit_result_summary():
    # Always write a short summary line at process exit (best-effort).
    try:
        state = _LAST_RESULT.get("state") or "unknown"
        reason = _LAST_RESULT.get("reason") or ""
        err = _LAST_RESULT.get("error") or ""
        summary = {
            "event": "result_summary",
            "state": state,
            "reason": reason,
            "error": err,
        }
        line = json.dumps(summary, ensure_ascii=False)
        _file_write(line)
        try:
            print(line, flush=True)
        except Exception:
            pass
    except Exception:
        pass


_atexit.register(_emit_result_summary)



def env_str(key: str, default: str = "") -> str:
    v = os.environ.get(key)
    if v is None:
        return default
    return str(v)


def env_int(key: str, default: int) -> int:
    try:
        return int(str(os.environ.get(key, str(default))).strip())
    except Exception:
        return default


def _cpe_ssh_cli_path() -> str:
    # Prefer TOOLS_PATH (same convention as other scripts); fallback to /home/da40/charter/tools
    tools = env_str("TOOLS_PATH", "").strip()
    if tools:
        cand = os.path.join(tools, "cpe_ssh.py")
        if os.path.exists(cand):
            return cand
    cand2 = "/home/da40/charter/tools/cpe_ssh.py"
    return cand2


def _run_cpe_ssh_cli(cmd: str, extra_args: Optional[List[str]] = None, timeout: Optional[float] = None) -> Dict[str, Any]:
    """Run tools/cpe_ssh.py and parse output.

    Primary path: expect JSON on stdout.
    Hardened fallback: accept plain-text stdout for a few known commands
    (wan-ipv4 / iface-mac / macs / wan-ipv6-detail / ping), because some customer
    environments may output non-JSON even with rc=0.
    """
    host = env_str("SSH_HOST", "").strip() or env_str("EXPECTED_LAN_IP", "192.168.1.1").strip() or "192.168.1.1"
    user = env_str("SSH_USER", "operator").strip() or "operator"
    password = env_str("SSH_PASSWORD", "").strip() or env_str("SSH_ENABLE_PASSWORD", "").strip()
    if not password:
        return {"ok": False, "error": "missing SSH_PASSWORD (or SSH_ENABLE_PASSWORD)", "cmd": cmd, "host": host, "user": user}

    cli = _cpe_ssh_cli_path()
    if not os.path.exists(cli):
        return {"ok": False, "error": f"cpe_ssh.py not found at {cli}", "cmd": cmd, "host": host, "user": user}

    args = [sys.executable, cli, "--host", host, "--user", user, "--password", password, "--cmd", cmd]
    if extra_args:
        args.extend(extra_args)

    tmo = timeout if timeout is not None else float(env_int("SSH_TIMEOUT_SEC", 30))
    r = subprocess.run(args, capture_output=True, text=True, timeout=tmo)
    out = (r.stdout or "").strip()
    err = (r.stderr or "").strip()

    # 1) JSON happy-path
    try:
        j = json.loads(out) if out else {}
        if isinstance(j, dict) and j:
            j.setdefault("rc", r.returncode)
            j.setdefault("host", host)
            j.setdefault("user", user)
            j.setdefault("cmd", cmd)
            return j
    except Exception:
        pass

    # 2) Non-JSON fallback (hardened)
    base = {
        "rc": r.returncode,
        "host": host,
        "user": user,
        "cmd": cmd,
        "stdout": out,
        "stdout_tail": out[-400:],
        "stderr_tail": err[-400:],
    }
    j: Dict[str, Any] = {"ok": (r.returncode == 0), "error": "non-json-output", **base}

    if cmd in ("wan-ipv4",):
        m = re.search(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", out)
        if m:
            ip = m.group(0)
            j.update({"ok": True, "ipv4": ip, "wan_ipv4": ip})
            j.pop("error", None)

    elif cmd in ("iface-mac",):
        m = re.search(r"\b([0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5})\b", out)
        if m:
            mac = m.group(1)
            j.update({"ok": True, "mac": mac, "wan_mac": mac})
            j.pop("error", None)

    elif cmd in ("macs",):
        macs = re.findall(r"\b([0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5})\b", out)
        if macs:
            j.update({"ok": True, "macs_list": macs})
            j.pop("error", None)

    elif cmd in ("wan-ipv6-detail", "wan-ipv6"):
        m = re.search(r"\b([0-9A-Fa-f]{0,4}:(?:[0-9A-Fa-f]{0,4}:){1,6}[0-9A-Fa-f]{0,4})(?:/(\d{1,3}))?\b", out)
        if m:
            ipv6 = m.group(1)
            plen = m.group(2)
            j.update({"ok": True, "ipv6": ipv6, "prefix_len": int(plen) if plen else None, "wan_ipv6": ipv6})
            j.pop("error", None)

    elif cmd in ("ping",):
        # BusyBox ping often prints: "X packets transmitted, Y packets received, Z% packet loss"
        m = re.search(r"(\d+(?:\.\d+)?)%\s*packet\s*loss", out, re.IGNORECASE)
        if m:
            loss = float(m.group(1))
            max_loss = float(env_int("SSH_PING_MAX_LOSS", 50))
            j.update({"ok": (loss <= max_loss), "loss_pct": loss})
            j.pop("error", None)

    return j

def env_bool(key: str, default: bool = False) -> bool:
    v = os.environ.get(key)
    if v is None:
        return default
    s = str(v).strip().lower()
    if s in ("1", "true", "yes", "y", "on"):
        return True
    if s in ("0", "false", "no", "n", "off"):
        return False
    return default


def _norm_key(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").strip().lower())


def _looks_ipv4(s: str) -> bool:
    s = (s or "").strip()
    if not s:
        return False
    m = re.search(r"\b(\d{1,3})(?:\.(\d{1,3})){3}\b", s)
    if not m:
        return False
    parts = m.group(0).split(".")
    try:
        return all(0 <= int(p) <= 255 for p in parts)
    except Exception:
        return False


def _looks_base64(s: str) -> bool:
    s = (s or "").strip()
    if len(s) < 8:
        return False
    if re.fullmatch(r"[A-Za-z0-9+/]+={0,2}", s) is None:
        return False
    return len(s) % 4 == 0


def _b64_decode_safe(s: str) -> str:
    import base64

    try:
        return base64.b64decode((s or "").encode("utf-8"), validate=False).decode("utf-8", "ignore").strip()
    except Exception:
        return ""


def _split_csv(s: str) -> List[str]:
    return [x.strip() for x in (s or "").split(",") if x.strip()]


def _url_host(url: str) -> str:
    try:
        return (urlparse(url).hostname or "").strip()
    except Exception:
        return ""


def resolve_host_ipv4(host: str) -> List[str]:
    """Resolve host to IPv4 addresses (best-effort)."""
    host = (host or "").strip()
    if not host:
        return []

    # Prefer getent because it respects /etc/hosts + DNS + mDNS/LLMNR setups.
    addrs: List[str] = []
    try:
        p = subprocess.run(["getent", "ahostsv4", host], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out = (p.stdout or "")
        for line in out.splitlines():
            parts = line.split()
            if parts and _looks_ipv4(parts[0]):
                if parts[0] not in addrs:
                    addrs.append(parts[0])
    except Exception:
        pass

    if addrs:
        return addrs

    # Fallback to socket
    try:
        infos = socket.getaddrinfo(host, None, family=socket.AF_INET)
        for info in infos:
            ip = info[4][0]
            if _looks_ipv4(ip) and ip not in addrs:
                addrs.append(ip)
    except Exception:
        return []

    return addrs


def _normalize_mac(s: str) -> str:
    """Normalize MAC string to lower-case colon-separated 6-byte format."""
    s = (s or "").strip().lower()
    if not s:
        return ""
    # extract the first 6 hex bytes we can find
    bytes_ = re.findall(r"[0-9a-f]{2}", s)
    if len(bytes_) < 6:
        return ""
    bytes_ = bytes_[:6]
    return ":".join(bytes_)


def _parse_ifconfig_a_macs(text: str) -> Dict[str, str]:
    """Parse interface MACs from command output into {iface: mac}. Best-effort.

    Supported formats:
      - ifconfig -a / ifconfig
      - ip link show / ip -o link
    """
    macs: Dict[str, str] = {}
    cur: Optional[str] = None
    for raw in (text or "").splitlines():
        line = raw.rstrip("\r")
        if not line.strip():
            continue
        if line[:1].strip():
            # interface header line usually starts at column 0
            # ip link format example: "2: eth0@ifb0: <...>" (avoid capturing "2:")
            m_hdr = re.match(r"^\s*\d+:\s*([^:]+):", line)
            if m_hdr:
                cur = m_hdr.group(1).split("@")[0]
            else:
                cur = line.split()[0]
            # try parse mac on same line
            m = re.search(r"\b(?:hwaddr|ether|link/ether)\b\s+([^\s]+)", line, re.I)
            if m and cur:
                mac = _normalize_mac(m.group(1))
                if mac:
                    macs[cur] = mac
            continue

        # indented line within current interface
        if not cur:
            continue
        m = re.search(r"\b(?:hwaddr|ether|link/ether)\b\s+([^\s]+)", line, re.I)
        if m:
            mac = _normalize_mac(m.group(1))
            if mac:
                macs[cur] = mac

    return macs


def maybe_enable_ssh_via_noc(creds: NocCreds, token: str, location_id: str, node_id: str) -> bool:
    """Enable SSH via NOC kvConfigs (optional). Returns True if we attempted enable."""
    if noc is None:
        raise RuntimeError("noc_api_cli import failed")

    if not env_bool("ENABLE_SSH_VIA_NOC", False):
        jlog("ssh_enable_skip", reason="ENABLE_SSH_VIA_NOC=0")
        return False

    customer_id = env_str("CUSTOMER_ID")
    passwd = (
        env_str("SSH_ENABLE_PASSWORD", "").strip()
        or env_str("SSH_PASSWORD", "").strip()
        or env_str("CPE_PASSWORD", "").strip()
    )
    timeout_min = env_int("SSH_ENABLE_TIMEOUT_MIN", 30)

    if not passwd:
        jlog("ssh_enable_skip", reason="missing_password", hint="set SSH_ENABLE_PASSWORD (or SSH_PASSWORD)")
        return False

    jlog("ssh_enable_start", timeout_min=timeout_min)
    resp = noc.ssh_enable(
        creds.base,
        customer_id,
        location_id,
        node_id,
        passwd,
        timeout_min,
        token=token,
        bearer=creds.bearer,
        insecure=creds.insecure,
    )
    jlog("ssh_enable_ok", response=resp)
    return True


def validate_macs_against_ifconfig(warehouse: Dict[str, Any]) -> Tuple[bool, Dict[str, Any]]:
    """Validate warehouse MAC fields against `ifconfig -a` from the CPE (via SSH).

    Mapping (default per requirement):
      - WAN  : ifconfig br-wan
      - LAN  : ifconfig br-home / BR_LAN
      - WLAN2.4: ifconfig wifi0
      - WLAN5.0: ifconfig wifi1
      - WLAN6.0: ifconfig wifi2
    """
    if not env_bool("VALIDATE_MACS_VIA_SSH", False):
        return True, {"skipped": True, "reason": "VALIDATE_MACS_VIA_SSH=0"}

    # Lazy import so the script still works in environments without tools.
    try:
        import cpe_ssh  # type: ignore
    except Exception as e:
        return False, {"skipped": False, "error": f"import cpe_ssh failed: {e}"}

    host = env_str("SSH_HOST", "").strip() or env_str("EXPECTED_LAN_IP", "192.168.1.1").strip() or "192.168.1.1"
    user = env_str("SSH_USER", "operator").strip() or "operator"
    password = env_str("SSH_PASSWORD", "").strip() or env_str("SSH_ENABLE_PASSWORD", "").strip()
    timeout = float(env_int("SSH_TIMEOUT_SEC", 30))
    strict = env_bool("MAC_VALIDATION_STRICT", True)
    allow_swap = env_bool("ALLOW_WIFI5_WIFI6_SWAP", True)

    if not password:
        return False, {"skipped": False, "error": "missing SSH_PASSWORD (or SSH_ENABLE_PASSWORD)"}

    # Wait for SSH to be ready (after factory reset / ssh-enable it may take time)
    ready_retries = env_int("SSH_READY_RETRIES", 10)
    ready_sleep = float(env_int("SSH_READY_SLEEP_SEC", 3))
    ready_timeout = float(env_int("SSH_READY_TIMEOUT_SEC", 8))
    ready_cmd = env_str("SSH_READY_CMD", "uptime").strip() or "uptime"
    ready_ok = False
    last_err = ""
    for a in range(1, ready_retries + 1):
        rrc, rout, rerr, rsec = cpe_ssh.ssh_exec(host, user, password, ready_cmd, timeout=ready_timeout, login_shell=True)
        last_err = (rerr or "").strip()
        jlog("ssh_ready_check", attempt=a, max_retries=ready_retries, rc=rrc, sec=rsec, err_tail=last_err[-200:])
        if rrc == 0:
            ready_ok = True
            break
        time.sleep(ready_sleep)

    if not ready_ok:
        return False, {"skipped": False, "error": "ssh not ready", "err": last_err}
    # Fetch MACs via cpe_ssh.py --cmd macs (preferred; more robust than parsing ifconfig output here)
    import sys, subprocess, json as _json

    def _resolve_cpe_ssh_tool() -> str:
        # Priority:
        #   1) env CPE_SSH_TOOL (absolute or relative)
        #   2) bundled cpe_ssh.py in this script directory
        #   3) common tools path /home/da40/charter/tools/cpe_ssh.py
        p = env_str("CPE_SSH_TOOL", "").strip()
        if p and os.path.exists(p):
            return p
        here = os.path.join(os.path.dirname(__file__), "cpe_ssh.py")
        if os.path.exists(here):
            return here
        common = "/home/da40/charter/tools/cpe_ssh.py"
        return common

    def _macs_csv_ifaces() -> List[str]:
        v = env_str("MACS_IFACES", "").strip() or env_str("MACS_IFACES_CSV", "").strip() or env_str("SSH_MACS_IFACES", "").strip()
        if v:
            return [x.strip() for x in v.split(",") if x.strip()]
        return ["br-wan", "br-home", "wifi0", "wifi1", "wifi2"]

    tool = _resolve_cpe_ssh_tool()
    ifaces = _macs_csv_ifaces()

    tool_retries = env_int("SSH_MACS_RETRIES", 3)
    tool_sleep = float(env_int("SSH_MACS_SLEEP_SEC", 3))
    tool_timeout = float(env_int("SSH_MACS_TIMEOUT_SEC", max(30, int(timeout))))
    tool_max_timeout = float(env_int("SSH_MACS_MAX_TIMEOUT_SEC", max(60, int(timeout) * 2)))

    macs: Dict[str, str] = {}
    last_tool_err = ""
    last_tool_out = ""

    for a in range(1, tool_retries + 1):
        cmdv = [
            sys.executable,
            tool,
            "--host", host,
            "--user", user,
            "--password", password,
            "--timeout", str(tool_timeout),
            "--cmd", "macs",
            "--ifaces", ",".join(ifaces),
        ]
        try:
            p = subprocess.run(cmdv, capture_output=True, text=True)
            last_tool_out = (p.stdout or "").strip()
            last_tool_err = (p.stderr or "").strip()
            jlog("ssh_macs_via_tool", attempt=a, max_retries=tool_retries, rc=p.returncode,
                 timeout=tool_timeout, tool=tool, ifaces=",".join(ifaces),
                 out_tail=last_tool_out[-400:], err_tail=last_tool_err[-200:])
            if p.returncode == 0 and last_tool_out:
                data = _json.loads(last_tool_out)
                if isinstance(data, dict) and data.get("ok") and isinstance(data.get("macs"), dict):
                    macs = {str(k): _normalize_mac(str(v)) for k, v in data["macs"].items()}
                    break
        except Exception as e:
            last_tool_err = f"{type(e).__name__}: {e}"
            jlog("ssh_macs_via_tool_exc", attempt=a, max_retries=tool_retries, err=last_tool_err)
        # Increase timeout gradually (busy boot / rate-limit)
        if tool_timeout < tool_max_timeout:
            tool_timeout = min(tool_max_timeout, tool_timeout * 1.5)
        time.sleep(tool_sleep)

    if not macs:
        # Optional hard-fail if user wants tool-only behavior
        if env_bool("MACS_USE_TOOL_ONLY", False):
            return False, {
                "skipped": False,
                "error": "failed to fetch macs via cpe_ssh tool",
                "tool": tool,
                "stdout": last_tool_out[-800:],
                "stderr": last_tool_err[-400:],
            }

        # Fallback to legacy approach: run ifconfig/ip and parse locally
        retries = env_int("SSH_IFCONFIG_RETRIES", 3)
        sleep_sec = float(env_int("SSH_IFCONFIG_SLEEP_SEC", 3))
        max_timeout = float(env_int("SSH_IFCONFIG_MAX_TIMEOUT_SEC", max(30, int(timeout))))
        cur_timeout = float(timeout)

        out, err, cmd, rc = "", "", "", 0
        for a in range(1, retries + 1):
            # Prefer `ip -o link` then fallback to ifconfig
            cmd_candidates = [
                "ip -o link 2>/dev/null",
                "ip link show 2>/dev/null",
                "ifconfig -a 2>/dev/null",
                "ifconfig 2>/dev/null",
            ]
            for ccmd in cmd_candidates:
                cmd = ccmd
                rc, out, err, sec = cpe_ssh.ssh_exec(host, user, password, cmd, timeout=cur_timeout, login_shell=True)
                jlog("ssh_ifconfig_a", attempt=a, max_retries=retries, timeout=cur_timeout, rc=rc, sec=sec,
                     out_tail=(out or "")[-400:], err_tail=(err or "")[-200:], cmd=cmd)
                if rc == 0 and out:
                    break
            if rc == 0 and out:
                break
            if rc == 124 and cur_timeout < max_timeout:
                cur_timeout = min(max_timeout, cur_timeout * 1.5)
            time.sleep(sleep_sec)

        if rc != 0:
            return False, {
                "skipped": False,
                "error": f"ifconfig command failed rc={rc}",
                "cmd": cmd,
                "err": (err or "").strip(),
                "tool_stdout": last_tool_out[-800:],
                "tool_stderr": last_tool_err[-400:],
            }

        macs = _parse_ifconfig_a_macs(out)
    def _csv_ifaces(key: str, default_list: List[str]) -> List[str]:
        v = env_str(key, "").strip()
        if not v:
            return default_list
        return [x.strip() for x in v.split(",") if x.strip()]

    checks = [
        {
            "field": "WAN MAC Address",
            "ifaces": ["br-wan"],
        },
        {
            "field": "LAN MAC Address",
            "ifaces": ["br-home", "BR_LAN", "br-lan", "br0"],
        },
        {
            "field": "WLAN2.4 MAC Address",
            "ifaces": ["wifi0", "home-ap-24"],
        },
        {
            "field": "WLAN5.0 MAC Address",
            "ifaces": _csv_ifaces("WLAN5_IFACES", ["home-ap-50", "wifi1", "home-ap-5"]),
        },
        {
            "field": "WLAN6.0 MAC Address",
            "ifaces": _csv_ifaces("WLAN6_IFACES", ["home-ap-60", "wifi2", "home-ap-6"]),
        },
    ]

    results: List[Dict[str, Any]] = []
    ok_all = True
    candidates_by_field: Dict[str, List[Dict[str, str]]] = {}
    index_by_field: Dict[str, int] = {}
    swap_applied = False

    for c in checks:
        field = c["field"]
        exp = _normalize_mac(str(warehouse.get(field, "")))
        iface_used = ""
        got = ""
        cand_list: List[Dict[str, str]] = []
        for iface in c["ifaces"]:
            if iface in macs and macs[iface]:
                cand_list.append({"iface": iface, "mac": macs[iface]})
                if not got:
                    iface_used = iface
                    got = macs[iface]
        candidates_by_field[field] = cand_list


        ok = True
        reason = ""

        if not exp:
            ok = False if strict else True
            reason = "warehouse_field_missing"
        elif not got:
            ok = False if strict else True
            reason = "iface_mac_missing"
        elif exp != got:
            ok = False
            reason = "mismatch"

        index_by_field[field] = len(results)
        results.append({
            "field": field,
            "expected": exp,
            "iface": iface_used,
            "actual": got,
            "candidates": candidates_by_field.get(field, []),
            "ok": ok,
            "reason": reason,
        })

        if not ok:
            ok_all = False

    # Some platforms label radios differently (e.g. wifi1 <-> wifi2). If both expected values are present
    # but swapped between the 5G and 6G candidate iface sets, optionally accept the swap.
    if allow_swap:
        f5 = "WLAN5.0 MAC Address"
        f6 = "WLAN6.0 MAC Address"
        if f5 in index_by_field and f6 in index_by_field:
            r5 = results[index_by_field[f5]]
            r6 = results[index_by_field[f6]]
            exp5 = str(r5.get("expected", "") or "")
            exp6 = str(r6.get("expected", "") or "")
            if exp5 and exp6:
                c5 = [c.get("mac", "") for c in candidates_by_field.get(f5, [])]
                c6 = [c.get("mac", "") for c in candidates_by_field.get(f6, [])]
                if (not r5.get("ok") or not r6.get("ok")) and (exp5 in c6) and (exp6 in c5):
                    def _find_iface(field: str, mac: str) -> str:
                        for c in candidates_by_field.get(field, []):
                            if c.get("mac") == mac:
                                return str(c.get("iface") or "")
                        return ""
                    # swap: 5G expected found in 6G candidates and vice versa
                    r5["ok"] = True
                    r5["reason"] = "swap_allowed"
                    r5["iface"] = _find_iface(f6, exp5) or r5.get("iface", "")
                    r5["actual"] = exp5

                    r6["ok"] = True
                    r6["reason"] = "swap_allowed"
                    r6["iface"] = _find_iface(f5, exp6) or r6.get("iface", "")
                    r6["actual"] = exp6

                    swap_applied = True
                    ok_all = all(bool(r.get("ok")) for r in results)

    return ok_all, {"skipped": False, "strict": strict, "results": results, "allow_swap": allow_swap, "swap_applied": swap_applied, "ifaces_seen": sorted(list(macs.keys()))[:50]}


def _normalize_location(http_url: str, location: str) -> str:
    """Normalize Location header into an absolute URL when it's relative."""
    loc = (location or "").strip()
    if not loc:
        return ""
    if loc.lower().startswith("http://") or loc.lower().startswith("https://"):
        return loc
    # relative path
    host = _url_host(http_url)
    if not host:
        return loc
    if not loc.startswith("/"):
        loc = "/" + loc
    return f"https://{host}{loc}"


@dataclass
class NocCreds:
    base: str
    email: str
    password: str
    bearer: bool
    insecure: bool


def load_noc_creds() -> NocCreds:
    bearer = env_bool("BEARER", False)
    insecure = env_bool("INSECURE", False)

    profile = env_str("NOC_PROFILE", "").strip()
    profiles_file = env_str("PROFILES_FILE", "").strip() or os.path.expanduser("~/.secrets/noc_profiles.json")

    if profile:
        try:
            with open(profiles_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            prof = data.get(profile) or data.get(profile.upper())
            if prof and prof.get("base") and prof.get("email") and prof.get("password"):
                jlog("noc_profile_loaded", profile=profile, profiles_file=profiles_file)
                return NocCreds(
                    base=str(prof["base"]),
                    email=str(prof["email"]),
                    password=str(prof["password"]),
                    bearer=bearer,
                    insecure=insecure,
                )
            jlog("noc_profile_missing", profile=profile, profiles_file=profiles_file)
        except Exception as e:
            jlog("noc_profile_load_error", profile=profile, profiles_file=profiles_file, error=str(e))

    base = env_str("NOC_BASE", "").strip()
    email = env_str("NOC_EMAIL", "").strip()
    password = env_str("NOC_PASSWORD", "").strip()
    if not (base and email and password):
        raise RuntimeError("Missing NOC credentials: provide NOC_PROFILE/PROFILES_FILE or NOC_BASE/NOC_EMAIL/NOC_PASSWORD")

    jlog("noc_profile_fallback_env", base=base)
    return NocCreds(base=base, email=email, password=password, bearer=bearer, insecure=insecure)


def noc_login(creds: NocCreds) -> str:
    if noc is None:
        raise RuntimeError("noc_api_cli import failed")
    tok = noc.login(creds.base, creds.email, creds.password, bearer=creds.bearer, insecure=creds.insecure)
    jlog("noc_login_ok")
    return tok



def node_id_fallback_via_cpe_info() -> Optional[str]:
    """Fallback: get node_id from WAN MAC via cpe_info --node-id --value.

    We prefer an explicit tool path from env CPE_INFO_TOOL; if it points to a python file,
    we execute it with the current interpreter to avoid chmod issues.
    """
    if not env_bool("NODE_ID_FALLBACK_CPE_INFO", True):
        return None

    tool = (env_str("CPE_INFO_TOOL", "").strip()
            or env_str("CPE_INFO", "").strip()
            or "/home/da40/charter/tools/cpe_info")

    # If a local copy exists in run dir, prefer it
    if os.path.exists("./cpe_info"):
        tool = "./cpe_info"

    cmd = [tool, "--node-id", "--value"]
    if tool.endswith(".py") or (os.path.exists(tool) and not os.access(tool, os.X_OK)):
        cmd = [sys.executable, tool, "--node-id", "--value"]

    jlog("node_id_fallback_cmd", cmd=cmd)
    try:
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=10)
        out = (p.stdout or "").strip()
        err = (p.stderr or "").strip()
        if p.returncode != 0 or not out:
            jlog("node_id_fallback_fail", rc=p.returncode, stdout_tail=out[-200:], stderr_tail=err[-200:])
            return None
        node_id = out.strip().lower()
        # basic sanity: 12 hex chars
        if not re.fullmatch(r"[0-9a-f]{12}", node_id):
            jlog("node_id_fallback_fail", rc=p.returncode, stdout_tail=out[-200:], stderr_tail=err[-200:], reason="bad_node_id_format")
            return None
        jlog("node_id_fallback_ok", node_id=node_id)
        return node_id
    except Exception as e:
        jlog("node_id_fallback_fail", error=str(e))
        return None


def resolve_node_id() -> str:
    """Resolve node_id using ONLY cpe_info --node-id (no console/serial).

    This aligns sanity/stability precondition standard:
      - `cpe_info --node-id` returns 12-hex node id (WAN MAC without colons)
    """
    tool = env_str("CPE_INFO_TOOL", "").strip() or "/home/da40/charter/tools/cpe_info"
    max_retries = env_int("NODE_ID_MAX_RETRIES", 5)
    interval = float(env_int("NODE_ID_RETRY_INTERVAL_SEC", 3))
    timeout_sec = float(env_int("NODE_ID_TIMEOUT_SEC", 60))

    # If tool is a python file (or not executable), execute with current interpreter
    cmd = [tool, "--node-id"]
    if tool.endswith(".py") or (os.path.exists(tool) and not os.access(tool, os.X_OK)):
        cmd = [sys.executable, tool, "--node-id"]

    last_err = ""
    for attempt in range(1, max_retries + 1):
        try:
            p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout_sec)
            out = (p.stdout or "").strip()
            err = (p.stderr or "").strip()
            raw = out if out else err

            node_id = ""
            for ln in raw.splitlines():
                ln = ln.strip()
                if not ln:
                    continue
                node_id = ln
                break

            ok = bool(re.fullmatch(r"[0-9a-fA-F]{12}", node_id))
            jlog("node_id_cpe_info", attempt=attempt, cmd=cmd, rc=p.returncode, raw=(raw[:300] if raw else ""), node_id=node_id, ok=ok)
            if p.returncode == 0 and ok:
                return node_id.lower()

            last_err = f"rc={p.returncode} node_id={node_id!r}"
        except Exception as e:
            last_err = str(e)
            jlog("node_id_cpe_info_exception", attempt=attempt, cmd=cmd, error=last_err)

        if attempt < max_retries:
            time.sleep(max(0.0, interval))

    raise RuntimeError(f"node-id resolve failed via cpe_info --node-id: {last_err}")


def resolve_location_id(creds: NocCreds, token: str, node_id: str) -> str:
    if noc is None:
        raise RuntimeError("noc_api_cli import failed")
    loc = noc.get_location_id(
        creds.base,
        env_str("CUSTOMER_ID"),
        node_id,
        token=token,
        bearer=creds.bearer,
        insecure=creds.insecure,
    )
    jlog("location_id_ok", location_id=loc)
    return loc


def do_factory_reset(creds: NocCreds, token: str, location_id: str) -> None:
    if noc is None:
        raise RuntimeError("noc_api_cli import failed")

    customer_id = env_str("CUSTOMER_ID")
    jlog("factory_reset_start", customer_id=customer_id, location_id=location_id)
    noc.factory_reset(
        creds.base,
        customer_id,
        location_id,
        token=token,
        bearer=creds.bearer,
        insecure=creds.insecure,
        options=None,
    )
    jlog("factory_reset_sent")

    # Optional: console mute during reboot window (same behavior as C15807240)
    mute_raw = (
        env_str("RESET_MUTE_SECS", "").strip()
        or env_str("FACTORY_RESET_MUTE_SECS", "").strip()
        or env_str("FR_MUTE_SECS", "").strip()
    )

    if not mute_raw:
        jlog("factory_reset_mute_console_skip", reason="env_not_set")
    else:
        try:
            mute_secs = int(mute_raw)
        except Exception:
            mute_secs = 0
            jlog("factory_reset_mute_console_invalid", mute_raw=mute_raw)

        if mute_secs <= 0:
            jlog("factory_reset_mute_console_skip", reason="mute_secs<=0", mute_raw=mute_raw)
        else:
            # mute-only; do not acquire serial/console lock
            use_lock = False
            lock_timeout = env_int(
                "CONSOLE_LOCK_TIMEOUT_SEC", env_int("FACTORY_RESET_MUTE_LOCK_TIMEOUT_SEC", 5)
            )
            retry_timeout = env_int("CONSOLE_LOCK_RETRY_TIMEOUT_SEC", 60)
            retry_interval = env_int("CONSOLE_LOCK_RETRY_INTERVAL_SEC", 3)

            until_ts = None
            t0 = time.time()
            attempt = 0
            while True:
                attempt += 1
                try:
                    import cpe_ssh  # type: ignore

                    until_ts = cpe_ssh.set_console_mute(mute_secs, use_lock=use_lock, lock_timeout=lock_timeout)
                    jlog(
                        "factory_reset_mute_console",
                        mute_secs=mute_secs,
                        use_lock=use_lock,
                        lock_timeout=lock_timeout,
                        until_ts=until_ts,
                        attempt=attempt,
                    )
                    break
                except Exception as e:
                    elapsed = time.time() - t0
                    if elapsed >= retry_timeout:
                        jlog(
                            "factory_reset_mute_console_fail",
                            mute_secs=mute_secs,
                            use_lock=use_lock,
                            lock_timeout=lock_timeout,
                            attempts=attempt,
                            retry_timeout=retry_timeout,
                            error=str(e),
                        )
                        break
                    jlog(
                        "factory_reset_mute_console_retry",
                        mute_secs=mute_secs,
                        use_lock=use_lock,
                        lock_timeout=lock_timeout,
                        attempt=attempt,
                        retry_in_sec=retry_interval,
                        elapsed_sec=round(elapsed, 3),
                        error=str(e),
                    )
                    time.sleep(retry_interval)

            if until_ts is None:
                sm = os.path.join(TOOLS_PATH or "/home/da40/charter/tools", "serial_mute.py")
                if os.path.exists(sm):
                    cmd = [sys.executable, sm, "--set", str(mute_secs)]
                    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                    jlog(
                        "factory_reset_mute_console_fallback",
                        cmd=cmd,
                        rc=p.returncode,
                        out=(p.stdout or "").strip(),
                        err=(p.stderr or "").strip(),
                    )

    settle = env_int("FR_SETTLE_WAIT_SEC", 120)
    if settle > 0:
        jlog("factory_reset_settle_wait", secs=settle)
        time.sleep(settle)


def check_http_redirect(http_url: str, timeout_sec: int = 5) -> Tuple[bool, Dict[str, str]]:
    cmd = [
        "curl",
        "-4",
        "-sSI",
        "-m",
        str(max(1, timeout_sec)),
        http_url,
    ]
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    out = (p.stdout or "")
    status = ""
    location = ""
    for line in out.splitlines():
        if not status and line.lower().startswith("http/"):
            status = line.strip()
        if line.lower().startswith("location:"):
            location = line.split(":", 1)[1].strip()

    ok = False
    code = None
    m = re.search(r"\s(\d{3})\s", status)
    if m:
        try:
            code = int(m.group(1))
        except Exception:
            code = None

    if code in (301, 302, 303, 307, 308):
        loc_abs = _normalize_location(http_url, location)
        if loc_abs.lower().startswith("https://"):
            ok = True

    info = {"status": status, "location": location, "location_abs": _normalize_location(http_url, location), "rc": str(p.returncode)}
    return ok, info



def _curl_effective_url(url: str, timeout_sec: int = 10) -> Tuple[bool, Dict[str, str]]:
    """Follow redirects and return the final effective URL.

    We use curl -L and -w %{url_effective}. For HTTPS with self-signed certs, -k is required.
    """
    cmd = [
        "curl",
        "-4",
        "-k",
        "-Ls",
        "-o",
        "/dev/null",
        "-m",
        str(max(1, timeout_sec)),
        "-w",
        "%{url_effective}",
        url,
    ]
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    eff = (p.stdout or "").strip()
    ok = (p.returncode == 0 and bool(eff))
    info = {
        "rc": str(p.returncode),
        "effective_url": eff,
        "stderr": (p.stderr or "").strip(),
    }
    return ok, info




def check_redirect_expected(http_url: str, expected_https: str) -> Tuple[bool, Dict[str, Any]]:
    """Check that http_url redirects to expected https URL.

    Behavior:
      - We always require the HTTP response is a redirect (30x) and its Location resolves to https://...
      - By default (REDIRECT_CHECK_FINAL=1), we additionally follow redirects and compare the *final* URL
        (curl %{url_effective}) to expected_https.

    Knobs:
      - REDIRECT_CHECK_FINAL: 1/0 (default 1)
      - REDIRECT_MATCH_MODE: strict | prefix | https_only (default strict)
      - ALLOW_RELATIVE_LOCATION: 1/0 (default 1)

    Backward compatible aliases:
      - REDIRECT_STRICT / REDIRECT_ALLOW_RELATIVE
    """

    ok_basic, info = check_http_redirect(http_url, timeout_sec=env_int("WEB_TIMEOUT_SEC", env_int("WAREHOUSE_TIMEOUT_SEC", 3)) + 2)

    # Preferred knobs
    mode = (env_str("REDIRECT_MATCH_MODE", "").strip().lower() or "strict")
    allow_relative = env_bool("ALLOW_RELATIVE_LOCATION", True)

    # Backward compatible knobs
    if os.environ.get("ALLOW_RELATIVE_LOCATION") is None:
        allow_relative = env_bool("REDIRECT_ALLOW_RELATIVE", True)
    if os.environ.get("REDIRECT_MATCH_MODE") is None:
        strict_old = env_bool("REDIRECT_STRICT", True)
        mode = "strict" if strict_old else "https_only"

    loc = str(info.get("location") or "").strip()
    loc_abs = str(info.get("location_abs") or "").strip()

    # First-hop candidate (Location)
    cand_first = loc_abs if allow_relative else loc
    cand_first_l = cand_first.strip().lower().rstrip("/")

    exp_l = (expected_https or "").strip().lower().rstrip("/")

    ok = ok_basic
    reason = ""

    check_final = env_bool("REDIRECT_CHECK_FINAL", True)
    final_ok = True
    final_info: Dict[str, str] = {}
    final_url = ""

    if ok and check_final:
        # Follow redirects and compare final effective URL.
        final_ok, final_info = _curl_effective_url(
            http_url,
            timeout_sec=env_int("REDIRECT_FINAL_TIMEOUT_SEC", env_int("WEB_TIMEOUT_SEC", env_int("WAREHOUSE_TIMEOUT_SEC", 3)) + 7),
        )
        final_url = (final_info.get("effective_url") or "").strip()
        cand_final_l = final_url.strip().lower().rstrip("/")

        if not final_ok:
            ok = False
            reason = "final_url_fetch_failed"
        else:
            if mode == "strict":
                if exp_l and cand_final_l != exp_l:
                    ok = False
                    reason = "final_url_mismatch"
            elif mode == "prefix":
                if exp_l and not cand_final_l.startswith(exp_l):
                    ok = False
                    reason = "final_url_prefix_mismatch"
            elif mode == "https_only":
                if not cand_final_l.startswith("https://"):
                    ok = False
                    reason = "final_url_not_https"
            else:
                # Unknown mode: be strict.
                if exp_l and cand_final_l != exp_l:
                    ok = False
                    reason = "final_url_mismatch_unknown_mode"

    else:
        # Compare only the first-hop Location.
        if ok and mode in ("strict", "prefix") and exp_l:
            if mode == "strict":
                if cand_first_l != exp_l:
                    ok = False
                    reason = "location_mismatch"
            else:
                if not cand_first_l.startswith(exp_l):
                    ok = False
                    reason = "location_prefix_mismatch"
        elif ok and mode == "https_only":
            # ok_basic already ensures https:// on Location
            pass
        elif ok and mode not in ("strict", "prefix", "https_only"):
            if exp_l and cand_first_l != exp_l:
                ok = False
                reason = "location_mismatch_unknown_mode"

    detail: Dict[str, Any] = {
        "http_url": http_url,
        "expected": expected_https,
        "match_mode": mode,
        "allow_relative": allow_relative,
        "basic_ok": ok_basic,
        "reason": reason,
        "check_final": check_final,
        "first_location": loc,
        "first_location_abs": loc_abs,
        "first_candidate": cand_first,
        "first_candidate_norm": cand_first_l,
        "final_ok": final_ok,
        "final_url": final_url,
        **info,
        **({"final_info": final_info} if final_info else {}),
    }
    return ok, detail



def fetch_index_via_cpe_info(base_url: str) -> Dict[str, str]:
    """Fetch /cgi-bin/index.cgi via cpe_info tool (helper module).

    We treat cpe_info like other helper tools (e.g., cpe_warehouse_info.py):
      - called via subprocess
      - returns JSON dict on stdout
    """
    # Resolve tool path
    tool = env_str("CPE_INFO_TOOL", "").strip()
    if not tool:
        # Prefer local copy if bundled with the script
        local = os.path.join(os.path.dirname(__file__), "cpe_info")
        tool = local if os.path.exists(local) else "/home/da40/charter/tools/cpe_info"

    # cpe_info accepts base like https://myrouter (it will normalize and append /cgi-bin/index.cgi)
    timeout = env_int("WEB_TIMEOUT_SEC", env_int("WAREHOUSE_TIMEOUT_SEC", 25))
    retries = env_int("WEB_RETRIES", env_int("WAREHOUSE_RETRIES", 10))
    sleep_s = env_int("WEB_SLEEP_SEC", env_int("WAREHOUSE_SLEEP_SEC", 3))

    cmd = [sys.executable, tool, base_url, "--json"]

    jlog("web_fetch_cmd", cmd=cmd, timeout=timeout, retries=retries, sleep=sleep_s)

    last_err = ""
    for attempt in range(1, max(1, retries) + 1):
        t0 = time.time()
        try:
            p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout + 2)
        except subprocess.TimeoutExpired as e:
            sec = round(time.time() - t0, 3)
            last_err = f"TimeoutExpired after {getattr(e, 'timeout', timeout + 2)}s"
            jlog("web_fetch_attempt", attempt=attempt, max_retries=retries, rc=124, sec=sec, ok=False, err_tail=last_err)
            if attempt < retries:
                time.sleep(max(0, float(sleep_s)))
                continue
            raise RuntimeError(f"cpe_info timed out after {retries} attempts (timeout={timeout + 2}s): {last_err}")

        sec = round(time.time() - t0, 3)
        out = (p.stdout or "").strip()
        err = (p.stderr or "").strip()
        last_err = err or out[:200]
        ok = (p.returncode == 0) and out.startswith("{") and out.endswith("}")
        jlog("web_fetch_attempt", attempt=attempt, max_retries=retries, rc=p.returncode, sec=sec, ok=ok, err_tail=(err[-200:] if err else ""))

        if ok:
            try:
                data = json.loads(out)
            except Exception as e:
                jlog("web_fetch_json_error", error=str(e), out_head=out[:200])
                data = {}
            # Normalize to str map
            norm: Dict[str, str] = {}
            for k, v in (data or {}).items():
                norm[str(k)] = "" if v is None else str(v)
            return norm

        if attempt < retries:
            time.sleep(max(0, float(sleep_s)))

    raise RuntimeError(f"cpe_info failed after {retries} attempts: {last_err}")


def _pick_first(table: Dict[str, str], keys: List[str]) -> str:
    for k in keys:
        v = (table.get(k) or "").strip()
        if v:
            return v
    return ""


def normalize_mac(raw: str) -> str:
    s = (raw or "").strip().lower().replace("-", ":")
    s = re.sub(r"[^0-9a-f:]", "", s)
    # If it's a 12-hex string without delimiters, format it
    hex_only = re.sub(r"[^0-9a-f]", "", s)
    if len(hex_only) == 12 and ":" not in s:
        s = ":".join(hex_only[i : i + 2] for i in range(0, 12, 2))
    return s


def normalize_ipv6(raw: str) -> str:
    s = (raw or "").strip()
    if not s:
        return ""
    # Remove prefix length if present
    s = s.split("/", 1)[0]
    try:
        return str(ipaddress.ip_address(s))
    except Exception:
        return s.lower()



def _match(a: Any, b: Any, mode: str = "strict") -> bool:
    """Robust matcher to reduce customer-env differences.
    Modes:
      - strict: case-insensitive exact match after strip
      - contains: symmetric substring match (case-insensitive)
      - startswith / endswith: symmetric prefix/suffix match
      - regex: treat either side as regex and test against the other (best-effort)
    """
    sa = str(a or "").strip()
    sb = str(b or "").strip()
    m = (mode or "strict").strip().lower()
    if sa == "" and sb == "":
        return True

    la = sa.lower()
    lb = sb.lower()

    if m == "strict":
        return la == lb
    if m == "contains":
        return (la == lb) or (la in lb) or (lb in la)
    if m == "startswith":
        return (la == lb) or lb.startswith(la) or la.startswith(lb)
    if m == "endswith":
        return (la == lb) or lb.endswith(la) or la.endswith(lb)
    if m == "regex":
        for pat, val in ((sa, sb), (sb, sa)):
            try:
                if re.search(pat, val):
                    return True
            except Exception:
                continue
        return False

    # default fallback
    return la == lb

def extract_web_fields(table: Dict[str, str]) -> Dict[str, str]:
    """Extract fields we care about from Web UI index page with alias tolerance."""
    return {
        "wan_ipv4": _pick_first(table, ["IPv4", "WAN IPv4", "IPv4 Address", "WAN IPv4 Address", "WAN IPv4 address", "IPv4 Address (WAN)"]),
        "wan_mac": _pick_first(table, ["MAC", "WAN MAC", "WAN MAC Address", "MAC Address", "MAC address", "WAN MAC address"]),
        "wan_ipv6": _pick_first(table, ["IPv6", "WAN IPv6", "IPv6 Address", "WAN IPv6 Address", "IPv6 Address (WAN)"]),
        "internet_status": _pick_first(table, ["Internet Status", "Internet", "WAN Status", "WAN Connection"]),
        "fw_version": _pick_first(table, ["FW Version", "Firmware Version", "Software Version", "FW", "Firmware"]),
        "serial_number": _pick_first(table, ["Serial Number", "Serial", "S/N", "SN"]),
        "model": _pick_first(table, ["Model", "Model #", "Model#", "Model Number"]),
    }


def extract_awlan_fields_from_ovsh(out: str) -> Dict[str, str]:
    """Parse `ovsh s AWLAN_Node` table output."""
    out = strip_ansi_text(out or "")
    fields = {"serial_number": "", "model": "", "firmware_version": ""}
    for line in out.splitlines():
        if "|" not in line:
            continue
        parts = [p.strip() for p in line.split("|")]
        if len(parts) < 2:
            continue
        key = parts[0]
        val = parts[1].strip()
        if key in fields and val:
            fields[key] = val
    return fields


def get_awlan_node_info_via_ssh() -> Dict[str, str]:
    """SSH to CPE and read AWLAN_Node values (serial/model/firmware_version).

    Prefer tools/cpe_ssh.py --cmd awlan-info (clean JSON, no banners).
    """
    j = _run_cpe_ssh_cli("awlan-info")
    if isinstance(j, dict) and j.get("ok"):
        return {
            "serial_number": (j.get("serial_number") or "").strip(),
            "model": (j.get("model") or "").strip(),
            "firmware_version": (j.get("firmware_version") or "").strip(),
        }

    # Fallback to legacy module-based method if CLI cmd not available.
    try:
        import cpe_ssh  # type: ignore
    except Exception as e:
        raise RuntimeError(f"import cpe_ssh failed (and awlan-info CLI failed): {e}")

    host = env_str("SSH_HOST", "").strip() or env_str("EXPECTED_LAN_IP", "192.168.1.1").strip() or "192.168.1.1"
    user = env_str("SSH_USER", "operator").strip() or "operator"
    password = env_str("SSH_PASSWORD", "").strip() or env_str("SSH_ENABLE_PASSWORD", "").strip()
    timeout = float(env_int("SSH_TIMEOUT_SEC", 30))

    if not password:
        raise RuntimeError("missing SSH_PASSWORD (or SSH_ENABLE_PASSWORD)")

    if hasattr(cpe_ssh, "get_awlan_node_info"):
        info = cpe_ssh.get_awlan_node_info(host, user=user, password=password, timeout=timeout)  # type: ignore
        if isinstance(info, tuple) and info:
            info = info[0]
        if isinstance(info, dict):
            return {
                "serial_number": (info.get("serial_number") or "").strip(),
                "model": (info.get("model") or "").strip(),
                "firmware_version": (info.get("firmware_version") or "").strip(),
            }

    # Final fallback: run ovsh and parse output
    cmd = "([ -x /usr/opensync/tools/ovsh ] && /usr/opensync/tools/ovsh s AWLAN_Node 2>/dev/null) || " \
          "([ -x /usr/opensync/bin/ovsh ] && /usr/opensync/bin/ovsh s AWLAN_Node 2>/dev/null) || " \
          "(ovsh s AWLAN_Node 2>/dev/null)"
    rc, out, err, sec = cpe_ssh.ssh_exec(host, user, password, cmd, timeout=timeout, login_shell=True)  # type: ignore
    if rc != 0:
        raise RuntimeError(f"ovsh exec failed rc={rc}: {err}")

    fields = parse_awlan_node_from_ovsh(out)
    return {
        "serial_number": (fields.get("serial_number") or "").strip(),
        "model": (fields.get("model") or "").strip(),
        "firmware_version": (fields.get("firmware_version") or "").strip(),
    }

def _parse_ip_o_addr(output: str, family: str) -> str:
    """Parse `ip -4/-6 -o addr show ...` output and return first address."""
    if not output:
        return ""
    for line in output.splitlines():
        line = line.strip()
        if not line:
            continue
        # Example (IPv4): 7: br-wan    inet 172.14.1.199/23 brd ...
        # Example (IPv6): 7: br-wan    inet6 2001:db8::1/64 scope global ...
        token = "inet6" if family == "6" else "inet"
        if token not in line:
            continue
        try:
            after = line.split(token, 1)[1].strip()
            addr = after.split()[0].split("/")[0].strip()
            return addr
        except Exception:
            continue
    return ""


def get_br_wan_info_via_ssh() -> Dict[str, Any]:
    """Read br-wan IPv4/MAC/global-IPv6 from CPE via tools/cpe_ssh.py (CLI).

    NOTE: we intentionally use the CLI tool to avoid login banners contaminating stdout.
    """
    iface = env_str("WAN_IFACE", "br-wan").strip() or "br-wan"

    # IPv4
    j4 = _run_cpe_ssh_cli("wan-ipv4", extra_args=["--iface", iface])
    ipv4 = ""
    if isinstance(j4, dict) and j4.get("ok"):
        ipv4 = (j4.get("ipv4") or j4.get("wan_ipv4") or "").strip()

    # MAC (some tool versions support iface-mac)
    jm = _run_cpe_ssh_cli("iface-mac", extra_args=["--iface", iface])
    mac = ""
    if isinstance(jm, dict) and jm.get("ok"):
        mac = (jm.get("mac") or jm.get("wan_mac") or "").strip()

    # IPv6 (global only; if none, keep empty string)
    j6 = _run_cpe_ssh_cli("wan-ipv6-detail", extra_args=["--iface", iface])
    ipv6 = ""
    if isinstance(j6, dict) and j6.get("ok"):
        # Try a few common shapes:
        # 1) {"global": ["2001:.../64", ...]}
        gl = j6.get("global")
        if isinstance(gl, list) and gl:
            ipv6 = str(gl[0]).strip().lower()
        # 2) {"ipv6": "2001:..."} or {"wan_ipv6": "..."}
        if not ipv6:
            ipv6 = (j6.get("ipv6") or j6.get("wan_ipv6") or "").strip().lower()

    return {
        "iface": iface,
        # Canonical keys (preferred)
        "wan_ipv4": ipv4,
        "wan_mac": normalize_mac(mac or ""),
        "wan_ipv6": ipv6,
        "ipv6_global": ipv6,
        # Backward/compat keys (some older code expects these)
        "ipv4": ipv4,
        "mac": normalize_mac(mac or ""),
        "ipv6": ipv6,
        # Extra diagnostics
        "mac_raw": (mac or "").strip(),
        "rc_v4": j4.get("rc", 1) if isinstance(j4, dict) else 1,
        "rc_mac": jm.get("rc", 1) if isinstance(jm, dict) else 1,
        "rc_v6": j6.get("rc", 1) if isinstance(j6, dict) else 1,
        "tool": "cpe_ssh.py",
        "detail": {
            "wan-ipv4": j4,
            "iface-mac": jm,
            "wan-ipv6-detail": j6,
        },
    }

def ping_internet_via_ssh() -> tuple[bool, Dict[str, Any]]:
    """Ping a well-known internet IP from the router via tools/cpe_ssh.py (CLI).

    Returns:
      (ok, detail)
    """
    host = env_str("SSH_HOST", "") or env_str("EXPECTED_LAN_IP", "192.168.1.1")
    user = env_str("SSH_USER", "operator")
    password = env_str("SSH_PASSWORD", "")
    timeout = env_int("SSH_TIMEOUT_SEC", 30)
    ping_host = env_str("PING_TARGET", "8.8.8.8")
    ping_count = env_int("PING_COUNT", 1)

    if not password:
        raise RuntimeError("SSH_PASSWORD is empty; cannot ping via SSH")

    j = _run_cpe_ssh_cli("ping", extra_args=["--target", ping_host, "--count", str(ping_count)], timeout=float(timeout))

    ok = bool(j.get("ok"))
    # Some tool builds return plain text + rc=0; accept that as success.
    if (not ok) and (j.get("error") == "non-json-output") and (int(j.get("rc", 1)) == 0):
        ok = True

    detail = {
        "ok": ok,
        "host": host,
        "user": user,
        "target": ping_host,
        "tool_cmd": "ping",
        "rc": int(j.get("rc", 1)) if isinstance(j, dict) else 1,
        "tool_detail": j,
    }
    jlog("ssh_ping", **detail)
    return ok, detail

def validate_sanity(table: Dict[str, str]) -> Tuple[bool, Dict[str, Any]]:
    details: Dict[str, Any] = {}

    bad_ipv4_fields = []
    for k, v in table.items():
        if "ipv4" in k.lower():
            if v and not _looks_ipv4(v):
                bad_ipv4_fields.append({"field": k, "value": v})
    details["bad_ipv4_fields"] = bad_ipv4_fields

    if env_bool("CHECK_DEFAULT_B64", True):
        b64_issues = []
        dssid = table.get("Default SSID", "")
        dpw = table.get("Default Password", "")
        dssid_dec = table.get("Default SSID (decoded)", "")
        dpw_dec = table.get("Default Password (decoded)", "")

        if dssid:
            if not _looks_base64(dssid) or not dssid_dec:
                b64_issues.append({"field": "Default SSID", "value": dssid, "decoded": dssid_dec})
        if dpw:
            if not _looks_base64(dpw) or not dpw_dec:
                b64_issues.append({"field": "Default Password", "value": dpw, "decoded": dpw_dec})

        details["default_b64_issues"] = b64_issues

    if env_bool("EXPECT_SAME_AS_DEFAULT", True):
        same_issues = []
        for fld in ("Current SSID", "Current Password"):
            v = (table.get(fld, "") or "").strip().lower()
            if v and "same" in v and "default" in v:
                continue
            if v:
                same_issues.append({"field": fld, "value": table.get(fld, "")})
        details["same_as_default_issues"] = same_issues

    ok = not details.get("bad_ipv4_fields") and not details.get("default_b64_issues") and not details.get("same_as_default_issues")
    return ok, details


def change_wifi(creds: NocCreds, token: str, location_id: str) -> None:
    if noc is None:
        raise RuntimeError("noc_api_cli import failed")

    ssid = env_str("NEW_WIFI_SSID", "").strip()
    pw = env_str("NEW_WIFI_PASSWORD", "").strip()
    if not ssid or not pw:
        raise RuntimeError("CHANGE_WIFI enabled but NEW_WIFI_SSID/NEW_WIFI_PASSWORD missing")

    jlog("wifi_update_start", ssid=ssid)
    noc.wifi_network_update(
        creds.base,
        env_str("CUSTOMER_ID"),
        location_id,
        token=token,
        bearer=creds.bearer,
        insecure=creds.insecure,
        ssid=ssid,
        encryption_key=pw,
    )
    jlog("wifi_update_sent")

    wait_s = env_int("WIFI_APPLY_WAIT_SEC", 60)
    if wait_s > 0:
        jlog("wifi_apply_wait", secs=wait_s)
        time.sleep(wait_s)


def validate_wifi_changed(before: Dict[str, str], after: Dict[str, str]) -> Tuple[bool, Dict[str, Any]]:
    details: Dict[str, Any] = {}

    b_cur_ssid = before.get("Current SSID", "")
    a_cur_ssid = after.get("Current SSID", "")
    b_cur_pw = before.get("Current Password", "")
    a_cur_pw = after.get("Current Password", "")

    issues = []
    if b_cur_ssid and ("same" in b_cur_ssid.lower() and "default" in b_cur_ssid.lower()):
        if a_cur_ssid and ("same" in a_cur_ssid.lower() and "default" in a_cur_ssid.lower()):
            issues.append({"field": "Current SSID", "before": b_cur_ssid, "after": a_cur_ssid})

    if b_cur_pw and ("same" in b_cur_pw.lower() and "default" in b_cur_pw.lower()):
        if a_cur_pw and ("same" in a_cur_pw.lower() and "default" in a_cur_pw.lower()):
            issues.append({"field": "Current Password", "before": b_cur_pw, "after": a_cur_pw})

    if a_cur_ssid and _looks_base64(a_cur_ssid):
        details["current_ssid_decoded"] = _b64_decode_safe(a_cur_ssid)
    if a_cur_pw and _looks_base64(a_cur_pw):
        details["current_password_decoded"] = _b64_decode_safe(a_cur_pw)

    details["issues"] = issues
    return len(issues) == 0, details


def _load_redirect_pairs() -> List[Tuple[str, str]]:
    """Load redirect pairs in order.

    Preferred (new, web/index page naming):
      - WEB_HTTP_URLS (csv)
      - WEB_EXPECT_HTTPS_URLS (csv)

    Backward compatible (legacy warehouse naming):
      - WAREHOUSE_HTTP_URLS (csv)
      - WAREHOUSE_EXPECT_HTTPS_URLS (csv)

    Also supports single-pair aliases:
      - WEB_HTTP_URL / WEB_HTTPS_URL
      - WAREHOUSE_HTTP_URL / WAREHOUSE_HTTPS_URL
    """

    http_urls = _split_csv(env_str("WEB_HTTP_URLS", env_str("WAREHOUSE_HTTP_URLS", "")))
    exp_urls = _split_csv(env_str("WEB_EXPECT_HTTPS_URLS", env_str("WAREHOUSE_EXPECT_HTTPS_URLS", "")))

    if http_urls and exp_urls:
        if len(http_urls) != len(exp_urls):
            raise RuntimeError("WAREHOUSE_HTTP_URLS and WAREHOUSE_EXPECT_HTTPS_URLS length mismatch")
        return list(zip(http_urls, exp_urls))

    http_url = env_str("WEB_HTTP_URL", env_str("WAREHOUSE_HTTP_URL", "")).strip()
    https_url = env_str("WEB_HTTPS_URL", env_str("WAREHOUSE_HTTPS_URL", "")).strip()
    if http_url and https_url:
        return [(http_url, https_url)]

    raise RuntimeError("Missing warehouse URL(s): set WAREHOUSE_HTTP_URLS+WAREHOUSE_EXPECT_HTTPS_URLS or WAREHOUSE_HTTP_URL+WAREHOUSE_HTTPS_URL")


def _maybe_check_domain_resolution(pairs: List[Tuple[str, str]]) -> Tuple[bool, Dict[str, Any]]:
    if not env_bool("CHECK_DOMAIN_RESOLVE", True):
        return True, {"mode": "skip"}

    expected_ip = env_str("EXPECTED_LAN_IP", "192.168.1.1").strip()
    strict_ip = env_bool("DOMAIN_RESOLVE_STRICT", True)

    # Name resolution can lag after factory reset (DHCP/DNS/LLMNR/mDNS). Add retries.
    retries = env_int("DOMAIN_RESOLVE_RETRIES", env_int("WAREHOUSE_RETRIES", 10))
    sleep_s = env_int("DOMAIN_RESOLVE_SLEEP_SEC", env_int("WAREHOUSE_SLEEP_SEC", 3))

    def _getent_hosts_raw(h: str) -> List[str]:
        try:
            p = subprocess.run(["getent", "hosts", h], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            lines = [ln.strip() for ln in (p.stdout or "").splitlines() if ln.strip()]
            return lines[:5]
        except Exception:
            return []

    detail: Dict[str, Any] = {
        "expected_lan_ip": expected_ip,
        "strict": strict_ip,
        "retries": retries,
        "sleep_sec": sleep_s,
        "hosts": [],
    }
    all_ok = True

    for http_url, _exp in pairs:
        host = _url_host(http_url)
        last_addrs: List[str] = []
        addrs: List[str] = []
        raw_hosts: List[str] = []
        ok = False
        attempt_used = 0
        for attempt in range(1, max(1, retries) + 1):
            attempt_used = attempt
            addrs = resolve_host_ipv4(host)
            last_addrs = addrs
            ok = bool(addrs)
            if ok:
                break
            # If IPv4 not found, capture what getent hosts sees (often IPv6 link-local only)
            if attempt == 1:
                raw_hosts = _getent_hosts_raw(host)
            if attempt < retries:
                time.sleep(max(0, sleep_s))
        reason = ""
        if ok and strict_ip and expected_ip:
            if expected_ip not in addrs:
                ok = False
                reason = "ip_mismatch"
        if not ok and not reason:
            reason = "resolve_failed" if not last_addrs else "unknown"
        entry: Dict[str, Any] = {"host": host, "addrs": addrs, "ok": ok, "reason": reason, "attempt": attempt_used}
        if raw_hosts:
            entry["getent_hosts"] = raw_hosts
            # If getent hosts returned only IPv6 (fe80::/etc), this hints why some tools fail without -4.
            if all(not _looks_ipv4(ln.split()[0]) for ln in raw_hosts if ln.split()):
                entry["note"] = "getent_hosts_ipv6_only"
        detail["hosts"].append(entry)
        if not ok:
            all_ok = False

    return all_ok, detail



def _emit_config_snapshot():
    jlog("config_snapshot",
         DO_FACTORY_RESET=env_bool("DO_FACTORY_RESET", True),
         CHECK_HTTP_REDIRECT=env_bool("CHECK_HTTP_REDIRECT", True),
         CHECK_DOMAIN_RESOLVE=env_bool("CHECK_DOMAIN_RESOLVE", True),
         CHECK_WAN_IPV4=env_bool("CHECK_WAN_IPV4", True),
         CHECK_WAN_IPV4_MATCH=env_bool("CHECK_WAN_IPV4_MATCH", False),
         CHECK_WAN_MAC_MATCH=env_bool("CHECK_WAN_MAC_MATCH", False),
         CHECK_WAN_IPV6_MATCH=env_bool("CHECK_WAN_IPV6_MATCH", False),
         CHECK_INTERNET_STATUS_PING=env_bool("CHECK_INTERNET_STATUS_PING", False),
         COMPARE_WEB_VS_AWLAN=env_bool("COMPARE_WEB_VS_AWLAN", True),
         REDIRECT_MATCH_MODE=env_str("REDIRECT_MATCH_MODE", "strict"),
         FW_MATCH_MODE=env_str("FW_MATCH_MODE", "contains"),
         PRIMARY_FETCH_HTTPS_URL=env_str("PRIMARY_FETCH_HTTPS_URL", ""),
         WEB_HTTP_URLS=env_str("WEB_HTTP_URLS", ""),
         WEB_EXPECT_HTTPS_URLS=env_str("WEB_EXPECT_HTTPS_URLS", ""),
    )

def run() -> int:
    try:
        jlog("config_flags", DO_FACTORY_RESET=env_bool("DO_FACTORY_RESET", True), CHECK_WAN_IPV4=env_bool("CHECK_WAN_IPV4", True), COMPARE_WEB_VS_AWLAN=env_bool("COMPARE_WEB_VS_AWLAN", True), CHECK_HTTP_REDIRECT=env_bool("CHECK_HTTP_REDIRECT", True), REDIRECT_MATCH_MODE=env_str("REDIRECT_MATCH_MODE", "strict"), PRIMARY_FETCH_HTTPS_URL=env_str("PRIMARY_FETCH_HTTPS_URL", ""), SSH_HOST=env_str("SSH_HOST", ""), SSH_USER=env_str("SSH_USER", "operator"))
        _emit_config_snapshot()
        creds = load_noc_creds()
        token = noc_login(creds)

        node_id = resolve_node_id()
        location_id = resolve_location_id(creds, token, node_id)

        if env_bool("DO_FACTORY_RESET", True):
            do_factory_reset(creds, token, location_id)

            # Optional: enable SSH via NOC after FR (FR may reset kvConfigs / access control).
            # IMPORTANT: when DO_FACTORY_RESET=0 (typical sanity runs), we MUST NOT touch SSHM settings.
            ssh_enabled = maybe_enable_ssh_via_noc(creds, token, location_id, node_id)
            if ssh_enabled:
                time.sleep(float(env_int("SSH_ENABLE_WAIT_SEC", 10)))

        # Redirect pairs: http://myrouter -> https://myrouter/cgi-bin/index.cgi
        pairs = _load_redirect_pairs()

        ok_dns, dns_detail = _maybe_check_domain_resolution(pairs)
        jlog("domain_resolve_check", ok=ok_dns, detail=dns_detail)
        if not ok_dns:
            jlog("fail", reason="domain_resolve_failed")
            return _ret(20)

        if env_bool("CHECK_HTTP_REDIRECT", True):
            redir_retries = env_int("REDIRECT_RETRIES", env_int("WEB_RETRIES", 10))
            redir_sleep = env_int("REDIRECT_SLEEP_SEC", env_int("WEB_SLEEP_SEC", 3))
            for http_url, expected_https in pairs:
                ok = False
                last_detail: Dict[str, Any] = {}
                for attempt in range(1, max(1, redir_retries) + 1):
                    ok, detail = check_redirect_expected(http_url, expected_https)
                    last_detail = dict(detail)
                    last_detail["attempt"] = attempt
                    last_detail["max_retries"] = redir_retries
                    jlog("http_redirect_check", ok=ok, detail=last_detail)
                    if ok:
                        break
                    if attempt < redir_retries:
                        time.sleep(max(0, float(redir_sleep)))
                if not ok:
                    jlog("fail", reason="http_redirect_mismatch", http_url=http_url, expected_https=expected_https, detail=last_detail)
                    return _ret(2)

        # Use an explicit fetch URL (often /cgi-bin/index.cgi) for web content.
        # Redirect target can be different from fetch URL (some devices redirect http->https://myrouter/ and then UI lives at /cgi-bin/index.cgi).
        primary_fetch_https = (
            env_str("PRIMARY_FETCH_HTTPS_URL", "").strip()
            or env_str("WEB_FETCH_URL", "").strip()
            or env_str("PRIMARY_HTTPS_URL", "").strip()
            or (pairs[0][1] if pairs else "")
        )
        if not primary_fetch_https:
            raise RuntimeError("PRIMARY_FETCH_HTTPS_URL/WEB_FETCH_URL not set and no redirect pairs")

        web_table = fetch_index_via_cpe_info(primary_fetch_https)
        web_fields = extract_web_fields(web_table)
        # Normalize types (customer env sometimes returns non-str values)
        web_fields = {k: ("" if v is None else str(v)).strip() for k, v in (web_fields or {}).items()}
        jlog("web_fields", **web_fields)

        # Optional: fetch WAN/interface info from the router shell via SSH (br-wan)
        need_wan_shell = any(
            env_bool(k, False)
            for k in [
                "CHECK_WAN_IPV4_MATCH",
                "CHECK_WAN_MAC_MATCH",
                "CHECK_WAN_IPV6_MATCH",
                "CHECK_INTERNET_STATUS_PING",
            ]
        )
        wan_shell: Dict[str, str] = {}
        if need_wan_shell:
            wan_shell = get_br_wan_info_via_ssh()
            # Normalize common scalar fields; keep 'detail' as-is
            for _k in ("wan_ipv4","ipv4","wan_mac","mac","wan_ipv6","ipv6","ipv6_global","mac_raw"):
                if _k in wan_shell:
                    wan_shell[_k] = ("" if wan_shell[_k] is None else str(wan_shell[_k])).strip()
            jlog("wan_shell_fields", **wan_shell)

        # Step 2: Internet Status (web) vs SSH ping (best-effort)
        if env_bool("CHECK_INTERNET_STATUS_PING", False):
            ping_ok, ping_detail = ping_internet_via_ssh()

            # NOTE: After factory reset, Web UI may temporarily show 'Determining...' even when WAN is up.
            # We treat some web statuses as transient and optionally poll Web UI before deciding.
            transient = {"", "determining", "determining...", "checking", "checking...", "unknown"}
            allow_transient_ok = env_bool("ALLOW_WEB_INTERNET_TRANSIENT", True)
            poll_retries = env_int("INTERNET_STATUS_POLL_RETRIES", 10)
            poll_sleep = float(env_int("INTERNET_STATUS_POLL_SLEEP_SEC", 3))

            web_internet = (web_fields.get("internet_status") or "").strip()
            web_norm = web_internet.lower().strip()

            # If ping works but web is transient, poll web a bit for it to settle to 'Connected'
            if ping_ok and (web_norm in transient) and poll_retries > 1:
                for i in range(1, poll_retries + 1):
                    if web_norm == "connected":
                        break
                    jlog("internet_status_poll", attempt=i, max_retries=poll_retries, web_internet=web_internet)
                    if i == poll_retries:
                        break
                    time.sleep(max(0.0, poll_sleep))
                    try:
                        web_table = fetch_index_via_cpe_info(primary_fetch_https)
                        web_fields = extract_web_fields(web_table)
                        web_fields = {k: ("" if v is None else str(v)).strip() for k, v in (web_fields or {}).items()}
                        web_internet = (web_fields.get("internet_status") or "").strip()
                        web_norm = web_internet.lower().strip()
                        jlog("web_fields_poll", **web_fields)
                    except Exception as e:
                        jlog("internet_status_poll_error", attempt=i, error=str(e))

            web_is_connected = web_norm == "connected"
            strict = env_bool("PING_STRICT", False)

            ok = True
            # If ping works but web says not connected:
            # - If web is transient and allow_transient_ok, do NOT fail (avoid false negatives right after reset)
            # - Otherwise, fail (web should report Connected)
            if ping_ok and not web_is_connected:
                if allow_transient_ok and (web_norm in transient):
                    ok = True
                else:
                    ok = False

            # If web says connected but ping fails -> maybe ICMP blocked; only fail in strict mode
            if (not ping_ok) and web_is_connected and strict:
                ok = False

            jlog(
                "internet_status_ping",
                ok=ok,
                strict=strict,
                allow_transient_ok=allow_transient_ok,
                web_internet=web_internet,
                ping_ok=ping_ok,
                ping_detail=ping_detail,
            )
            if not ok:
                jlog("fail", reason="internet_status_mismatch", web_internet=web_internet, ping_ok=ping_ok)
                return _ret(6)
        jlog("step", name="before_check_wan_ipv4")
        jlog("step", name="enter_check_wan_ipv4")

        # Step 7: WAN IPv4 should be present (web)
        if env_bool("CHECK_WAN_IPV4", True):
            ipv4 = str(web_fields.get("wan_ipv4") or "").strip()
            ok_ipv4 = bool(re.match(r"^\d{1,3}(\.\d{1,3}){3}$", ipv4)) and ipv4 != "0.0.0.0"
            jlog("check_wan_ipv4", ok=ok_ipv4, wan_ipv4=ipv4)
            jlog("step", name="after_check_wan_ipv4")
            if not ok_ipv4:
                jlog("fail", reason="wan_ipv4_invalid", wan_ipv4=ipv4)
                return _ret(7)

        # Step 4: Web IPv4 must match br-wan IPv4 from router shell
        if env_bool("CHECK_WAN_IPV4_MATCH", False):
            w_ipv4 = str(web_fields.get("wan_ipv4") or "").strip()
            s_ipv4 = ((wan_shell.get("wan_ipv4") or wan_shell.get("ipv4") or "")).strip()
            ok = bool(w_ipv4) and bool(s_ipv4) and w_ipv4 == s_ipv4
            jlog("check_wan_ipv4_match", ok=ok, web_ipv4=w_ipv4, ssh_brwan_ipv4=s_ipv4)
            if not ok:
                jlog("fail", reason="wan_ipv4_mismatch", web_ipv4=w_ipv4, ssh_brwan_ipv4=s_ipv4)
                return _ret(4)

        # Step 5: Web MAC must match br-wan MAC from router shell
        if env_bool("CHECK_WAN_MAC_MATCH", False):
            w_mac = normalize_mac(web_fields.get("wan_mac") or "")
            s_mac = normalize_mac((wan_shell.get("wan_mac") or wan_shell.get("mac") or ""))
            ok = bool(w_mac) and bool(s_mac) and w_mac == s_mac
            jlog("check_wan_mac_match", ok=ok, web_mac=w_mac, ssh_brwan_mac=s_mac)
            if not ok:
                jlog("fail", reason="wan_mac_mismatch", web_mac=w_mac, ssh_brwan_mac=s_mac)
                return _ret(5)

        # Step 6: Web IPv6 must match br-wan global IPv6 (if present)
        if env_bool("CHECK_WAN_IPV6_MATCH", False):
            w_ipv6 = (web_fields.get("wan_ipv6") or "").strip().lower()
            s_ipv6 = (wan_shell.get("ipv6_global") or wan_shell.get("wan_ipv6") or wan_shell.get("ipv6") or "").strip().lower()
            # Normalize: compare base IPv6 address (ignore /prefix if present)
            w_ipv6_base = w_ipv6.split("/", 1)[0]
            s_ipv6_base = s_ipv6.split("/", 1)[0]
            if not s_ipv6_base:
                # No global IPv6 on br-wan -> web should not show it
                ok = (not w_ipv6_base)
                jlog("check_wan_ipv6_match", ok=ok, note="no_global_ipv6", web_ipv6=w_ipv6, web_ipv6_base=w_ipv6_base, ssh_brwan_ipv6_global=s_ipv6, ssh_brwan_ipv6_global_base=s_ipv6_base)
                if not ok:
                    jlog("fail", reason="wan_ipv6_web_should_be_empty", web_ipv6=w_ipv6, web_ipv6_base=w_ipv6_base)
                    return _ret(9)
            else:
                ok = bool(w_ipv6_base) and (w_ipv6_base == s_ipv6_base)
                jlog("check_wan_ipv6_match", ok=ok, web_ipv6=w_ipv6, web_ipv6_base=w_ipv6_base, ssh_brwan_ipv6_global=s_ipv6, ssh_brwan_ipv6_global_base=s_ipv6_base)
                if not ok:
                    jlog("fail", reason="wan_ipv6_mismatch", web_ipv6=w_ipv6, web_ipv6_base=w_ipv6_base, ssh_brwan_ipv6_global=s_ipv6, ssh_brwan_ipv6_global_base=s_ipv6_base)
                    return _ret(9)

        # Step 8/9 (+Model): Compare Web vs SSH(AWLAN_Node)
        if env_bool("COMPARE_WEB_VS_AWLAN", True):
            awlan = get_awlan_node_info_via_ssh()
            jlog("awlan_fields", **awlan)

            sn_mode = (env_str("SN_MATCH_MODE", "exact").strip().lower() or "exact")
            model_mode = (env_str("MODEL_MATCH_MODE", "exact").strip().lower() or "exact")
            fw_mode = (env_str("FW_MATCH_MODE", "contains").strip().lower() or "contains")

            w_sn = web_fields.get("serial_number", "")
            w_model = web_fields.get("model", "")
            w_fw = web_fields.get("fw_version", "")

            s_sn = awlan.get("serial_number", "")
            s_model = awlan.get("model", "")
            s_fw = awlan.get("firmware_version", "")

            ok_sn = _match(w_sn, s_sn, sn_mode)
            ok_model = _match(w_model, s_model, model_mode)
            ok_fw = _match(w_fw, s_fw, fw_mode)

            jlog("compare_web_vs_awlan",
                 ok=(ok_sn and ok_model and ok_fw),
                 sn={"ok": ok_sn, "web": w_sn, "ssh": s_sn, "mode": sn_mode},
                 model={"ok": ok_model, "web": w_model, "ssh": s_model, "mode": model_mode},
                 fw={"ok": ok_fw, "web": w_fw, "ssh": s_fw, "mode": fw_mode})

            if not (ok_sn and ok_model and ok_fw):
                jlog("fail", reason="web_vs_awlan_mismatch")
                return _ret(8)

        jlog("pass")
        return _ret(0)

    except KeyboardInterrupt:
        jlog("fail", reason="keyboard_interrupt")
        return _ret(130)
    except BaseException as e:
        try:
            jlog("error", error=str(e), exc_type=type(e).__name__, traceback=traceback.format_exc()[-4000:])
        finally:
            try:
                os.write(2, ("[fatal] " + str(e) + "\n").encode("utf-8", errors="replace"))
            except Exception:
                pass
        return _ret(1)

    finally:
        # IMPORTANT: emit summary BEFORE returning to wrapper.
        # Some runners use os._exit() and would skip atexit handlers.
        _emit_result_summary_now()