# -*- coding: utf-8 -*-

"""Wi-Fi client helpers used by C15807949.

Reuses the same approach as C00000003_WIFI_basic_test:
- Fetch SSID/PSK from CPE via tools/cpe_ssh.py --cmd wifi-creds
- Connect/disconnect test PC Wi-Fi NIC via tools/wifi_iwd.py (preferred) or tools/wifi_nm.py

All actions are logged as JSON lines via util.jlog.
"""

from __future__ import annotations

import os
import re
import secrets
import time
from typing import Any, Dict, Optional, Tuple

from .util import jlog, parse_last_json, q, run_cmd
from .ssh import ensure_ssh_ready


def _tools_path() -> str:
    return os.environ.get("TOOLS_PATH", "/home/da40/charter/tools").rstrip("/")


def _clean_env(v: str) -> str:
    """Some runners inject inline comments like "5g # ..."."""
    return (v or "").split("#", 1)[0].strip()


def gen_laa_mac() -> str:
    """Generate a locally-administered, unicast MAC (02:xx:xx:xx:xx:xx)."""
    b = bytearray(secrets.token_bytes(6))
    b[0] = 0x02
    return ":".join(f"{x:02x}" for x in b)


def _iface_mac(iface: str) -> str:
    try:
        with open(f"/sys/class/net/{iface}/address", "r", encoding="utf-8") as f:
            return f.read().strip().lower()
    except Exception:
        return ""


def _set_iface_mac(iface: str, mac: str) -> bool:
    """Best-effort set interface MAC.

    Many Wi-Fi drivers require the interface to be down.
    """
    mac = (mac or "").strip().lower()
    if not mac:
        return False

    cmd = (
        f"ip link set dev {q(iface)} down && "
        f"ip link set dev {q(iface)} address {q(mac)} && "
        f"ip link set dev {q(iface)} up"
    )
    rc, out, err, sec = run_cmd(cmd, timeout=20)
    ok = rc == 0
    jlog("wifi_set_mac", ok=ok, rc=rc, sec=sec, iface=iface, mac=mac, err_tail=(err or "")[-200:])
    return ok


def ensure_wifi_test_mac(iface: str) -> str:
    """Optionally force a stable test MAC to avoid randomization across reconnects.

    Controlled by env:
      - WIFI_FORCE_STATIC_MAC (default 0)
      - WIFI_TEST_MAC / TEST_MAC (if empty and force==1, auto-generate a LAA)

    Returns: current MAC after any attempt to set.
    """
    force = int(_clean_env(os.environ.get("WIFI_FORCE_STATIC_MAC", "0") or "0") or "0") == 1
    mac = (_clean_env(os.environ.get("WIFI_TEST_MAC", "") or "") or _clean_env(os.environ.get("TEST_MAC", "") or "")).lower()

    if force and not mac:
        mac = gen_laa_mac()
        os.environ["WIFI_TEST_MAC"] = mac
        os.environ["TEST_MAC"] = mac

    if force and mac:
        _set_iface_mac(iface, mac)

    return _iface_mac(iface)


def _ip4_addr(iface: str) -> str:
    rc, out, err, sec = run_cmd(f"ip -4 -o addr show dev {q(iface)}", timeout=10)
    m = re.search(r"\binet\s+(\d+\.\d+\.\d+\.\d+)/\d+", out or "")
    return m.group(1) if m else ""


def _ping(iface: str, target: str, *, count: int = 3, timeout_sec: int = 5) -> bool:
    if not target:
        return True
    cmd = f"ping -I {q(iface)} -c {int(count)} -W {int(timeout_sec)} {q(target)}"
    rc, out, err, sec = run_cmd(cmd, timeout=max(10, int(count) * int(timeout_sec) + 5))
    ok = rc == 0
    jlog("wifi_ping", ok=ok, rc=rc, sec=sec, iface=iface, target=target)
    return ok


def _cpe_ssh_wifi_creds() -> Dict[str, Any]:
    tools = _tools_path()
    host = _clean_env(os.environ.get("CPE_HOST", os.environ.get("SSH_HOST_LAN", "192.168.1.1")))
    user = _clean_env(os.environ.get("CPE_SSH_USER", os.environ.get("SSH_USER", "operator")))
    pw = os.environ.get("CPE_SSH_PASSWORD") or os.environ.get("SSH_PASSWORD") or os.environ.get("SSH_PASSWORD_DEFAULT") or "123456789"
    timeout = float(_clean_env(os.environ.get("CPE_SSH_TIMEOUT_SEC", "30")) or "30")

    cmd = (
        f"python3 {q(tools + '/cpe_ssh.py')} --host {q(host)} --user {q(user)} --password {q(pw)} "
        f"--timeout {q(str(timeout))} --cmd wifi-creds --which both"
    )

    def _run_once() -> Tuple[bool, Dict[str, Any], int, str, str, float]:
        rc, out, err, sec = run_cmd(cmd, timeout=timeout + 40)
        obj = parse_last_json(out or "") or parse_last_json(err or "") or {}
        ok = (rc == 0) and isinstance(obj, dict) and bool(obj.get("ok", True))
        jlog("wifi_creds", ok=ok, rc=rc, sec=sec, host=host, user=user)
        if not ok:
            jlog("wifi_creds_diag", out_tail=(out or "")[-500:], err_tail=(err or "")[-500:])
        return ok, (obj if isinstance(obj, dict) else {}), rc, out or "", err or "", sec

    ok, obj, rc, out, err, sec = _run_once()
    if ok:
        return obj

    # If SSH is temporarily unavailable, try to re-enable via NOC (same pattern as dhcp_verify).
    node_id = os.environ.get("NODE_ID", "").strip()
    if node_id:
        jlog("wifi_creds_reensure_ssh", node_id=node_id, reason="wifi_creds_failed")
        try:
            ensure_ssh_ready(node_id)
        except Exception as e:
            jlog("wifi_creds_reensure_ssh_error", node_id=node_id, error=str(e))

        ok2, obj2, rc2, out2, err2, sec2 = _run_once()
        if ok2:
            return obj2

    raise RuntimeError("wifi_creds_failed")


def _infer_band_from_ifname(ifname: str) -> Optional[str]:
    s = (ifname or "").strip().lower()
    if "6g" in s or "-60" in s or s.endswith("60"):
        return "6g"
    if "5g" in s or "-50" in s or s.endswith("50"):
        return "5g"
    if "2g" in s or "2.4" in s or "-24" in s or s.endswith("24"):
        return "2g"
    if s.endswith("0"):
        return "2g"
    if s.endswith("1"):
        return "5g"
    if s.endswith("2"):
        return "6g"
    return None


def choose_wifi_creds(creds: Dict[str, Any], band: str = "", prefer: str = "current") -> Optional[Dict[str, str]]:
    """Pick SSID/PSK pair from cpe_ssh.py wifi-creds output."""
    band = (band or "").strip().lower()
    prefer = (prefer or "current").strip().lower()

    def _from_default() -> Optional[Dict[str, str]]:
        d = creds.get("default") or {}
        if not isinstance(d, dict):
            return None
        bands = d.get("bands") or []
        if not isinstance(bands, list):
            return None
        if band:
            for b in bands:
                if not isinstance(b, dict):
                    continue
                if str(b.get("band") or "").strip().lower() != band:
                    continue
                ssid = str(b.get("ssid") or "").strip()
                psk = str(b.get("psk") or "").strip()
                if ssid and psk:
                    return {"ssid": ssid, "psk": psk, "source": f"default:{band}"}
        for b in bands:
            if not isinstance(b, dict):
                continue
            ssid = str(b.get("ssid") or "").strip()
            psk = str(b.get("psk") or "").strip()
            if ssid and psk:
                bb = str(b.get("band") or "").strip().lower()
                return {"ssid": ssid, "psk": psk, "source": f"default:{bb or 'band'}"}
        return None

    def _from_current() -> Optional[Dict[str, str]]:
        c = creds.get("current") or {}
        if not isinstance(c, dict):
            return None
        vifs = c.get("vifs") or []
        if not isinstance(vifs, list):
            return None

        if band:
            for v in vifs:
                if not isinstance(v, dict):
                    continue
                ssid = str(v.get("ssid") or "").strip()
                psk = str(v.get("psk") or "").strip()
                ifname = str(v.get("if_name") or "").strip()
                vb = _infer_band_from_ifname(ifname)
                if ssid and psk and vb == band:
                    return {"ssid": ssid, "psk": psk, "source": f"current:{ifname or vb or 'vif'}"}

        for v in vifs:
            if not isinstance(v, dict):
                continue
            ssid = str(v.get("ssid") or "").strip()
            psk = str(v.get("psk") or "").strip()
            ifname = str(v.get("if_name") or "").strip()
            if ssid and psk:
                return {"ssid": ssid, "psk": psk, "source": f"current:{ifname or 'vif'}"}
        return None

    if prefer == "current":
        return _from_current() or _from_default()
    return _from_default() or _from_current()


def _wifi_iwd_tool() -> str:
    return os.environ.get("WIFI_IWD_TOOL") or (_tools_path() + "/wifi_iwd.py")


def _wifi_nm_tool() -> str:
    return os.environ.get("WIFI_NM_TOOL") or (_tools_path() + "/wifi_nm.py")


def _wifi_connect_cmd(method: str, iface: str, ssid: str, band: str, timeout_sec: int, nm_retries: int) -> Tuple[str, Dict[str, str]]:
    env = os.environ.copy()
    env["WIFI_PSK"] = env.get("WIFI_PSK") or ""

    py = os.environ.get("PYTHON", "python3")
    method = (method or "").strip().lower()

    if method == "iwd":
        cmd = [
            py,
            _wifi_iwd_tool(),
            "--json",
            "ensure",
            "--iface",
            iface,
            "--ssid",
            ssid,
            "--password-env",
            "WIFI_PSK",
            "--timeout",
            str(int(timeout_sec)),
        ]
        if band:
            cmd += ["--band", band]
        cmd += ["--takeover", "--restore-nm", "--unmanaged"]
        return " ".join(q(x) for x in cmd), env

    # nm
    cmd = [
        py,
        _wifi_nm_tool(),
        "--json",
        "ensure",
        "--iface",
        iface,
        "--ssid",
        ssid,
        "--password-env",
        "WIFI_PSK",
        "--timeout",
        str(int(timeout_sec)),
        "--retries",
        str(int(nm_retries)),
    ]
    if band:
        cmd += ["--band", band]
    return " ".join(q(x) for x in cmd), env


def disconnect_best_effort(iface: str) -> None:
    """Try disconnect with iwd, then nm.

    Notes:
      - In iwd takeover mode, NetworkManager may be stopped or not managing this iface.
      - We only attempt nm disconnect when nmcli reports the iface is connected.
    """
    py = os.environ.get("PYTHON", "python3")

    # iwd
    cmd1 = f"{py} {q(_wifi_iwd_tool())} --json disconnect --iface {q(iface)} --restore-nm --unmanaged"
    rc1, out1, err1, sec1 = run_cmd(cmd1, timeout=30)
    jlog("wifi_disconnect", method="iwd", ok=(rc1 == 0), rc=rc1, sec=sec1, iface=iface)

    # nm (only if iface is managed + connected)
    try:
        if _nm_iface_is_connected(iface):
            cmd2 = f"{py} {q(_wifi_nm_tool())} --json disconnect --iface {q(iface)}"
            rc2, out2, err2, sec2 = run_cmd(cmd2, timeout=30)
            jlog("wifi_disconnect", method="nm", ok=(rc2 == 0), rc=rc2, sec=sec2, iface=iface)
        else:
            jlog("wifi_disconnect", method="nm", ok=True, rc=0, sec=0.0, iface=iface, skipped=True)
    except Exception as e:
        jlog("wifi_disconnect", method="nm", ok=True, rc=0, sec=0.0, iface=iface, skipped=True, note=str(e))


def _nm_iface_is_connected(iface: str) -> bool:
    """Return True if nmcli shows iface is connected."""
    import shutil

    if not iface:
        return False
    if shutil.which("nmcli") is None:
        return False
    rc, out, err, _ = run_cmd("nmcli -t -f DEVICE,STATE dev status", timeout=10)
    if rc != 0:
        return False
    for line in (out or "").splitlines():
        if not line:
            continue
        if line.startswith(iface + ":"):
            state = line.split(":", 1)[1].strip().lower()
            return state == "connected"
    return False


def connect_from_cpe_creds() -> Dict[str, Any]:
    """Fetch Wi-Fi creds from CPE then connect, returning {ssid, iface, mac, ipv4, method_used} etc."""
    iface = _clean_env(os.environ.get("WIFI_IFACE", "wlan0") or "wlan0")
    method = _clean_env(os.environ.get("WIFI_METHOD", "auto") or "auto").lower()
    band = _clean_env(os.environ.get("WIFI_BAND", "5g") or "").lower()
    prefer = _clean_env(os.environ.get("WIFI_CRED_PREFER", "current") or "current").lower()
    timeout_sec = int(_clean_env(os.environ.get("WIFI_TIMEOUT_SEC", "45")) or "45")
    nm_retries = int(_clean_env(os.environ.get("WIFI_NM_RETRIES", "2")) or "2")

    # Ensure stable MAC if requested
    mac_now = ensure_wifi_test_mac(iface)

    creds = _cpe_ssh_wifi_creds()
    chosen = choose_wifi_creds(creds, band=band, prefer=prefer)
    if not chosen:
        raise RuntimeError("no_usable_wifi_creds")

    ssid = chosen["ssid"]
    psk = chosen["psk"]

    os.environ["WIFI_PSK"] = psk

    jlog("wifi_creds_select", ok=True, iface=iface, ssid=ssid, source=chosen.get("source"), band=band, prefer=prefer)

    # Try connect
    tries = []
    if method == "iwd":
        tries = ["iwd"]
    elif method == "nm":
        tries = ["nm"]
    else:
        tries = ["iwd", "nm"]

    last = {"rc": None, "out": "", "err": "", "sec": 0.0}
    method_used = ""

    for m in tries:
        cmd, env = _wifi_connect_cmd(m, iface, ssid, band, timeout_sec, nm_retries)
        t0 = time.time()
        rc, out, err, sec = run_cmd(cmd, timeout=max(90, timeout_sec + 45), env=env)
        last = {"rc": rc, "out": out, "err": err, "sec": sec}

        obj = parse_last_json(out or "") or parse_last_json(err or "") or {}
        ok = (rc == 0) and (not isinstance(obj, dict) or bool(obj.get("ok", True)))

        jlog("wifi_connect", method=m, ok=ok, rc=rc, sec=sec, iface=iface, ssid=ssid)

        if ok:
            method_used = m
            break

    if not method_used:
        jlog("wifi_connect_fail", rc=last.get("rc"), out_tail=(last.get("out") or "")[-800:], err_tail=(last.get("err") or "")[-800:])
        raise RuntimeError("wifi_connect_failed")

    # Verify IP
    ip4 = _ip4_addr(iface)
    ip_ok = bool(ip4)
    jlog("wifi_ipv4", ok=ip_ok, iface=iface, ipv4=ip4)
    if not ip_ok:
        raise RuntimeError("wifi_no_ipv4")

    # MAC (after connection)
    mac = _iface_mac(iface)
    jlog("wifi_client_mac", ok=bool(mac), iface=iface, mac=mac)

    # Optional pings
    ping_router = _clean_env(os.environ.get("WIFI_PING_ROUTER", "192.168.1.1"))
    ping_count = int(_clean_env(os.environ.get("WIFI_PING_COUNT", "3")) or "3")
    ping_timeout = int(_clean_env(os.environ.get("WIFI_PING_TIMEOUT_SEC", "5")) or "5")

    if int(_clean_env(os.environ.get("WIFI_PING_ROUTER_ENABLE", "1")) or "1") == 1:
        if not _ping(iface, ping_router, count=ping_count, timeout_sec=ping_timeout):
            raise RuntimeError("wifi_ping_router_failed")

    if int(_clean_env(os.environ.get("WIFI_PING_INTERNET", "0")) or "0") == 1:
        target = _clean_env(os.environ.get("WIFI_PING_TARGET", "www.google.com"))
        if target and not _ping(iface, target, count=ping_count, timeout_sec=ping_timeout):
            raise RuntimeError("wifi_ping_internet_failed")

    return {
        "ssid": ssid,
        "iface": iface,
        "method": method_used,
        "ipv4": ip4,
        "mac": mac,
        "mac_before": mac_now,
    }


def reconnect_and_get_ip(expected_ip: str = "") -> Dict[str, Any]:
    """Disconnect then reconnect, returning the new ipv4 and asserting expected_ip if provided."""
    iface = _clean_env(os.environ.get("WIFI_IFACE", "wlan0") or "wlan0")
    wait_sec = float(_clean_env(os.environ.get("WIFI_RECONNECT_WAIT_SEC", "2")) or "2")

    jlog("wifi_reconnect_start", iface=iface, expected_ip=expected_ip or None)
    disconnect_best_effort(iface)
    if wait_sec > 0:
        time.sleep(wait_sec)

    info = connect_from_cpe_creds()
    got = info.get("ipv4") or ""
    ok = (not expected_ip) or (got == expected_ip)
    jlog("wifi_reconnect", ok=ok, iface=iface, got_ip=got, expected_ip=expected_ip or None)
    if expected_ip and got != expected_ip:
        raise RuntimeError(f"wifi_ip_mismatch got={got} expected={expected_ip}")
    return info
