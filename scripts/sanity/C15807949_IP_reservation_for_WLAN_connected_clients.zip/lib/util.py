# -*- coding: utf-8 -*-
import os, json, time, shlex, subprocess, re
from typing import Any, Dict, Optional, Tuple, List, Union

# ---------------------------------------------------------------------------
# Test Plan alignment (presentation-only)
#
# We keep the original "event" names for backward compatibility, and attach:
#   - tp_step  : int (0=meta/preconditions, 1..6 align to Test Plan steps)
#   - tp_event : str (step-aligned human-readable event id)
#
# This does NOT change any test logic; it only enriches log output.
# ---------------------------------------------------------------------------

# Static mapping for events that have an unambiguous Test Plan step.
_TP_EVENT_MAP: Dict[str, Tuple[int, str]] = {
    # Meta / wrapper-ish
    "test_start": (0, "tp0.test_start"),
    "test_end": (0, "tp0.test_end"),

    # Step 1: Power on / claimed on Dev NOC / readiness
    "cpe_cloud_check": (1, "tp1.cloud_check"),
    "pdu_reset_start": (1, "tp1.pdu_reset_start"),
    "pdu_reset_end": (1, "tp1.pdu_reset_end"),
    "node_id": (1, "tp1.get_node_id"),
    "node_id_error": (1, "tp1.get_node_id.error"),
    "ssh_port": (1, "tp1.ssh.port_scan"),
    "ssh_probe_start": (1, "tp1.ssh.probe_start"),
    "ssh_probe": (1, "tp1.ssh.probe"),
    "ssh_enable_cmd": (1, "tp1.ssh_enable.cmd"),
    "ssh_enable_start": (1, "tp1.ssh_enable.start"),
    "ssh_enable_end": (1, "tp1.ssh_enable.end"),
    "ssh_enable_wait": (1, "tp1.ssh_enable.wait"),
    "ssh_enable_attempt_failed": (1, "tp1.ssh_enable.attempt_failed"),
    "ssh_enable_skip": (1, "tp1.ssh_enable.skip"),
    "ssh_enable": (1, "tp1.ssh_enable"),

    # Step 4: Enter / assign static IP (reservation set)
    "cleanup_warn": (4, "tp4.cleanup_warn"),
    "dhcp_resv_del": (4, "tp4.reservation.delete_best_effort"),
    "dhcp_resv_del_skip": (4, "tp4.reservation.delete_skip"),
    "dhcp_resv_set": (4, "tp4.reservation.set"),
    "noc_location_override": (4, "tp4.noc.location_id.override"),
    "noc_location_resolved": (4, "tp4.noc.location_id.resolved"),

    # Step 5: Disconnect/reconnect device -> renew + connectivity
    "skip_lan_renew": (5, "tp5.lan_renew.skipped"),
    "lan_renew_start": (5, "tp5.lan_renew.start"),
    "lan_renew_retry": (5, "tp5.lan_renew.retry"),
    "lan_renew": (5, "tp5.lan_renew.result"),
    "lan_renew_diag": (5, "tp5.lan_renew.diag"),

    # Step 6: Verify reserved/leased tables (console in TP; SSH in automation)
    "dhcp_dump": (6, "tp6.dhcp.dump"),
    "dhcp_dump_diag": (6, "tp6.dhcp.dump.diag"),
    "dhcp_dump_retry": (6, "tp6.dhcp.dump.retry"),
    "dhcp_dump_reensure_ssh": (6, "tp6.dhcp.dump.reensure_ssh"),
    "dhcp_dump_reensure_ssh_failed": (6, "tp6.dhcp.dump.reensure_ssh_failed"),
    "assert_reserved_ok": (6, "tp6.assert_reserved.ok"),
    "assert_reserved_fail": (6, "tp6.assert_reserved.fail"),
    "lease_wait": (6, "tp6.lease.wait"),
    "assert_leased_ok": (6, "tp6.assert_leased.ok"),
    "assert_leased_fail": (6, "tp6.assert_leased.fail"),

    # WLAN client steps (Wi-Fi side)
    "wifi_creds": (1, "tp1.wifi.creds"),
    "wifi_creds_select": (1, "tp1.wifi.creds_select"),
    "wifi_connect": (1, "tp1.wifi.connect"),
    "wifi_ipv4": (1, "tp1.wifi.ipv4"),
    "wifi_client_mac": (3, "tp3.wifi_device.mac"),
    "wifi_reconnect_start": (5, "tp5.wifi.reconnect.start"),
    "wifi_reconnect": (5, "tp5.wifi.reconnect.result"),

    # Step 7-9: remove + verify reservation cleared
    "dhcp_resv_del_strict": (7, "tp7.reservation.delete"),
    "assert_reserved_absent_ok": (8, "tp8.assert_reserved_absent.ok"),
    "assert_reserved_absent_fail": (8, "tp8.assert_reserved_absent.fail"),
    "dhcp_dump_after_delete": (9, "tp9.dhcp.dump_after_delete"),

# Generic (profile load is shared by multiple phases)
    "noc_profile_load_error": (0, "tp0.profile.load_error"),
    "noc_profile_not_found": (0, "tp0.profile.not_found"),
}


def _tp_hint(event: str, fields: Dict[str, Any]) -> Optional[Tuple[int, str]]:
    """Return (tp_step, tp_event) if we can infer a TP alignment."""
    if event in _TP_EVENT_MAP:
        return _TP_EVENT_MAP[event]

    # Special-case: step_start/step_end wrapping ssh_ready.
    if event in ("step_start", "step_end") and fields.get("name") == "ssh_ready":
        return (1, f"tp1.ssh_ready.{ 'start' if event=='step_start' else 'end' }")

    return None

def jlog(event: str, **fields: Any) -> None:
    # Presentation-only TP alignment.
    # Add tp_step + tp_event if not already provided.
    try:
        if "tp_step" not in fields or "tp_event" not in fields:
            hint = _tp_hint(event, fields)
            if hint:
                # Avoid mutating caller dict
                fields = dict(fields)
                fields.setdefault("tp_step", hint[0])
                fields.setdefault("tp_event", hint[1])
    except Exception:
        # Never allow logging enrichment to break test execution.
        pass

    obj = {"event": event}
    obj.update(fields)
    print(json.dumps(obj, ensure_ascii=False), flush=True)

def slog(msg: str) -> None:
    print(msg, flush=True)

def q(s: str) -> str:
    return shlex.quote(str(s))

def run_cmd(cmd: str, timeout: float = 30.0, env: Optional[Dict[str, str]] = None) -> Tuple[int, str, str, float]:
    """
    Run shell command locally. Returns (rc, stdout, stderr, sec).
    """
    t0 = time.time()
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
    try:
        out, err = p.communicate(timeout=timeout)
        rc = p.returncode
    except subprocess.TimeoutExpired:
        p.kill()
        out, err = p.communicate()
        rc = 124
    sec = time.time() - t0
    return rc, out.decode(errors="ignore"), err.decode(errors="ignore"), sec

_JSON_RE = re.compile(r'\{.*\}', re.S)

def parse_last_json(text: str) -> Optional[Dict[str, Any]]:
    """
    Find and parse the last JSON object in text.
    """
    # common case: whole stdout is json
    s = text.strip()
    if s.startswith("{") and s.endswith("}"):
        try:
            return json.loads(s)
        except Exception:
            pass
    # fallback: search for last {...}
    matches = list(_JSON_RE.finditer(text))
    for m in reversed(matches):
        chunk = m.group(0)
        try:
            return json.loads(chunk)
        except Exception:
            continue
    return None

def retry(fn, attempts: int, wait_sec: float, on_fail_event: str, **ctx):
    last = None
    for i in range(1, attempts+1):
        try:
            return fn(i)
        except Exception as e:
            last = e
            jlog(on_fail_event, attempt=i, attempts=attempts, error=str(e), **ctx)
            if i < attempts and wait_sec > 0:
                time.sleep(wait_sec)
    if last:
        raise last
    raise RuntimeError("retry failed")
