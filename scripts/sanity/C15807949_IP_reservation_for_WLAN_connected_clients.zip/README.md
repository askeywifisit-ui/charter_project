# C15807949_IP_reservation_for_WLAN_connected_clients

## 1) 目的 / 覆蓋範圍
- 驗證 Wi‑Fi SSID 廣播、client 連線或 radio toggle 行為。

## 2) 前置條件 / 環境
- 需有可用 WLAN client，且腳本指定的 SSID/頻段在環境中存在。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- （manifest 未包含常見 env 或解析不到；可直接查看 zip 內 manifest.yaml）

## 5) PASS/FAIL 判定
- PASS：SSID/連線/radio 狀態符合預期。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807949_IP_reservation_for_WLAN_connected_clients

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807949_IP_reservation_for_WLAN_connected_clients

## Purpose
Automate **IP reservation for WLAN connected clients** using the Control PC's Wi‑Fi NIC as the test client.

This validates end-to-end:
1. Control PC connects to the router Wi‑Fi and obtains an IPv4 lease
2. DHCP reservation is created via NOC API (MAC → IPv4)
3. After Wi‑Fi disconnect/reconnect, the client receives the **reserved IPv4**
4. DHCP reserved/leased tables on the CPE (via SSH) match expectations
5. Reservation is deleted and the CPE reserved table is cleared

## Topology
Control PC (this runner) has a Wi‑Fi NIC (ex: `wlx6cb0ce1ff230`) and connects to the router SSID.

## What replaces the manual UI/console steps
- **UI "Create DHCP Reservation"** is replaced by **NOC DHCP reservation API** (in `lib/dhcp_api.py`).
- **Serial console `ovsh s DHCP_*`** is replaced by **SSH DHCP dump** (`cpe_ssh.py --cmd dhcp`).

## Precondition behavior (cycle #1 only)
1. `cpe_info --cloud` retry until timeout
2. If still not ready → PDU reset once → retry
3. Resolve node-id via `cpe_info --node-id`
4. Ensure SSH is ready (port scan → NOC ssh-enable if needed → SSH probe with `uptime`)

## Script flow
1. Connect Wi‑Fi using SSID/PSK fetched from the CPE (`cpe_ssh.py --cmd wifi-creds`)
2. Create DHCP reservation for the Wi‑Fi NIC MAC → `TEST_RESERVED_IP`
3. Verify reservation appears on CPE
4. Disconnect/reconnect Wi‑Fi and verify client IPv4 equals `TEST_RESERVED_IP`
5. Verify DHCP lease appears for the client
6. Delete reservation and verify it is absent from the CPE reserved table

## Important notes
- Manual TP step 4 says the reserved IP should be **different** from the initial lease.
  - Default behavior enforces this.
  - If `AUTO_PICK_FREE_IP=1` (default), the script will pick another free IP in the same /24.
  - If you must allow reserving the current IP, set `ALLOW_SAME_IP=1`.

- If your OS randomizes the Wi‑Fi MAC per connection/SSID, enable a stable MAC:
  - `WIFI_FORCE_STATIC_MAC=1` and optionally set `WIFI_TEST_MAC`.

- Deleting all reservations is dangerous in shared locations:
  - `CLEAR_ALL_NOC_DHCP_RESERVATIONS=0` by default.

## Key env vars
See `manifest.yaml`. Common edits:
- `WIFI_IFACE` (ex: `wlx6cb0ce1ff230`)
- `WIFI_METHOD` (`auto|iwd|nm`)
- `WIFI_BAND` (`2g|5g|6g`)
- `TEST_RESERVED_IP`, `TEST_HOSTNAME`

## External dependencies
- `/home/da40/charter/tools/cpe_info`
- `/home/da40/charter/tools/cpe_ssh.py`
- `/home/da40/charter/tools/wifi_iwd.py` and/or `/home/da40/charter/tools/wifi_nm.py`
- NOC credentials in `PROFILES_FILE`
```

```
