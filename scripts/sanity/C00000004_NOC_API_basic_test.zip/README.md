# C00000001_SSH_basic_test

## 1) 目的 / 覆蓋範圍
- 驗證 SSH 可用性與安全策略（允許/拒絕、port 限制、帳密錯誤等）。

## 2) 前置條件 / 環境
- 需具備對應 client 位置（LAN/WAN）與連線條件。
- 若需 NOC enable SSH，請用 `.secrets`/`PROFILES_FILE`。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- suite（manifest）：`stability`（注意：與資料夾不同，建議後續統一）
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：1
- CYCLE_INTERVAL：70

## 5) PASS/FAIL 判定
- PASS：SSH 行為符合預期策略。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C00000001 – SSH + NOC API Basic

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- suite（manifest）：`stability`（注意：與資料夾不同，建議後續統一）
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：1
- CYCLE_INTERVAL：70

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
> Professional update: remove hard-coded/empty NOC credentials and avoid serial node-id; use NOC_PROFILE+PROFILES_FILE and cpe_info --node-id.

# C00000001 – SSH + NOC API Basic

A **sanity / phase‑0** validation script that confirms the control plane is working:

- NOC API login/token
- Serial metrics → `node_id`
- NOC context lookup → `location_id`
- (Optional) NOC API feature checks (speedtest / Wi‑Fi / LTE / reboot)
- SSH enable via NOC + **SSH ready** verification on LAN

This package uses a **cycle wrapper** and a **unified precondition**:

- `cycle_wrapper.py` runs the test for `CYCLES` iterations.
- On **first cycle only**, it runs **precondition()**:
  1. **CPE_READY** (via `cpe_info -status`, with optional single PDU reset)
  2. **SSH_ENABLE + SSH_READY** (enable via NOC + TCP/22 + lightweight SSH command)

---

## Files

- `cycle_wrapper.py` – cycle control + unified precondition (first cycle only)
- `main_impl_orig.py` – main test logic (NOC API checks + optional ssh-enable/disable)
- `manifest.yaml` – default configuration for the harness
- `requirements.txt` – python deps (`requests`, `PyYAML`)

---

## Tooling dependency (tools.zip)

The script calls the following tools from `TOOLS_PATH`:

| Tool | Used by | Purpose |
|---|---|---|
| `noc_api_cli.py` | `main_impl_orig.py`, `cycle_wrapper.py` (via imports) | NOC login, node/location lookup, ssh-enable/disable, Wi‑Fi/LTE/speedtest/reboot APIs |
| `cpe_info` | `main_impl_orig.py`, `cycle_wrapper.py` | Fetch `node_id` via `cpe_info --node-id` (no serial/console) |
| `cpe_info` | `cycle_wrapper.py`, `main_impl_orig.py` | CPE status checks (`-status`, `--internet`, console password fallback) |
| `cpe_ssh.py` | `cycle_wrapper.py` | LAN SSH command check (`--cmd health`/`uptime`) |
| `serial_mute.py` | `cycle_wrapper.py` | Mute serial/console access during reboot/PDU operations |
| `pdu_outlet*.py` | `cycle_wrapper.py` | Power control for “single PDU reset” workaround |

> **Important**: `PDU_SCRIPT` must support `PDU_OUTLET_ID` (both lab/customer drivers should be the unified versions).

---

## How to run

### 1) Run in the harness (recommended)
The harness reads `manifest.yaml` and executes:

- entrypoint: `cycle_wrapper.py:run`
- original entry: `main_impl_orig.py:run` (via `ORIGINAL_ENTRY`)

Override variables via your harness `--set` mechanism.

### 2) Run locally (control PC)
From the script folder:

```bash
python3 -m pip install -r requirements.txt

# Use manifest.yaml defaults by exporting env (or edit manifest.yaml)
python3 cycle_wrapper.py
```

You may also run the underlying logic directly:

```bash
python3 main_impl_orig.py
```

> Running `main_impl_orig.py` directly **will not** execute the precondition in `cycle_wrapper.py`.

---

## Test flow

### A) Precondition (first cycle only)

#### A‑1. CPE_READY
1. Run `CPE_INFO_STATUS_CMD` (default: `cpe_info -status`).
2. Parse **Internet Status** and **Cloud Status**.
3. Ready criteria:
   - Internet must be `Connected`
   - Cloud must be `Connected` when `CPE_READY_REQUIRE_CLOUD=1`
4. Retry up to `CPE_READY_MAX_RETRIES` with `CPE_READY_RETRY_INTERVAL_SEC`.

If still not ready and `PDU_RESET_ON_NOT_READY=1`:
- Perform **exactly one** PDU reset:
  1) `serial_mute.py --set <REBOOT_MUTE_SECS>` (or fallback to `serial.mute` file)
```
