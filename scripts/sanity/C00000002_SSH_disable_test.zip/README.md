# C00000002_SSH_disable_test

## 1) 目的 / 覆蓋範圍
- 驗證 SSH 可用性與安全策略（允許/拒絕、port 限制、帳密錯誤等）。

## 2) 前置條件 / 環境
- 需具備對應 client 位置（LAN/WAN）與連線條件。
- 若需 NOC enable SSH，請用 `.secrets`/`PROFILES_FILE`。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'70'

## 5) PASS/FAIL 判定
- PASS：SSH 行為符合預期策略。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C00000002_SSH_disable_test

## 1) 目的 / 覆蓋範圍
- 驗證 SSH 安全策略與可用性（例如僅允許 port 22、錯誤憑證不可登入、disable 後不可登入等）。

## 2) 前置條件 / 環境
- 需可從指定 client 端連到 CPE（LAN/WAN 視腳本而定）。
- 若透過 NOC 使能 SSH，需提供 NOC profile/credentials（建議走 `.secrets`/`PROFILES_FILE`）。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'70'

## 5) PASS/FAIL 判定
- PASS：符合策略（允許/拒絕）行為與預期一致。
- FAIL：SSH policy 或連線條件不符。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C00000002_SSH_disable_test (v1)

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'70'

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C00000002_SSH_disable_test (v1)

用途：**單純用 NOC API 將 CPE 的 SSH AccessControl 設為 false（關閉 port 22）**，用來測試其他腳本在偵測到 port 22 關閉時，是否會自動走「NOC ssh-enable」流程。

## Test Flow
1. Load NOC profile (PROFILES_FILE + NOC_PROFILE) into env (only fills missing fields)
2. Wait CPE Cloud Connected (`cpe_info --cloud`)
3. Get node-id (`cpe_info --node-id`)
4. Disable SSH via NOC API (`noc_api_cli.ssh_disable`)
5. Wait `WAIT_AFTER_SSH_DISABLE_SEC`
6. Verify port 22 is closed (optional; controlled by `SSH_DISABLE_VERIFY`)

## Key env
- PROFILES_FILE / NOC_PROFILE (推薦)
- NOC_BASE, CUSTOMER_ID, NOC_EMAIL, NOC_PASSWORD (若 profiles 沒補齊，可由 runner/env 注入)
- WAIT_AFTER_SSH_DISABLE_SEC (default 60)
- SSH_DISABLE_VERIFY (default 1), SSH_DISABLE_VERIFY_TIMEOUT_SEC (default 120)

## Notes
- 本腳本不使用 console，不需要 SSH login 進 CPE。
- 若你要測其他腳本的 auto ssh-enable，先跑這包把 SSH 關掉，再跑目標腳本。
```

```
```
