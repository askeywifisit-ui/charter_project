#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""C00000002_SSH_disable_test — Disable SSH via NOC API (kvConfigs).

Goal:
- Turn OFF SSHM.sshAccessControl via NOC API (port 22 should become closed)
- Optionally verify port 22 is closed so other scripts can test their auto ssh-enable behavior.

This script matches the A2435638 wrapper architecture:
- entrypoint: cycle_wrapper.py:run
- actual logic: main_impl.py:run
"""

from __future__ import annotations

import json
import os
import socket
import subprocess
import time
import pathlib
from typing import Any, Dict, Tuple, Optional


# ------------------------------------------------------------
# Logging helpers (human + JSON lines)
# ------------------------------------------------------------

def _ts() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

def _log(msg: str) -> None:
    print(msg, flush=True)

def _emit(event: str, **k: Any) -> None:
    d = {"event": event}
    if _gi("LOG_INCLUDE_TS", 0) == 1:
        d["ts"] = _ts()
    d.update(k)
    print(json.dumps(d, ensure_ascii=False), flush=True)


# ------------------------------------------------------------
# Env helpers
# ------------------------------------------------------------

def _g(name: str, default: Any = "") -> str:
    v = os.environ.get(name)
    if v is None:
        return str(default)
    return str(v)

def _gi(name: str, default: int) -> int:
    try:
        return int(str(os.environ.get(name, str(default))).strip())
    except Exception:
        return int(default)

def _gb(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    s = str(v).strip().lower()
    if s in ("1", "true", "yes", "on", "y"):
        return True
    if s in ("0", "false", "no", "off", "n"):
        return False
    return default


# ------------------------------------------------------------
# Tools paths / imports
# ------------------------------------------------------------

def _tools_path() -> str:
    return _g("TOOLS_PATH", _g("TOOLS_DIR", "/home/da40/charter/tools")).strip() or "/home/da40/charter/tools"

def _cpe_info_tool() -> str:
    return _g("CPE_INFO_TOOL", str(pathlib.Path(_tools_path()) / "cpe_info"))

def _import_noc_api_cli():
    """Import tools/noc_api_cli.py as a module."""
    tp = _tools_path()
    if tp and tp not in os.sys.path:
        os.sys.path.insert(0, tp)
    try:
        import noc_api_cli  # type: ignore
        return noc_api_cli
    except Exception as e:
        raise RuntimeError(f"noc_api_cli import failed (TOOLS_PATH={tp}): {e}")


# ------------------------------------------------------------
# Profiles (PROFILES_FILE only)
# ------------------------------------------------------------

def _load_profile_into_env() -> None:
    """Load NOC profile from PROFILES_FILE if NOC_PROFILE is set.
    Only fills env vars if not already set.
    """
    profile = _g("NOC_PROFILE", "").strip()
    if not profile:
        return

    path = (
        os.environ.get("PROFILES_FILE")
        or os.environ.get("NOC_PROFILES_PATH")  # legacy
        or os.path.expanduser("~/.secrets/noc_profiles.json")
    )

    if os.environ.get("NOC_PROFILES_PATH") and not os.environ.get("PROFILES_FILE"):
        _emit("deprecated_env", name="NOC_PROFILES_PATH", use="PROFILES_FILE", path=path)

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        _emit("noc_profile_missing", profile=profile, path=path)
        return
    except Exception as e:
        _emit("noc_profile_load_error", profile=profile, path=path, error=str(e))
        return

    prof = data.get(profile) or data.get(profile.upper()) or {}
    if not prof:
        _emit("noc_profile_not_found", profile=profile, path=path)
        return

    applied = []
    mapping = {
        "NOC_BASE": "base",
        "NOC_EMAIL": "email",
        "NOC_PASSWORD": "password",
        "CUSTOMER_ID": "customer_id",
        "LOCATION_ID": "location_id",
        "BEARER": "bearer",
        "INSECURE": "insecure",
    }

    for env_k, json_k in mapping.items():
        if os.environ.get(env_k) and str(os.environ.get(env_k)).strip() != "":
            continue
        if json_k in prof and prof[json_k] is not None:
            os.environ[env_k] = str(prof[json_k])
            applied.append(env_k)

    _emit("noc_profile_loaded", profile=profile, applied=applied)


# ------------------------------------------------------------
# Basic process / networking helpers
# ------------------------------------------------------------

def _run(argv, timeout: float = 30.0) -> Tuple[int, str]:
    t0 = time.time()
    try:
        p = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)
        out = (p.stdout or "").strip()
        _emit("cmd", ok=(p.returncode == 0), rc=p.returncode, sec=round(time.time() - t0, 3), argv=argv, sample=out.splitlines()[:3])
        return p.returncode, out
    except subprocess.TimeoutExpired:
        _emit("cmd", ok=False, rc=None, timeout=True, sec=round(time.time() - t0, 3), argv=argv)
        return 124, ""

def _tcp_open(host: str, port: int, per_try_timeout: float = 2.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=per_try_timeout):
            return True
    except Exception:
        return False

def _wait_port_closed(host: str, port: int, timeout_sec: int, interval_sec: float) -> bool:
    t0 = time.time()
    while time.time() - t0 < timeout_sec:
        if not _tcp_open(host, port, per_try_timeout=min(2.0, interval_sec)):
            return True
        time.sleep(interval_sec)
    return False


# ------------------------------------------------------------
# CPE ready / node-id
# ------------------------------------------------------------

def ensure_cpe_ready() -> bool:
    max_retries = _gi("CPE_READY_MAX_RETRIES", 10)
    sleep_sec = _gi("CPE_READY_RETRY_SLEEP_SEC", 30)
    tool = _cpe_info_tool()
    timeout = float(_g("CPE_INFO_TIMEOUT_SEC", "30") or "30")

    _emit("step_start", name="cpe_ready", max_retries=max_retries, sleep_sec=sleep_sec, tool=tool)
    for i in range(1, max_retries + 1):
        rc, out = _run([tool, "--cloud"], timeout=timeout)
        ok = (rc == 0 and "Cloud Status: Connected" in out)
        _emit("step_progress", name="cpe_ready", try_no=i, ok=ok, sample=out.splitlines()[:2])
        if ok:
            _emit("step_end", name="cpe_ready", ok=True)
            return True
        time.sleep(sleep_sec)

    _emit("step_end", name="cpe_ready", ok=False)
    return False

def get_node_id() -> str:
    tool = _cpe_info_tool()
    rc, out = _run([tool, "--node-id"], timeout=15)
    if rc != 0:
        return ""
    for line in out.splitlines():
        s = line.strip()
        if s:
            return s
    return ""


# ------------------------------------------------------------
# NOC: disable ssh
# ------------------------------------------------------------

def disable_ssh_via_noc(node_id: str) -> Tuple[bool, Optional[str]]:
    """Disable SSH via NOC API; returns (ok, location_id)."""
    noc = _import_noc_api_cli()

    base = _g("NOC_BASE", "https://piranha-int.tau.dev-charter.net").strip()
    customer_id = _g("CUSTOMER_ID", "").strip()
    email = _g("NOC_EMAIL", "").strip()
    password = _g("NOC_PASSWORD", "").strip()
    bearer = _gb("BEARER", False)
    insecure = _gb("INSECURE", False)

    if not customer_id:
        _emit("ssh_disable", ok=False, error="CUSTOMER_ID not set")
        return False, None
    if not email or not password:
        _emit("ssh_disable", ok=False, error="NOC_EMAIL/NOC_PASSWORD not set (or missing in PROFILES_FILE)")
        return False, None

    try:
        token = noc.login(base, email, password, bearer=bearer, insecure=insecure)

        loc_env = _g("LOCATION_ID", "").strip()
        location_id = loc_env or noc.get_location_id(base, customer_id, node_id, token=token, bearer=bearer, insecure=insecure)

        _emit(
            "ssh_disable_start",
            node_id=node_id,
            location_id=location_id,
            customer_id=customer_id,
            base=base,
        )

        resp = noc.ssh_disable(
            base,
            customer_id,
            location_id,
            node_id,
            token=token,
            bearer=bearer,
            insecure=insecure,
        )
        _emit("ssh_disable_end", ok=True, resp=resp)
        return True, location_id
    except Exception as e:
        _emit("ssh_disable_end", ok=False, error=str(e))
        return False, None


# ------------------------------------------------------------
# Entry
# ------------------------------------------------------------

def run() -> int:
    _emit("runner_start", name="C00000002_SSH_disable_test")

    # load profile once
    _load_profile_into_env()

    # precondition: cpe ready + node-id
    if not ensure_cpe_ready():
        _log("[runner] FAIL: cpe_ready")
        return 1

    node_id = get_node_id()
    if not node_id:
        _emit("node_id", ok=False)
        _log("[runner] FAIL: node-id missing")
        return 1
    _emit("node_id", ok=True, node_id=node_id)

    host = _g("CPE_HOST", "192.168.1.1").strip() or "192.168.1.1"
    port = _gi("CPE_SSH_PORT", 22)

    # disable ssh
    _emit("step_start", name="ssh_disable", host=host, port=port, node_id=node_id)
    ok, location_id = disable_ssh_via_noc(node_id=node_id)
    _emit("step_end", name="ssh_disable", ok=ok, location_id=location_id)
    if not ok:
        _log("[runner] FAIL: ssh_disable")
        return 1

    wait_after = _gi("WAIT_AFTER_SSH_DISABLE_SEC", 60)
    if wait_after > 0:
        _emit("sleep", name="after_ssh_disable", seconds=wait_after)
        _log(f"[runner] wait {wait_after}s")
        time.sleep(wait_after)

    # verify port closed (optional)
    if _gb("SSH_DISABLE_VERIFY", True):
        timeout = _gi("SSH_DISABLE_VERIFY_TIMEOUT_SEC", 120)
        interval = float(_g("SSH_DISABLE_VERIFY_INTERVAL_SEC", "2") or "2")
        _emit("step_start", name="verify_port_closed", host=host, port=port, timeout_sec=timeout, interval_sec=interval)
        closed = _wait_port_closed(host, port, timeout_sec=timeout, interval_sec=interval)
        _emit("step_end", name="verify_port_closed", ok=closed)
        if not closed:
            _log("[runner] FAIL: port 22 still open (disable not applied yet?)")
            return 1

    _log("[runner] PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(run())
