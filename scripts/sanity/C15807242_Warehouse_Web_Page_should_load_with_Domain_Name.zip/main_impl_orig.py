#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""C15807242 - Warehouse Web Page should load with Domain Name

Automation outline (based on C15807240 structure):
  1) Resolve NOC credentials (profiles.json recommended) and login.
  2) Resolve node-id via serial metrics tool, then resolve location-id.
  3) (Optional) Factory Reset via NOC API.
  4) Verify both domain entry points redirect from HTTP to HTTPS:
       - http://MyRouter/warehouse     -> https://myrouter/cgi-bin/warehouse.cgi
       - http://MyRouter.lan/warehouse -> https://myrouter.lan/cgi-bin/warehouse.cgi
     (Host case-insensitive; strictness configurable.)
  5) (Optional) Validate the domain names resolve to the expected LAN IPv4.
  6) Fetch/parse warehouse.cgi via domain name using cpe_warehouse_info.py.
  7) Validate required fields and sanity checks.
  8) (Optional) Change Wi‑Fi SSID/Password via NOC API and re-validate warehouse values.

All logs are emitted as one-line JSON to be charter-runner friendly.
"""

from __future__ import annotations

import json
import os
import re
import socket
import subprocess
import sys
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse


# -------------------------------------------------
# Load tools (noc_api_cli) from TOOLS_PATH
# -------------------------------------------------
TOOLS_PATH = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
if TOOLS_PATH and TOOLS_PATH not in sys.path:
    sys.path.insert(0, TOOLS_PATH)

try:
    import noc_api_cli as noc  # type: ignore
except Exception as e:
    noc = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "noc_api_cli", "error": str(e)}), flush=True)


LOOP_FAIL = True


# -------------------------------------------------
# helpers
# -------------------------------------------------

def jlog(event: str, **kv: Any) -> None:
    payload = {"event": event}
    payload.update(kv)
    print(json.dumps(payload, ensure_ascii=False), flush=True)


def env_str(key: str, default: str = "") -> str:
    v = os.environ.get(key)
    if v is None:
        return default
    return str(v)


def env_int(key: str, default: int) -> int:
    try:
        return int(str(os.environ.get(key, str(default))).strip())
    except Exception:
        return default


def env_bool(key: str, default: bool = False) -> bool:
    v = os.environ.get(key)
    if v is None:
        return default
    s = str(v).strip().lower()
    if s in ("1", "true", "yes", "y", "on"):
        return True
    if s in ("0", "false", "no", "n", "off"):
        return False
    return default


def _norm_key(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").strip().lower())


def _looks_ipv4(s: str) -> bool:
    s = (s or "").strip()
    if not s:
        return False
    m = re.search(r"\b(\d{1,3})(?:\.(\d{1,3})){3}\b", s)
    if not m:
        return False
    parts = m.group(0).split(".")
    try:
        return all(0 <= int(p) <= 255 for p in parts)
    except Exception:
        return False


def _looks_base64(s: str) -> bool:
    s = (s or "").strip()
    if len(s) < 8:
        return False
    if re.fullmatch(r"[A-Za-z0-9+/]+={0,2}", s) is None:
        return False
    return len(s) % 4 == 0


def _b64_decode_safe(s: str) -> str:
    import base64

    try:
        return base64.b64decode((s or "").encode("utf-8"), validate=False).decode("utf-8", "ignore").strip()
    except Exception:
        return ""


def _split_csv(s: str) -> List[str]:
    return [x.strip() for x in (s or "").split(",") if x.strip()]


def _url_host(url: str) -> str:
    try:
        return (urlparse(url).hostname or "").strip()
    except Exception:
        return ""


def resolve_host_ipv4(host: str) -> List[str]:
    """Resolve host to IPv4 addresses (best-effort)."""
    host = (host or "").strip()
    if not host:
        return []

    # Prefer getent because it respects /etc/hosts + DNS + mDNS/LLMNR setups.
    addrs: List[str] = []
    try:
        p = subprocess.run(["getent", "ahostsv4", host], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out = (p.stdout or "")
        for line in out.splitlines():
            parts = line.split()
            if parts and _looks_ipv4(parts[0]):
                if parts[0] not in addrs:
                    addrs.append(parts[0])
    except Exception:
        pass

    if addrs:
        return addrs

    # Fallback to socket
    try:
        infos = socket.getaddrinfo(host, None, family=socket.AF_INET)
        for info in infos:
            ip = info[4][0]
            if _looks_ipv4(ip) and ip not in addrs:
                addrs.append(ip)
    except Exception:
        return []

    return addrs


def _normalize_mac(s: str) -> str:
    """Normalize MAC string to lower-case colon-separated 6-byte format."""
    s = (s or "").strip().lower()
    if not s:
        return ""
    # extract the first 6 hex bytes we can find
    bytes_ = re.findall(r"[0-9a-f]{2}", s)
    if len(bytes_) < 6:
        return ""
    bytes_ = bytes_[:6]
    return ":".join(bytes_)


def _parse_ifconfig_a_macs(text: str) -> Dict[str, str]:
    """Parse interface MACs from command output into {iface: mac}. Best-effort.

    Supported formats:
      - ifconfig -a / ifconfig
      - ip link show / ip -o link
    """
    macs: Dict[str, str] = {}
    cur: Optional[str] = None
    for raw in (text or "").splitlines():
        line = raw.rstrip("\r")
        if not line.strip():
            continue
        if line[:1].strip():
            # interface header line usually starts at column 0
            # ip link format example: "2: eth0@ifb0: <...>" (avoid capturing "2:")
            m_hdr = re.match(r"^\s*\d+:\s*([^:]+):", line)
            if m_hdr:
                cur = m_hdr.group(1).split("@")[0]
            else:
                cur = line.split()[0]
            # try parse mac on same line
            m = re.search(r"\b(?:hwaddr|ether|link/ether)\b\s+([^\s]+)", line, re.I)
            if m and cur:
                mac = _normalize_mac(m.group(1))
                if mac:
                    macs[cur] = mac
            continue

        # indented line within current interface
        if not cur:
            continue
        m = re.search(r"\b(?:hwaddr|ether|link/ether)\b\s+([^\s]+)", line, re.I)
        if m:
            mac = _normalize_mac(m.group(1))
            if mac:
                macs[cur] = mac

    return macs


def maybe_enable_ssh_via_noc(creds: NocCreds, token: str, location_id: str, node_id: str) -> bool:
    """Enable SSH via NOC kvConfigs (optional). Returns True if we attempted enable."""
    if noc is None:
        raise RuntimeError("noc_api_cli import failed")

    if not env_bool("ENABLE_SSH_VIA_NOC", False):
        jlog("ssh_enable_skip", reason="ENABLE_SSH_VIA_NOC=0")
        return False

    customer_id = env_str("CUSTOMER_ID")
    passwd = (
        env_str("SSH_ENABLE_PASSWORD", "").strip()
        or env_str("SSH_PASSWORD", "").strip()
        or env_str("CPE_PASSWORD", "").strip()
    )
    timeout_min = env_int("SSH_ENABLE_TIMEOUT_MIN", 30)

    if not passwd:
        jlog("ssh_enable_skip", reason="missing_password", hint="set SSH_ENABLE_PASSWORD (or SSH_PASSWORD)")
        return False

    jlog("ssh_enable_start", timeout_min=timeout_min)
    resp = noc.ssh_enable(
        creds.base,
        customer_id,
        location_id,
        node_id,
        passwd,
        timeout_min,
        token=token,
        bearer=creds.bearer,
        insecure=creds.insecure,
    )
    jlog("ssh_enable_ok", response=resp)
    return True


def validate_macs_against_ifconfig(warehouse: Dict[str, Any]) -> Tuple[bool, Dict[str, Any]]:
    """Validate warehouse MAC fields against `ifconfig -a` from the CPE (via SSH).

    Mapping (default per requirement):
      - WAN  : ifconfig br-wan
      - LAN  : ifconfig br-home / BR_LAN
      - WLAN2.4: ifconfig wifi0
      - WLAN5.0: ifconfig wifi1
      - WLAN6.0: ifconfig wifi2
    """
    if not env_bool("VALIDATE_MACS_VIA_SSH", False):
        return True, {"skipped": True, "reason": "VALIDATE_MACS_VIA_SSH=0"}

    # Lazy import so the script still works in environments without tools.
    try:
        import cpe_ssh  # type: ignore
    except Exception as e:
        return False, {"skipped": False, "error": f"import cpe_ssh failed: {e}"}

    host = env_str("SSH_HOST", "").strip() or env_str("EXPECTED_LAN_IP", "192.168.1.1").strip() or "192.168.1.1"
    user = env_str("SSH_USER", "operator").strip() or "operator"
    password = env_str("SSH_PASSWORD", "").strip() or env_str("SSH_ENABLE_PASSWORD", "").strip()
    timeout = float(env_int("SSH_TIMEOUT_SEC", 30))
    strict = env_bool("MAC_VALIDATION_STRICT", True)
    allow_swap = env_bool("ALLOW_WIFI5_WIFI6_SWAP", True)

    if not password:
        return False, {"skipped": False, "error": "missing SSH_PASSWORD (or SSH_ENABLE_PASSWORD)"}

    # Wait for SSH to be ready (after factory reset / ssh-enable it may take time)
    ready_retries = env_int("SSH_READY_RETRIES", 10)
    ready_sleep = float(env_int("SSH_READY_SLEEP_SEC", 3))
    ready_timeout = float(env_int("SSH_READY_TIMEOUT_SEC", 8))
    ready_cmd = env_str("SSH_READY_CMD", "echo ready").strip() or "echo ready"
    ready_ok = False
    last_err = ""
    for a in range(1, ready_retries + 1):
        rrc, rout, rerr, rsec = cpe_ssh.ssh_exec(host, user, password, ready_cmd, timeout=ready_timeout, login_shell=True)
        last_err = (rerr or "").strip()
        jlog("ssh_ready_check", attempt=a, max_retries=ready_retries, rc=rrc, sec=rsec, err_tail=last_err[-200:])
        if rrc == 0:
            ready_ok = True
            break
        time.sleep(ready_sleep)

    if not ready_ok:
        return False, {"skipped": False, "error": "ssh not ready", "err": last_err}

    # Run ifconfig (with fallbacks) with retries (can time out on busy boot)
    retries = env_int("SSH_IFCONFIG_RETRIES", 3)
    sleep_sec = float(env_int("SSH_IFCONFIG_SLEEP_SEC", 3))
    max_timeout = float(env_int("SSH_IFCONFIG_MAX_TIMEOUT_SEC", max(30, int(timeout))))
    cur_timeout = float(timeout)
    rc = 1
    out = ""
    err = ""
    sec = 0.0
    cmd = env_str(
        "SSH_IFCONFIG_CMD",
        "ifconfig -a || ifconfig || ip link show || ip -o link",
    ).strip() or "ifconfig -a || ifconfig || ip link show || ip -o link"

    for a in range(1, retries + 1):
        rc, out, err, sec = cpe_ssh.ssh_exec(host, user, password, cmd, timeout=cur_timeout, login_shell=True)
        jlog("ssh_ifconfig_a", attempt=a, max_retries=retries, timeout=cur_timeout, rc=rc, sec=sec, out_tail=(out or "")[-400:], err_tail=(err or "")[-200:], cmd=cmd)
        if rc == 0:
            break
        # rc=124 is timeout; increase timeout and retry
        if rc == 124 and cur_timeout < max_timeout:
            cur_timeout = min(max_timeout, cur_timeout * 1.5)
        time.sleep(sleep_sec)

    if rc != 0:
        return False, {
            "skipped": False,
            "error": f"ifconfig command failed rc={rc}",
            "cmd": cmd,
            "err": (err or "").strip(),
        }

    macs = _parse_ifconfig_a_macs(out)
    def _csv_ifaces(key: str, default_list: List[str]) -> List[str]:
        v = env_str(key, "").strip()
        if not v:
            return default_list
        return [x.strip() for x in v.split(",") if x.strip()]

    checks = [
        {
            "field": "WAN MAC Address",
            "ifaces": ["br-wan"],
        },
        {
            "field": "LAN MAC Address",
            "ifaces": ["br-home", "BR_LAN", "br-lan", "br0"],
        },
        {
            "field": "WLAN2.4 MAC Address",
            "ifaces": ["wifi0", "home-ap-24"],
        },
        {
            "field": "WLAN5.0 MAC Address",
            "ifaces": _csv_ifaces("WLAN5_IFACES", ["home-ap-50", "wifi1", "home-ap-5"]),
        },
        {
            "field": "WLAN6.0 MAC Address",
            "ifaces": _csv_ifaces("WLAN6_IFACES", ["home-ap-60", "wifi2", "home-ap-6"]),
        },
    ]

    results: List[Dict[str, Any]] = []
    ok_all = True
    candidates_by_field: Dict[str, List[Dict[str, str]]] = {}
    index_by_field: Dict[str, int] = {}
    swap_applied = False

    for c in checks:
        field = c["field"]
        exp = _normalize_mac(str(warehouse.get(field, "")))
        iface_used = ""
        got = ""
        cand_list: List[Dict[str, str]] = []
        for iface in c["ifaces"]:
            if iface in macs and macs[iface]:
                cand_list.append({"iface": iface, "mac": macs[iface]})
                if not got:
                    iface_used = iface
                    got = macs[iface]
        candidates_by_field[field] = cand_list


        ok = True
        reason = ""

        if not exp:
            ok = False if strict else True
            reason = "warehouse_field_missing"
        elif not got:
            ok = False if strict else True
            reason = "iface_mac_missing"
        elif exp != got:
            ok = False
            reason = "mismatch"

        index_by_field[field] = len(results)
        results.append({
            "field": field,
            "expected": exp,
            "iface": iface_used,
            "actual": got,
            "candidates": candidates_by_field.get(field, []),
            "ok": ok,
            "reason": reason,
        })

        if not ok:
            ok_all = False

    # Some platforms label radios differently (e.g. wifi1 <-> wifi2). If both expected values are present
    # but swapped between the 5G and 6G candidate iface sets, optionally accept the swap.
    if allow_swap:
        f5 = "WLAN5.0 MAC Address"
        f6 = "WLAN6.0 MAC Address"
        if f5 in index_by_field and f6 in index_by_field:
            r5 = results[index_by_field[f5]]
            r6 = results[index_by_field[f6]]
            exp5 = str(r5.get("expected", "") or "")
            exp6 = str(r6.get("expected", "") or "")
            if exp5 and exp6:
                c5 = [c.get("mac", "") for c in candidates_by_field.get(f5, [])]
                c6 = [c.get("mac", "") for c in candidates_by_field.get(f6, [])]
                if (not r5.get("ok") or not r6.get("ok")) and (exp5 in c6) and (exp6 in c5):
                    def _find_iface(field: str, mac: str) -> str:
                        for c in candidates_by_field.get(field, []):
                            if c.get("mac") == mac:
                                return str(c.get("iface") or "")
                        return ""
                    # swap: 5G expected found in 6G candidates and vice versa
                    r5["ok"] = True
                    r5["reason"] = "swap_allowed"
                    r5["iface"] = _find_iface(f6, exp5) or r5.get("iface", "")
                    r5["actual"] = exp5

                    r6["ok"] = True
                    r6["reason"] = "swap_allowed"
                    r6["iface"] = _find_iface(f5, exp6) or r6.get("iface", "")
                    r6["actual"] = exp6

                    swap_applied = True
                    ok_all = all(bool(r.get("ok")) for r in results)

    return ok_all, {"skipped": False, "strict": strict, "results": results, "allow_swap": allow_swap, "swap_applied": swap_applied, "ifaces_seen": sorted(list(macs.keys()))[:50]}


def _normalize_location(http_url: str, location: str) -> str:
    """Normalize Location header into an absolute URL when it's relative."""
    loc = (location or "").strip()
    if not loc:
        return ""
    if loc.lower().startswith("http://") or loc.lower().startswith("https://"):
        return loc
    # relative path
    host = _url_host(http_url)
    if not host:
        return loc
    if not loc.startswith("/"):
        loc = "/" + loc
    return f"https://{host}{loc}"


@dataclass
class NocCreds:
    base: str
    email: str
    password: str
    bearer: bool
    insecure: bool


def load_noc_creds() -> NocCreds:
    bearer = env_bool("BEARER", False)
    insecure = env_bool("INSECURE", False)

    profile = env_str("NOC_PROFILE", "").strip()
    profiles_file = env_str("PROFILES_FILE", "").strip() or os.path.expanduser("~/.secrets/noc_profiles.json")

    if profile:
        try:
            with open(profiles_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            prof = data.get(profile) or data.get(profile.upper())
            if prof and prof.get("base") and prof.get("email") and prof.get("password"):
                jlog("noc_profile_loaded", profile=profile, profiles_file=profiles_file)
                return NocCreds(
                    base=str(prof["base"]),
                    email=str(prof["email"]),
                    password=str(prof["password"]),
                    bearer=bearer,
                    insecure=insecure,
                )
            jlog("noc_profile_missing", profile=profile, profiles_file=profiles_file)
        except Exception as e:
            jlog("noc_profile_load_error", profile=profile, profiles_file=profiles_file, error=str(e))

    base = env_str("NOC_BASE", "").strip()
    email = env_str("NOC_EMAIL", "").strip()
    password = env_str("NOC_PASSWORD", "").strip()
    if not (base and email and password):
        raise RuntimeError("Missing NOC credentials: provide NOC_PROFILE/PROFILES_FILE or NOC_BASE/NOC_EMAIL/NOC_PASSWORD")

    jlog("noc_profile_fallback_env", base=base)
    return NocCreds(base=base, email=email, password=password, bearer=bearer, insecure=insecure)


def noc_login(creds: NocCreds) -> str:
    if noc is None:
        raise RuntimeError("noc_api_cli import failed")
    tok = noc.login(creds.base, creds.email, creds.password, bearer=creds.bearer, insecure=creds.insecure)
    jlog("noc_login_ok")
    return tok


def node_id_fallback_via_cpe_info() -> Optional[str]:
    """
    Fallback: use cpe_info to derive node_id from WAN MAC.
    Expected command (tool-style):
      cpe_info --node-id --value
    Returns node_id (12 hex) or None.
    """
    tool = env_str("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info").strip() or "/home/da40/charter/tools/cpe_info"

    # Allow using bundled tool in script directory if present
    if not os.path.exists(tool):
        local_tool = os.path.join(os.path.dirname(__file__), "cpe_info")
        if os.path.exists(local_tool):
            tool = local_tool

    args = [tool, "--node-id", "--value"]

    # If not executable or looks like a .py file, run with python explicitly
    cmd = args
    if (tool.endswith(".py")) or (not os.access(tool, os.X_OK)):
        cmd = [sys.executable] + args

    jlog("node_id_fallback_cmd", cmd=cmd)
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

    out = (p.stdout or "").strip()
    err = (p.stderr or "").strip()
    if p.returncode != 0:
        raise RuntimeError(f"cpe_info rc={p.returncode}: {(err or out)[-400:]}")

    node_id = out.strip().lower()
    if not re.fullmatch(r"[0-9a-f]{12}", node_id):
        raise RuntimeError(f"unexpected node_id from cpe_info: {out!r}")

    return node_id


def resolve_node_id() -> str:
    if noc is None:
        raise RuntimeError("noc_api_cli import failed")

    metrics_tool = env_str("METRICS_TOOL", "").strip()
    dev = env_str("CPE_DEV", "").strip()
    baud = env_int("CPE_BAUD", 115200)
    user = env_str("CPE_USER", "root").strip() or "root"
    password = env_str("CPE_PASSWORD", "").strip()

    max_retries = env_int("NODE_ID_MAX_RETRIES", 5)
    interval = float(env_int("NODE_ID_RETRY_INTERVAL_SEC", 3))

    last_err: Optional[str] = None
    for attempt in range(1, max_retries + 1):
        try:
            node_id = noc.serial_get_node_id(metrics_tool, dev, baud, user, password)
            jlog("node_id_ok", attempt=attempt, node_id=node_id)
            return node_id
        except Exception as e:
            last_err = str(e)
            jlog("node_id_retry", attempt=attempt, max_retries=max_retries, error=last_err)

            # Fallback: use cpe_info to derive node_id (WAN MAC -> node_id)
            if env_bool("NODE_ID_FALLBACK_CPE_INFO", True):
                try:
                    nid = node_id_fallback_via_cpe_info()
                    jlog("node_id_fallback_ok", attempt=attempt, node_id=nid)
                    return nid
                except Exception as fe:
                    jlog("node_id_fallback_fail", attempt=attempt, error=str(fe))

            if attempt < max_retries:
                time.sleep(max(0.0, interval))

    raise RuntimeError(f"node-id resolve failed: {last_err}")


def resolve_location_id(creds: NocCreds, token: str, node_id: str) -> str:
    if noc is None:
        raise RuntimeError("noc_api_cli import failed")
    loc = noc.get_location_id(
        creds.base,
        env_str("CUSTOMER_ID"),
        node_id,
        token=token,
        bearer=creds.bearer,
        insecure=creds.insecure,
    )
    jlog("location_id_ok", location_id=loc)
    return loc


def do_factory_reset(creds: NocCreds, token: str, location_id: str) -> None:
    if noc is None:
        raise RuntimeError("noc_api_cli import failed")

    customer_id = env_str("CUSTOMER_ID")
    jlog("factory_reset_start", customer_id=customer_id, location_id=location_id)
    noc.factory_reset(
        creds.base,
        customer_id,
        location_id,
        token=token,
        bearer=creds.bearer,
        insecure=creds.insecure,
        options=None,
    )
    jlog("factory_reset_sent")

    # Optional: console mute during reboot window (same behavior as C15807240)
    mute_raw = (
        env_str("RESET_MUTE_SECS", "").strip()
        or env_str("FACTORY_RESET_MUTE_SECS", "").strip()
        or env_str("FR_MUTE_SECS", "").strip()
    )

    if not mute_raw:
        jlog("factory_reset_mute_console_skip", reason="env_not_set")
    else:
        try:
            mute_secs = int(mute_raw)
        except Exception:
            mute_secs = 0
            jlog("factory_reset_mute_console_invalid", mute_raw=mute_raw)

        if mute_secs <= 0:
            jlog("factory_reset_mute_console_skip", reason="mute_secs<=0", mute_raw=mute_raw)
        else:
            use_lock = (
                env_bool("RESET_MUTE_WITH_LOCK", False)
                or env_bool("FACTORY_RESET_MUTE_WITH_LOCK", False)
                or env_bool("FR_MUTE_WITH_LOCK", False)
            )
            lock_timeout = env_int("CONSOLE_LOCK_TIMEOUT_SEC", env_int("FACTORY_RESET_MUTE_LOCK_TIMEOUT_SEC", 5))
            retry_timeout = env_int("CONSOLE_LOCK_RETRY_TIMEOUT_SEC", 60)
            retry_interval = env_int("CONSOLE_LOCK_RETRY_INTERVAL_SEC", 3)

            until_ts = None
            t0 = time.time()
            attempt = 0
            while True:
                attempt += 1
                try:
                    import cpe_ssh  # type: ignore

                    until_ts = cpe_ssh.set_console_mute(mute_secs, use_lock=use_lock, lock_timeout=lock_timeout)
                    jlog(
                        "factory_reset_mute_console",
                        mute_secs=mute_secs,
                        use_lock=use_lock,
                        lock_timeout=lock_timeout,
                        until_ts=until_ts,
                        attempt=attempt,
                    )
                    break
                except Exception as e:
                    elapsed = time.time() - t0
                    if elapsed >= retry_timeout:
                        jlog(
                            "factory_reset_mute_console_fail",
                            mute_secs=mute_secs,
                            use_lock=use_lock,
                            lock_timeout=lock_timeout,
                            attempts=attempt,
                            retry_timeout=retry_timeout,
                            error=str(e),
                        )
                        break
                    jlog(
                        "factory_reset_mute_console_retry",
                        mute_secs=mute_secs,
                        use_lock=use_lock,
                        lock_timeout=lock_timeout,
                        attempt=attempt,
                        retry_in_sec=retry_interval,
                        elapsed_sec=round(elapsed, 3),
                        error=str(e),
                    )
                    time.sleep(retry_interval)

            if until_ts is None:
                sm = os.path.join(TOOLS_PATH or "/home/da40/charter/tools", "serial_mute.py")
                if os.path.exists(sm):
                    cmd = [sys.executable, sm, "--set", str(mute_secs)]
                    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                    jlog(
                        "factory_reset_mute_console_fallback",
                        cmd=cmd,
                        rc=p.returncode,
                        out=(p.stdout or "").strip(),
                        err=(p.stderr or "").strip(),
                    )

    settle = env_int("FR_SETTLE_WAIT_SEC", 120)
    if settle > 0:
        jlog("factory_reset_settle_wait", secs=settle)
        time.sleep(settle)


def check_http_redirect(http_url: str, timeout_sec: int = 5) -> Tuple[bool, Dict[str, str]]:
    cmd = [
        "curl",
        "-4",
        "-sSI",
        "-m",
        str(max(1, timeout_sec)),
        http_url,
    ]
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    out = (p.stdout or "")
    status = ""
    location = ""
    for line in out.splitlines():
        if not status and line.lower().startswith("http/"):
            status = line.strip()
        if line.lower().startswith("location:"):
            location = line.split(":", 1)[1].strip()

    ok = False
    code = None
    m = re.search(r"\s(\d{3})\s", status)
    if m:
        try:
            code = int(m.group(1))
        except Exception:
            code = None

    if code in (301, 302, 303, 307, 308):
        loc_abs = _normalize_location(http_url, location)
        if loc_abs.lower().startswith("https://"):
            ok = True

    info = {"status": status, "location": location, "location_abs": _normalize_location(http_url, location), "rc": str(p.returncode)}
    return ok, info



def _curl_effective_url(url: str, timeout_sec: int = 10) -> Tuple[bool, Dict[str, str]]:
    """Follow redirects and return the final effective URL.

    We use curl -L and -w %{url_effective}. For HTTPS with self-signed certs, -k is required.
    """
    cmd = [
        "curl",
        "-4",
        "-k",
        "-Ls",
        "-o",
        "/dev/null",
        "-m",
        str(max(1, timeout_sec)),
        "-w",
        "%{url_effective}",
        url,
    ]
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    eff = (p.stdout or "").strip()
    ok = (p.returncode == 0 and bool(eff))
    info = {
        "rc": str(p.returncode),
        "effective_url": eff,
        "stderr": (p.stderr or "").strip(),
    }
    return ok, info




def check_redirect_expected(http_url: str, expected_https: str) -> Tuple[bool, Dict[str, Any]]:
    """Check that http_url redirects to expected https URL.

    Behavior:
      - We always require the HTTP response is a redirect (30x) and its Location resolves to https://...
      - By default (REDIRECT_CHECK_FINAL=1), we additionally follow redirects and compare the *final* URL
        (curl %{url_effective}) to expected_https.

    Knobs:
      - REDIRECT_CHECK_FINAL: 1/0 (default 1)
      - REDIRECT_MATCH_MODE: strict | prefix | https_only (default strict)
      - ALLOW_RELATIVE_LOCATION: 1/0 (default 1)

    Backward compatible aliases:
      - REDIRECT_STRICT / REDIRECT_ALLOW_RELATIVE
    """

    ok_basic, info = check_http_redirect(http_url, timeout_sec=env_int("WAREHOUSE_TIMEOUT_SEC", 3) + 2)

    # Preferred knobs
    mode = (env_str("REDIRECT_MATCH_MODE", "").strip().lower() or "strict")
    allow_relative = env_bool("ALLOW_RELATIVE_LOCATION", True)

    # Backward compatible knobs
    if os.environ.get("ALLOW_RELATIVE_LOCATION") is None:
        allow_relative = env_bool("REDIRECT_ALLOW_RELATIVE", True)
    if os.environ.get("REDIRECT_MATCH_MODE") is None:
        strict_old = env_bool("REDIRECT_STRICT", True)
        mode = "strict" if strict_old else "https_only"

    loc = str(info.get("location") or "").strip()
    loc_abs = str(info.get("location_abs") or "").strip()

    # First-hop candidate (Location)
    cand_first = loc_abs if allow_relative else loc
    cand_first_l = cand_first.strip().lower().rstrip("/")

    exp_l = (expected_https or "").strip().lower().rstrip("/")

    ok = ok_basic
    reason = ""

    check_final = env_bool("REDIRECT_CHECK_FINAL", True)
    final_ok = True
    final_info: Dict[str, str] = {}
    final_url = ""

    if ok and check_final:
        # Follow redirects and compare final effective URL.
        final_ok, final_info = _curl_effective_url(
            http_url,
            timeout_sec=env_int("REDIRECT_FINAL_TIMEOUT_SEC", env_int("WAREHOUSE_TIMEOUT_SEC", 3) + 7),
        )
        final_url = (final_info.get("effective_url") or "").strip()
        cand_final_l = final_url.strip().lower().rstrip("/")

        if not final_ok:
            ok = False
            reason = "final_url_fetch_failed"
        else:
            if mode == "strict":
                if exp_l and cand_final_l != exp_l:
                    ok = False
                    reason = "final_url_mismatch"
            elif mode == "prefix":
                if exp_l and not cand_final_l.startswith(exp_l):
                    ok = False
                    reason = "final_url_prefix_mismatch"
            elif mode == "https_only":
                if not cand_final_l.startswith("https://"):
                    ok = False
                    reason = "final_url_not_https"
            else:
                # Unknown mode: be strict.
                if exp_l and cand_final_l != exp_l:
                    ok = False
                    reason = "final_url_mismatch_unknown_mode"

    else:
        # Compare only the first-hop Location.
        if ok and mode in ("strict", "prefix") and exp_l:
            if mode == "strict":
                if cand_first_l != exp_l:
                    ok = False
                    reason = "location_mismatch"
            else:
                if not cand_first_l.startswith(exp_l):
                    ok = False
                    reason = "location_prefix_mismatch"
        elif ok and mode == "https_only":
            # ok_basic already ensures https:// on Location
            pass
        elif ok and mode not in ("strict", "prefix", "https_only"):
            if exp_l and cand_first_l != exp_l:
                ok = False
                reason = "location_mismatch_unknown_mode"

    detail: Dict[str, Any] = {
        "http_url": http_url,
        "expected": expected_https,
        "match_mode": mode,
        "allow_relative": allow_relative,
        "basic_ok": ok_basic,
        "reason": reason,
        "check_final": check_final,
        "first_location": loc,
        "first_location_abs": loc_abs,
        "first_candidate": cand_first,
        "first_candidate_norm": cand_first_l,
        "final_ok": final_ok,
        "final_url": final_url,
        **info,
        **({"final_info": final_info} if final_info else {}),
    }
    return ok, detail


def fetch_warehouse(url: str, ip_mode: str = "4") -> Dict[str, str]:
    tool = env_str("WAREHOUSE_TOOL", "/home/da40/charter/tools/cpe_warehouse_info.py").strip()

    wid = env_str("WAREHOUSE_ID", "").strip() or env_str("WAREHOUSE_USER", "").strip()
    wpw = env_str("WAREHOUSE_PASSWORD", "").strip() or env_str("WAREHOUSE_PW", "").strip()
    if not wid or not wpw:
        raise RuntimeError("Missing warehouse credentials: set WAREHOUSE_ID + WAREHOUSE_PASSWORD")

    timeout = env_int("WAREHOUSE_TIMEOUT_SEC", 3)
    retries = env_int("WAREHOUSE_RETRIES", 10)
    sleep_s = env_int("WAREHOUSE_SLEEP_SEC", 3)

    cmd = [
        sys.executable,
        tool,
        url,
        "--user",
        wid,
        "--password",
        wpw,
        "--json",
        "--decode-base64",
        "--timeout",
        str(timeout),
        "--retries",
        str(retries),
        "--sleep",
        str(sleep_s),
        "--ipv",
        ip_mode,
    ]

    jlog("warehouse_fetch_cmd", cmd=cmd)
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if p.returncode != 0:
        raise RuntimeError(f"warehouse tool failed rc={p.returncode}: {(p.stderr or p.stdout or '').strip()}")

    txt = (p.stdout or "").strip()
    try:
        data = json.loads(txt)
    except Exception as e:
        raise RuntimeError(f"warehouse json parse failed: {e}; output_head={txt[:200]!r}")

    out: Dict[str, str] = {}
    for k, v in (data or {}).items():
        out[str(k)] = "" if v is None else str(v)

    return out


def validate_required_fields(table: Dict[str, str]) -> Tuple[bool, Dict[str, Any]]:
    required_raw = env_str("REQUIRED_FIELDS", "").strip()
    if not required_raw:
        return True, {"mode": "skip"}

    required = [x.strip() for x in required_raw.split(",") if x.strip()]

    alias_map = {
        "LAN IPv4 Address": ["IPv4 Address", "LAN IP Address", "LAN IP", "LAN Address", "LAN IPv4", "LAN IPv4 addr"],
        "WAN IPv4 Address": ["WAN IP Address", "WAN IP", "WAN IPv4", "WAN IPv4 addr"],
    }

    norm_map = {_norm_key(k): k for k in table.keys()}

    missing = []
    present = []
    for want in required:
        candidates = [want] + alias_map.get(want, [])
        got_key = None
        for cand in candidates:
            if cand in table:
                got_key = cand
                break
            nk = _norm_key(cand)
            if nk in norm_map:
                got_key = norm_map[nk]
                break

        if not got_key:
            missing.append(want)
            continue

        present.append({"want": want, "key": got_key, "value": table.get(got_key, "")})

    ok = len(missing) == 0
    details: Dict[str, Any] = {"missing": missing, "present": present}
    if not ok:
        keys = list(table.keys())
        details["available_keys_head"] = keys[:50]
        if len(keys) > 50:
            details["available_keys_more"] = len(keys) - 50
    return ok, details


def validate_sanity(table: Dict[str, str]) -> Tuple[bool, Dict[str, Any]]:
    details: Dict[str, Any] = {}

    bad_ipv4_fields = []
    for k, v in table.items():
        if "ipv4" in k.lower():
            if v and not _looks_ipv4(v):
                bad_ipv4_fields.append({"field": k, "value": v})
    details["bad_ipv4_fields"] = bad_ipv4_fields

    if env_bool("CHECK_DEFAULT_B64", True):
        b64_issues = []
        dssid = table.get("Default SSID", "")
        dpw = table.get("Default Password", "")
        dssid_dec = table.get("Default SSID (decoded)", "")
        dpw_dec = table.get("Default Password (decoded)", "")

        if dssid:
            if not _looks_base64(dssid) or not dssid_dec:
                b64_issues.append({"field": "Default SSID", "value": dssid, "decoded": dssid_dec})
        if dpw:
            if not _looks_base64(dpw) or not dpw_dec:
                b64_issues.append({"field": "Default Password", "value": dpw, "decoded": dpw_dec})

        details["default_b64_issues"] = b64_issues

    if env_bool("EXPECT_SAME_AS_DEFAULT", True):
        same_issues = []
        for fld in ("Current SSID", "Current Password"):
            v = (table.get(fld, "") or "").strip().lower()
            if v and "same" in v and "default" in v:
                continue
            if v:
                same_issues.append({"field": fld, "value": table.get(fld, "")})
        details["same_as_default_issues"] = same_issues

    ok = not details.get("bad_ipv4_fields") and not details.get("default_b64_issues") and not details.get("same_as_default_issues")
    return ok, details


def change_wifi(creds: NocCreds, token: str, location_id: str) -> None:
    if noc is None:
        raise RuntimeError("noc_api_cli import failed")

    ssid = env_str("NEW_WIFI_SSID", "").strip()
    pw = env_str("NEW_WIFI_PASSWORD", "").strip()
    if not ssid or not pw:
        raise RuntimeError("CHANGE_WIFI enabled but NEW_WIFI_SSID/NEW_WIFI_PASSWORD missing")

    jlog("wifi_update_start", ssid=ssid)
    noc.wifi_network_update(
        creds.base,
        env_str("CUSTOMER_ID"),
        location_id,
        token=token,
        bearer=creds.bearer,
        insecure=creds.insecure,
        ssid=ssid,
        encryption_key=pw,
    )
    jlog("wifi_update_sent")

    wait_s = env_int("WIFI_APPLY_WAIT_SEC", 60)
    if wait_s > 0:
        jlog("wifi_apply_wait", secs=wait_s)
        time.sleep(wait_s)


def validate_wifi_changed(before: Dict[str, str], after: Dict[str, str]) -> Tuple[bool, Dict[str, Any]]:
    details: Dict[str, Any] = {}

    b_cur_ssid = before.get("Current SSID", "")
    a_cur_ssid = after.get("Current SSID", "")
    b_cur_pw = before.get("Current Password", "")
    a_cur_pw = after.get("Current Password", "")

    issues = []
    if b_cur_ssid and ("same" in b_cur_ssid.lower() and "default" in b_cur_ssid.lower()):
        if a_cur_ssid and ("same" in a_cur_ssid.lower() and "default" in a_cur_ssid.lower()):
            issues.append({"field": "Current SSID", "before": b_cur_ssid, "after": a_cur_ssid})

    if b_cur_pw and ("same" in b_cur_pw.lower() and "default" in b_cur_pw.lower()):
        if a_cur_pw and ("same" in a_cur_pw.lower() and "default" in a_cur_pw.lower()):
            issues.append({"field": "Current Password", "before": b_cur_pw, "after": a_cur_pw})

    if a_cur_ssid and _looks_base64(a_cur_ssid):
        details["current_ssid_decoded"] = _b64_decode_safe(a_cur_ssid)
    if a_cur_pw and _looks_base64(a_cur_pw):
        details["current_password_decoded"] = _b64_decode_safe(a_cur_pw)

    details["issues"] = issues
    return len(issues) == 0, details


def _load_redirect_pairs() -> List[Tuple[str, str]]:
    """Load redirect pairs in order.

    Preferred:
      - WAREHOUSE_HTTP_URLS (csv)
      - WAREHOUSE_EXPECT_HTTPS_URLS (csv)

    Backward compatible:
      - WAREHOUSE_HTTP_URL
      - WAREHOUSE_HTTPS_URL
    """
    http_urls = _split_csv(env_str("WAREHOUSE_HTTP_URLS", ""))
    exp_urls = _split_csv(env_str("WAREHOUSE_EXPECT_HTTPS_URLS", ""))

    if http_urls and exp_urls:
        if len(http_urls) != len(exp_urls):
            raise RuntimeError("WAREHOUSE_HTTP_URLS and WAREHOUSE_EXPECT_HTTPS_URLS length mismatch")
        return list(zip(http_urls, exp_urls))

    http_url = env_str("WAREHOUSE_HTTP_URL", "").strip()
    https_url = env_str("WAREHOUSE_HTTPS_URL", "").strip()
    if http_url and https_url:
        return [(http_url, https_url)]

    raise RuntimeError("Missing warehouse URL(s): set WAREHOUSE_HTTP_URLS+WAREHOUSE_EXPECT_HTTPS_URLS or WAREHOUSE_HTTP_URL+WAREHOUSE_HTTPS_URL")


def _maybe_check_domain_resolution(pairs: List[Tuple[str, str]]) -> Tuple[bool, Dict[str, Any]]:
    if not env_bool("CHECK_DOMAIN_RESOLVE", True):
        return True, {"mode": "skip"}

    expected_ip = env_str("EXPECTED_LAN_IP", "192.168.1.1").strip()
    strict_ip = env_bool("DOMAIN_RESOLVE_STRICT", True)

    # Name resolution can lag after factory reset (DHCP/DNS/LLMNR/mDNS). Add retries.
    retries = env_int("DOMAIN_RESOLVE_RETRIES", env_int("WAREHOUSE_RETRIES", 10))
    sleep_s = env_int("DOMAIN_RESOLVE_SLEEP_SEC", env_int("WAREHOUSE_SLEEP_SEC", 3))

    def _getent_hosts_raw(h: str) -> List[str]:
        try:
            p = subprocess.run(["getent", "hosts", h], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            lines = [ln.strip() for ln in (p.stdout or "").splitlines() if ln.strip()]
            return lines[:5]
        except Exception:
            return []

    detail: Dict[str, Any] = {
        "expected_lan_ip": expected_ip,
        "strict": strict_ip,
        "retries": retries,
        "sleep_sec": sleep_s,
        "hosts": [],
    }
    all_ok = True

    for http_url, _exp in pairs:
        host = _url_host(http_url)
        last_addrs: List[str] = []
        addrs: List[str] = []
        raw_hosts: List[str] = []
        ok = False
        attempt_used = 0
        for attempt in range(1, max(1, retries) + 1):
            attempt_used = attempt
            addrs = resolve_host_ipv4(host)
            last_addrs = addrs
            ok = bool(addrs)
            if ok:
                break
            # If IPv4 not found, capture what getent hosts sees (often IPv6 link-local only)
            if attempt == 1:
                raw_hosts = _getent_hosts_raw(host)
            if attempt < retries:
                time.sleep(max(0, sleep_s))
        reason = ""
        if ok and strict_ip and expected_ip:
            if expected_ip not in addrs:
                ok = False
                reason = "ip_mismatch"
        if not ok and not reason:
            reason = "resolve_failed" if not last_addrs else "unknown"
        entry: Dict[str, Any] = {"host": host, "addrs": addrs, "ok": ok, "reason": reason, "attempt": attempt_used}
        if raw_hosts:
            entry["getent_hosts"] = raw_hosts
            # If getent hosts returned only IPv6 (fe80::/etc), this hints why some tools fail without -4.
            if all(not _looks_ipv4(ln.split()[0]) for ln in raw_hosts if ln.split()):
                entry["note"] = "getent_hosts_ipv6_only"
        detail["hosts"].append(entry)
        if not ok:
            all_ok = False

    return all_ok, detail


def run() -> int:
    try:
        creds = load_noc_creds()
        token = noc_login(creds)

        node_id = resolve_node_id()
        location_id = resolve_location_id(creds, token, node_id)

        if env_bool("DO_FACTORY_RESET", True):
            do_factory_reset(creds, token, location_id)

        # Optional: enable SSH via NOC after FR (FR may reset kvConfigs / access control).
        # This is required if you want to validate MAC addresses against `ifconfig -a`.
        ssh_enabled = maybe_enable_ssh_via_noc(creds, token, location_id, node_id)
        if ssh_enabled:
            wait_s = float(env_int("SSH_ENABLE_WAIT_SEC", 10))
            if wait_s > 0:
                jlog("ssh_enable_wait", secs=wait_s)
                time.sleep(wait_s)

        pairs = _load_redirect_pairs()
        jlog("redirect_pairs", count=len(pairs), pairs=pairs)

        ok_dns, dns_detail = _maybe_check_domain_resolution(pairs)
        jlog("domain_resolve_check", ok=ok_dns, detail=dns_detail)
        if not ok_dns:
            jlog("fail", reason="domain_resolve_failed")
            return 21

        if env_bool("CHECK_HTTP_REDIRECT", True):
            # Redirect readiness can lag after factory reset; add retries.
            redir_retries = env_int("REDIRECT_RETRIES", env_int("WAREHOUSE_RETRIES", 10))
            redir_sleep = env_int("REDIRECT_SLEEP_SEC", env_int("WAREHOUSE_SLEEP_SEC", 3))

            for http_url, expected_https in pairs:
                last_detail: Dict[str, Any] = {}
                ok = False
                for attempt in range(1, max(1, redir_retries) + 1):
                    ok, detail = check_redirect_expected(http_url, expected_https)
                    last_detail = dict(detail)
                    last_detail["attempt"] = attempt
                    last_detail["max_retries"] = redir_retries
                    jlog("http_redirect_check", ok=ok, detail=last_detail)
                    if ok:
                        break
                    if attempt < redir_retries:
                        time.sleep(max(0, redir_sleep))

                if not ok:
                    jlog("fail", reason="http_redirect_mismatch", http_url=http_url)
                    return 2

        # Choose the primary HTTPS URL used to fetch the table.
        primary_https = env_str("PRIMARY_WAREHOUSE_HTTPS_URL", "").strip() or (pairs[0][1] if pairs else "")
        if not primary_https:
            raise RuntimeError("PRIMARY_WAREHOUSE_HTTPS_URL not set and no redirect pairs")

        before = fetch_warehouse(primary_https, ip_mode="4")
        jlog("warehouse_fetch_ok", url=primary_https, keys=len(before))

        ok_macs, mac_detail = validate_macs_against_ifconfig(before)
        jlog("validate_macs_against_ifconfig", ok=ok_macs, detail=mac_detail)
        if not ok_macs:
            jlog("fail", reason="mac_validation_failed")
            return 7

        ok_req, req_detail = validate_required_fields(before)
        jlog("validate_required_fields", ok=ok_req, detail=req_detail)
        if not ok_req:
            jlog("fail", reason="missing_required_fields")
            return 3

        ok_sanity, sanity_detail = validate_sanity(before)
        jlog("validate_sanity", ok=ok_sanity, detail=sanity_detail)
        if not ok_sanity:
            jlog("fail", reason="sanity_check_failed")
            return 4

        # Optional change Wi‑Fi and validate again
        if env_bool("CHANGE_WIFI", True):
            change_wifi(creds, token, location_id)

            if env_bool("RECHECK_REDIRECT_AFTER_WIFI", True) and env_bool("CHECK_HTTP_REDIRECT", True):
                redir_retries = env_int("REDIRECT_RETRIES", env_int("WAREHOUSE_RETRIES", 10))
                redir_sleep = env_int("REDIRECT_SLEEP_SEC", env_int("WAREHOUSE_SLEEP_SEC", 3))

                for http_url, expected_https in pairs:
                    last_detail: Dict[str, Any] = {}
                    ok = False
                    for attempt in range(1, max(1, redir_retries) + 1):
                        ok, detail = check_redirect_expected(http_url, expected_https)
                        last_detail = dict(detail)
                        last_detail["attempt"] = attempt
                        last_detail["max_retries"] = redir_retries
                        jlog("http_redirect_check_after_wifi", ok=ok, detail=last_detail)
                        if ok:
                            break
                        if attempt < redir_retries:
                            time.sleep(max(0, redir_sleep))

                    if not ok:
                        jlog("fail", reason="http_redirect_mismatch_after_wifi", http_url=http_url)
                        return 22

            after = fetch_warehouse(primary_https, ip_mode="4")
            jlog("warehouse_fetch_after_wifi_ok", url=primary_https, keys=len(after))

            ok_req2, req_detail2 = validate_required_fields(after)
            jlog("validate_required_fields_after", ok=ok_req2, detail=req_detail2)
            if not ok_req2:
                jlog("fail", reason="missing_required_fields_after_wifi")
                return 5

            ok_changed, changed_detail = validate_wifi_changed(before, after)
            jlog("validate_wifi_changed", ok=ok_changed, detail=changed_detail)
            if not ok_changed:
                jlog("fail", reason="wifi_change_not_reflected")
                return 6

        jlog("pass")
        return 0

    except Exception as e:
        jlog("exception", error=str(e))
        return 1


if __name__ == "__main__":
    raise SystemExit(run())
