#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Generic cycle wrapper (stability/sanity style)
- Reads cycles/interval/stop flags from env
- Executes ORIGINAL_ENTRY (module.py:func) each cycle
- If target module defines precondition(), it is executed once at cycle #1
"""

import os
import time
import json
import importlib.util
import pathlib
import inspect
import traceback

def _env_int(*keys, default=0):
    for k in keys:
        v = os.environ.get(k)
        if v is not None and str(v).strip() != "":
            try:
                return int(str(v).strip())
            except Exception:
                pass
    return default

def _env_float(*keys, default=0.0):
    for k in keys:
        v = os.environ.get(k)
        if v is not None and str(v).strip() != "":
            try:
                return float(str(v).strip())
            except Exception:
                pass
    return default

def _resolve_entry(entry: str):
    """
    entry: "file.py:func" or "module:func"
    """
    if ":" not in entry:
        raise ValueError(f"Invalid entry: {entry}")
    mod_s, func_name = entry.split(":", 1)
    mod_s = mod_s.strip()
    func_name = func_name.strip()

    # If looks like a file, load from file path (relative to this script)
    base = pathlib.Path(__file__).resolve().parent
    if mod_s.endswith(".py"):
        path = (base / mod_s).resolve()
        spec = importlib.util.spec_from_file_location(path.stem, str(path))
        if spec is None or spec.loader is None:
            raise RuntimeError(f"Cannot load module from {path}")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)  # type: ignore[attr-defined]
    else:
        mod = __import__(mod_s, fromlist=["*"])
    func = getattr(mod, func_name, None)
    if not callable(func):
        raise RuntimeError(f"Entry function not found: {entry}")
    return mod, func

def _call(func, *args, **kwargs):
    """
    Call with best-effort signature compatibility.
    """
    try:
        sig = inspect.signature(func)
        if len(sig.parameters) == 0:
            return func()
        # Try common kw
        if "cycle" in sig.parameters and "total" in sig.parameters:
            return func(cycle=kwargs.get("cycle"), total=kwargs.get("total"))
        if "cycle_index" in sig.parameters and "cycle_total" in sig.parameters:
            return func(cycle_index=kwargs.get("cycle"), cycle_total=kwargs.get("total"))
        # Positional fallback
        return func(kwargs.get("cycle"), kwargs.get("total"))
    except TypeError:
        # Final fallback
        return func()

def run():
    # Prefer CYCLES (used by most scripts) and keep CYCLE_TOTAL as backward-compatible fallback.
    cycles = _env_int("CYCLES", "CYCLE_TOTAL", default=1)
    interval = _env_float("CYCLE_INTERVAL_SEC", "CYCLE_INTERVAL", default=60.0)
    stop_on_fail = _env_int("STOP_ON_FAIL", default=1)

    entry = os.environ.get("ORIGINAL_ENTRY", "main_impl.py:run")
    try:
        mod, func = _resolve_entry(entry)
    except Exception as e:
        print(json.dumps({"event": "entry_resolve_error", "entry": entry, "error": str(e)}), flush=True)
        traceback.print_exc()
        return 1

    # optional precondition
    precond = getattr(mod, "precondition", None)
    state = None

    overall_rc = 0
    for i in range(cycles):
        cycle_no = i + 1
        print(json.dumps({"event": "cycle_start", "cycle": cycle_no, "total": cycles}), flush=True)

        try:
            if cycle_no == 1 and callable(precond):
                print(json.dumps({"event": "precondition_start"}), flush=True)
                state = precond()
                print(json.dumps({"event": "precondition_end", "ok": True}), flush=True)

            rc = _call(func, cycle=cycle_no, total=cycles)  # may ignore args
            if isinstance(rc, dict):
                # allow {"rc": int, ...}
                rc = int(rc.get("rc", 0))
            else:
                rc = int(rc) if rc is not None else 0
        except SystemExit as se:
            try:
                rc = int(se.code)
            except Exception:
                rc = 0
        except BaseException as e:
            tb = traceback.format_exc()
            print(json.dumps({"event":"cycle_error","cycle":cycle_no,"error":str(e),"trace":tb.splitlines()[-8:]}, ensure_ascii=False), flush=True)
            rc = 1

        print(json.dumps({"event": "cycle_end", "cycle": cycle_no, "rc": rc}), flush=True)
        if rc != 0:
            overall_rc = rc
            if stop_on_fail:
                print(json.dumps({"event": "stop_on_fail", "cycle": cycle_no}), flush=True)
                break

        if cycle_no < cycles and interval > 0:
            print(json.dumps({"event": "cycle_sleep", "sec": interval}), flush=True)
            time.sleep(interval)

    return int(overall_rc)

if __name__ == "__main__":
    import sys
    sys.exit(run())
