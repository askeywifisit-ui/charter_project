# C15807946_Delete_DHCP_Reservation

## 1) 目的 / 覆蓋範圍
- 驗證 DHCP reservation 的新增/更新/刪除或 reset 後行為。

## 2) 前置條件 / 環境
- 需可透過平台/工具對 DHCP reservation API 操作。
- 注意：若目標 IP 已被占用，可能回 422（例如 used by Netgear）。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'70'
- TOOLS_PATH：/home/da40/charter/tools
- PING_IFACE：eno2
- PROFILES_FILE：/home/da40/charter/.secrets/noc_profiles.json
- NOC_PROFILE：SPECTRUM_INT
- CUSTOMER_ID：682d4e5179b80027cd6fb27e

## 5) PASS/FAIL 判定
- PASS：reservation 操作成功且驗證點符合預期。
- FAIL：422/衝突或驗證點不符（需看 log）。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807946_Delete_DHCP_Reservation

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'70'
- TOOLS_PATH：/home/da40/charter/tools

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807946_Delete_DHCP_Reservation

## Purpose
Delete a DHCP reservation (MAC → IPv4) and validate end-to-end:
- **precondition()** builds a baseline reservation (MAC → IP) (cycle #1 only)
- The test cycle deletes the baseline reservation via NOC API
- CPE runtime reflects the deletion (reserved table no longer contains the baseline MAC)
- Optional DHCP renew + ping to validate connectivity

## Topology
Control PC (this runner) ↔ LAN (wired) ↔ CPE router

## Key dependencies (external tools)
- `cpe_info` : readiness + node-id
- NOC DHCP reservation APIs: `noc_api_cli.py` (indirectly) and/or direct HTTP calls in `lib/dhcp_api.py`
- `cpe_ssh.py` : query DHCP tables from CPE over SSH
- `lan_macvlan.py` : create isolated LAN client, renew DHCP, report IPv4

## Precondition behavior (cycle #1 only)
1. Readiness check via `cpe_info -status` (poll until `CLOUD_READY_TIMEOUT_SEC`)
2. If not ready: set serial mute (`tools/serial_mute.py --set SERIAL_MUTE_SEC`) then PDU reset once (`PDU_SCRIPT reset`) then retry readiness
3. Resolve node-id via `cpe_info --node-id`
4. Ensure SSH is ready (scan port 22; if closed: NOC `ssh-enable`; then probe `uptime`)
5. Cleanup NOC DHCP reservations (default: clear **ALL** reservations in this lab location)
6. Create baseline reservation for `LAN_TEST_MAC` → `TEST_RESERVED_IP` (`TEST_HOSTNAME`)
7. Verify CPE reserved table contains the baseline entry, then renew LAN client and verify leased table matches

## Test cycle flow
1. Delete baseline reservation via NOC API (FAIL if HTTP error)
2. Verify NOC reservation list no longer contains the baseline MAC (poll)
3. Verify CPE reserved table no longer contains the baseline MAC (poll)
4. If `EXPECT_NO_*_RESERVATIONS_AFTER_DELETE=1`, also verify the reservation list becomes empty (poll)
5. If `LAN_RENEW_AFTER_DELETE=1`, run one DHCP renew + ping; log the obtained IP (does **not** strictly require IP to change)

## Notes
- Do not store secrets in the script zip. Provide NOC/CPE passwords via `PROFILES_FILE` or environment variables.
- For `lan_macvlan.py`, prefer `LAN_TEST_IFACE=auto` to avoid interface-name collisions.
```

```
