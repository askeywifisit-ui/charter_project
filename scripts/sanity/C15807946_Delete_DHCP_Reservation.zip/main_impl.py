#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""C15807946_Delete_DHCP_Reservation

Automation replaces UI steps with NOC DHCP reservation APIs and replaces
serial-console `ovsh s DHCP_*` checks with SSH DHCP dumps (`tools/cpe_ssh.py`).

User requirements baked into this script:
- Cleanup scope: default to "clear ALL" NOC DHCP reservations (lab location)
- In precondition(): build 1 baseline DHCP reservation (MAC → IPv4)
"""

import os
import secrets
import time
import re
from typing import Any, Dict, List, Optional, Tuple

from lib.util import jlog, run_cmd, parse_last_json, q
from lib.precondition import precondition as _cpe_precondition
from lib.dhcp_api import (
    dhcp_resv_set,
    dhcp_resv_del,
    dhcp_resv_del_best_effort,
    dhcp_resv_list,
    ensure_ip_not_reserved,
    dhcp_resv_clear_all_best_effort,
)
from lib.dhcp_verify import (
    assert_reserved,
    lan_renew_and_assert_ip,
    wait_for_lease,
    get_dhcp_tables,
)

_NODE_ID: Optional[str] = None


def gen_laa_mac() -> str:
    """Generate a locally-administered, unicast MAC (02:xx:xx:xx:xx:xx)."""
    b = bytearray(secrets.token_bytes(6))
    b[0] = 0x02
    return ":".join(f"{x:02x}" for x in b)


def ensure_test_mac() -> str:
    """Ensure a MAC is available for this run."""
    mac = (os.environ.get("LAN_TEST_MAC") or os.environ.get("TEST_MAC") or "").strip()
    if not mac:
        mac = gen_laa_mac()
        os.environ["LAN_TEST_MAC"] = mac
        os.environ["TEST_MAC"] = mac
    return mac


def _norm_mac(x: str) -> str:
    return (x or "").strip().lower()


def _used_ips_from_dhcp_tables(data: Dict[str, Any]) -> set:
    """Collect IPs in use from CPE DHCP reserved/leased tables."""
    reserved = data.get("reserved") or data.get("dhcp", {}).get("reserved") or []
    leased = data.get("leased") or data.get("dhcp", {}).get("leased") or []

    used = set()
    for r in reserved:
        ip = str(r.get("ip_addr") or r.get("ip") or "").strip()
        if ip:
            used.add(ip)
    for l in leased:
        ip = str(l.get("inet_addr") or l.get("ip_addr") or l.get("ip") or "").strip()
        if ip:
            used.add(ip)
    return used


def pick_free_ip(preferred_ip: str, used: set) -> str:
    """Pick a free IP in the same /24 by scanning upward, then wrapping."""
    preferred_ip = (preferred_ip or "").strip()
    if not preferred_ip or preferred_ip not in used:
        return preferred_ip

    parts = preferred_ip.split(".")
    if len(parts) != 4:
        return preferred_ip

    base = ".".join(parts[:3])
    try:
        start = int(parts[3])
    except Exception:
        return preferred_ip

    def cand(n: int) -> str:
        return f"{base}.{n}"

    for n in range(start + 1, 255):
        if n in (0, 1, 255):
            continue
        ip = cand(n)
        if ip not in used:
            return ip

    for n in range(2, max(2, start)):
        if n in (0, 1, 255):
            continue
        ip = cand(n)
        if ip not in used:
            return ip

    return preferred_ip

def _local_ipv4(iface: str) -> str:
    """Best-effort: return IPv4 address of a local interface (no CIDR)."""
    iface = (iface or "").strip()
    if not iface:
        return ""
    cmd = f"ip -4 -o addr show dev {q(iface)}"
    rc, out, err, sec = run_cmd(cmd, timeout=5)
    m = re.search(r"\binet\s+(\d+\.\d+\.\d+\.\d+)/", out or "")
    return m.group(1) if m else ""


def _is_ip_in_use_error(e: Exception) -> bool:
    s = str(e) or ""
    # Example: ... http=422 body={"error":{"message":"This IP address is currently used by chartertester."...}}
    return ("http=422" in s) and ("IP address is currently used" in s or "currently used by" in s)


def dhcp_resv_set_with_retry(node_id: str, mac: str, ip: str, host_name: str) -> str:
    """Set reservation, auto-picking a new IP if backend reports the IP is currently in use.

    Why: some backends reject PUT reservation when the target IP is leased to another client.
    We try the preferred IP first, then scan within the same /24 using pick_free_ip().
    """
    max_try = int(os.environ.get("IP_IN_USE_RETRY_MAX", "10") or "10")
    used: set = set()

    # Prefer CPE-used IPs if available (best-effort)
    try:
        data = get_dhcp_tables()
        used |= _used_ips_from_dhcp_tables(data or {})
    except Exception:
        pass

    # Also avoid the test runner's own IPv4 to prevent self-collision
    for k in ("LAN_PARENT_IFACE", "PING_IFACE"):
        lip = _local_ipv4(os.environ.get(k, ""))
        if lip:
            used.add(lip)

    tried = set()
    cur = (ip or "").strip()
    for attempt in range(1, max_try + 1):
        tried.add(cur)
        try:
            # ensure target IP isn't reserved by another MAC (best-effort)
            ensure_ip_not_reserved(node_id, cur, mac)
            dhcp_resv_set(node_id, mac, cur, host_name)
            return cur
        except Exception as e:
            if _is_ip_in_use_error(e):
                jlog("dhcp_resv_set_retry_ip_in_use", attempt=attempt, ip=cur, error=str(e)[:200])
                used.add(cur)
                nxt = pick_free_ip(cur, used)
                if not nxt or nxt == cur or nxt in tried:
                    # last-resort: walk upward in the same /24
                    parts = cur.split(".")
                    if len(parts) == 4 and parts[3].isdigit():
                        base = ".".join(parts[:3])
                        start = int(parts[3])
                        found = ""
                        for n in range(start + 1, 255):
                            cand = f"{base}.{n}"
                            if cand in used or cand in tried or n in (0, 1, 255):
                                continue
                            found = cand
                            break
                        nxt = found or nxt or cur
                cur = nxt
                os.environ["TEST_RESERVED_IP"] = cur
                continue
            raise
    raise RuntimeError(f"no_free_ip_found: preferred={ip} attempts={max_try} last={cur}")


def _extract_reservations_list(j: Any) -> List[Dict[str, Any]]:
    if j is None:
        return []
    if isinstance(j, list):
        return [x for x in j if isinstance(x, dict)]
    if isinstance(j, dict):
        for k in ("reservations", "items", "data"):
            v = j.get(k)
            if isinstance(v, list):
                return [x for x in v if isinstance(x, dict)]
    return []


def _noc_reservations(node_id: str) -> List[Dict[str, Any]]:
    j = dhcp_resv_list(node_id)
    return _extract_reservations_list(j)


def _noc_item_mac(it: Dict[str, Any]) -> str:
    return _norm_mac(str(it.get("mac") or it.get("id") or it.get("deviceMac") or ""))


def _cpe_reserved_list(dhcp_dump: Dict[str, Any]) -> List[Dict[str, Any]]:
    res = dhcp_dump.get("reserved") or dhcp_dump.get("dhcp", {}).get("reserved") or []
    if isinstance(res, list):
        return [x for x in res if isinstance(x, dict)]
    return []


def _cpe_reserved_has_mac(dhcp_dump: Dict[str, Any], mac: str) -> bool:
    mac_n = _norm_mac(mac)
    for r in _cpe_reserved_list(dhcp_dump):
        m = _norm_mac(str(r.get("hw_addr") or r.get("mac") or ""))
        if m == mac_n:
            return True
    return False


def _wait_until(event: str, fn, timeout_sec: float, interval_sec: float, **ctx) -> None:
    t0 = time.time()
    attempt = 0
    last_info: Any = None
    while time.time() - t0 < timeout_sec:
        attempt += 1
        try:
            ok, info = fn()
            last_info = info
            jlog(event, ok=ok, attempt=attempt, elapsed_sec=round(time.time() - t0, 2), **ctx, **(info or {}))
            if ok:
                return
        except Exception as e:
            last_info = {"error": str(e)}
            jlog(event, ok=False, attempt=attempt, elapsed_sec=round(time.time() - t0, 2), **ctx, error=str(e))
        time.sleep(max(0.2, interval_sec))

    raise RuntimeError(f"timeout_waiting_for_{event} last={last_info!r}")


def _lan_macvlan_cli() -> str:
    tools = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools").rstrip("/")
    return f"python3 {q(tools + '/lan_macvlan.py')}"


def lan_renew_and_ping(mac: str) -> str:
    """Renew DHCP for the simulated LAN client and optionally ping.

    Returns obtained IPv4.
    """
    parent = (os.environ.get("LAN_PARENT_IFACE") or "").strip()
    iface = (os.environ.get("LAN_TEST_IFACE") or "auto").strip()
    ping = (os.environ.get("LAN_PING_TARGET") or "").strip()
    timeout = float(os.environ.get("LAN_RENEW_TIMEOUT_SEC", "120"))

    base_cmd = f"{_lan_macvlan_cli()} --iface {q(iface)} --mac {q(mac)} --renew --json"
    cmd = base_cmd
    if parent:
        cmd = f"{_lan_macvlan_cli()} --parent {q(parent)} --iface {q(iface)} --mac {q(mac)} --renew --json"
    if ping:
        cmd += f" --ping {q(ping)}"

    rc, out, err, sec = run_cmd(cmd, timeout=timeout)
    obj = parse_last_json(out) or parse_last_json(err) or {}
    ipv4 = None
    try:
        ipv4 = (obj.get("dhcp") or {}).get("ipv4")
    except Exception:
        ipv4 = None

    ok_tool = True
    try:
        ok_tool = bool(obj.get("ok", True))
    except Exception:
        ok_tool = True

    ok = (rc == 0) and ok_tool and bool(ipv4)
    jlog(
        "lan_renew_after_delete",
        ok=ok,
        rc=rc,
        sec=sec,
        iface=(obj.get("iface") or iface),
        got_ip=ipv4,
        stderr_sample=(err.strip().splitlines()[-1] if err.strip() else ""),
    )
    if not ok:
        raise RuntimeError(f"lan_renew_after_delete_failed rc={rc} got_ip={ipv4} err={err.strip()[-200:]}")
    return str(ipv4)


def _build_baseline_reservation(node_id: str) -> Dict[str, Any]:
    """Build (or rebuild) baseline DHCP reservation.

    This is intentionally idempotent and safe to call every cycle, so multi-cycle runs
    can validate reliability (each cycle performs set→verify→delete→verify).
    """
    test_name = os.environ.get("TEST_NAME", "C15807946_Delete_DHCP_Reservation")
    mac = ensure_test_mac()
    ip = (os.environ.get("TEST_RESERVED_IP") or "").strip()
    hostname = (os.environ.get("TEST_HOSTNAME") or "").strip()

    if not mac or not ip or not hostname:
        raise RuntimeError("missing_env: require TEST_RESERVED_IP + TEST_HOSTNAME; LAN_TEST_MAC optional")

    jlog("baseline_start", test=test_name, mac=mac, ip=ip, hostname=hostname)

    # 0) Clear ALL cloud DHCP reservations in this location (best-effort)
    if int(os.environ.get("CLEAR_ALL_NOC_DHCP_RESERVATIONS", "0") or "0") == 1:
        prefix = (os.environ.get("CLEAR_ALL_NOC_DHCP_RESERVATIONS_HOSTNAME_PREFIX") or "").strip()
        dhcp_resv_clear_all_best_effort(node_id, hostname_prefix=prefix)

    # 0.1) If preferred IP is already in-use on CPE, pick a free one
    if int(os.environ.get("AUTO_PICK_FREE_IP", "0") or "0") == 1:
        try:
            data = get_dhcp_tables()
            used = _used_ips_from_dhcp_tables(data or {})
            new_ip = pick_free_ip(ip, used)
            if new_ip and new_ip != ip:
                jlog(
                    "ip_autopick",
                    preferred_ip=ip,
                    chosen_ip=new_ip,
                    reason="ip_in_use_on_cpe",
                    used_count=len(used),
                )
                ip = new_ip
                os.environ["TEST_RESERVED_IP"] = ip
        except Exception as e:
            jlog("ip_autopick_skip", error=str(e))

    # 1) cleanup best-effort (by this run's MAC)
    dhcp_resv_del_best_effort(node_id, mac)

    # 2) ensure target IP is not reserved by another MAC (best-effort)
    ensure_ip_not_reserved(node_id, ip, mac)

    # 3) add baseline reservation (auto-pick if backend says IP already in use)
    ip = dhcp_resv_set_with_retry(node_id, mac, ip, hostname)
    os.environ["TEST_RESERVED_IP"] = ip

    # 4) wait until CPE reserved table reflects the reservation (eventual consistency)
    wait_after_set = float(os.environ.get("WAIT_AFTER_RESERVATION_SET_SEC", "5") or "5")
    if wait_after_set > 0:
        jlog("wait_after_reservation_set", seconds=wait_after_set)
        time.sleep(wait_after_set)

    def _cpe_reserved_check() -> Tuple[bool, Dict[str, Any]]:
        d = get_dhcp_tables()
        reserved = _cpe_reserved_list(d or {})
        has_mac = _cpe_reserved_has_mac(d or {}, mac)
        # best-effort check of IP match if present in table
        ip_match = False
        mac_n = _norm_mac(mac)
        for r in reserved:
            m = _norm_mac(str(r.get("hw_addr") or r.get("mac") or ""))
            rip = str(r.get("ip_addr") or r.get("ip") or "").strip()
            if m == mac_n and rip == ip:
                ip_match = True
                break
        # If we can find MAC entry, consider it good enough; IP fields may vary by dump format.
        ok = bool(has_mac)
        return ok, {"cpe_reserved_count": len(reserved), "has_mac": has_mac, "ip_match": ip_match}

    sync_timeout = float(os.environ.get("RESERVATION_SYNC_TIMEOUT_SEC", "60") or "60")
    sync_interval = float(os.environ.get("RESERVATION_SYNC_INTERVAL_SEC", "3") or "3")
    _wait_until(
        "verify_cpe_reserved_present",
        _cpe_reserved_check,
        sync_timeout,
        sync_interval,
        mac=mac,
        ip=ip,
    )

    # 5) verify reservation exists on CPE (strict assertion)
    assert_reserved(mac, ip, hostname)

    # 5) renew LAN client and assert it gets reserved IP
    if int(os.environ.get("SKIP_LAN_RENEW", "0") or "0") != 1:
        lan_renew_and_assert_ip(mac, ip)
        # 6) verify leased table eventually reflects the client
        wait_for_lease(mac, ip)
    else:
        jlog("skip_lan_renew", reason="SKIP_LAN_RENEW=1")

    # expose baseline values for the cycle
    os.environ["BASELINE_RESERVED_IP"] = ip
    os.environ["BASELINE_MAC"] = mac

    jlog("baseline_end", ok=True, mac=mac, ip=ip, hostname=hostname)
    return {"node_id": node_id, "mac": mac, "ip": ip, "hostname": hostname}


def precondition() -> Dict[str, Any]:
    """Cycle #1 only: ensure CPE ready + SSH ready."""
    global _NODE_ID
    _NODE_ID = _cpe_precondition()
    return {"node_id": _NODE_ID}
def run(cycle=None, total=None) -> int:
    """One cycle execution."""
    global _NODE_ID

    test_name = os.environ.get("TEST_NAME", "C15807946_Delete_DHCP_Reservation")
    mac = ensure_test_mac()
    hostname = (os.environ.get("TEST_HOSTNAME") or "").strip()
    baseline_ip = (os.environ.get("BASELINE_RESERVED_IP") or os.environ.get("TEST_RESERVED_IP") or "").strip()

    if not _NODE_ID:
        _NODE_ID = _cpe_precondition()

    jlog("test_start", test=test_name, cycle=cycle, total=total, mac=mac, ip=baseline_ip, hostname=hostname)

    # Rebuild baseline reservation every cycle (set→verify) so multi-cycle runs are meaningful.
    _build_baseline_reservation(_NODE_ID)

    # Refresh baseline values (may be auto-picked)
    baseline_ip = (os.environ.get("BASELINE_RESERVED_IP") or os.environ.get("TEST_RESERVED_IP") or "").strip()


    if not mac or not baseline_ip or not hostname:
        raise RuntimeError("missing_env: require TEST_RESERVED_IP + TEST_HOSTNAME; LAN_TEST_MAC optional")

    # 1) delete reservation (must succeed)
    jlog("dhcp_resv_delete_start", mac=mac)
    dhcp_resv_del(_NODE_ID, mac)
    jlog("dhcp_resv_delete_end", ok=True, mac=mac)

    # 2) verify NOC reservation list no longer contains this MAC
    timeout = float(os.environ.get("DELETE_VERIFY_TIMEOUT_SEC", "60") or "60")
    interval = float(os.environ.get("DELETE_VERIFY_INTERVAL_SEC", "5") or "5")

    expect_noc_empty = int(os.environ.get("EXPECT_NO_NOC_RESERVATIONS_AFTER_DELETE", "0") or "0") == 1
    mac_n = _norm_mac(mac)

    def _noc_check() -> Tuple[bool, Dict[str, Any]]:
        items = _noc_reservations(_NODE_ID)
        has = any(_noc_item_mac(it) == mac_n for it in items)
        if has:
            return False, {"noc_count": len(items)}
        if expect_noc_empty:
            return (len(items) == 0), {"noc_count": len(items)}
        return True, {"noc_count": len(items)}

    _wait_until("verify_noc_reservation_absent", _noc_check, timeout, interval, mac=mac, expect_empty=expect_noc_empty)

    # 3) verify CPE reserved table no longer contains this MAC
    expect_cpe_empty = int(os.environ.get("EXPECT_NO_CPE_RESERVATIONS_AFTER_DELETE", "0") or "0") == 1

    def _cpe_check() -> Tuple[bool, Dict[str, Any]]:
        d = get_dhcp_tables()
        reserved = _cpe_reserved_list(d or {})
        has = _cpe_reserved_has_mac(d or {}, mac)
        if has:
            return False, {"cpe_reserved_count": len(reserved)}
        if expect_cpe_empty:
            return (len(reserved) == 0), {"cpe_reserved_count": len(reserved)}
        return True, {"cpe_reserved_count": len(reserved)}

    _wait_until("verify_cpe_reserved_absent", _cpe_check, timeout, interval, mac=mac, expect_empty=expect_cpe_empty)

    # 4) optional renew+ping after delete (does not strictly require IP change)
    if int(os.environ.get("LAN_RENEW_AFTER_DELETE", "0") or "0") == 1:
        attempts = int(os.environ.get("LAN_RENEW_AFTER_DELETE_ATTEMPTS", "2") or "2")
        got_ip: Optional[str] = None
        last_err: Optional[str] = None
        for i in range(1, max(1, attempts) + 1):
            try:
                got_ip = lan_renew_and_ping(mac)
                last_err = None
                break
            except Exception as e:
                last_err = str(e)
                jlog("lan_renew_after_delete_retry", attempt=i, attempts=attempts, error=str(e))
                time.sleep(2)
        if last_err and got_ip is None:
            raise RuntimeError(f"lan_renew_after_delete_failed: {last_err}")

        if got_ip == baseline_ip:
            jlog(
                "delete_got_same_ip",
                ok=True,
                note="DHCP may re-assign the same IP dynamically after reservation deletion; main check is reserved table removal",
                baseline_ip=baseline_ip,
                got_ip=got_ip,
            )
        else:
            jlog("delete_got_ip", ok=True, baseline_ip=baseline_ip, got_ip=got_ip)

    jlog("test_end", test=test_name, ok=True)
    return 0


if __name__ == "__main__":
    import sys

    sys.exit(run())