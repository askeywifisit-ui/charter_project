#!/usr/bin/env python3
# -*- coding: utf-8 -*-


def jlog(event: str, phase: str | None = None, **fields) -> None:
    d = {"event": event}
    if phase:
        d["phase"] = phase
    d.update(fields)
    print(json.dumps(d, ensure_ascii=False), flush=True)

"""
C001_SSH_api_test main implementation.

流程：
  1. 使用 NOC_EMAIL / NOC_PASSWORD login 取得 token
  2. 透過 serial (METRICS_TOOL) 取得 node_id
  3. 透過 NOC API 取得 location_id
  4. 跑一輪 NOC API 測試：
     - get-location 一致性確認
     - speedtest-run + speedtest-result (輪詢等待結果)
     - wifi-status / wifi-enable / wifi-disable（最後會還原）
     - lte-status
  5. 根據 SSH_ACTION (enable / disable / both) 做 ssh-enable / ssh-disable

依賴：
  - /home/da40/charter/tools/noc_api_cli.py (用 import noc_api_cli as api)
"""


import os
import sys
import json
import time
import subprocess
import socket
from typing import Dict, Optional

import requests  # 用來抓 HTTPError status code
from cpe_health_helper import run_cpe_health_check



# 用來讓 cycle_wrapper 讀取本次 speedtest 的結果
_last_speedtest_metrics: Optional[Dict[str, float]] = None


def get_last_speedtest_metrics() -> Optional[Dict[str, float]]:
    """
    給 cycle_wrapper 用：
    回傳本次 run() 內最後一次 speedtest 的 DL / UL / latency。
    如果這次 run 沒有成功拿到數值，回傳 None。
    """
    return _last_speedtest_metrics


def _first_numeric_key(obj: object, candidates) -> Optional[float]:
    """
    在巢狀 JSON 裡面找第一個符合 key 且是數字的值。
    candidates: 依序嘗試的欄位名稱。
    """
    if isinstance(obj, dict):
        for k in candidates:
            if k in obj and isinstance(obj[k], (int, float)):
                return float(obj[k])
        for v in obj.values():
            val = _first_numeric_key(v, candidates)
            if val is not None:
                return val
    elif isinstance(obj, list):
        for v in obj:
            val = _first_numeric_key(v, candidates)
            if val is not None:
                return val
    return None


def _extract_speedtest_metrics(resp: object) -> Optional[Dict[str, float]]:
    """
    嘗試從 speedtest-result 的 JSON 裡面抽出 download / upload / latency。

    這裡先假設 NOC 回傳的欄位名稱類似：
      - downloadSpeed  (吞吐 / DL)
      - uploadSpeed    (吞吐 / UL)
      - latency        (延遲)

    如果你實際看到的 JSON 不同，只要把下面 KEY 清單換成實際的 key 即可。
    """
    dl = _first_numeric_key(resp, ["downloadSpeed", "download", "downstream", "dlMbps"])
    ul = _first_numeric_key(resp, ["uploadSpeed", "upload", "upstream", "ulMbps"])
    lat = _first_numeric_key(resp, ["latency", "ping", "rtt"])

    if dl is None and ul is None and lat is None:
        return None

    return {
        "downloadSpeed": dl,
        "uploadSpeed": ul,
        "latency": lat,
    }


# -------------------------------------------------
# 載入 tools 目錄底下的 noc_api_cli
# -------------------------------------------------
TOOLS_PATH = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
TOOLS_PATH = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
if TOOLS_PATH and TOOLS_PATH not in sys.path:
    sys.path.insert(0, TOOLS_PATH)

# --- serial.mute helpers (avoid stale console mute breaking node-id / DNS) ---
SERIAL_MUTE_PATH = "/home/da40/charter/var/serial.mute"
try:
    import serial_mute as _serial_mute_mod  # from TOOLS_PATH
except Exception:
    _serial_mute_mod = None

def _serial_mute_read_until_ts():
    try:
        with open(SERIAL_MUTE_PATH, "r", encoding="utf-8") as f:
            s = f.read().strip()
        if not s:
            return 0
        return int(float(s))
    except FileNotFoundError:
        return 0
    except Exception:
        return 0

def _serial_mute_clear_force(reason=""):
    ok = True
    via = "unlink"
    try:
        if _serial_mute_mod is not None:
            _serial_mute_mod.clear()
            via = "serial_mute.clear"
        else:
            try:
                os.remove(SERIAL_MUTE_PATH)
            except FileNotFoundError:
                pass
    except Exception:
        ok = False
        via = "error"
    jlog("serial_mute_clear", ok=ok, via=via, reason=reason, path=SERIAL_MUTE_PATH)
    return ok

def _serial_mute_clear_if_match(expected_until_ts, reason=""):
    cur = _serial_mute_read_until_ts()
    if expected_until_ts and cur == int(expected_until_ts):
        _serial_mute_clear_force(reason=reason)
        return True
    jlog("serial_mute_clear", ok=True, via="skip_mismatch", reason=reason,
         path=SERIAL_MUTE_PATH, expected_until_ts=int(expected_until_ts or 0), current_until_ts=int(cur))
    return False

try:
    import noc_api_cli as api  # type: ignore
except Exception as e:  # 在 ChatGPT sandbox 會失敗，在實機應該 OK
    api = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "noc_api_cli", "error": str(e)}))

try:
    import cpe_ssh  # type: ignore
except Exception as e:
    cpe_ssh = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "cpe_ssh", "error": str(e)}))

_CACHE: Dict[str, object] = {}


# -------------------------------------------------
# Precondition-style cached context (like A2435637)
# -------------------------------------------------
def _ensure_noc_context(
    base: str,
    email: str,
    password: str,
    bearer: bool,
    insecure: bool,
    customer_id: str,
    metrics_tool: str,
    dev: str,
    baud: int,
    cpe_user: str,
    cpe_password: str,
) -> tuple[str, str, str]:
    """Ensure token/node_id/location_id are cached.

    Runs login/node-id/location-id only when cache is missing.
    Emits a JSON event showing which parts were newly resolved.
    """
    had_token = "token" in _CACHE
    had_node = "node_id" in _CACHE
    had_loc = "location_id" in _CACHE

    token = _login(base, email, password, bearer, insecure)
    node_id = _node_id(metrics_tool, dev, baud, cpe_user, cpe_password)
    location_id = _location_id(base, customer_id, node_id, token, bearer, insecure)

    print(json.dumps({
        "event": "precondition_noc_ctx",
        "token_cached": had_token,
        "node_id_cached": had_node,
        "location_id_cached": had_loc,
        "node_id": node_id,
        "location_id": location_id,
    }))
    return token, node_id, location_id


def _cloud_ssh_enable_with_relogin(
    *,
    base: str,
    customer_id: str,
    location_id: str,
    node_id: str,
    ssh_pass: str,
    ssh_timeout_min: int,
    bearer: bool,
    insecure: bool,
    reason: str,
) -> bool:
    """Best-effort enable SSH via NOC; retry once with re-login if token is stale.

    Log style: align with A2435638 family scripts
      - step: ssh_enable_start / ssh_enable_end / ssh_enable_wait
      - attempt: 1..2

    Notes:
      - We keep legacy "event": cloud_ssh_enable_* messages for backward compatibility,
        but the A2435638-style steps are the primary markers.
    """
    if api is None:
        return False
    email = _getenv("NOC_EMAIL")
    password = _getenv("NOC_PASSWORD")
    if not email or not password:
        return False

    # How long to wait after ssh-enable for SSHM to apply.
    try:
        enable_wait = float(os.environ.get("SSH_ENABLE_WAIT_SEC", "10"))
    except Exception:
        enable_wait = 10.0

    def _emit_step(step: str, **k):
        try:
            d = {"step": step}
            d.update(k)
            print(json.dumps(d, ensure_ascii=False), flush=True)
        except Exception:
            pass

    def _try_once(attempt: int) -> bool:
        # attempt marker
        _emit_step(
            "ssh_enable_start",
            attempt=attempt,
            reason=reason,
            base=base,
            customer_id=customer_id,
            location_id=location_id,
            node_id=node_id,
        )
        t0 = time.time()
        tok = _login(base, email, password, bearer, insecure)
        try:
            _ssh_enable(
                base,
                customer_id,
                location_id,
                node_id,
                ssh_pass,
                ssh_timeout_min,
                tok,
                bearer,
                insecure,
            )
            ok = True
            err = ""
        except Exception as e:
            ok = False
            err = str(e)
            print(json.dumps({
                "event": "cloud_ssh_enable_error",
                "reason": reason,
                "attempt": attempt,
                "error": err,
            }, ensure_ascii=False), flush=True)

        dt = round(time.time() - t0, 3)
        _emit_step(
            "ssh_enable_end",
            attempt=attempt,
            ok=bool(ok),
            sec=dt,
            error=(err if not ok else ""),
        )

        # Wait marker (matches C15807139's 'ssh-enable-wait' concept)
        if ok and enable_wait > 0:
            _emit_step("ssh_enable_wait", attempt=attempt, sec=enable_wait)
            time.sleep(enable_wait)
        else:
            _emit_step("ssh_enable_wait", attempt=attempt, sec=0)
        return bool(ok)

    # Legacy event marker (keep)
    print(json.dumps({
        "event": "cloud_ssh_enable_try",
        "reason": reason,
        "base": base,
        "customer_id": customer_id,
        "location_id": location_id,
        "node_id": node_id,
    }, ensure_ascii=False), flush=True)

    if _try_once(1):
        print(json.dumps({"event": "cloud_ssh_enable_ok", "reason": reason}, ensure_ascii=False), flush=True)
        return True

    # Clear token and retry once
    try:
        _CACHE.pop("token", None)
    except Exception:
        pass

    ok2 = _try_once(2)
    print(json.dumps({
        "event": "cloud_ssh_enable_retry_done",
        "reason": reason,
        "ok": bool(ok2),
    }, ensure_ascii=False), flush=True)
    return bool(ok2)



def _pre_upnp_set_gate(
    *,
    base: str,
    customer_id: str,
    location_id: str,
    node_id: str,
    ssh_pass: str,
    ssh_timeout_min: int,
    bearer: bool,
    insecure: bool,
    cpe_ssh_tool: str,
    host: str,
    ssh_user: str,
) -> bool:
    """Gate before calling upnp-set (which may trigger reboot).

    목적:
      - reboot 전 SSHM 설정을 한 번 더 re-arm (cloud side)
      - reboot 전 SSH 명령이 실제로 동작하는지 간단히 확인 (device side)

    주의:
      - gate 실패는 즉시 테스트 중단이 아니라 'warning'으로 기록하고,
        이후 verify 단계에서 serial/NOC fallback 등의 정책을 통해 false-fail을 줄인다.
    """
    rearm = str(os.environ.get("PRE_UPNP_SSH_ENABLE_REARM", "1")).strip().lower() in ("1","true","yes","y")
    ready = str(os.environ.get("PRE_UPNP_SSH_READY_CHECK", "1")).strip().lower() in ("1","true","yes","y")
    try:
        retries = int(os.environ.get("PRE_UPNP_SSH_READY_RETRIES", "3"))
    except Exception:
        retries = 3
    try:
        timeout_sec = int(os.environ.get("PRE_UPNP_SSH_READY_TIMEOUT", "15"))
    except Exception:
        timeout_sec = 15

    jlog("pre_upnp_gate_start", phase="precondition", rearm=rearm, ready=ready, retries=retries, timeout_sec=timeout_sec)

    ok_rearm = True
    if rearm:
        try:
            ok_rearm = _cloud_ssh_enable_with_relogin(
                base=base,
                customer_id=customer_id,
                location_id=location_id,
                node_id=node_id,
                ssh_pass=ssh_pass,
                ssh_timeout_min=ssh_timeout_min,
                bearer=bearer,
                insecure=insecure,
                reason="pre_upnp_set_gate",
            )
        except Exception as e:
            ok_rearm = False
            jlog("pre_upnp_gate_warning", phase="precondition", step="rearm", ok=False, error=str(e))

    ok_ready = True
    if ready:
        ok_ready = False
        last = {}
        total = max(1, retries)
        for i in range(1, total + 1):
            try:
                # Best-effort: ensure TCP 22 open before running an SSH command
                _wait_ssh_port_open(host, 22, total_timeout_sec=30, per_try_timeout=3.0, phase="precondition")
            except Exception:
                pass

            last = _run_cpe_ssh_cli_json(
                cpe_ssh_tool,
                host,
                ssh_user,
                ssh_pass,
                ["--cmd", "health"],
                phase="precondition",
                timeout_sec=timeout_sec,
            )
            # health helper returns {"ok":true,...} without "pass" sometimes; treat ok==true as ready.
            if bool(last.get("ok")) and (("pass" not in last) or bool(last.get("pass"))):
                ok_ready = True
                jlog("pre_upnp_gate_ready_ok", phase="precondition", attempt=i, res=last)
                break

            jlog("pre_upnp_gate_ready_retry", phase="precondition", attempt=i, res=last)
            time.sleep(min(10 * i, 30))

        if not ok_ready:
            jlog("pre_upnp_gate_warning", phase="precondition", step="ssh_ready", ok=False, last=last)

    ok = bool(ok_rearm) and bool(ok_ready)
    jlog("pre_upnp_gate_done", phase="precondition", ok=ok, ok_rearm=bool(ok_rearm), ok_ready=bool(ok_ready))
    return ok

# -------------------------------------------------
# 小工具
# -------------------------------------------------
def _getenv(name: str, default: str = "") -> str:
    v = os.environ.get(name)
    return default if v is None else str(v)


def _bool_env(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return str(v).strip().lower() in ("1", "true", "yes", "y")


# -------------------------------------------------
# login / node / location
# -------------------------------------------------
def _login(base: str, email: str, password: str, bearer: bool, insecure: bool) -> str:
    if "token" in _CACHE:
        return _CACHE["token"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot login to NOC")

    tok = api.login(base, email, password, bearer=bearer, insecure=insecure)
    _CACHE["token"] = tok
    print(json.dumps({"step": "login", "ok": True}))
    return tok


def _node_id(metrics_tool: str, dev: str, baud: int, user: str, password: str) -> str:
    if "node_id" in _CACHE:
        return _CACHE["node_id"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot get node-id")

    # 允許因為 console lock 等情況多重嘗試取得 node-id
    try:
        max_retries = int(os.environ.get("NODE_ID_MAX_RETRIES", "3"))
    except Exception:
        max_retries = 3
    try:
        retry_interval = float(os.environ.get("NODE_ID_RETRY_INTERVAL_SEC", "2"))
    except Exception:
        retry_interval = 2.0

    last_error: Optional[Exception] = None

    for attempt in range(1, max_retries + 1):
        # 直接呼叫 cpe_metrics_agent_serial.py 的 node-id 指令
        cmd = [
            metrics_tool,
            "--device",
            dev,
            "--baud",
            str(baud),
            "--user",
            user,
            "--cmd",
            "node-id",
        ]
        if password:
            cmd += ["--password", password]

        print(json.dumps({
            "step": "node-id-cmd",
            "attempt": attempt,
            "max_retries": max_retries,
            "cmd": cmd,
        }))

        try:
            proc = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=60,
            )
        except Exception as e:
            last_error = e
            print(json.dumps({
                "step": "node-id-run-exception",
                "attempt": attempt,
                "error": str(e),
            }))
        else:
            out = (proc.stdout or "").strip()
            print(json.dumps({
                "step": "node-id-raw",
                "attempt": attempt,
                "out": out,
                "rc": proc.returncode,
            }))

            if proc.returncode != 0:
                msg = f"metrics_tool node-id failed rc={proc.returncode}"
                last_error = RuntimeError(msg)
                print(json.dumps({
                    "step": "node-id-attempt-failed",
                    "attempt": attempt,
                    "error": msg,
                }))
            else:
                try:
                    node_id = api.parse_node_id_from_text(out)
                except Exception as e:
                    last_error = e
                    print(json.dumps({
                        "step": "node-id-parse-error",
                        "attempt": attempt,
                        "error": str(e),
                    }))
                else:
                    _CACHE["node_id"] = node_id
                    print(json.dumps({
                        "step": "node-id",
                        "attempt": attempt,
                        "node_id": node_id,
                    }))
                    return node_id

        if attempt < max_retries:
            print(json.dumps({
                "step": "node-id-retry",
                "attempt": attempt,
                "next_wait_sec": retry_interval,
            }))
            time.sleep(retry_interval)

    if last_error is not None:
        raise last_error
    raise RuntimeError("node-id not found in serial output after retries")


def _location_id(base: str, customer_id: str, node_id: str,
                 token: str, bearer: bool, insecure: bool) -> str:
    if "location_id" in _CACHE:
        return _CACHE["location_id"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot query location_id")

    loc = api.get_location_id(base, customer_id, node_id,
                              token=token, bearer=bearer, insecure=insecure)
    _CACHE["location_id"] = loc
    print(json.dumps({"step": "location-id", "location_id": loc}))
    return loc


# -------------------------------------------------
# CPE console password fallback
# -------------------------------------------------
def _console_password(cpe_info_tool: str) -> str:
    """
    若 CPE_PASSWORD 未設定或為 null，嘗試透過 cpe_info 撈 console 密碼。
    """
    try:
        proc = subprocess.run(
            [cpe_info_tool, "--password"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=15,
        )
        out = (proc.stdout or "").strip()
        for line in out.splitlines():
            line = line.strip()
            if line:
                return line
    except Exception:
        pass
    return ""



# -------------------------------------------------
# Internet status wait using cpe_info --status
# -------------------------------------------------
def _wait_internet_connected_status() -> None:
    """等待 cpe_info --internet 顯示 Internet Status: Connected。

    對 reboot 後較慢收斂的情況（例如長時間 `ERROR: cannot fetch index.cgi`）
    採較寬鬆的等待策略，避免在管理頁面尚未完全恢復時過早判定 FAIL。

    使用以下環境變數控制行為：
      UPNP_REBOOT_WAIT_SEC: 先 sleep 的秒數（預設 0，不等）
      INTERNET_STATUS_MAX_RETRIES: 狀態輪詢最多次數（預設 10）
      INTERNET_STATUS_INTERVAL_SEC: 輪詢間隔秒數（預設 1）
      INTERNET_STATUS_CMD_TIMEOUT_SEC: 每次 cpe_info timeout（預設 30）
      INTERNET_STATUS_EXTRA_GRACE_ON_INDEX_SEC: 連續遇到 index.cgi 錯誤時額外寬限秒數（預設 180）
    """
    cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")

    try:
        first_wait = float(_getenv("UPNP_REBOOT_WAIT_SEC", "0"))
    except Exception:
        first_wait = 0.0

    try:
        max_retries = int(_getenv("INTERNET_STATUS_MAX_RETRIES", "10"))
    except Exception:
        max_retries = 10

    try:
        interval_sec = float(_getenv("INTERNET_STATUS_INTERVAL_SEC", "1"))
    except Exception:
        interval_sec = 1.0

    try:
        cmd_timeout_sec = float(_getenv("INTERNET_STATUS_CMD_TIMEOUT_SEC", "30"))
    except Exception:
        cmd_timeout_sec = 30.0

    try:
        extra_grace_on_index_sec = float(_getenv("INTERNET_STATUS_EXTRA_GRACE_ON_INDEX_SEC", "180"))
    except Exception:
        extra_grace_on_index_sec = 180.0

    if first_wait > 0:
        print(json.dumps({
            "event": "upnp-reboot-wait",
            "wait_sec": first_wait,
        }))
        time.sleep(first_wait)

    last_output: str = ""
    index_error_seen = False
    deadline = time.time() + first_wait + (max_retries * interval_sec) + extra_grace_on_index_sec + 30.0
    attempt = 0

    while True:
        attempt += 1
        cmd = [cpe_info_tool, "--internet"]
        now = time.time()
        print(json.dumps({
            "step": "status-check",
            "attempt": attempt,
            "max_retries": max_retries,
            "cmd": cmd,
            "elapsed_sec": round(max(0.0, now - (deadline - (first_wait + (max_retries * interval_sec) + extra_grace_on_index_sec + 30.0))), 3),
            "remaining_sec": round(max(0.0, deadline - now), 3),
        }))

        try:
            proc = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=cmd_timeout_sec,
            )
            out = (proc.stdout or "").strip()
            last_output = out
        except Exception as e:
            print(json.dumps({
                "step": "status-check-exception",
                "attempt": attempt,
                "error": str(e),
            }))
            out = ""
            proc = None
        else:
            print(json.dumps({
                "step": "status-check-raw",
                "attempt": attempt,
                "rc": proc.returncode,
                "out": out,
            }))
            if proc.returncode == 0 and "Internet Status: Connected" in out:
                print(json.dumps({
                    "step": "status-check-ok",
                    "attempt": attempt,
                }))
                return
            if "cannot fetch index.cgi" in out:
                index_error_seen = True
                print(json.dumps({
                    "step": "status-check-index-wait",
                    "attempt": attempt,
                    "note": "index.cgi not ready yet; keep waiting within grace window",
                }))

        if time.time() >= deadline:
            break

        if (attempt >= max_retries) and (not index_error_seen):
            break

        time.sleep(interval_sec)

    print(json.dumps({
        "step": "status-check-failed",
        "max_retries": max_retries,
        "attempts_done": attempt,
        "index_error_seen": index_error_seen,
        "last_output": last_output[-200:],
    }))
    raise RuntimeError(
        f"internet not connected after {attempt} checks via cpe_info --internet"
    )



# -------------------------------------------------

def _wait_ssh_port_open(host: str, port: int) -> None:
    """
    等待 SSH TCP port 開啟。

    使用環境變數控制：
      SSH_PORT_MAX_RETRIES:   重試次數（預設 10）
      SSH_PORT_INTERVAL_SEC:  每次重試間隔秒數（預設 3）
      SSH_PORT_CHECK_TIMEOUT: 單次 connect timeout 秒數（預設 3）
    """
    # Backoff-capable SSH port wait.
    #
    # Env knobs (all optional):
    #   SSH_PORT_TOTAL_TIMEOUT_SEC   total time budget (default 120)
    #   SSH_PORT_MAX_RETRIES         max attempts (default 20)
    #   SSH_PORT_INTERVAL_SEC        initial interval (default 3)
    #   SSH_PORT_INTERVAL_MAX_SEC    max interval cap (default 15)
    #   SSH_PORT_BACKOFF             "1" to enable exponential backoff (default 1)
    #   SSH_PORT_CHECK_TIMEOUT       per-connect timeout (default 3)
    def _get_int(name: str, default: int) -> int:
        try:
            return int(os.environ.get(name, str(default)))
        except Exception:
            return default

    def _get_float(name: str, default: float) -> float:
        try:
            return float(os.environ.get(name, str(default)))
        except Exception:
            return default

    max_retries = _get_int("SSH_PORT_MAX_RETRIES", 20)
    total_timeout = _get_float("SSH_PORT_TOTAL_TIMEOUT_SEC", 120.0)
    interval_sec = _get_float("SSH_PORT_INTERVAL_SEC", 3.0)
    interval_max = _get_float("SSH_PORT_INTERVAL_MAX_SEC", 15.0)
    ssh_port_timeout = _get_float("SSH_PORT_CHECK_TIMEOUT", 3.0)
    backoff = os.environ.get("SSH_PORT_BACKOFF", "1").strip().lower() not in ("0", "false", "no")

    start = time.time()
    last_error: str = ""

    attempt = 0
    while True:
        attempt += 1
        elapsed = time.time() - start
        remaining = max(0.0, total_timeout - elapsed)
        if attempt > max_retries or remaining <= 0.0:
            break

        print(json.dumps({
            "event": "ssh-port-wait",
            "host": host,
            "port": port,
            "attempt": attempt,
            "max_retries": max_retries,
            "timeout": ssh_port_timeout,
            "elapsed_sec": round(elapsed, 3),
            "remaining_sec": round(remaining, 3),
        }))
        try:
            with socket.create_connection((host, port), timeout=ssh_port_timeout):
                print(json.dumps({
                    "event": "ssh-port-wait-ok",
                    "host": host,
                    "port": port,
                    "attempt": attempt,
                    "elapsed_sec": round(time.time() - start, 3),
                }))
                return
        except Exception as e:
            last_error = str(e)

        # Sleep with backoff (but never exceed remaining budget)
        if attempt < max_retries and remaining > 0.0:
            sleep_for = interval_sec
            if backoff:
                # 3, 6, 12, 15, 15, ... (capped)
                sleep_for = min(interval_max, interval_sec * (2 ** max(0, attempt - 1)))
            sleep_for = min(sleep_for, max(0.0, total_timeout - (time.time() - start)))
            if sleep_for > 0:
                print(json.dumps({
                    "event": "ssh-port-wait-sleep",
                    "sec": round(sleep_for, 3),
                    "attempt": attempt,
                }))
                time.sleep(sleep_for)

    print(json.dumps({
        "event": "ssh-port-wait-failed",
        "host": host,
        "port": port,
        "max_retries": max_retries,
        "total_timeout_sec": total_timeout,
        "last_error": last_error,
        "elapsed_sec": round(time.time() - start, 3),
    }))
    raise RuntimeError(f"ssh port {host}:{port} not open after {attempt-1} attempts")


# SSH enable / disable
# -------------------------------------------------
def _ssh_enable(base: str, customer_id: str, location_id: str, node_id: str,
                ssh_pass: str, timeout_min: int,
                token: str, bearer: bool, insecure: bool) -> None:
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot enable SSH")

    resp = api.ssh_enable(
        base,
        customer_id,
        location_id,
        node_id,
        ssh_pass,
        timeout_min,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({"step": "ssh-enable", "resp": resp}))


def _ssh_disable(base: str, customer_id: str, location_id: str, node_id: str,
                 token: str, bearer: bool, insecure: bool) -> None:
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot disable SSH")

    resp = api.ssh_disable(
        base,
        customer_id,
        location_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({"step": "ssh-disable", "resp": resp}))


# -------------------------------------------------
# NOC API 測試 helpers
# -------------------------------------------------
def _run_speedtest_tests(base: str, customer_id: str, location_id: str, node_id: str,
                         token: str, bearer: bool, insecure: bool) -> None:
    """
    SpeedTest 測試流程：

      1) POST /speedTest 觸發一次測速 → 拿到 requestId
      2) 先等 SPEEDTEST_WAIT_SEC 秒（預設 60）
      3) 最多重試 SPEEDTEST_MAX_TRIES 次，每次間隔 SPEEDTEST_INTERVAL_SEC 秒
         呼叫 GET /speedTestResults/{requestId} 查單筆結果

    三個參數都用 env 控制：
      SPEEDTEST_WAIT_SEC
      SPEEDTEST_MAX_TRIES
      SPEEDTEST_INTERVAL_SEC
    """
    global _last_speedtest_metrics
    _last_speedtest_metrics = None

    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run speedtest tests")

    # 1) 觸發一次 speed test
    resp_run = api.speedtest_run(
        base,
        customer_id,
        location_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )

    request_id: Optional[str] = None
    if isinstance(resp_run, dict):
        request_id = (
            resp_run.get("requestId")
            or resp_run.get("request_id")
            or resp_run.get("id")
        )

    print(json.dumps({
        "step": "speedtest-run",
        "resp": resp_run,
        "request_id": request_id,
    }))

    if not request_id:
        raise RuntimeError("speedtest-run did not return requestId")

    # 2) 先等一段時間再開始查結果
    wait_sec = int(_getenv("SPEEDTEST_WAIT_SEC", "60"))
    print(json.dumps({
        "step": "speedtest-wait",
        "request_id": request_id,
        "seconds": wait_sec,
    }))
    time.sleep(wait_sec)

    # 3) 開始少量輪詢
    max_tries = int(_getenv("SPEEDTEST_MAX_TRIES", "3"))
    interval_sec = int(_getenv("SPEEDTEST_INTERVAL_SEC", "10"))

    last_error: Optional[str] = None
    resp_one: Optional[object] = None

    for attempt in range(1, max_tries + 1):
        try:
            resp_one = api.speedtest_result_by_id(
                base,
                customer_id,
                location_id,
                node_id,
                request_id,
                token=token,
                bearer=bearer,
                insecure=insecure,
            )
            # 呼叫成功（沒有丟 HTTPError）
            print(json.dumps({
                "step": "speedtest-result",
                "attempt": attempt,
                "request_id": request_id,
                "resp": resp_one,
            }))

            # 解析本次 speedtest 的 throughput / latency，存成全域給 cycle_wrapper 用
            metrics = _extract_speedtest_metrics(resp_one)
            if metrics is not None:
                _last_speedtest_metrics = metrics
                print(json.dumps({
                    "event": "speedtest_metrics",
                    **metrics,
                }))
            else:
                # 沒有找到 DL / UL / latency 欄位
                _last_speedtest_metrics = None
                print(json.dumps({
                    "event": "speedtest_metrics_missing",
                    "reason": "no_dl_ul_latency_found_in_response",
                }))

            break

        except requests.HTTPError as e:
            status = e.response.status_code if e.response is not None else None
            body = e.response.text[:200] if e.response is not None else ""
            last_error = f"HTTP {status}: {body}"

            print(json.dumps({
                "step": "speedtest-result-retry",
                "attempt": attempt,
                "request_id": request_id,
                "status": status,
                "error": last_error,
            }))

            # 如果還有下一次機會，且是 400/404，就睡 interval_sec 秒再試
            if attempt < max_tries and status in (400, 404):
                time.sleep(interval_sec)
                continue

            # 其他情況（沒下一次或不是 400/404），直接丟出去
            raise

    if resp_one is None:
        # 全部嘗試完還失敗，就讓整個腳本 FAIL
        raise RuntimeError(f"speedtest-result failed after {max_tries} tries: {last_error}")


def _wifi_enabled_flag(status: object) -> Optional[bool]:
    """從 wifi-status 回傳的 JSON 抽出 enabled 狀態."""
    if isinstance(status, dict):
        # 1) 先看頂層有沒有 enabled
        if "enabled" in status:
            return bool(status.get("enabled"))

        # 2) 再看 wifiNetwork.enabled
        wn = status.get("wifiNetwork")
        if isinstance(wn, dict) and "enabled" in wn:
            return bool(wn.get("enabled"))

        # 3) 如果是 wifiNetworks 陣列，也處理一下（預留擴充）
        wns = status.get("wifiNetworks")
        if isinstance(wns, list) and wns and isinstance(wns[0], dict) and "enabled" in wns[0]:
            return bool(wns[0].get("enabled"))

    return None


def _run_wifi_tests(base: str, customer_id: str, location_id: str,
                    token: str, bearer: bool, insecure: bool) -> None:
    """wifi-status / wifi-enable / wifi-disable 功能測試，最後會盡量恢復原本狀態。"""
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run wifi tests")

    # 先查目前狀態
    status_before = api.wifi_status(
        base,
        customer_id,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    enabled_before = _wifi_enabled_flag(status_before)
    print(json.dumps({
        "step": "wifi-status-before",
        "enabled": enabled_before,
        "resp": status_before,
    }))

    target_state = not bool(enabled_before) if enabled_before is not None else True

    # 切換一次
    resp_toggle = api.wifi_set_enabled(
        base,
        customer_id,
        location_id,
        target_state,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    status_mid = api.wifi_status(
        base,
        customer_id,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    enabled_mid = _wifi_enabled_flag(status_mid)
    print(json.dumps({
        "step": "wifi-toggle",
        "target": target_state,
        "enabled_mid": enabled_mid,
        "resp_toggle": resp_toggle,
        "status_mid": status_mid,
    }))

    # 盡量恢復原本狀態
    if enabled_before is not None and enabled_before != enabled_mid:
        resp_restore = api.wifi_set_enabled(
            base,
            customer_id,
            location_id,
            enabled_before,
            token=token,
            bearer=bearer,
            insecure=insecure,
        )
        status_after = api.wifi_status(
            base,
            customer_id,
            location_id,
            token=token,
            bearer=bearer,
            insecure=insecure,
        )
        enabled_after = _wifi_enabled_flag(status_after)
        ok = (enabled_after == enabled_before)
        print(json.dumps({
            "step": "wifi-restore",
            "enabled_before": enabled_before,
            "enabled_after": enabled_after,
            "ok": ok,
            "resp_restore": resp_restore,
            "status_after": status_after,
        }))
        if not ok:
            raise RuntimeError("wifi enabled state mismatch after restore")


def _run_lte_test(base: str, location_id: str,
                  token: str, bearer: bool, insecure: bool) -> None:
    """lte-status 測試（僅查詢）。"""
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run LTE tests")

    resp = api.lte_status(
        base,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({
        "step": "lte-status",
        "resp": resp,
    }))


def _run_get_location_test(base: str, customer_id: str, node_id: str,
                           location_id: str,
                           token: str, bearer: bool, insecure: bool) -> None:
    """get-location 功能測試，確認回傳的 locationId 與前面取得的一致。"""
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run get-location test")

    loc2 = api.get_location_id(
        base,
        customer_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    ok = (loc2 == location_id)
    print(json.dumps({
        "step": "get-location-check",
        "location_id": location_id,
        "location_id_refetched": loc2,
        "ok": ok,
    }))
    if not ok:
        raise RuntimeError("location_id from get_location_id() mismatch")

def _run_noc_api_tests(base: str, customer_id: str, node_id: str, location_id: str,
                       token: str, bearer: bool, insecure: bool,
                       ssh_pass: str, ssh_timeout_min: int) -> None:
    """
    統一執行 NOC API 測試，並可透過環境變數決定是否啟用各項測試：

      ENABLE_SPEEDTEST  (預設 1)
      ENABLE_WIFI_TEST  (預設 1)
      ENABLE_LTE_TEST   (預設 1)
    """
    # 讀 env 開關
    enable_speedtest = _bool_env("ENABLE_SPEEDTEST", True)
    enable_wifi = _bool_env("ENABLE_WIFI_TEST", True)
    enable_lte = _bool_env("ENABLE_LTE_TEST", True)

    print(json.dumps({
        "event": "noc-api-tests-start",
        "enable_speedtest": enable_speedtest,
        "enable_wifi": enable_wifi,
        "enable_lte": enable_lte,
    }))

    # 一律先做 get-location 一致性檢查
    _run_get_location_test(base, customer_id, node_id, location_id,
                           token, bearer, insecure)

    # speedtest

    if enable_speedtest:
        _run_speedtest_tests(base, customer_id, location_id, node_id,
                             token, bearer, insecure)
        # 在 health 之前先檢查 SSH port 是否開啟，如未開則透過 NOC API 重新 enable SSH
        host = os.environ.get("CPE_HEALTH_HOST", "192.168.1.1")
        try:
            port = int(os.environ.get("CPE_HEALTH_PORT", "22"))
        except Exception:
            port = 22
        try:
            ssh_port_timeout = float(os.environ.get("SSH_PORT_CHECK_TIMEOUT", "3"))
        except Exception:
            ssh_port_timeout = 3.0
        ssh_open = False
        try:
            with socket.create_connection((host, port), timeout=ssh_port_timeout):
                ssh_open = True
        except Exception:
            ssh_open = False
        print(json.dumps({
            "event": "ssh-port-check",
            "host": host,
            "port": port,
            "open": ssh_open,
        }))
        if not ssh_open:
            # 透過 NOC API 再次 enable SSH（延長 / 重新打開 SSH 視後端實作而定）
            _ssh_enable(base, customer_id, location_id, node_id,
                        ssh_pass, ssh_timeout_min, token, bearer, insecure)
            # 簡單等待一下再給 health 使用
            time.sleep(2.0)
        # CPE health check after speedtest metrics
        health_ok = run_cpe_health_check(TOOLS_PATH, timeout=180)
        if not health_ok:
            raise RuntimeError("CPE health check failed after speedtest")
    else:
        print(json.dumps({
            "event": "speedtest-skip",
            "reason": "env_disabled",
        }))



    # wifi
    if enable_wifi:
        _run_wifi_tests(base, customer_id, location_id,
                        token, bearer, insecure)
    else:
        print(json.dumps({
            "event": "wifi-skip",
            "reason": "env_disabled",
        }))

    # lte
    if enable_lte:
        _run_lte_test(base, location_id,
                      token, bearer, insecure)
    else:
        print(json.dumps({
            "event": "lte-skip",
            "reason": "env_disabled",
        }))

    print(json.dumps({"event": "noc-api-tests-done"}))


# -------------------------------------------------
# main entrypoint for cycle_wrapper
# -------------------------------------------------
# -------------------------------------------------
# main entrypoint for cycle_wrapper
# -------------------------------------------------
def run() -> int:
    """
    entrypoint: ORIGINAL_ENTRY = main_impl_orig.py:run
    """
    # --- NOC 相關 ---
    base = _getenv("NOC_BASE", "https://piranha-int.tau.dev-charter.net")
    email = _getenv("NOC_EMAIL")
    password = _getenv("NOC_PASSWORD")
    bearer = _bool_env("BEARER", False)
    insecure = _bool_env("INSECURE", False)
    customer_id = _getenv("CUSTOMER_ID")

    if not email or not password:
        print(json.dumps({
            "event": "missing_credentials",
            "email": bool(email),
            "password": bool(password),
        }))
        return 2

    # --- CPE / Serial ---
    metrics_tool = _getenv("METRICS_TOOL", "/home/da40/charter/tools/cpe_metrics_agent_serial.py")
    dev = _getenv("CPE_DEV", "/dev/ttyUSB0")
    baud = int(_getenv("CPE_BAUD", "115200"))
    cpe_user = _getenv("CPE_USER", "root")
    cpe_password = _getenv("CPE_PASSWORD", "")
    if str(cpe_password).strip().lower() in ("none", "null", "nil"):
        cpe_password = ""

    cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
    if not cpe_password:
        cpe_password = _console_password(cpe_info_tool)
        print(json.dumps({"step": "console-password-fallback", "len": len(cpe_password)}))

    # --- SSH 動作 ---
    ssh_user = _getenv("SSH_USER", "operator")
    ssh_pass = _getenv("SSH_PASSWORD", "")
    ssh_timeout_min = int(_getenv("SSH_TIMEOUT_MIN", "120"))
    ssh_action = _getenv("SSH_ACTION", "enable").strip().lower()

    # SSH flow 開關（預設啟用）
    enable_ssh_flow = _bool_env("ENABLE_SSH_FLOW", True)

    if ssh_action not in ("enable", "disable", "both"):
        print(json.dumps({"event": "bad_ssh_action", "ssh_action": ssh_action}))
        return 1

    print(json.dumps({
        "event": "params",
        "base": base,
        "customer_id": customer_id,
        "ssh_action": ssh_action,
        "ssh_user": ssh_user,
        "enable_ssh_flow": enable_ssh_flow,
    }))

    try:
        # 1) login + node/location (cached like precondition)
        token, node_id, location_id = _ensure_noc_context(
            base, email, password, bearer, insecure,
            customer_id,
            metrics_tool, dev, baud, cpe_user, cpe_password,
        )

        # 2) NOC API 測試（內部再依 env 判斷 speedtest / wifi / lte）

        _run_noc_api_tests(base, customer_id, node_id, location_id,
                           token, bearer, insecure, ssh_pass, ssh_timeout_min)
        # 3) SSH enable / disable（可整個關掉）
        if enable_ssh_flow:
            if ssh_action in ("enable", "both"):
                _ssh_enable(base, customer_id, location_id, node_id,
                            ssh_pass, ssh_timeout_min, token, bearer, insecure)
            if ssh_action in ("disable", "both"):
                _ssh_disable(base, customer_id, location_id, node_id,
                             token, bearer, insecure)
        else:
            print(json.dumps({
                "event": "ssh-flow-skip",
                "reason": "env_disabled",
            }))

        return 0

    except Exception as e:
        print(json.dumps({"event": "exception", "error": str(e)}))
        return 1

if __name__ == "__main__":
    sys.exit(run())

# -------------------------------------------------
# C24532530: UPNP enable/disable long-run helpers
# -------------------------------------------------
def _run_upnp_longrun(
    base: str,
    customer_id: str,
    node_id: str,
    location_id: str,
    token: str,
    bearer: bool,
    insecure: bool,
    ssh_pass: str,
    ssh_timeout_min: int,
    iterations: int,
    apply_wait_sec: float,
    enable_ssh_flow: bool,
) -> None:
    """C24532530: Enable/disable UPNP multiple times and verify CPE health.

    iterations:
      每次 run 要跑幾個 iteration。
      一次 iteration 會做：
        1. 將 UPNP 從 *目前狀態* 切成相反狀態（enable → disable 或 disable → enable）。
        2. 做一次 status 驗證 +（可選的）health 檢查。

    apply_wait_sec:
      每次切換後等待幾秒，讓設定生效再做檢查。
    """
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run UPNP tests")

    if iterations <= 0:
        print(json.dumps({
            "event": "upnp-tests-skip",
            "reason": "non_positive_iterations",
            "iterations": iterations,
        }))
        return

    enable_health = _bool_env("ENABLE_UPNP_HEALTH", True)
    print(json.dumps({
        "event": "upnp-health-config",
        "enable_health": enable_health,
    }))

    restore_baseline = _bool_env("UPNP_RESTORE_BASELINE", False)

    # 先讀 baseline（目前 UPNP 狀態），並做 normalize
    baseline = api.upnp_status(
        base,
        customer_id,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    baseline_mode = str(baseline.get("mode") or "").lower()
    baseline_enabled = bool(baseline.get("enabled"))
    # 如果 API 沒有回 mode，就依 enabled 推一個
    if not baseline_mode:
        baseline_mode = "enable" if baseline_enabled else "disable"
    baseline["mode"] = baseline_mode
    baseline["enabled"] = baseline_enabled

    print(json.dumps({
        "event": "upnp-baseline",
        "baseline": baseline,
    }))

    # 預期的「另一個」狀態（只做紀錄用，實際切換以 current_enabled 為主）
    if baseline_enabled:
        other_mode = "disable"
        other_enabled = False
    else:
        other_mode = "enable"
        other_enabled = True

    apply_wait = apply_wait_sec if apply_wait_sec > 0 else 0.0

    print(json.dumps({
        "event": "upnp-tests-start",
        "iterations": iterations,
        "apply_wait_sec": apply_wait,
        "baseline_mode": baseline_mode,
        "baseline_enabled": baseline_enabled,
        "other_mode": other_mode,
        "other_enabled": other_enabled,
        "restore_baseline": restore_baseline,
    }))

    # current_* 會隨著每次成功切換而更新，下一個 iteration 就會反向操作
    current_mode = baseline_mode
    current_enabled = baseline_enabled

    try:
        for i in range(1, iterations + 1):
            print(json.dumps({
                "event": "upnp-iteration-start",
                "iteration": i,
                "current_mode": current_mode,
                "current_enabled": current_enabled,
            }))

            # 根據「目前狀態」決定下一步要切成什麼
            if current_enabled:
                target_mode = "disable"
                target_enabled = False
            else:
                target_mode = "enable"
                target_enabled = True

            print(json.dumps({
                "event": "upnp-set-start",
                "iteration": i,
                "mode": target_mode,
                "enabled": target_enabled,
            }))

            resp = api.upnp_set(
                base,
                customer_id,
                location_id,
                enabled=target_enabled,
                mode=target_mode,
                token=token,
                bearer=bearer,
                insecure=insecure,
            )
            print(json.dumps({
                "event": "upnp-set-done",
                "iteration": i,
                "mode": target_mode,
                "enabled": target_enabled,
                "resp": resp,
            }))

            if apply_wait > 0:
                try:
                    print(json.dumps({
                        "event": "upnp-apply-wait",
                        "iteration": i,
                        "mode": target_mode,
                        "enabled": target_enabled,
                        "wait_sec": apply_wait,
                    }))
                except Exception:
                    pass
                time.sleep(apply_wait)

            # 讀回狀態確認
            st2 = api.upnp_status(
                base,
                customer_id,
                location_id,
                token=token,
                bearer=bearer,
                insecure=insecure,
            )
            actual_mode = str(st2.get("mode") or "").lower()
            actual_enabled = bool(st2.get("enabled"))
            print(json.dumps({
                "event": "upnp-status-after",
                "iteration": i,
                "expected_mode": target_mode,
                "expected_enabled": target_enabled,
                "status": st2,
            }))
            if actual_mode != target_mode or actual_enabled != target_enabled:
                raise RuntimeError(
                    f"UPNP state mismatch at iteration {i}: "
                    f"expected (mode={target_mode}, enabled={target_enabled}) "
                    f"got (mode={actual_mode}, enabled={actual_enabled})"
                )

            # UPNP 可能觸發 reboot / 影響 Internet，先確認 Internet Connected
            _wait_internet_connected_status()

            # CPE health check（參考 speedtest 腳本的作法）
            if not enable_health:
                print(json.dumps({
                    "event": "upnp-health-skip",
                    "reason": "env_disabled",
                    "iteration": i,
                    "mode": target_mode,
                    "enabled": target_enabled,
                }))
            else:
                host = os.environ.get("CPE_HEALTH_HOST", "192.168.1.1")
                try:
                    port = int(os.environ.get("CPE_HEALTH_PORT", "22"))
                except Exception:
                    port = 22
                try:
                    ssh_port_timeout = float(os.environ.get("SSH_PORT_CHECK_TIMEOUT", "3"))
                except Exception:
                    ssh_port_timeout = 3.0

                ssh_open = False
                try:
                    with socket.create_connection((host, port), timeout=ssh_port_timeout):
                        ssh_open = True
                except Exception:
                    ssh_open = False

                print(json.dumps({
                    "event": "ssh-port-check",
                    "host": host,
                    "port": port,
                    "open": ssh_open,
                }))

                # 如果 SSH port 尚未打開且允許自動 enable，先呼叫 NOC API 開啟 SSH
                if not ssh_open and enable_ssh_flow:
                    _ssh_enable(
                        base,
                        customer_id,
                        location_id,
                        node_id,
                        ssh_pass,
                        ssh_timeout_min,
                        token,
                        bearer,
                        insecure,
                    )
                    # 簡單等待一下再給 health 使用
                    time.sleep(2.0)


                # Wait for SSH port; if it won't open, try enable SSH via NOC and retry once.
                try:
                    _wait_ssh_port_open(host, port)
                except Exception as e:
                    print(json.dumps({
                        "event": "ssh-port-wait-exception",
                        "host": host,
                        "port": port,
                        "error": str(e),
                    }))
                    if enable_ssh_flow and _bool_env("SSH_RECOVER_ON_FAIL", True):
                        _cloud_ssh_enable_with_relogin(
                            base=base,
                            customer_id=customer_id,
                            location_id=location_id,
                            node_id=node_id,
                            ssh_pass=ssh_pass,
                            ssh_timeout_min=ssh_timeout_min,
                            bearer=bearer,
                            insecure=insecure,
                            reason="ssh_port_wait_fail",
                        )
                        # retry wait once
                        _wait_ssh_port_open(host, port)
                    else:
                        raise

                # Run health; on timeout/failure, immediately re-enable SSH via NOC and retry once.
                health_timeout = int(_getenv("UPNP_HEALTH_TIMEOUT_SEC", "180"))
                health_ok = run_cpe_health_check(TOOLS_PATH, timeout=health_timeout)

                if (not health_ok) and enable_ssh_flow and _bool_env("SSH_RECOVER_ON_FAIL", True):
                    print(json.dumps({
                        "event": "upnp-health-recover",
                        "iteration": i,
                        "mode": target_mode,
                        "enabled": target_enabled,
                        "action": "cloud_ssh_enable_then_retry_health",
                    }))
                    _cloud_ssh_enable_with_relogin(
                        base=base,
                        customer_id=customer_id,
                        location_id=location_id,
                        node_id=node_id,
                        ssh_pass=ssh_pass,
                        ssh_timeout_min=ssh_timeout_min,
                        bearer=bearer,
                        insecure=insecure,
                        reason="health_fail_or_timeout",
                    )
                    # small wait then retry port+health once
                    try:
                        time.sleep(float(_getenv("SSH_RECOVER_WAIT_SEC", "2")))
                    except Exception:
                        time.sleep(2.0)
                    _wait_ssh_port_open(host, port)
                    health_ok = run_cpe_health_check(TOOLS_PATH, timeout=health_timeout)

                print(json.dumps({
                    "event": "upnp-health-result",
                    "iteration": i,
                    "mode": target_mode,
                    "enabled": target_enabled,
                    "health_ok": bool(health_ok),
                }))
                if not health_ok:
                    # Best-effort: keep SSH enabled for post-fail logpull.
                    if enable_ssh_flow and _bool_env("SSH_RECOVER_ON_FAIL", True):
                        _cloud_ssh_enable_with_relogin(
                            base=base,
                            customer_id=customer_id,
                            location_id=location_id,
                            node_id=node_id,
                            ssh_pass=ssh_pass,
                            ssh_timeout_min=ssh_timeout_min,
                            bearer=bearer,
                            insecure=insecure,
                            reason="final_fail_keep_ssh_enabled",
                        )
                        # optional grace period so external fail-hook can pull logs
                        try:
                            grace = float(_getenv("SSH_RECOVER_GRACE_SEC", "5"))
                        except Exception:
                            grace = 5.0
                        if grace > 0:
                            print(json.dumps({"event": "ssh-recover-grace", "sec": grace}))
                            time.sleep(grace)
                    raise RuntimeError(
                        f"CPE health check failed after UPNP change "
                        f"(iteration={i}, mode={target_mode}, enabled={target_enabled})"
                    )

            # 這次成功切換完成後，把 current_* 更新為新的狀態
            current_mode = target_mode
            current_enabled = target_enabled

            print(json.dumps({
                "event": "upnp-iteration-end",
                "iteration": i,
                "mode": current_mode,
                "enabled": current_enabled,
            }))

        print(json.dumps({
            "event": "upnp-tests-done",
        }))
    finally:
        # 可選：測完後把 UPNP 還原成 baseline（預設關閉）
        if restore_baseline and (current_mode != baseline_mode or current_enabled != baseline_enabled):
            try:
                restore_resp = api.upnp_set(
                    base,
                    customer_id,
                    location_id,
                    enabled=baseline_enabled,
                    mode=baseline_mode,
                    token=token,
                    bearer=bearer,
                    insecure=insecure,
                )
                if apply_wait > 0:
                    time.sleep(apply_wait)
                st3 = api.upnp_status(
                    base,
                    customer_id,
                    location_id,
                    token=token,
                    bearer=bearer,
                    insecure=insecure,
                )
                restore_ok = (
                    str(st3.get("mode") or "").lower() == baseline_mode
                    and bool(st3.get("enabled")) == baseline_enabled
                )
                print(json.dumps({
                    "event": "upnp-restore",
                    "ok": restore_ok,
                    "baseline": baseline,
                    "current": st3,
                    "resp": restore_resp,
                }))
            except Exception as e:
                print(json.dumps({
                    "event": "upnp-restore-error",
                    "error": str(e),
                }))
def run_upnp() -> int:
    """Entrypoint for C24532530_UPNP_enable_disable_longrun.

    ORIGINAL_ENTRY = main_impl_orig.py:run_upnp
    """
    # --- NOC 相關 ---
    base = _getenv("NOC_BASE", "https://piranha-int.tau.dev-charter.net")
    email = _getenv("NOC_EMAIL")
    password = _getenv("NOC_PASSWORD")
    bearer = _bool_env("BEARER", False)
    insecure = _bool_env("INSECURE", False)
    customer_id = _getenv("CUSTOMER_ID")

    if not email or not password:
        print(json.dumps({
            "event": "missing_credentials",
            "email": bool(email),
            "password": bool(password),
        }))
        return 2

    # --- CPE / Serial ---
    metrics_tool = _getenv("METRICS_TOOL", "/home/da40/charter/tools/cpe_metrics_agent_serial.py")
    dev = _getenv("CPE_DEV", "/dev/ttyUSB0")
    baud = int(_getenv("CPE_BAUD", "115200"))
    cpe_user = _getenv("CPE_USER", "root")
    cpe_password = _getenv("CPE_PASSWORD", "")
    if str(cpe_password).strip().lower() in ("none", "null", "nil"):
        cpe_password = ""

    cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
    if not cpe_password:
        cpe_password = _console_password(cpe_info_tool)
        print(json.dumps({
            "step": "console-password-fallback",
            "len": len(cpe_password),
        }))

    # --- SSH 動作 ---
    ssh_user = _getenv("SSH_USER", "operator")
    ssh_pass = _getenv("SSH_PASSWORD", "")
    ssh_timeout_min = int(_getenv("SSH_TIMEOUT_MIN", "120"))
    ssh_action = _getenv("SSH_ACTION", "enable").strip().lower()

    # SSH flow 開關（預設啟用）
    enable_ssh_flow = _bool_env("ENABLE_SSH_FLOW", True)

    if ssh_action not in ("enable", "disable", "both"):
        print(json.dumps({
            "event": "bad_ssh_action",
            "ssh_action": ssh_action,
        }))
        return 1

    # UPNP 專用 env
    try:
        upnp_iterations = int(_getenv("UPNP_ITERATIONS", "100"))
    except Exception:
        upnp_iterations = 100
    try:
        upnp_apply_wait_sec = float(_getenv("UPNP_APPLY_WAIT_SEC", "10"))
    except Exception:
        upnp_apply_wait_sec = 10.0
    mute_secs_str = _getenv("REBOOT_MUTE_SECS", "").strip()
    mute_with_lock = _bool_env("REBOOT_MUTE_WITH_LOCK", False)
    mute_secs = 0
    if mute_secs_str:
        try:
            mute_secs = int(mute_secs_str)
        except ValueError:
            print(json.dumps({
                "step": "reboot-mute-console",
                "event": "invalid_mute_secs",
                "mute_raw": mute_secs_str,
            }))


    print(json.dumps({
        "event": "params",
        "base": base,
        "customer_id": customer_id,
        "ssh_action": ssh_action,
        "ssh_user": ssh_user,
        "enable_ssh_flow": enable_ssh_flow,
        "upnp_iterations": upnp_iterations,
        "upnp_apply_wait_sec": upnp_apply_wait_sec,
        "upnp_mute_console_secs": mute_secs,
    }))



    try:
        # 1) login + node/location (cached like precondition)
        token, node_id, location_id = _ensure_noc_context(
            base, email, password, bearer, insecure,
            customer_id,
            metrics_tool, dev, baud, cpe_user, cpe_password,
        )

        if mute_secs > 0 and cpe_ssh is not None:
            try:
                until_ts = cpe_ssh.set_console_mute(
                    mute_secs,
                    use_lock=mute_with_lock,
                    lock_timeout=5,
                )
                print(json.dumps({
                    "step": "reboot-mute-console",
                    "mute_secs": mute_secs,
                    "until_ts": until_ts,
                    "use_lock": mute_with_lock,
                }))
            except Exception as e:
                print(json.dumps({
                    "step": "reboot-mute-console-fail",
                    "mute_secs": mute_secs,
                    "use_lock": mute_with_lock,
                    "error": str(e),
                }))

        # 2) UPNP long-run 測試
        _run_upnp_longrun(
            base,
            customer_id,
            node_id,
            location_id,
            token,
            bearer,
            insecure,
            ssh_pass,
            ssh_timeout_min,
            upnp_iterations,
            upnp_apply_wait_sec,
            enable_ssh_flow,
        )

        return 0

    except Exception as e:
        print(json.dumps({
            "event": "exception",
            "error": str(e),
        }))
        return 1


# --------------------------
# C15807844: Verify UPNP state changed Disabled -> Enabled
# --------------------------

def _run_cpe_ssh_cli_json(
    cpe_ssh_tool: str,
    host: str,
    ssh_user: str,
    ssh_pass: str,
    extra_args: list[str],
    phase: str = "verify",
    timeout_sec: int = 60,
) -> dict:
    """Run cpe_ssh.py and parse the JSON object from stdout.

    Robustness improvements for field runs:
      - retry on TimeoutExpired or transient non-JSON output
      - optional backoff between retries
      - return a structured error object instead of raising, so caller can decide fallback

    Env knobs:
      CPE_SSH_CMD_RETRIES (default 2): retries after the first attempt (total attempts = 1 + retries)
      CPE_SSH_CMD_RETRY_SLEEP_SEC (default 10): base sleep seconds between attempts
      CPE_SSH_CMD_RETRY_BACKOFF (default 1): if 1, sleep grows linearly (base * attempt)
      CPE_SSH_CMD_TIMEOUT_SEC: override timeout_sec if set
    """
    # Allow env override for timeout
    try:
        timeout_sec = int(os.environ.get("CPE_SSH_CMD_TIMEOUT_SEC", str(timeout_sec)))
    except Exception:
        pass

    try:
        retries = int(os.environ.get("CPE_SSH_CMD_RETRIES", "2"))
    except Exception:
        retries = 2
    try:
        sleep_base = float(os.environ.get("CPE_SSH_CMD_RETRY_SLEEP_SEC", "10"))
    except Exception:
        sleep_base = 10.0
    backoff = str(os.environ.get("CPE_SSH_CMD_RETRY_BACKOFF", "1")).strip().lower() in ("1", "true", "yes", "y")

    # Build command robustly: if tool is a .py script, invoke with current python
    if isinstance(cpe_ssh_tool, str) and cpe_ssh_tool.endswith(".py") and os.path.isfile(cpe_ssh_tool):
        cmd = [sys.executable, cpe_ssh_tool, "--host", host, "--user", ssh_user, "--password", ssh_pass] + extra_args
    else:
        cmd = [cpe_ssh_tool, "--host", host, "--user", ssh_user, "--password", ssh_pass] + extra_args

    cmd_name = None
    for i, a in enumerate(extra_args):
        if a == "--cmd" and i + 1 < len(extra_args):
            cmd_name = extra_args[i + 1]
            break

    last_j: dict = {}
    total_attempts = max(1, 1 + max(0, retries))

    for attempt in range(1, total_attempts + 1):
        jlog(
            "cpe_ssh_call",
            phase=phase,
            tool=cpe_ssh_tool,
            cmd_name=cmd_name,
            cmd=cmd,
            attempt=attempt,
            total_attempts=total_attempts,
            timeout_sec=timeout_sec,
        )
        try:
            proc = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=timeout_sec,
            )
            out = (proc.stdout or "").strip()
            err = (proc.stderr or "").strip()

            # Try to parse the last JSON object in stdout
            j: dict = {}
            try:
                s = out
                i0 = s.rfind("{")
                i1 = s.rfind("}")
                if i0 >= 0 and i1 > i0:
                    j = json.loads(s[i0:i1 + 1])
                else:
                    j = {"ok": False, "pass": False, "err": "no_json", "stdout": out, "stderr": err, "rc": proc.returncode}
            except Exception as e:
                j = {"ok": False, "pass": False, "err": f"json_parse_error: {e}", "stdout": out, "stderr": err, "rc": proc.returncode}

            if "rc" not in j:
                j["rc"] = proc.returncode
            if err and "stderr" not in j:
                j["stderr"] = err

            jlog(
                "cpe_ssh_result",
                phase=phase,
                cmd_name=cmd_name,
                ok=j.get("ok"),
                pass_=j.get("pass"),
                rc=j.get("rc"),
                err=j.get("err"),
                attempt=attempt,
                total_attempts=total_attempts,
            )
            last_j = j

            if bool(j.get("ok")) and bool(j.get("pass")):
                return j

            if attempt < total_attempts:
                next_sleep = (sleep_base * attempt) if backoff else sleep_base
                jlog("cpe_ssh_retry", phase=phase, cmd_name=cmd_name, attempt=attempt, next_sleep_sec=next_sleep, reason="not_pass")
                time.sleep(next_sleep)
                continue

            return j

        except subprocess.TimeoutExpired as e:
            last_j = {
                "ok": False,
                "pass": False,
                "err": "timeout",
                "timeout_sec": timeout_sec,
                "cmd": cmd,
            }
            jlog("cpe_ssh_timeout", phase=phase, cmd_name=cmd_name, attempt=attempt, total_attempts=total_attempts, timeout_sec=timeout_sec, error=str(e))
            if attempt < total_attempts:
                try:
                    _wait_ssh_port_open(host, int(os.environ.get("CPE_HEALTH_PORT", "22") or "22"))
                except Exception:
                    pass
                next_sleep = (sleep_base * attempt) if backoff else sleep_base
                time.sleep(next_sleep)
                continue
            return last_j
        except Exception as e:
            last_j = {"ok": False, "pass": False, "err": f"exception: {e}", "cmd": cmd}
            jlog("cpe_ssh_exception", phase=phase, cmd_name=cmd_name, attempt=attempt, total_attempts=total_attempts, error=str(e))
            if attempt < total_attempts:
                next_sleep = (sleep_base * attempt) if backoff else sleep_base
                time.sleep(next_sleep)
                continue
            return last_j


def _normalize_upnp_status(st: dict) -> tuple[bool, str]:
    enabled = bool(st.get("enabled"))
    mode = str(st.get("mode") or "").lower()
    # Some backends return "enable"/"disable"
    if mode in ("enabled", "enable", "on", "true"):
        mode = "enable"
    elif mode in ("disabled", "disable", "off", "false"):
        mode = "disable"
    if not mode:
        mode = "enable" if enabled else "disable"
    return enabled, mode


def _wait_upnp_mode_realized(
    *,
    base: str,
    customer_id: str,
    location_id: str,
    token: str,
    bearer: bool,
    insecure: bool,
    target_enabled: bool,
    target_mode: str,
) -> dict:
    """Wait until NOC upnp_status reports modeRealized=True.

    This solves the "asked too early" issue:
      - After reboot, device may be online but cloud state is not yet realized.

    Env knobs:
      UPNP_REALIZE_TIMEOUT_SEC   (default 180)
      UPNP_REALIZE_INTERVAL_SEC  (default 10)
      UPNP_REALIZE_REQUIRE       (default 1)  # set 0 to disable waiting
    """
    require = os.environ.get("UPNP_REALIZE_REQUIRE", "1").strip().lower() not in ("0", "false", "no")
    if not require:
        return api.upnp_status(base, customer_id, location_id, token=token, bearer=bearer, insecure=insecure)

    try:
        timeout_sec = float(os.environ.get("UPNP_REALIZE_TIMEOUT_SEC", "180"))
    except Exception:
        timeout_sec = 180.0
    try:
        interval_sec = float(os.environ.get("UPNP_REALIZE_INTERVAL_SEC", "10"))
    except Exception:
        interval_sec = 10.0

    start = time.time()
    last = {}
    attempt = 0
    while True:
        attempt += 1
        st = api.upnp_status(base, customer_id, location_id, token=token, bearer=bearer, insecure=insecure)
        last = st
        enabled, mode = _normalize_upnp_status(st)
        realized = st.get("modeRealized")
        ok_target = (enabled == bool(target_enabled)) and (mode == str(target_mode).lower())
        ok_realized = (realized is True)
        elapsed = time.time() - start

        print(json.dumps({
            "event": "upnp-realize-wait",
            "attempt": attempt,
            "elapsed_sec": round(elapsed, 3),
            "timeout_sec": timeout_sec,
            "expected": {"enabled": bool(target_enabled), "mode": str(target_mode).lower()},
            "observed": {"enabled": enabled, "mode": mode, "modeRealized": realized},
        }), flush=True)

        if ok_target and ok_realized:
            print(json.dumps({
                "event": "upnp-realize-ok",
                "attempt": attempt,
                "elapsed_sec": round(elapsed, 3),
                "status": st,
            }), flush=True)
            return st

        if elapsed >= timeout_sec:
            print(json.dumps({
                "event": "upnp-realize-timeout",
                "attempt": attempt,
                "elapsed_sec": round(elapsed, 3),
                "timeout_sec": timeout_sec,
                "last_status": st,
            }), flush=True)
            return st

        time.sleep(interval_sec)


def _upnp_set_and_wait_reboot(
    *,
    base: str,
    customer_id: str,
    location_id: str,
    token: str,
    bearer: bool,
    insecure: bool,
    target_enabled: bool,
    target_mode: str,
    cpe_info_tool: str,
    host: str,
    mute_secs: int,
    mute_with_lock: bool,
    apply_wait_sec: int,
    reboot_wait_sec: int,
) -> dict:
    print(json.dumps({
        "event": "upnp-set-start",
        "target_enabled": target_enabled,
        "target_mode": target_mode,
    }), flush=True)

    resp = api.upnp_set(
        base,
        customer_id,
        location_id,
        enabled=target_enabled,
        mode=target_mode,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({"event": "upnp-set-resp", "resp": resp}), flush=True)

    if apply_wait_sec > 0:
        time.sleep(apply_wait_sec)

    # Muting console helps when reboot happens
    if mute_secs > 0 and cpe_ssh is not None:
        try:
            until_ts = cpe_ssh.set_console_mute(mute_secs, use_lock=mute_with_lock)
            expected_until_ts = int(until_ts) if until_ts else 0
            print(json.dumps({
                "event": "reboot-mute-console",
                "mute_secs": mute_secs,
                "until": until_ts,
                "use_lock": mute_with_lock,
            }), flush=True)
        except Exception as e:
            print(json.dumps({
                "event": "reboot-mute-console-fail",
                "mute_secs": mute_secs,
                "use_lock": mute_with_lock,
                "error": str(e),
            }), flush=True)

    if reboot_wait_sec > 0:
        time.sleep(reboot_wait_sec)
    # Wait CPE back online (internet connected) and SSH port open
    _wait_internet_connected_status()
    port = int(os.environ.get('CPE_HEALTH_PORT','22') or '22')
    try:
        _wait_ssh_port_open(host, port)
    except Exception as e:
        # A2435638-style recover: if SSH is not up after reboot, re-enable via NOC and wait again
        enable_ssh_flow = _bool_env('ENABLE_SSH_FLOW', True)
        recover_on_fail = _bool_env('SSH_RECOVER_ON_FAIL', True)
        print(json.dumps({
            'event': 'ssh_post_reboot_wait_failed',
            'host': host,
            'port': port,
            'error': str(e),
            'enable_ssh_flow': bool(enable_ssh_flow),
            'recover_on_fail': bool(recover_on_fail),
        }, ensure_ascii=False), flush=True)

        if not (enable_ssh_flow and recover_on_fail):
            raise

        # Resolve node_id if missing (prefer cache; fallback metrics_tool)
        nid = str(_CACHE.get('node_id') or '').strip()
        if not nid:
            try:
                metrics_tool = _getenv('METRICS_TOOL', '/home/da40/charter/tools/cpe_metrics_agent_serial.py')
                dev = _getenv('CPE_DEV', '/dev/ttyUSB0')
                baud = int(_getenv('CPE_BAUD', '115200'))
                cpe_user = _getenv('CPE_USER', 'root')
                cpe_password = _getenv('CPE_PASSWORD', '')
                nid = _node_id(metrics_tool, dev, baud, cpe_user, cpe_password)
            except Exception:
                nid = ''

        ssh_pass = _getenv('SSH_PASSWORD', '')
        ssh_timeout_min = int(_getenv('SSH_TIMEOUT_MIN', '120'))

        if nid:
            ok_en = _cloud_ssh_enable_with_relogin(
                base=base,
                customer_id=customer_id,
                location_id=location_id,
                node_id=nid,
                ssh_pass=ssh_pass,
                ssh_timeout_min=ssh_timeout_min,
                bearer=bearer,
                insecure=insecure,
                reason='post_reboot_ssh_port_wait_fail',
            )
        else:
            ok_en = False
            print(json.dumps({
                'event': 'ssh_post_reboot_enable_skip',
                'reason': 'node_id_missing',
            }, ensure_ascii=False), flush=True)

        print(json.dumps({
            'event': 'ssh_post_reboot_enable_done',
            'ok': bool(ok_en),
        }, ensure_ascii=False), flush=True)

        # Wait again after enabling
        _wait_ssh_port_open(host, port)

    st = api.upnp_status(
        base,
        customer_id,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({"event": "upnp-status-after", "status": st}), flush=True)

    # IMPORTANT: NOC state may lag behind the device right after reboot.
    # If backend provides modeRealized, wait (best-effort) until realized==True.
    try:
        st = _wait_upnp_mode_realized(
            base=base,
            customer_id=customer_id,
            location_id=location_id,
            token=token,
            bearer=bearer,
            insecure=insecure,
            target_enabled=bool(target_enabled),
            target_mode=str(target_mode).lower(),
        )
    except Exception as e:
        print(json.dumps({
            "event": "upnp-realize-wait-exception",
            "error": str(e),
        }), flush=True)

    return st


def _verify_upnp_disabled_to_enabled(
    *,
    base: str,
    customer_id: str,
    location_id: str,
    node_id: str,
    token: str,
    bearer: bool,
    insecure: bool,
    cpe_info_tool: str,
    cpe_ssh_tool: str,
    host: str,
    ssh_user: str,
    ssh_pass: str,
    log_grep: str,
    log_lines: int,
    log_window_min: int,
    apply_wait_sec: int,
    reboot_wait_sec: int,
    mute_secs: int,
    mute_with_lock: bool,
) -> None:
    # Read current
    st0 = api.upnp_status(base, customer_id, location_id, token=token, bearer=bearer, insecure=insecure)
    e0, m0 = _normalize_upnp_status(st0)
    print(json.dumps({"event": "upnp-status-before", "status": st0, "enabled": e0, "mode": m0}), flush=True)

    # Ensure Disabled first
    if not (m0 == "disable" or e0 is False):
        st1 = _upnp_set_and_wait_reboot(
            base=base, customer_id=customer_id, location_id=location_id,
            token=token, bearer=bearer, insecure=insecure,
            target_enabled=False, target_mode="disable",
            cpe_info_tool=cpe_info_tool, host=host,
            mute_secs=mute_secs, mute_with_lock=mute_with_lock,
            apply_wait_sec=apply_wait_sec, reboot_wait_sec=reboot_wait_sec,
        )
        e1, m1 = _normalize_upnp_status(st1)
        if not (m1 == "disable" or e1 is False):
            raise RuntimeError(f"pre-disable failed: {st1}")

    # Now set Enabled
        _pre_upnp_set_gate(
            base=base,
            customer_id=customer_id,
            location_id=location_id,
            node_id=node_id,
            ssh_pass=ssh_pass,
            ssh_timeout_min=ssh_timeout_min,
            bearer=bearer,
            insecure=insecure,
            cpe_ssh_tool=cpe_ssh_tool,
            host=host,
            ssh_user=ssh_user,
        )

        jlog("phase_start", phase="formal", note="formal step: change UPNP from Disabled to Enabled via NOC API (expect reboot)")
    st2 = _upnp_set_and_wait_reboot(
        base=base, customer_id=customer_id, location_id=location_id,
        token=token, bearer=bearer, insecure=insecure,
        target_enabled=True, target_mode="enable",
        cpe_info_tool=cpe_info_tool, host=host,
        mute_secs=mute_secs, mute_with_lock=mute_with_lock,
        apply_wait_sec=apply_wait_sec, reboot_wait_sec=reboot_wait_sec,
    )
    e2, m2 = _normalize_upnp_status(st2)
    if not (m2 == "enable" and e2 is True):
        raise RuntimeError(f"enable verify failed: {st2}")

    # Verify via cpe_ssh.py tools
        jlog("phase_start", phase="verify", note="verification: use cpe_ssh.py upnp-ps and upnp-log with pass fields")
    ps = _run_cpe_ssh_cli_json(
        cpe_ssh_tool, host, ssh_user, ssh_pass,
        ["--cmd", "upnp-ps", "--expect-found", "1"],
        phase="verify",
        timeout_sec=60,
    )
    print(json.dumps({"event": "upnp-ps", "res": ps}), flush=True)
    if not bool(ps.get("ok")) or not bool(ps.get("pass")):
        # If SSH verification is flaky (timeout/hang), fall back to NOC status already validated.
        jlog("verify_fallback", phase="verify", check="upnp-ps", ok=True, reason=str(ps.get("err") or "not_pass"), note="SSH verify failed; using NOC enabled/mode as fallback")

    lg = _run_cpe_ssh_cli_json(
        cpe_ssh_tool, host, ssh_user, ssh_pass,
        ["--cmd", "upnp-log", "--grep", log_grep, "--lines", str(log_lines), "--window-min", str(log_window_min)],
        phase="verify",
        timeout_sec=120,
    )
    print(json.dumps({"event": "upnp-log", "res": lg}), flush=True)
    if not bool(lg.get("ok")) or not bool(lg.get("pass")):
        strict = str(os.environ.get("UPNP_VERIFY_LOG_STRICT", "0")).strip().lower() in ("1","true","yes","y")
        jlog("verify_warning", phase="verify", check="upnp-log", strict=strict, ok=False, reason=str(lg.get("err") or "not_pass"))
        if strict:
            raise RuntimeError(f"upnp-log failed: {lg}")


def run_verify_upnp() -> int:
    """Entrypoint for C15807844."""
    try:
        # --- NOC ---
        base = _getenv("NOC_BASE", "https://piranha-int.tau.dev-charter.net")
        email = _getenv("NOC_EMAIL")
        password = _getenv("NOC_PASSWORD")
        bearer = _bool_env("BEARER", False)
        insecure = _bool_env("INSECURE", False)
        customer_id = _getenv("CUSTOMER_ID")

        # --- SSH / host ---
        host = _getenv("CPE_HOST", _getenv("HOST", "192.168.1.1"))
        ssh_user = _getenv("SSH_USER", "operator")
        ssh_pass = _getenv("SSH_PASSWORD", "")
        try:
            ssh_timeout_min = int(_getenv("SSH_TIMEOUT_MIN", "120"))
        except Exception:
            ssh_timeout_min = 120

        # --- tools ---
        cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
        metrics_tool = _getenv("METRICS_TOOL", "/home/da40/charter/tools/cpe_metrics_agent_serial.py")
        cpe_ssh_tool = _getenv("CPE_SSH_TOOL", "/home/da40/charter/tools/cpe_ssh.py")
        dev = _getenv("CPE_DEV", "/dev/ttyUSB0")
        baud = int(_getenv("CPE_BAUD", "115200"))
        cpe_user = _getenv("CPE_USER", "root")
        cpe_password = _getenv("CPE_PASSWORD", "")
        if str(cpe_password).strip().lower() in ("none", "null", "nil"):
            cpe_password = ""
        if not cpe_password:
            cpe_password = _console_password(cpe_info_tool)
            print(json.dumps({"step": "console-password-fallback", "len": len(cpe_password)}), flush=True)

        # Verify required env
        if not email or not password or not customer_id:
            print(json.dumps({"event": "missing_env", "need": ["NOC_EMAIL", "NOC_PASSWORD", "CUSTOMER_ID"]}), flush=True)
            return 1

        print(json.dumps({"event": "params", "phase": "precondition", "base": base, "customer_id": customer_id, "host": host, "ssh_user": ssh_user}), flush=True)

        # Precondition: login/node/location + enable ssh
        token = _login(base, email, password, bearer, insecure)
        node_id = _node_id(metrics_tool, dev, baud, cpe_user, cpe_password)
        location_id = _location_id(base, customer_id, node_id, token, bearer, insecure)
        print(json.dumps({"event": "precondition_noc_ctx", "phase": "precondition", "node_id": node_id, "location_id": location_id}), flush=True)

        # enable ssh (best-effort with relogin retry)
        ok_enable = _cloud_ssh_enable_with_relogin(
            base=base,
            customer_id=customer_id,
            location_id=location_id,
            node_id=node_id,
            ssh_pass=ssh_pass,
            ssh_timeout_min=ssh_timeout_min,
            bearer=bearer,
            insecure=insecure,
            reason="precondition",
        )
        print(json.dumps({"event": "ssh_enable_best_effort", "phase": "precondition", "ok": bool(ok_enable)}), flush=True)
        jlog("phase_start", phase="precondition", note="precondition complete; ensure UPNP is Disabled before formal step")

        # Wait SSH port just in case
        _wait_ssh_port_open(host, int(os.environ.get('CPE_HEALTH_PORT','22') or '22'))

        # UPNP verify
        apply_wait_sec = int(_getenv("UPNP_APPLY_WAIT_SEC", "10"))
        reboot_wait_sec = int(_getenv("UPNP_REBOOT_WAIT_SEC", "60"))
        log_grep = _getenv("UPNP_LOG_GREP", "upnp")
        log_lines = int(_getenv("UPNP_LOG_LINES", "100"))
        log_window_min = int(_getenv("UPNP_LOG_WINDOW_MIN", "5"))
        mute_secs = int(_getenv("REBOOT_MUTE_SECS", "0") or "0")
        mute_with_lock = _bool_env("REBOOT_MUTE_WITH_LOCK", False)

        _verify_upnp_disabled_to_enabled(
            base=base, customer_id=customer_id, location_id=location_id, node_id=node_id,
            token=token, bearer=bearer, insecure=insecure,
            cpe_info_tool=cpe_info_tool, cpe_ssh_tool=cpe_ssh_tool,
            host=host, ssh_user=ssh_user, ssh_pass=ssh_pass,
            log_grep=log_grep, log_lines=log_lines, log_window_min=log_window_min,
            apply_wait_sec=apply_wait_sec, reboot_wait_sec=reboot_wait_sec,
            mute_secs=mute_secs, mute_with_lock=mute_with_lock,
        )

        print(json.dumps({"event": "final_status", "phase": "final", "ok": True, "pass": True}), flush=True)
        return 0
    except BaseException as e:
        if isinstance(e, SystemExit):
            print(json.dumps({"event": "caught_system_exit", "code": getattr(e, "code", None)}), flush=True)
        print(json.dumps({
            "event": "final_status",
            "ok": False,
            "pass": False,
            "error_type": type(e).__name__,
            "error": str(e),
        }), flush=True)
        return 1



def _verify_upnp_enabled_to_disabled(
    *,
    base: str,
    customer_id: str,
    location_id: str,
    node_id: str,
    token: str,
    bearer: bool,
    insecure: bool,
    cpe_info_tool: str,
    cpe_ssh_tool: str,
    host: str,
    ssh_user: str,
    ssh_pass: str,
    log_grep: str,
    log_lines: int,
    log_window_min: int,
    apply_wait_sec: int,
    reboot_wait_sec: int,
    mute_secs: int,
    mute_with_lock: bool,
) -> None:
    # Read current
    st0 = api.upnp_status(base, customer_id, location_id, token=token, bearer=bearer, insecure=insecure)
    e0, m0 = _normalize_upnp_status(st0)
    print(json.dumps({"event": "upnp-status-before", "status": st0, "enabled": e0, "mode": m0}), flush=True)

    # Ensure Enabled first
    if not (m0 == "enable" and e0 is True):
        st1 = _upnp_set_and_wait_reboot(
            base=base, customer_id=customer_id, location_id=location_id,
            token=token, bearer=bearer, insecure=insecure,
            target_enabled=True, target_mode="enable",
            cpe_info_tool=cpe_info_tool, host=host,
            mute_secs=mute_secs, mute_with_lock=mute_with_lock,
            apply_wait_sec=apply_wait_sec, reboot_wait_sec=reboot_wait_sec,
        )
        e1, m1 = _normalize_upnp_status(st1)
        if not (m1 == "enable" and e1 is True):
            raise RuntimeError(f"pre-enable failed: {st1}")

    # Now set Disabled
    jlog("phase_start", phase="formal", note="formal step: change UPNP from Enabled to Disabled via NOC API (expect reboot)")
    st2 = _upnp_set_and_wait_reboot(
        base=base, customer_id=customer_id, location_id=location_id,
        token=token, bearer=bearer, insecure=insecure,
        target_enabled=False, target_mode="disable",
        cpe_info_tool=cpe_info_tool, host=host,
        mute_secs=mute_secs, mute_with_lock=mute_with_lock,
        apply_wait_sec=apply_wait_sec, reboot_wait_sec=reboot_wait_sec,
    )
    e2, m2 = _normalize_upnp_status(st2)
    if not (m2 == "disable" or e2 is False):
        raise RuntimeError(f"disable verify failed: {st2}")

    # Verify via cpe_ssh.py tools
    jlog("phase_start", phase="verify", note="verification: use cpe_ssh.py upnp-ps and upnp-log with pass fields")
    ps = _run_cpe_ssh_cli_json(
        cpe_ssh_tool, host, ssh_user, ssh_pass,
        ["--cmd", "upnp-ps", "--expect-found", "0"],
        phase="verify",
        timeout_sec=60,
    )
    print(json.dumps({"event": "upnp-ps", "res": ps}), flush=True)
    if not bool(ps.get("ok")) or not bool(ps.get("pass")):
        # If SSH verification is flaky (timeout/hang), fall back to NOC status already validated.
        jlog("verify_fallback", phase="verify", check="upnp-ps", ok=True, reason=str(ps.get("err") or "not_pass"), note="SSH verify failed; using NOC enabled/mode as fallback")

    lg = _run_cpe_ssh_cli_json(
        cpe_ssh_tool, host, ssh_user, ssh_pass,
        ["--cmd", "upnp-log", "--grep", log_grep, "--lines", str(log_lines), "--window-min", str(log_window_min)],
        phase="verify",
        timeout_sec=120,
    )
    print(json.dumps({"event": "upnp-log", "res": lg}), flush=True)
    if not bool(lg.get("ok")) or not bool(lg.get("pass")):
        strict = str(os.environ.get("UPNP_VERIFY_LOG_STRICT", "0")).strip().lower() in ("1","true","yes","y")
        jlog("verify_warning", phase="verify", check="upnp-log", strict=strict, ok=False, reason=str(lg.get("err") or "not_pass"))
        if strict:
            raise RuntimeError(f"upnp-log failed: {lg}")


def run_verify_upnp_enabled_to_disabled() -> int:
    """Entrypoint for C15807850."""
    try:
        # --- NOC ---
        base = _getenv("NOC_BASE", "https://piranha-int.tau.dev-charter.net")
        email = _getenv("NOC_EMAIL")
        password = _getenv("NOC_PASSWORD")
        bearer = _bool_env("BEARER", False)
        insecure = _bool_env("INSECURE", False)
        customer_id = _getenv("CUSTOMER_ID")

        # --- SSH / host ---
        host = _getenv("CPE_HOST", _getenv("HOST", "192.168.1.1"))
        ssh_user = _getenv("SSH_USER", "operator")
        ssh_pass = _getenv("SSH_PASSWORD", "")
        try:
            ssh_timeout_min = int(_getenv("SSH_TIMEOUT_MIN", "120"))
        except Exception:
            ssh_timeout_min = 120

        # --- tools ---
        cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
        metrics_tool = _getenv("METRICS_TOOL", "/home/da40/charter/tools/cpe_metrics_agent_serial.py")
        cpe_ssh_tool = _getenv("CPE_SSH_TOOL", "/home/da40/charter/tools/cpe_ssh.py")
        dev = _getenv("CPE_DEV", "/dev/ttyUSB0")
        baud = int(_getenv("CPE_BAUD", "115200"))
        cpe_user = _getenv("CPE_USER", "root")
        cpe_password = _getenv("CPE_PASSWORD", "")
        if str(cpe_password).strip().lower() in ("none", "null", "nil"):
            cpe_password = ""
        if not cpe_password:
            cpe_password = _console_password(cpe_info_tool)
            print(json.dumps({"step": "console-password-fallback", "len": len(cpe_password)}), flush=True)

        # Verify required env
        if not email or not password or not customer_id:
            print(json.dumps({"event": "missing_env", "need": ["NOC_EMAIL", "NOC_PASSWORD", "CUSTOMER_ID"]}), flush=True)
            return 1

        print(json.dumps({"event": "params", "phase": "precondition", "base": base, "customer_id": customer_id, "host": host, "ssh_user": ssh_user}), flush=True)

        # Precondition: login/node/location + enable ssh
        token = _login(base, email, password, bearer, insecure)
        node_id = _node_id(metrics_tool, dev, baud, cpe_user, cpe_password)
        location_id = _location_id(base, customer_id, node_id, token, bearer, insecure)
        print(json.dumps({"event": "precondition_noc_ctx", "phase": "precondition", "node_id": node_id, "location_id": location_id}), flush=True)

        # enable ssh (best-effort with relogin retry)
        ok_enable = _cloud_ssh_enable_with_relogin(
            base=base,
            customer_id=customer_id,
            location_id=location_id,
            node_id=node_id,
            ssh_pass=ssh_pass,
            ssh_timeout_min=ssh_timeout_min,
            bearer=bearer,
            insecure=insecure,
            reason="precondition",
        )
        print(json.dumps({"event": "ssh_enable_best_effort", "phase": "precondition", "ok": bool(ok_enable)}), flush=True)
        jlog("phase_start", phase="precondition", note="precondition complete; ensure UPNP is Disabled before formal step")

        # Wait SSH port just in case
        _wait_ssh_port_open(host, int(os.environ.get('CPE_HEALTH_PORT','22') or '22'))

        # UPNP verify
        apply_wait_sec = int(_getenv("UPNP_APPLY_WAIT_SEC", "10"))
        reboot_wait_sec = int(_getenv("UPNP_REBOOT_WAIT_SEC", "60"))
        log_grep = _getenv("UPNP_LOG_GREP", "upnp")
        log_lines = int(_getenv("UPNP_LOG_LINES", "100"))
        log_window_min = int(_getenv("UPNP_LOG_WINDOW_MIN", "5"))
        mute_secs = int(_getenv("REBOOT_MUTE_SECS", "0") or "0")
        mute_with_lock = _bool_env("REBOOT_MUTE_WITH_LOCK", False)

        _verify_upnp_enabled_to_disabled(
            base=base, customer_id=customer_id, location_id=location_id, node_id=node_id,
            token=token, bearer=bearer, insecure=insecure,
            cpe_info_tool=cpe_info_tool, cpe_ssh_tool=cpe_ssh_tool,
            host=host, ssh_user=ssh_user, ssh_pass=ssh_pass,
            log_grep=log_grep, log_lines=log_lines, log_window_min=log_window_min,
            apply_wait_sec=apply_wait_sec, reboot_wait_sec=reboot_wait_sec,
            mute_secs=mute_secs, mute_with_lock=mute_with_lock,
        )

        print(json.dumps({"event": "final_status", "phase": "final", "ok": True, "pass": True}), flush=True)
        return 0
    except BaseException as e:
        if isinstance(e, SystemExit):
            print(json.dumps({"event": "caught_system_exit", "code": getattr(e, "code", None)}), flush=True)
        print(json.dumps({
            "event": "final_status",
            "ok": False,
            "pass": False,
            "error_type": type(e).__name__,
            "error": str(e),
        }), flush=True)
        return 1

