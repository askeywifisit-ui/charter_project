#!/usr/bin/env python3
"""Generic cycle wrapper.

Reads env:
  - CYCLES
  - CYCLE_INTERVAL
  - STOP_ON_FAIL
  - ORIGINAL_ENTRY (e.g. "main_impl_orig.py:run")

Calls the entry function once per cycle.

Extra (first cycle only): optional CPE-ready precondition
  - Run `cpe_info -status` and verify Internet/Cloud status
  - If not ready, retry a few times
  - Still not ready => PDU reset (python3 pdu_outlet1.py reset), wait, then re-check

Defaults can be overridden via env (manifest.yaml env block):
  - CPE_READY_CHECK (default: 1)
  - CPE_INFO_STATUS_CMD (default: "cpe_info -status")
  - CPE_READY_MAX_RETRIES (default: 5)
  - CPE_READY_RETRY_INTERVAL_SEC (default: 3)
  - CPE_READY_REQUIRE_CLOUD (default: 1)

  - PDU_RESET_ON_NOT_READY (default: 1)
  - PDU_RESET_SCRIPT (default: "/home/da40/charter/tools/pdu_outlet1.py")
  - PDU_RESET_ACTION (default: "reset")
  - PDU_RESET_WAIT_SEC (default: 120)
  - PDU_RESET_TIMEOUT_SEC (default: 600)
"""

import os
import time
import importlib
import sys
import json
import subprocess
import shlex


def _parse_bool(val, default: bool = False) -> bool:
    if val is None:
        return default
    s = str(val).strip().lower()
    return s in ("1", "true", "yes", "y", "on")


def _env_int(name: str, default: int) -> int:
    try:
        return int(str(os.environ.get(name, str(default))).strip())
    except Exception:
        return default


def _env_str(name: str, default: str) -> str:
    v = os.environ.get(name)
    if v is None or str(v).strip() == "":
        return default
    return str(v)


def _run_cmd_text(cmd: str, timeout: int) -> tuple[int, str, str]:
    """Run a shell-like command string (shlex.split) and return (rc, stdout, stderr)."""
    args = shlex.split(cmd)
    proc = subprocess.run(
        args,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=timeout,
    )
    return proc.returncode, (proc.stdout or ""), (proc.stderr or "")


def _parse_cpe_info_status(text: str) -> dict:
    """Parse `cpe_info -status` output into a dict."""
    internet = None
    cloud = None
    for raw_line in (text or "").splitlines():
        line = raw_line.strip()
        if not line:
            continue
        lower = line.lower()
        if lower.startswith("internet status"):
            # Internet Status: Connected
            parts = line.split(":", 1)
            if len(parts) == 2:
                internet = parts[1].strip()
        elif lower.startswith("cloud status"):
            parts = line.split(":", 1)
            if len(parts) == 2:
                cloud = parts[1].strip()
    return {"internet": internet, "cloud": cloud}


def _is_connected(val: str | None) -> bool:
    return bool(val) and str(val).strip().lower() == "connected"


def _check_cpe_ready_once() -> tuple[bool, dict]:
    cmd = _env_str("CPE_INFO_STATUS_CMD", "cpe_info -status")
    timeout = _env_int("CPE_INFO_STATUS_TIMEOUT_SEC", 30)
    require_cloud = _parse_bool(os.environ.get("CPE_READY_REQUIRE_CLOUD", "1"), default=True)

    try:
        rc, out, err = _run_cmd_text(cmd, timeout=timeout)
    except subprocess.TimeoutExpired:
        info = {"ok": False, "reason": "timeout", "cmd": cmd, "timeout": timeout}
        return False, info
    except Exception as e:
        info = {"ok": False, "reason": "exception", "cmd": cmd, "error": str(e)}
        return False, info

    parsed = _parse_cpe_info_status(out)
    internet_ok = _is_connected(parsed.get("internet"))
    cloud_ok = _is_connected(parsed.get("cloud")) if require_cloud else True

    ok = bool(internet_ok and cloud_ok)
    info = {
        "ok": ok,
        "cmd": cmd,
        "rc": rc,
        "internet": parsed.get("internet"),
        "cloud": parsed.get("cloud"),
        "require_cloud": require_cloud,
        "stdout_tail": (out or "").strip()[-300:],
        "stderr_tail": (err or "").strip()[-300:],
    }
    return ok, info


def _pdu_reset() -> bool:
    script = _env_str("PDU_RESET_SCRIPT", "/home/da40/charter/tools/pdu_outlet1.py")
    action = _env_str("PDU_RESET_ACTION", "reset")
    timeout = _env_int("PDU_RESET_TIMEOUT_SEC", 600)

    cmd = ["python3", script, action]
    print(json.dumps({"event": "pdu_reset_start", "cmd": " ".join(cmd), "timeout": timeout}))

    try:
        proc = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        print(json.dumps({"event": "pdu_reset_error", "error": "timeout", "timeout": timeout}))
        return False
    except Exception as e:
        print(json.dumps({"event": "pdu_reset_error", "error": str(e)}))
        return False

    out = (proc.stdout or "").strip()
    err = (proc.stderr or "").strip()
    print(
        json.dumps(
            {
                "event": "pdu_reset_done",
                "rc": proc.returncode,
                "stdout_tail": out[-400:],
                "stderr_tail": err[-400:],
            }
        )
    )
    return proc.returncode == 0


def ensure_cpe_ready_first_cycle() -> bool:
    if not _parse_bool(os.environ.get("CPE_READY_CHECK", "1"), default=True):
        print(json.dumps({"event": "cpe_ready_skip", "reason": "CPE_READY_CHECK=0"}))
        return True

    max_retries = _env_int("CPE_READY_MAX_RETRIES", 5)
    interval = _env_int("CPE_READY_RETRY_INTERVAL_SEC", 3)

    print(
        json.dumps(
            {
                "event": "cpe_ready_check_start",
                "max_retries": max_retries,
                "interval_sec": interval,
                "require_cloud": _parse_bool(os.environ.get("CPE_READY_REQUIRE_CLOUD", "1"), default=True),
            }
        )
    )

    last_info = None
    for attempt in range(1, max_retries + 1):
        ok, info = _check_cpe_ready_once()
        info.update({"event": "cpe_ready_check_attempt", "attempt": attempt, "max_retries": max_retries})
        print(json.dumps(info))
        last_info = info
        if ok:
            print(json.dumps({"event": "cpe_ready_check_ok", "attempt": attempt}))
            return True
        if attempt < max_retries and interval > 0:
            time.sleep(interval)

    # Not ready after retries
    if not _parse_bool(os.environ.get("PDU_RESET_ON_NOT_READY", "1"), default=True):
        print(json.dumps({"event": "cpe_not_ready_no_pdu_reset", "last": last_info}))
        return False

    # PDU reset and wait
    if not _pdu_reset():
        print(json.dumps({"event": "cpe_not_ready_pdu_reset_failed", "last": last_info}))
        return False

    wait_sec = _env_int("PDU_RESET_WAIT_SEC", 120)
    if wait_sec > 0:
        print(json.dumps({"event": "pdu_reset_wait", "wait_sec": wait_sec}))
        time.sleep(wait_sec)

    # Re-check after reset
    print(json.dumps({"event": "cpe_ready_recheck_after_pdu_reset"}))
    for attempt in range(1, max_retries + 1):
        ok, info = _check_cpe_ready_once()
        info.update({"event": "cpe_ready_recheck_attempt", "attempt": attempt, "max_retries": max_retries})
        print(json.dumps(info))
        if ok:
            print(json.dumps({"event": "cpe_ready_recheck_ok", "attempt": attempt}))
            return True
        if attempt < max_retries and interval > 0:
            time.sleep(interval)

    print(json.dumps({"event": "cpe_ready_recheck_failed"}))
    return False


def _resolve_entry(entry: str):
    if not entry:
        raise ValueError("Empty ORIGINAL_ENTRY")
    if ":" not in entry:
        raise ValueError(f"Bad ORIGINAL_ENTRY format: {entry!r}")
    mod_name, func_name = entry.split(":", 1)
    if mod_name.endswith(".py"):
        mod_name = mod_name[:-3]
    mod = importlib.import_module(mod_name)
    func = getattr(mod, func_name)
    return func


def run() -> int:
    cycles = int(os.environ.get("CYCLES", "1"))
    interval = int(os.environ.get("CYCLE_INTERVAL", "30"))
    stop_on_fail = _parse_bool(os.environ.get("STOP_ON_FAIL", "1"), default=True)
    entry = os.environ.get("ORIGINAL_ENTRY", "main_impl_orig.py:run")

    try:
        func = _resolve_entry(entry)
    except Exception as e:
        print(json.dumps({"event": "entry_resolve_error", "entry": entry, "error": str(e)}))
        return 1

    overall_rc = 0
    for i in range(cycles):
        print(json.dumps({"event": "cycle_start", "cycle": i + 1, "total": cycles}))

        if i == 0:
            if not ensure_cpe_ready_first_cycle():
                print(json.dumps({"event": "precondition_failed", "cycle": 1, "rc": 2}))
                return 2

        try:
            rc = func()
        except SystemExit as se:
            rc = int(se.code or 0)
        except Exception as e:
            print(json.dumps({"event": "cycle_exception", "cycle": i + 1, "error": str(e)}))
            rc = 1

        try:
            rc = int(rc)
        except Exception:
            rc = 1

        print(json.dumps({"event": "cycle_end", "cycle": i + 1, "rc": rc}))
        if rc != 0:
            overall_rc = rc
            if stop_on_fail:
                break

        if i < cycles - 1 and interval > 0:
            time.sleep(interval)

    print(json.dumps({"event": "all_cycles_done", "rc": overall_rc}))
    return overall_rc


if __name__ == "__main__":
    sys.exit(run())
