#!/usr/bin/env python3
"""cycle_wrapper

Generic cycle wrapper for C00000001.

Env:
  - CYCLES
  - CYCLE_INTERVAL
  - STOP_ON_FAIL
  - ORIGINAL_ENTRY (e.g. "main_impl_orig.py:run")

Precondition (first cycle only):
  - CPE_READY via `cpe_info -status` (+ optional single PDU reset + console mute)
  - SSH_ENABLE + SSH_READY via NOC + LAN SSH check
"""

import os
import time
import importlib
import sys
import json


def _parse_bool(val, default=False):
    if val is None:
        return default
    s = str(val).strip().lower()
    return s in ("1", "true", "yes", "on", "y")


def _resolve_entry(entry: str):
    if not entry:
        raise ValueError("Empty ORIGINAL_ENTRY")
    if ":" not in entry:
        raise ValueError(f"Bad ORIGINAL_ENTRY format: {entry!r}")
    mod_name, func_name = entry.split(":", 1)
    if mod_name.endswith(".py"):
        mod_name = mod_name[:-3]
    mod = importlib.import_module(mod_name)
    func = getattr(mod, func_name)
    return func


import socket
import subprocess
import shlex


# ================================================================
# Precondition: first-cycle CPE_READY + SSH_ENABLE/READY
# - CPE_READY: `cpe_info -status` (Internet+Cloud) retry N times
#              if still not ready => console mute + single PDU reset => wait => re-check
# - SSH: enable via NOC + check LAN TCP/22 + run a lightweight SSH command via tools/cpe_ssh.py
# ================================================================


# ---- console mute helpers (avoid serial/console lock during reboot/pdu cycles) ----
_MUTE_FILE = "/home/da40/charter/var/serial.mute"
_MUTE_LOCK_FILE = "/home/da40/charter/var/serial.mute.lock"


def _set_perms(path: str) -> None:
    try:
        os.chmod(path, 0o664)
    except Exception:
        pass


def _console_mute_fallback(secs: int, reason: str = "mute") -> dict:
    """Fallback mute: write /home/da40/charter/var/serial.mute as epoch seconds."""
    try:
        secs = int(secs)
    except Exception:
        secs = 0
    secs = max(0, secs)
    now = time.time()
    until = int(now + secs) if secs > 0 else 0

    try:
        os.makedirs(os.path.dirname(_MUTE_FILE), exist_ok=True)
        if until > 0:
            with open(_MUTE_FILE, "w") as f:
                f.write(str(until))
            _set_perms(_MUTE_FILE)
    except Exception as e:
        return {"ok": False, "mute_secs": secs, "until": until, "reason": reason, "error": str(e)}

    # Optional lock marker (some environments use it to block console readers)
    with_lock = _parse_bool(os.environ.get("REBOOT_MUTE_WITH_LOCK", "0"), default=False)
    if with_lock and until > 0:
        try:
            with open(_MUTE_LOCK_FILE, "w") as f:
                f.write(str(until))
            _set_perms(_MUTE_LOCK_FILE)
        except Exception:
            pass

    return {"ok": True, "mute_secs": secs, "until": until, "reason": reason, "with_lock": bool(with_lock)}


def _console_mute(secs: int, reason: str = "mute") -> dict:
    """Preferred mute: tools/serial_mute.py --set <secs> ; fallback to file-based mute."""
    tools_path = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
    tool = os.path.join(tools_path, "serial_mute.py")
    pybin = os.environ.get("PYTHON", "python3")
    if os.path.exists(tool):
        try:
            cp = subprocess.run([pybin, tool, "--set", str(int(secs))], capture_output=True, text=True, timeout=20)
            ok = (cp.returncode == 0)
            return {
                "ok": ok,
                "mute_secs": int(secs),
                "reason": reason,
                "method": "serial_mute.py",
                "rc": cp.returncode,
                "out": (cp.stdout or "")[-2000:],
                "err": (cp.stderr or "")[-2000:],
            }
        except Exception as e:
            # fall through
            return {**_console_mute_fallback(secs, reason=reason), "method": "file", "warn": str(e)}
    return {**_console_mute_fallback(secs, reason=reason), "method": "file"}


def _cpe_ready_run_cmd(cmd, timeout=30):
    # Run command and return (rc, combined_output).
    try:
        cp = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=timeout,
        )
        return cp.returncode, (cp.stdout or "")
    except Exception as e:
        return 99, f"ERROR: cmd failed: {cmd!r} ({e})"


def _cpe_ready_parse_status(output: str):
    internet = None
    cloud = None
    for line in (output or "").splitlines():
        if ":" not in line:
            continue
        k, v = line.split(":", 1)
        k = k.strip().lower()
        v = v.strip()
        if k == "internet status":
            internet = v
        elif k == "cloud status":
            cloud = v
    return internet, cloud


def _cpe_ready_is_connected(val: str) -> bool:
    return val is not None and val.strip().lower() == "connected"


def _probe_cpe_ready(phase: str) -> bool:
    """Probe CPE readiness by parsing `cpe_info -status`.

    Logs:
      {"step":"cpe-ready-probe","attempt":..,"internet":..,"cloud":..,"ready":..,"phase":..}
    """
    status_cmd = os.environ.get("CPE_INFO_STATUS_CMD", "cpe_info -status")
    retries = int(os.environ.get("CPE_READY_MAX_RETRIES", "10"))
    interval = float(os.environ.get("CPE_READY_RETRY_INTERVAL_SEC", "3"))
    require_cloud = _parse_bool(os.environ.get("CPE_READY_REQUIRE_CLOUD", "1"), default=True)

    for attempt in range(1, retries + 1):
        rc, out = _cpe_ready_run_cmd(shlex.split(status_cmd), timeout=20)
        internet, cloud = _cpe_ready_parse_status(out)
        ready = _cpe_ready_is_connected(internet) and ((not require_cloud) or _cpe_ready_is_connected(cloud))
        print(json.dumps({
            "step": "cpe-ready-probe",
            "attempt": attempt,
            "cmd_rc": rc,
            "internet": internet,
            "cloud": cloud,
            "ready": ready,
            "phase": phase,
        }, ensure_ascii=False), flush=True)
        if ready:
            return True
        if attempt < retries and interval > 0:
            time.sleep(interval)
    return False


def _ensure_cpe_ready() -> dict:
    """Ensure CPE ready, with optional single PDU reset workaround."""
    if not _parse_bool(os.environ.get("CPE_READY_CHECK", "1"), default=True):
        return {"ok": True, "skipped": True}

    if _probe_cpe_ready("initial"):
        return {"ok": True, "pdu_reset_used": False}

    if not _parse_bool(os.environ.get("PDU_RESET_ON_NOT_READY", "1"), default=True):
        return {"ok": False, "failed_step": "cpe-ready", "error": "cpe not ready"}

    # ---- single PDU reset ----
    # follow spec: PDU_RESET_SCRIPT first, then PDU_SCRIPT
    pdu_script = os.environ.get("PDU_RESET_SCRIPT") or os.environ.get("PDU_SCRIPT") or "/home/da40/charter/tools/pdu_outlet1.py"
    pdu_action = os.environ.get("PDU_RESET_ACTION", "reset")
    pdu_timeout = int(os.environ.get("PDU_RESET_TIMEOUT_SEC", "120"))
    pdu_wait = int(os.environ.get("PDU_RESET_WAIT_SEC", "120"))
    post_stab = int(os.environ.get("POST_PDU_STABILIZE_SEC", "40"))
    pdu_outlet_id = os.environ.get("PDU_OUTLET_ID")
    pybin = os.environ.get("PYTHON", "python3")

    try:
        mute_secs = int(os.environ.get("REBOOT_MUTE_SECS", "60"))
    except Exception:
        mute_secs = 60

    mute_res = _console_mute(mute_secs, reason="pdu_reset")
    print(json.dumps({
        "event": "console-mute",
        "ok": bool(mute_res.get("ok")),
        "mute_secs": mute_res.get("mute_secs"),
        "method": mute_res.get("method"),
        "rc": mute_res.get("rc"),
        "error": mute_res.get("error"),
    }, ensure_ascii=False), flush=True)

    prc, pout = _cpe_ready_run_cmd([pybin, pdu_script, pdu_action], timeout=pdu_timeout)
    pdu_ok = (prc == 0)
    print(json.dumps({
        "event": "pdu-reset",
        "ok": pdu_ok,
        "script": pdu_script,
        "action": pdu_action,
        "outlet_id": pdu_outlet_id,
        "rc": prc,
        "output_tail": (pout or "")[-2000:],
        "timeout_sec": pdu_timeout,
    }, ensure_ascii=False), flush=True)
    if not pdu_ok:
        return {"ok": False, "failed_step": "pdu-reset", "error": f"pdu reset failed rc={prc}"}

    total_wait = max(0, pdu_wait) + max(0, post_stab)
    if total_wait > 0:
        print(json.dumps({"event": "post-pdu-wait", "wait_sec": total_wait}, ensure_ascii=False), flush=True)
        if pdu_wait > 0:
            time.sleep(pdu_wait)
        if post_stab > 0:
            time.sleep(post_stab)

    if _probe_cpe_ready("after-pdu"):
        return {"ok": True, "pdu_reset_used": True}

    return {"ok": False, "failed_step": "cpe-ready", "error": "cpe not ready after single pdu reset", "pdu_reset_used": True}


def _tcp_port_open(host: str, port: int, timeout_sec: float = 2.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout_sec):
            return True
    except Exception:
        return False


def _ssh_cmd_check(host: str, user: str, password: str, cmd: str) -> dict:
    """Run a lightweight SSH command using tools/cpe_ssh.py; return {ok, rc, out/json} dict."""
    tool = os.environ.get("CPE_SSH_TOOL", "/home/da40/charter/tools/cpe_ssh.py")
    pybin = os.environ.get("PYTHON", "python3")
    timeout_sec = int(os.environ.get("SSH_TOOL_TIMEOUT", "15"))
    argv = [pybin, tool, "--host", host, "--user", user, "--password", password, "--cmd", cmd]

    try:
        cp = subprocess.run(argv, capture_output=True, text=True, timeout=timeout_sec)
        out = (cp.stdout or "")
        err = (cp.stderr or "")
        payload = None
        ok = (cp.returncode == 0)
        try:
            payload = json.loads(out) if out.strip().startswith("{") else None
            if isinstance(payload, dict) and "ok" in payload:
                ok = bool(payload.get("ok"))
        except Exception:
            payload = None
        return {
            "ok": ok,
            "rc": cp.returncode,
            "out": out[-2000:],
            "err": err[-2000:],
            "json": payload,
        }
    except Exception as e:
        return {"ok": False, "rc": 99, "error": str(e)}


def _ensure_ssh_ready(impl_mod) -> dict:
    """Enable SSH via NOC and verify SSH ready over LAN."""
    enable_ssh_flow = _parse_bool(os.environ.get("ENABLE_SSH_FLOW", "1"), default=True)
    if not enable_ssh_flow:
        return {"ok": True, "skipped": True, "ssh_ready": False}

    ssh_action = (os.environ.get("SSH_ACTION", "enable") or "enable").strip().lower()
    if ssh_action not in ("enable", "disable", "both"):
        return {"ok": False, "failed_step": "ssh-action", "error": f"bad SSH_ACTION={ssh_action}"}

    # Only verify ready when enabling
    require_ready = _parse_bool(os.environ.get("REQUIRE_SSH_READY", "1"), default=True)
    if ssh_action not in ("enable", "both"):
        return {"ok": True, "ssh_ready": False, "skipped": True}

    # --- build NOC config like main_impl_orig.run ---
    profile_name = os.environ.get("NOC_PROFILE", "")
    base = os.environ.get("NOC_BASE", "")
    email = os.environ.get("NOC_EMAIL", "")
    password = os.environ.get("NOC_PASSWORD", "")
    if profile_name and hasattr(impl_mod, "_load_noc_profile"):
        prof = impl_mod._load_noc_profile(profile_name)  # type: ignore[attr-defined]
        if prof:
            base = prof.get("base") or base
            email = prof.get("email") or email
            password = prof.get("password") or password
            print(json.dumps({
                "event": "noc-profile-applied",
                "profile": profile_name,
                "base": base,
                "email": bool(email),
                "password": bool(password),
                "where": "cycle_wrapper.precondition",
            }, ensure_ascii=False), flush=True)
        else:
            print(json.dumps({
                "event": "noc-profile-not-applied",
                "profile": profile_name,
                "where": "cycle_wrapper.precondition",
            }, ensure_ascii=False), flush=True)
    if not base:
        base = "https://piranha-int.tau.dev-charter.net"

    bearer = _parse_bool(os.environ.get("BEARER", "0"), default=False)
    insecure = _parse_bool(os.environ.get("INSECURE", "0"), default=False)
    customer_id = os.environ.get("CUSTOMER_ID", "")

    if not email or not password:
        return {"ok": False, "failed_step": "noc-login", "error": "missing NOC_EMAIL/NOC_PASSWORD"}

    # serial params for node-id
    metrics_tool = os.environ.get("METRICS_TOOL", "/home/da40/charter/tools/cpe_metrics_agent_serial.py")
    dev = os.environ.get("CPE_DEV", "/dev/ttyUSB0")
    baud = int(os.environ.get("CPE_BAUD", "115200"))
    cpe_user = os.environ.get("CPE_USER", "root")
    cpe_password = os.environ.get("CPE_PASSWORD", "")
    if str(cpe_password).strip().lower() in ("none", "null", "nil"):
        cpe_password = ""
    if not cpe_password and hasattr(impl_mod, "_console_password"):
        cpe_info_tool = os.environ.get("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
        try:
            cpe_password = impl_mod._console_password(cpe_info_tool)  # type: ignore[attr-defined]
        except Exception:
            cpe_password = ""

    ssh_user = os.environ.get("SSH_USER", "operator")
    ssh_pass = os.environ.get("SSH_PASSWORD", "")
    ssh_timeout_min = int(os.environ.get("SSH_TIMEOUT_MIN", "120"))

    # 1) login/node/location (add retry for flaky NOC / transient timeout)
    noc_ctx_retries = int(os.environ.get("NOC_CONTEXT_RETRIES", "3") or "3")
    noc_ctx_wait = float(os.environ.get("NOC_CONTEXT_RETRY_WAIT_SEC", "5") or "5")

    last_err = None
    token = None
    node_id = None
    location_id = None

    for attempt in range(1, max(1, noc_ctx_retries) + 1):
        try:
            # clear cached token/context to avoid stale partial state
            try:
                cache = getattr(impl_mod, "_CACHE", None)
                if isinstance(cache, dict):
                    cache.pop("token", None)
                    cache.pop("node_id", None)
                    cache.pop("location_id", None)
            except Exception:
                pass

            token = impl_mod._login(base, email, password, bearer, insecure)  # type: ignore[attr-defined]
            node_id = impl_mod._node_id(metrics_tool, dev, baud, cpe_user, cpe_password)  # type: ignore[attr-defined]
            location_id = impl_mod._location_id(base, customer_id, node_id, token, bearer, insecure)  # type: ignore[attr-defined]
            last_err = None
            break
        except Exception as e:
            last_err = str(e)
            print(json.dumps({
                "event": "noc-context-retry",
                "attempt": attempt,
                "retries": noc_ctx_retries,
                "wait_sec": noc_ctx_wait,
                "error": last_err,
            }, ensure_ascii=False), flush=True)
            if attempt < noc_ctx_retries and noc_ctx_wait > 0:
                time.sleep(noc_ctx_wait)

    if last_err or not token or not node_id or not location_id:
        return {"ok": False, "failed_step": "noc-context", "error": last_err or "noc context failed"}

    # 2) ssh-enable
    try:
        impl_mod._ssh_enable(base, customer_id, location_id, node_id, ssh_pass, ssh_timeout_min, token, bearer, insecure)  # type: ignore[attr-defined]
        os.environ["PRECOND_SSH_ENABLED"] = "1"
    except Exception as e:
        print(json.dumps({"step": "ssh-enable", "ok": False, "error": str(e)}, ensure_ascii=False), flush=True)
        return {"ok": False, "failed_step": "ssh-enable", "error": str(e), "node_id": node_id, "location_id": location_id, "token_present": True}

    if not require_ready:
        return {"ok": True, "ssh_ready": True, "node_id": node_id, "location_id": location_id, "token_present": True}

    host = os.environ.get("SSH_HOST_LAN", "192.168.1.1")
    ready_cmd = os.environ.get("SSH_READY_CMD", "health")
    ready_retry = int(os.environ.get("SSH_READY_RETRY", "2"))
    ready_wait = float(os.environ.get("SSH_READY_WAIT_SEC", "2"))

    for attempt in range(1, ready_retry + 1):
        port_open = _tcp_port_open(host, 22, timeout_sec=2.0)
        print(json.dumps({
            "event": "ssh-port-check",
            "attempt": attempt,
            "open": port_open,
            "host": host,
            "port": 22,
        }, ensure_ascii=False), flush=True)

        if port_open:
            chk = _ssh_cmd_check(host, ssh_user, ssh_pass, ready_cmd)
            print(json.dumps({
                "event": "ssh-cmd-check",
                "attempt": attempt,
                "cmd": ready_cmd,
                "ok": bool(chk.get("ok")),
                "out": chk.get("json") if chk.get("json") is not None else chk.get("out"),
                "rc": chk.get("rc"),
            }, ensure_ascii=False), flush=True)
            if chk.get("ok"):
                return {"ok": True, "ssh_ready": True, "node_id": node_id, "location_id": location_id, "token_present": True}
        else:
            # re-enable once more before retry (best-effort)
            try:
                impl_mod._ssh_enable(base, customer_id, location_id, node_id, ssh_pass, ssh_timeout_min, token, bearer, insecure)  # type: ignore[attr-defined]
            except Exception:
                pass

        if attempt < ready_retry and ready_wait > 0:
            time.sleep(ready_wait)

    return {"ok": False, "failed_step": "ssh-ready", "error": "ssh not ready after retries", "node_id": node_id, "location_id": location_id, "token_present": True}


def precondition(entry_module) -> dict:
    """Unified precondition: CPE_READY + SSH_ENABLE/READY (first cycle)."""
    cpe_res = _ensure_cpe_ready()
    if not cpe_res.get("ok"):
        return {"ok": False, "failed_step": cpe_res.get("failed_step", "cpe-ready"), "error": cpe_res.get("error", "cpe not ready"), "cpe_ready": False}

    ssh_res = _ensure_ssh_ready(entry_module)
    if not ssh_res.get("ok"):
        return {
            "ok": False,
            "failed_step": ssh_res.get("failed_step", "ssh"),
            "error": ssh_res.get("error", "ssh precondition failed"),
            "cpe_ready": True,
            "ssh_ready": False,
            "node_id": ssh_res.get("node_id"),
            "location_id": ssh_res.get("location_id"),
            "token_present": bool(ssh_res.get("token_present")),
        }

    return {
        "ok": True,
        "cpe_ready": True,
        "ssh_ready": bool(ssh_res.get("ssh_ready")),
        "node_id": ssh_res.get("node_id"),
        "location_id": ssh_res.get("location_id"),
        "token_present": bool(ssh_res.get("token_present")),
        "pdu_reset_used": bool(cpe_res.get("pdu_reset_used", False)),
    }

def run() -> int:
    cycles = int(os.environ.get("CYCLES", "1"))
    interval = int(os.environ.get("CYCLE_INTERVAL", "30"))
    stop_on_fail = _parse_bool(os.environ.get("STOP_ON_FAIL", "1"), default=True)
    entry = os.environ.get("ORIGINAL_ENTRY", "main_impl_orig.py:run")

    try:
        func = _resolve_entry(entry)
    except Exception as e:
        print(json.dumps({"event": "entry_resolve_error", "entry": entry, "error": str(e)}), flush=True)
        return 1

    # Import entry module object for precondition helpers
    try:
        mod_name = entry.split(":", 1)[0]
        if mod_name.endswith(".py"):
            mod_name = mod_name[:-3]
        entry_mod = importlib.import_module(mod_name)
    except Exception as e:
        print(json.dumps({"event": "entry_module_import_error", "entry": entry, "error": str(e)}), flush=True)
        return 1

    overall_rc = 0
    for i in range(cycles):
        # Precondition: only on first cycle
        if i == 0:
            pre = precondition(entry_mod)
            print(json.dumps({"event": "precondition", "result": pre}, ensure_ascii=False), flush=True)
            if not pre.get("ok"):
                print(json.dumps({
                    "event": "precondition_fail",
                    "cycle": 1,
                    "rc": 2,
                    "failed_step": pre.get("failed_step"),
                    "error": pre.get("error"),
                    "last": pre,
                }, ensure_ascii=False), flush=True)
                return 2

        print(json.dumps({"event": "cycle_start", "cycle": i + 1, "total": cycles}), flush=True)
        try:
            rc = func()
        except SystemExit as se:
            rc = int(se.code or 0)
        except Exception as e:
            print(json.dumps({"event": "cycle_exception", "cycle": i + 1, "error": str(e)}), flush=True)
            rc = 1

        try:
            rc = int(rc)
        except Exception:
            rc = 1

        print(json.dumps({"event": "cycle_end", "cycle": i + 1, "rc": rc}), flush=True)
        if rc != 0:
            overall_rc = rc
            if stop_on_fail:
                break

        if i < cycles - 1 and interval > 0:
            time.sleep(interval)

    print(json.dumps({"event": "all_cycles_done", "rc": overall_rc}), flush=True)
    return overall_rc


if __name__ == "__main__":
    sys.exit(run())

