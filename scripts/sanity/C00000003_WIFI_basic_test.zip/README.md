# C00000003_WIFI_basic_test

## 1) 目的 / 覆蓋範圍
- 驗證 Wi‑Fi SSID 廣播、client 連線或 radio toggle 行為。

## 2) 前置條件 / 環境
- 需有可用 WLAN client，且腳本指定的 SSID/頻段在環境中存在。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：1
- CYCLE_INTERVAL：70

## 5) PASS/FAIL 判定
- PASS：SSID/連線/radio 狀態符合預期。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C00000003_WIFI_basic_test

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：1
- CYCLE_INTERVAL：70

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C00000003_WIFI_basic_test

Wi‑Fi basic connectivity test (LAN client) built on the same **cycle_wrapper + precondition** architecture as `C00000001_SSH_basic_test`.

## What this test does

1. **Precondition (cycle #1 only)**
   - `cpe_info -status` retry (Internet + Cloud). If still not ready, performs **one** PDU power reset (with console mute) then retries.
   - Enables SSH via **NOC API** (using `PROFILES_FILE` + `NOC_PROFILE`) and validates LAN SSH is reachable.

2. **Wi‑Fi basic test (each cycle)**
   - SSH to CPE and fetch **SSID / PSK** using `cpe_ssh.py --cmd wifi-creds`.
   - Connect the test PC Wi‑Fi NIC (default: `wlx6cb0ce1ff230`) to the CPE SSID using:
     - `wifi_iwd.py` (preferred) or
     - `wifi_nm.py` (fallback)
   - Verify:
     - Wi‑Fi interface has an IPv4 address
     - Ping CPE router (default `192.168.1.1`)
     - (Optional) Ping Internet target (default `www.google.com`)

## Files

- `manifest.yaml` – script manifest + environment defaults
- `cycle_wrapper.py` – cycle loop + precondition (CPE ready + SSH enable/ready)
- `main_impl_orig.py` – Wi‑Fi test logic + NOC helper functions used by precondition

## Environment variables (common)

You can override any value in `manifest.yaml` at runtime.

### NOC profile (recommended)
- `PROFILES_FILE` – path to `noc_profiles.json`
- `NOC_PROFILE` – profile name, e.g. `SPECTRUM_INT`
- `CUSTOMER_ID` – customer id
- `NOC_BASE` – NOC base URL

### CPE LAN SSH
- `SSH_HOST_LAN` – default `192.168.1.1`
- `SSH_USER` / `SSH_PASSWORD`

### Wi‑Fi parameters
- `WIFI_IFACE` – Wi‑Fi NIC on test PC (e.g. `wlx6cb0ce1ff230`)
- `WIFI_METHOD` – `auto` (default), `iwd`, `nm`
- `WIFI_BAND` – `2g` / `5g` / `6g` (default `5g`, empty means any)
- `WIFI_CRED_PREFER` – `current` (ovsh runtime) or `default` (mf_tool label)
- `WIFI_DISCONNECT_ON_EXIT` – `1` to disconnect after test

### Connectivity checks
- `WIFI_PING_ROUTER` – default `192.168.1.1`
- `WIFI_PING_INTERNET` – `1` to ping Internet target
- `WIFI_PING_TARGET` – default `www.google.com`

## Expected output

- JSON line logs for each major step (`wifi-creds`, `wifi-connect`, `wifi-ipv4`, `ping-router`, `ping-internet`, `result`).
- Exit code `0` on PASS, `1` on FAIL.

```

```
