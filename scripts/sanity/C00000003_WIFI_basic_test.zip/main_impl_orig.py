#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
C001_SSH_api_test main implementation.

流程：
  1. 使用 NOC_EMAIL / NOC_PASSWORD login 取得 token
  2. 透過 serial (METRICS_TOOL) 取得 node_id
  3. 透過 NOC API 取得 location_id
  4. 跑一輪 NOC API 測試：
     - get-location 一致性確認
     - speedtest-run + speedtest-result (輪詢等待結果)
     - wifi-status / wifi-enable / wifi-disable（最後會還原）
     - lte-status
     - reboot-node（可選，避免不小心重開設備，用 ENABLE_REBOOT_TEST 控制）
  5. 根據 SSH_ACTION (enable / disable / both) 做 ssh-enable / ssh-disable
"""

import os
import sys
import json
import time
import subprocess
from typing import Dict, Optional, List

import requests  # 用來抓 HTTPError status code


# -------------------------------------------------
# 載入 tools 目錄底下的 noc_api_cli
# -------------------------------------------------
TOOLS_PATH = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
if TOOLS_PATH and TOOLS_PATH not in sys.path:
    sys.path.insert(0, TOOLS_PATH)

try:
    import noc_api_cli as api  # type: ignore
except Exception as e:  # 在 ChatGPT sandbox 會失敗，在實機應該 OK
    api = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "noc_api_cli", "error": str(e)}))

_CACHE: Dict[str, object] = {}
try:
    import cpe_ssh  # type: ignore
except Exception as e:
    cpe_ssh = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "cpe_ssh", "error": str(e)}))



# -------------------------------------------------
# 小工具
# -------------------------------------------------
def _getenv(name: str, default: str = "") -> str:
    v = os.environ.get(name, default)
    if v is None:
        return default
    return str(v)


def _bool_env(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    v = v.strip().lower()
    if v in ("1", "true", "yes", "on", "y"):
        return True
    if v in ("0", "false", "no", "off", "n"):
        return False
    return default


def _load_noc_profile(profile_name: str) -> Optional[Dict[str, str]]:
    """載入指定的 NOC profile 設定。

    讀取順序（統一以 PROFILES_FILE 為主）：
      1. 環境變數 PROFILES_FILE
      2. (legacy) 環境變數 NOC_PROFILES_PATH
      3. 預設 ~/.secrets/noc_profiles.json

    回傳 dict，例如: {"base": "...", "email": "...", "password": "..." }。
    如果檔案不存在或 profile 找不到，回傳 None，並印出對應事件。
    """
    path = (
        os.environ.get("PROFILES_FILE")
        or os.environ.get("NOC_PROFILES_PATH")
        or os.path.expanduser("~/.secrets/noc_profiles.json")
    )

    # legacy alias warning (keep compatibility but prefer PROFILES_FILE)
    if os.environ.get("NOC_PROFILES_PATH") and not os.environ.get("PROFILES_FILE"):
        print(json.dumps({
            "event": "deprecated_env",
            "name": "NOC_PROFILES_PATH",
            "use": "PROFILES_FILE",
            "path": path,
        }, ensure_ascii=False), flush=True)


    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError as e:
        print(json.dumps({
            "event": "noc-profile-load-error",
            "profile": profile_name,
            "path": path,
            "error": str(e),
        }))
        return None
    except Exception as e:
        print(json.dumps({
            "event": "noc-profile-load-error",
            "profile": profile_name,
            "path": path,
            "error": f"load-error: {e}",
        }))
        return None

    prof = data.get(profile_name) or data.get(profile_name.upper())
    if not prof:
        print(json.dumps({
            "event": "noc-profile-load-error",
            "profile": profile_name,
            "path": path,
            "error": f"profile '{profile_name}' not found in file",
        }))
        return None

    base = prof.get("base")
    email = prof.get("email")
    password = prof.get("password")

    return {
        "base": base,
        "email": email,
        "password": password,
    }


def _login(base: str, email: str, password: str, bearer: bool, insecure: bool) -> str:
    if "token" in _CACHE:
        return _CACHE["token"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot login to NOC")

    tok = api.login(base, email, password, bearer=bearer, insecure=insecure)
    _CACHE["token"] = tok
    print(json.dumps({"step": "login", "ok": True}))
    return tok



def _node_id(metrics_tool: str, dev: str, baud: int, user: str, password: str) -> str:
    """Resolve node_id via `cpe_info --node-id` only (no console/serial)."""
    if "node_id" in _CACHE:
        try:
            print(json.dumps({"step": "node-id", "cached": True, "node_id": _CACHE["node_id"]}))
        except Exception:
            pass
        return _CACHE["node_id"]  # type: ignore[return-value]

    try:
        max_retries = int(os.environ.get("NODE_ID_MAX_RETRIES", "3"))
    except Exception:
        max_retries = 3
    try:
        retry_interval = float(os.environ.get("NODE_ID_RETRY_INTERVAL_SEC", "2"))
    except Exception:
        retry_interval = 2.0

    def _norm_node_id(raw: str) -> str:
        s = (raw or "").strip()
        if not s:
            return ""
        for ln in s.splitlines():
            ln = ln.strip()
            if ln:
                s = ln
                break
        s = s.replace(":", "").strip().lower()
        if len(s) == 12 and all(c in "0123456789abcdef" for c in s):
            return s
        return ""

    cpe_info_tool = os.environ.get("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
    last_raw = ""

    for attempt in range(1, max_retries + 1):
        for extra_args in (["--node-id"], ["--node-id", "--value"]):
            cmd = ([cpe_info_tool] if os.path.exists(cpe_info_tool) else ["cpe_info"]) + extra_args
            try:
                proc = subprocess.run(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    timeout=20,
                )
                last_raw = (proc.stdout or "").strip()
            except Exception as e:
                last_raw = str(e)
                print(json.dumps({
                    "step": "node-id-cpe_info-exception",
                    "attempt": attempt,
                    "cmd": cmd,
                    "error": str(e),
                }))
                continue

            nid = _norm_node_id(last_raw)
            ok = (proc.returncode == 0 and bool(nid))
            print(json.dumps({
                "step": "node-id-cpe_info",
                "attempt": attempt,
                "cmd": cmd,
                "rc": proc.returncode,
                "raw": last_raw,
                "node_id": nid if ok else "",
                "ok": ok,
            }))
            if ok:
                _CACHE["node_id"] = nid
                return nid

        if attempt < max_retries:
            print(json.dumps({
                "step": "node-id-retry",
                "attempt": attempt,
                "next_wait_sec": retry_interval,
            }))
            time.sleep(retry_interval)

    raise RuntimeError(f"cpe_info --node-id failed after {max_retries} retries; last_output={last_raw!r}")


def _location_id(base: str, customer_id: str, node_id: str,
                 token: str, bearer: bool, insecure: bool) -> str:
    if "location_id" in _CACHE:
        return _CACHE["location_id"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot get location-id")

    loc_id = api.get_location_id(
        base,
        customer_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    _CACHE["location_id"] = loc_id
    print(json.dumps({"step": "location-id", "location_id": loc_id}))
    return loc_id


# -------------------------------------------------
# CPE console password fallback
# -------------------------------------------------
def _console_password(cpe_info_tool: str) -> str:
    """
    若 CPE_PASSWORD 未設定或為 null，嘗試透過 cpe_info 撈 console 密碼。
    """
    try:
        proc = subprocess.run(
            [cpe_info_tool, "--password"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=15,
        )
        out = (proc.stdout or "").strip()
        for line in out.splitlines():
            line = line.strip()
            if not line:
                continue
            # 直接回傳第一行非空白
            print(json.dumps({"step": "cpe-info-password", "line": line}))
            return line
    except Exception as e:
        print(json.dumps({
            "step": "cpe-info-password-error",
            "error": str(e),
        }))
    return ""


# -------------------------------------------------
# SSH enable / disable via NOC API
# -------------------------------------------------
def _ssh_enable(base: str, customer_id: str, location_id: str, node_id: str,
                ssh_pass: str, timeout_min: int,
                token: str, bearer: bool, insecure: bool) -> None:
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot enable SSH")

    try:
        resp = api.ssh_enable(
            base,
            customer_id,
            location_id,
            node_id,
            ssh_pass,
            timeout_min,
            token=token,
            bearer=bearer,
            insecure=insecure,
        )
        print(json.dumps({"step": "ssh-enable", "ok": True, "resp": resp}, ensure_ascii=False), flush=True)
    except Exception as e:
        print(json.dumps({"step": "ssh-enable", "ok": False, "error": str(e)}, ensure_ascii=False), flush=True)
        raise


def _ssh_disable(base: str, customer_id: str, location_id: str, node_id: str,
                 token: str, bearer: bool, insecure: bool) -> None:
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot disable SSH")

    try:
        resp = api.ssh_disable(
            base,
            customer_id,
            location_id,
            node_id,
            token=token,
            bearer=bearer,
            insecure=insecure,
        )
        print(json.dumps({"step": "ssh-disable", "ok": True, "resp": resp}, ensure_ascii=False), flush=True)
    except Exception as e:
        print(json.dumps({"step": "ssh-disable", "ok": False, "error": str(e)}, ensure_ascii=False), flush=True)
        raise


# -------------------------------------------------
# Speedtest 測試
# -------------------------------------------------
def _run_speedtest_tests(base: str, customer_id: str, location_id: str, node_id: str,
                         token: str, bearer: bool, insecure: bool) -> None:
    """執行 speedtest-run + speedtest-result 輪詢。"""
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run speedtest")

    # 1) 先觸發 speedtest-run
    resp_run = api.speedtest_run(
        base,
        customer_id,
        location_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )

    request_id = None
    if isinstance(resp_run, dict):
        request_id = (
            resp_run.get("requestId")
            or resp_run.get("request_id")
            or resp_run.get("id")
        )

    print(json.dumps({
        "step": "speedtest-run",
        "resp": resp_run,
        "request_id": request_id,
    }))

    if not request_id:
        raise RuntimeError("speedtest-run did not return requestId")

    # 2) 先等一段時間再開始查結果
    wait_sec = int(_getenv("SPEEDTEST_WAIT_SEC", "60"))
    print(json.dumps({
        "step": "speedtest-wait",
        "wait_sec": wait_sec,
    }))
    time.sleep(wait_sec)

    # 3) 輪詢結果
    max_attempts = int(_getenv("SPEEDTEST_MAX_ATTEMPTS", "10"))
    interval_sec = int(_getenv("SPEEDTEST_INTERVAL_SEC", "30"))

    last_error: Optional[str] = None
    for attempt in range(1, max_attempts + 1):
        try:
            resp_one = api.speedtest_result_by_id(
                base,
                customer_id,
                location_id,
                node_id,
                request_id,
                token=token,
                bearer=bearer,
                insecure=insecure,
            )
            # 呼叫成功（沒有丟 HTTPError）
            print(json.dumps({
                "step": "speedtest-result",
                "attempt": attempt,
                "request_id": request_id,
                "resp": resp_one,
            }))
            break

        except requests.HTTPError as e:
            status = e.response.status_code if e.response is not None else None
            body = e.response.text[:200] if e.response is not None else ""
            last_error = f"HTTP {status}: {body}"

            print(json.dumps({
                "step": "speedtest-result-retry",
                "attempt": attempt,
                "request_id": request_id,
                "status": status,
                "error": last_error,
            }))

            if status and 400 <= status < 500:
                # 4xx 通常不會因為重試成功，直接跳出
                break

        # 等下一輪
        time.sleep(interval_sec)

    if last_error:
        raise RuntimeError(f"speedtest-result failed: {last_error}")


# -------------------------------------------------
# Wi-Fi 測試
# -------------------------------------------------
def _wifi_enabled_flag(status_resp: dict) -> Optional[bool]:
    """
    嘗試從 wifi_status() 的回應中解析 enabled 狀態。
    schema 可能是：
      - {"enabled": true, ...}
      - {"wifiNetwork": {"enabled": true, ...}}
    """
    if not isinstance(status_resp, dict):
        return None

    if "enabled" in status_resp:
        v = status_resp.get("enabled")
    elif "wifiNetwork" in status_resp and isinstance(status_resp["wifiNetwork"], dict):
        v = status_resp["wifiNetwork"].get("enabled")
    else:
        return None

    if isinstance(v, bool):
        return v
    if isinstance(v, str):
        return v.strip().lower() in ("1", "true", "yes", "on", "y")
    return None


def _run_wifi_tests(base: str, customer_id: str, location_id: str,
                    token: str, bearer: bool, insecure: bool) -> None:
    """
    Wi-Fi 測試流程：
      1. 取得目前狀態 wifi-status-before
      2. 切換一次 enabled -> !enabled
      3. 再切回原本狀態
    """
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run Wi-Fi tests")

    # 1) 先查目前狀態
    status_before = api.wifi_status(
        base,
        customer_id,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    enabled_before = _wifi_enabled_flag(status_before)
    print(json.dumps({
        "step": "wifi-status-before",
        "enabled": enabled_before,
        "resp": status_before,
    }))

    target_state = not bool(enabled_before) if enabled_before is not None else True

    # 切換一次
    resp_toggle = api.wifi_set_enabled(
        base,
        customer_id,
        location_id,
        target_state,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    status_mid = api.wifi_status(
        base,
        customer_id,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    enabled_mid = _wifi_enabled_flag(status_mid)
    print(json.dumps({
        "step": "wifi-toggle",
        "target": target_state,
        "enabled_mid": enabled_mid,
        "resp_toggle": resp_toggle,
        "status_mid": status_mid,
    }))

    # 切回原本狀態
    if enabled_before is not None:
        resp_restore = api.wifi_set_enabled(
            base,
            customer_id,
            location_id,
            enabled_before,
            token=token,
            bearer=bearer,
            insecure=insecure,
        )
        status_after = api.wifi_status(
            base,
            customer_id,
            location_id,
            token=token,
            bearer=bearer,
            insecure=insecure,
        )
        enabled_after = _wifi_enabled_flag(status_after)
        ok = (enabled_after == enabled_before)
        print(json.dumps({
            "step": "wifi-restore",
            "enabled_before": enabled_before,
            "enabled_after": enabled_after,
            "ok": ok,
            "resp_restore": resp_restore,
            "status_after": status_after,
        }))
        if not ok:
            raise RuntimeError("wifi enabled state mismatch after restore")


def _run_lte_test(base: str, location_id: str,
                  token: str, bearer: bool, insecure: bool) -> None:
    """lte-status 測試（僅查詢）。"""
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run LTE tests")

    resp = api.lte_status(
        base,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({
        "step": "lte-status",
        "resp": resp,
    }))


def _run_reboot_test(base: str, customer_id: str, location_id: str, node_id: str,
                     token: str, bearer: bool, insecure: bool) -> None:
    """reboot-node 測試，並可選擇先 mute console 一段時間。"""
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run reboot test")

    # 先處理 console mute 的設定
    mute_secs_str = _getenv("REBOOT_MUTE_SECS", "").strip()
    mute_with_lock = _bool_env("REBOOT_MUTE_WITH_LOCK", False)

    mute_secs = 0
    if mute_secs_str:
        try:
            mute_secs = int(mute_secs_str)
        except ValueError:
            print(json.dumps({
                "step": "reboot-mute-console",
                "event": "invalid_mute_secs",
                "mute_raw": mute_secs_str,
            }))

    # 若有設定秒數，而且有成功 import cpe_ssh，就先 mute console
    if mute_secs > 0 and "cpe_ssh" in globals() and cpe_ssh is not None:
        try:
            until_ts = cpe_ssh.set_console_mute(
                mute_secs,
                use_lock=mute_with_lock,
                lock_timeout=5,
            )
            print(json.dumps({
                "step": "reboot-mute-console",
                "mute_secs": mute_secs,
                "until_ts": until_ts,
                "use_lock": mute_with_lock,
            }))
        except Exception as e:
            print(json.dumps({
                "step": "reboot-mute-console-fail",
                "mute_secs": mute_secs,
                "use_lock": mute_with_lock,
                "error": str(e),
            }))

    # 再來處理 reboot delay（NOC API 端）
    delay_str = _getenv("REBOOT_DELAY_SEC", "").strip()
    delay_val: Optional[float]
    if delay_str:
        try:
            delay_val = float(delay_str)
        except ValueError:
            print(json.dumps({
                "step": "reboot-node",
                "event": "invalid_delay",
                "delay_raw": delay_str,
            }))
            delay_val = None
    else:
        delay_val = None

    resp = api.reboot_node(
        base,
        customer_id,
        location_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
        delay=delay_val,
    )
    print(json.dumps({
        "step": "reboot-node",
        "delay": delay_val,
        "resp": resp,
    }))
def _run_get_location_test(base: str, customer_id: str, node_id: str,
                           location_id: str,
                           token: str, bearer: bool, insecure: bool) -> None:
    """get-location 功能測試，確認回傳的 locationId 與前面取得的一致。"""
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run get-location test")

    loc2 = api.get_location_id(
        base,
        customer_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    ok = (loc2 == location_id)
    print(json.dumps({
        "step": "get-location-check",
        "location_id": location_id,
        "location_id_refetched": loc2,
        "ok": ok,
    }))
    if not ok:
        raise RuntimeError("location_id from get_location_id() mismatch")



# -------------------------------------------------
# Internet connectivity pre-check using cpe_info --internet
# -------------------------------------------------
def _wait_internet_connected() -> None:
    """在執行 speedtest 之前，透過 cpe_info --internet 確認 Internet Status: Connected。

    預設會重試 10 次，每次間隔 3 秒，可由環境變數覆蓋：
      INTERNET_CHECK_MAX_RETRIES
      INTERNET_CHECK_INTERVAL_SEC
    """
    cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")

    try:
        max_retries = int(_getenv("INTERNET_CHECK_MAX_RETRIES", "10"))
    except Exception:
        max_retries = 10

    try:
        interval_sec = float(_getenv("INTERNET_CHECK_INTERVAL_SEC", "3"))
    except Exception:
        interval_sec = 3.0

    last_output = ""

    for attempt in range(1, max_retries + 1):
        cmd = [cpe_info_tool, "--internet"]
        print(json.dumps({
            "step": "internet-check",
            "attempt": attempt,
            "max_retries": max_retries,
            "cmd": cmd,
        }))

        try:
            proc = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=30,
            )
            out = (proc.stdout or "").strip()
            last_output = out
        except Exception as e:
            print(json.dumps({
                "step": "internet-check-exception",
                "attempt": attempt,
                "error": str(e),
            }))
        else:
            print(json.dumps({
                "step": "internet-check-raw",
                "attempt": attempt,
                "rc": proc.returncode,
                "out": out,
            }))
            # 成功條件：rc == 0 且輸出中有 "Internet Status: Connected"
            if proc.returncode == 0 and "Internet Status: Connected" in out:
                print(json.dumps({
                    "step": "internet-check-ok",
                    "attempt": attempt,
                }))
                return

        # 還沒成功就睡一下再試
        if attempt < max_retries:
            time.sleep(interval_sec)

    # 全部重試完還是沒 Connected → 當成 precondition fail
    print(json.dumps({
        "step": "internet-check-failed",
        "max_retries": max_retries,
        "last_output": last_output[-200:],
    }))
    raise RuntimeError(
        f"internet not connected after {max_retries} checks via cpe_info --internet"
    )


def _run_noc_api_tests(base: str, customer_id: str, node_id: str, location_id: str,
                       token: str, bearer: bool, insecure: bool) -> None:
    """
    統一執行 NOC API 測試，並可透過環境變數決定是否啟用各項測試：

      ENABLE_SPEEDTEST   (預設 1)
      ENABLE_WIFI_TEST   (預設 1)
      ENABLE_LTE_TEST    (預設 1)
      ENABLE_REBOOT_TEST (預設 0；避免不小心重開設備)

    另外可使用：
      REBOOT_DELAY_SEC   (選填，reboot 前等待秒數；未設定時使用 NOC API server 預設值)
    """
    # 讀 env 開關
    enable_speedtest = _bool_env("ENABLE_SPEEDTEST", True)
    enable_wifi = _bool_env("ENABLE_WIFI_TEST", True)
    enable_lte = _bool_env("ENABLE_LTE_TEST", True)
    enable_reboot = _bool_env("ENABLE_REBOOT_TEST", False)

    print(json.dumps({
        "event": "noc-api-tests-start",
        "enable_speedtest": enable_speedtest,
        "enable_wifi": enable_wifi,
        "enable_lte": enable_lte,
        "enable_reboot": enable_reboot,
    }))

    # 一律先做 get-location 一致性檢查
    _run_get_location_test(base, customer_id, node_id, location_id,
                           token, bearer, insecure)

    # speedtest
    if enable_speedtest:
        _wait_internet_connected()
        _run_speedtest_tests(base, customer_id, location_id, node_id,
                             token, bearer, insecure)
    else:
        print(json.dumps({
            "event": "speedtest-skip",
            "reason": "env_disabled",
        }))

    # wifi
    if enable_wifi:
        _run_wifi_tests(base, customer_id, location_id,
                        token, bearer, insecure)
    else:
        print(json.dumps({
            "event": "wifi-skip",
            "reason": "env_disabled",
        }))

    # lte
    if enable_lte:
        _run_lte_test(base, location_id,
                      token, bearer, insecure)
    else:
        print(json.dumps({
            "event": "lte-skip",
            "reason": "env_disabled",
        }))

    # reboot
    if enable_reboot:
        _run_reboot_test(base, customer_id, location_id, node_id,
                         token, bearer, insecure)
    else:
        print(json.dumps({
            "event": "reboot-skip",
            "reason": "env_disabled",
        }))

    print(json.dumps({"event": "noc-api-tests-done"}))


# -------------------------------------------------
# main entrypoint for cycle_wrapper
# -------------------------------------------------

# =============================================================
# C00000003 Wi-Fi basic test
# =============================================================

LOOP_FAIL = False


def _run_local(cmd: List[str], *, timeout: int = 60, env: Optional[Dict[str, str]] = None) -> Dict[str, object]:
    """Run a local command and return a structured result."""
    t0 = time.time()
    try:
        cp = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=env,
            timeout=timeout,
        )
        out = cp.stdout or ""
        err = cp.stderr or ""
        payload = None
        try:
            s = out.strip()
            if s.startswith("{") and s.endswith("}"):
                payload = json.loads(s)
        except Exception:
            payload = None
        ok = (cp.returncode == 0)
        if isinstance(payload, dict) and "ok" in payload:
            try:
                ok = bool(payload.get("ok"))
            except Exception:
                pass
        return {
            "ok": ok,
            "rc": cp.returncode,
            "sec": round(time.time() - t0, 3),
            "cmd": cmd,
            "stdout": out,
            "stderr": err,
            "json": payload,
        }
    except Exception as e:
        return {"ok": False, "rc": 99, "sec": round(time.time() - t0, 3), "cmd": cmd, "error": str(e)}


def _choose_wifi_creds(creds: dict, band: str, prefer: str = "current") -> Optional[Dict[str, str]]:
    """Pick {ssid, psk, source} from cpe_ssh --cmd wifi-creds output."""
    band = (band or "").strip().lower()
    if band in ("2.4", "2.4g", "2g", "24g"):
        band = "2g"
    elif band in ("5", "5g"):
        band = "5g"
    elif band in ("6", "6g"):
        band = "6g"

    prefer = (prefer or "current").strip().lower()
    if prefer not in ("current", "default"):
        prefer = "current"

    def _from_default() -> Optional[Dict[str, str]]:
        d = creds.get("default") or {}
        if not isinstance(d, dict):
            return None
        # try requested band, else 5g -> 2g -> 6g
        order = [band] if band else []
        for b in ("5g", "2g", "6g"):
            if b not in order:
                order.append(b)
        for b in order:
            item = d.get(b)
            if isinstance(item, dict):
                ssid = (item.get("ssid") or "").strip()
                psk = (item.get("psk") or "").strip()
                if ssid and psk:
                    return {"ssid": ssid, "psk": psk, "source": f"default:{b}"}
        return None

    def _infer_band_from_ifname(ifname: str) -> Optional[str]:
        s = (ifname or "").strip().lower()
        # common convention: wifi0=2g, wifi1=5g, wifi2=6g
        if s.endswith("0"):
            return "2g"
        if s.endswith("1"):
            return "5g"
        if s.endswith("2"):
            return "6g"
        return None

    def _from_current() -> Optional[Dict[str, str]]:
        c = creds.get("current") or {}
        if not isinstance(c, dict):
            return None
        vifs = c.get("vifs") or []
        if not isinstance(vifs, list):
            return None

        # try band match first if possible
        if band:
            for v in vifs:
                if not isinstance(v, dict):
                    continue
                ssid = (v.get("ssid") or "").strip()
                psk = (v.get("psk") or "").strip()
                ifname = (v.get("if_name") or "").strip()
                vb = _infer_band_from_ifname(ifname)
                if ssid and psk and vb == band:
                    return {"ssid": ssid, "psk": psk, "source": f"current:{ifname or vb or 'vif'}"}

        # fallback: first usable
        for v in vifs:
            if not isinstance(v, dict):
                continue
            ssid = (v.get("ssid") or "").strip()
            psk = (v.get("psk") or "").strip()
            ifname = (v.get("if_name") or "").strip()
            if ssid and psk:
                return {"ssid": ssid, "psk": psk, "source": f"current:{ifname or 'vif'}"}
        return None

    if prefer == "current":
        return _from_current() or _from_default()
    return _from_default() or _from_current()


def _ip4_addr(iface: str) -> Optional[str]:
    res = _run_local(["ip", "-4", "-o", "addr", "show", "dev", iface], timeout=10)
    out = (res.get("stdout") or "") if isinstance(res, dict) else ""
    m = __import__("re").search(r"\binet\s+(\d+\.\d+\.\d+\.\d+/\d+)", out)
    return m.group(1) if m else None


def _ping(iface: str, target: str, *, count: int = 3, timeout_sec: int = 5) -> Dict[str, object]:
    cmd = ["ping", "-I", iface, "-c", str(int(count)), "-W", str(int(timeout_sec)), str(target)]
    return _run_local(cmd, timeout=max(10, int(count) * int(timeout_sec) + 5))


def _wifi_disconnect(method_used: str, iface: str) -> None:
    pybin = os.environ.get("PYTHON", "python3")
    tools_path = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
    if method_used == "iwd":
        tool = os.environ.get("WIFI_IWD_TOOL") or os.path.join(tools_path, "wifi_iwd.py")
        _run_local([pybin, tool, "--json", "disconnect", "--iface", iface], timeout=30)
    elif method_used == "nm":
        tool = os.environ.get("WIFI_NM_TOOL") or os.path.join(tools_path, "wifi_nm.py")
        _run_local([pybin, tool, "--json", "disconnect", "--iface", iface], timeout=30)


def run() -> int:
    """Entry point for the Wi‑Fi basic test."""
    global LOOP_FAIL

    pybin = os.environ.get("PYTHON", "python3")
    tools_path = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")

    # --- CPE SSH params ---
    cpe_host = os.environ.get("SSH_HOST_LAN", "192.168.1.1")
    ssh_user = os.environ.get("SSH_USER", "operator")
    ssh_pass = os.environ.get("SSH_PASSWORD", "")
    cpe_ssh_tool = os.environ.get("CPE_SSH_TOOL") or os.path.join(tools_path, "cpe_ssh.py")

    # --- Wi‑Fi test params ---
    wifi_iface = os.environ.get("WIFI_IFACE", "wlx6cb0ce1ff230")
    wifi_method = (os.environ.get("WIFI_METHOD", "auto") or "auto").strip().lower()
    wifi_band = (os.environ.get("WIFI_BAND", "5g") or "").strip().lower()
    wifi_prefer = (os.environ.get("WIFI_CRED_PREFER", "current") or "current").strip().lower()
    wifi_timeout = int(os.environ.get("WIFI_TIMEOUT_SEC", "45"))
    wifi_nm_retries = int(os.environ.get("WIFI_NM_RETRIES", "2"))
    disconnect_on_exit = _bool_env("WIFI_DISCONNECT_ON_EXIT", True)

    # -------------------------------------------------
    # Cleanup: always disconnect via wifi_iwd in a finally-like manner
    # (atexit handler runs on any normal exit / SystemExit)
    # -------------------------------------------------
    if disconnect_on_exit:
        import atexit

        def _cleanup_wifi_iwd() -> None:
            try:
                tool = os.environ.get("WIFI_IWD_TOOL") or os.path.join(tools_path, "wifi_iwd.py")
                cmd = [
                    pybin, tool,
                    "--json", "disconnect",
                    "--iface", wifi_iface,
                    "--restore-nm", "--unmanaged",
                ]
                r = _run_local(cmd, timeout=30)
                print(json.dumps({
                    "step": "wifi-disconnect",
                    "method": "iwd",
                    "ok": bool((r or {}).get("ok")),
                    "rc": (r or {}).get("rc"),
                    "iface": wifi_iface,
                    "sec": (r or {}).get("sec"),
                }, ensure_ascii=False), flush=True)
            except Exception as e:
                print(json.dumps({
                    "step": "wifi-disconnect",
                    "method": "iwd",
                    "ok": False,
                    "iface": wifi_iface,
                    "error": str(e),
                }, ensure_ascii=False), flush=True)

        atexit.register(_cleanup_wifi_iwd)

        # Prevent double-disconnect from inline cleanup below.
        disconnect_on_exit = False


    ping_router = os.environ.get("WIFI_PING_ROUTER", "192.168.1.1")
    ping_internet = _bool_env("WIFI_PING_INTERNET", True)
    ping_target = os.environ.get("WIFI_PING_TARGET", "www.google.com")
    ping_count = int(os.environ.get("WIFI_PING_COUNT", "3"))
    ping_timeout_sec = int(os.environ.get("WIFI_PING_TIMEOUT_SEC", "5"))

    # =========================================================
    # Step 1) Fetch SSID/PSK from CPE
    # =========================================================
    cmd_creds = [
        pybin,
        cpe_ssh_tool,
        "--host", cpe_host,
        "--user", ssh_user,
        "--password", ssh_pass,
        "--cmd", "wifi-creds",
        "--which", "both",
        # NOTE: tools/cpe_ssh.py already outputs JSON by default.
        # Do NOT pass "--json" (it's not a valid flag for cpe_ssh.py).
    ]
    res_creds = _run_local(cmd_creds, timeout=60)
    creds_json = res_creds.get("json") if isinstance(res_creds, dict) else None

    print(json.dumps({
        "step": "wifi-creds",
        "ok": bool(res_creds.get("ok")),
        "rc": res_creds.get("rc"),
        "host": cpe_host,
        "band": wifi_band,
        "prefer": wifi_prefer,
    }, ensure_ascii=False), flush=True)

    if not (isinstance(creds_json, dict) and creds_json.get("ok")):
        LOOP_FAIL = True
        print(json.dumps({
            "step": "wifi-creds",
            "ok": False,
            "error": "failed to fetch wifi credentials from cpe (cpe_ssh.py --cmd wifi-creds)",
            "stdout_tail": (res_creds.get("stdout") or "")[-600:],
            "stderr_tail": (res_creds.get("stderr") or "")[-600:],
        }, ensure_ascii=False), flush=True)
        return 1

    chosen = _choose_wifi_creds(creds_json, wifi_band, prefer=wifi_prefer)
    if not chosen:
        LOOP_FAIL = True
        print(json.dumps({
            "step": "wifi-creds-select",
            "ok": False,
            "error": "no usable ssid/psk found in wifi-creds output",
        }, ensure_ascii=False), flush=True)
        return 1

    ssid = chosen["ssid"]
    psk = chosen["psk"]
    print(json.dumps({
        "step": "wifi-creds-select",
        "ok": True,
        "ssid": ssid,
        "source": chosen.get("source"),
        "iface": wifi_iface,
        "band": wifi_band,
    }, ensure_ascii=False), flush=True)

    # =========================================================
    # Step 2) Connect Wi‑Fi (iwd preferred)
    # =========================================================
    env = os.environ.copy()
    env["WIFI_PSK"] = psk

    method_used = None
    last_res = None

    def _try_iwd() -> Dict[str, object]:
        tool = os.environ.get("WIFI_IWD_TOOL") or os.path.join(tools_path, "wifi_iwd.py")
        cmd = [
            pybin, tool,
            "--json",
            "ensure",
            "--iface", wifi_iface,
            "--ssid", ssid,
            "--password-env", "WIFI_PSK",
            "--timeout", str(wifi_timeout),
        ]
        if wifi_band:
            cmd += ["--band", wifi_band]
        # safe defaults: takeover to avoid NM races; restore NM after
        cmd += ["--takeover", "--restore-nm", "--unmanaged"]
        return _run_local(cmd, timeout=max(90, wifi_timeout + 30), env=env)

    def _try_nm() -> Dict[str, object]:
        tool = os.environ.get("WIFI_NM_TOOL") or os.path.join(tools_path, "wifi_nm.py")
        cmd = [
            pybin, tool,
            "--json",
            "ensure",
            "--iface", wifi_iface,
            "--ssid", ssid,
            "--password-env", "WIFI_PSK",
            "--timeout", str(wifi_timeout),
            "--retries", str(wifi_nm_retries),
        ]
        if wifi_band:
            cmd += ["--band", wifi_band]
        return _run_local(cmd, timeout=max(90, wifi_timeout + 30), env=env)

    # order
    tries: List[str] = []
    if wifi_method == "iwd":
        tries = ["iwd"]
    elif wifi_method == "nm":
        tries = ["nm"]
    else:
        tries = ["iwd", "nm"]

    for m in tries:
        if m == "iwd":
            r = _try_iwd()
        else:
            r = _try_nm()
        last_res = r
        print(json.dumps({
            "step": "wifi-connect",
            "method": m,
            "ok": bool(r.get("ok")),
            "rc": r.get("rc"),
            "ssid": ssid,
            "iface": wifi_iface,
            "sec": r.get("sec"),
        }, ensure_ascii=False), flush=True)
        if r.get("ok"):
            method_used = m
            break

    if not method_used:
        LOOP_FAIL = True
        print(json.dumps({
            "step": "wifi-connect",
            "ok": False,
            "error": "wifi connect failed (both methods tried)" if wifi_method == "auto" else "wifi connect failed",
            "stdout_tail": ((last_res or {}).get("stdout") or "")[-800:],
            "stderr_tail": ((last_res or {}).get("stderr") or "")[-800:],
        }, ensure_ascii=False), flush=True)
        return 1

    # =========================================================
    # Step 3) Verify IPv4 + ping
    # =========================================================
    ip4 = _ip4_addr(wifi_iface)
    ip_ok = bool(ip4)
    print(json.dumps({
        "step": "wifi-ipv4",
        "ok": ip_ok,
        "iface": wifi_iface,
        "ipv4": ip4,
    }, ensure_ascii=False), flush=True)

    if not ip_ok:
        LOOP_FAIL = True
        if disconnect_on_exit:
            _wifi_disconnect(method_used, wifi_iface)
        return 1

    pr = _ping(wifi_iface, ping_router, count=ping_count, timeout_sec=ping_timeout_sec)
    print(json.dumps({
        "step": "ping-router",
        "ok": bool(pr.get("ok")),
        "target": ping_router,
        "iface": wifi_iface,
        "rc": pr.get("rc"),
    }, ensure_ascii=False), flush=True)

    if not pr.get("ok"):
        LOOP_FAIL = True
        if disconnect_on_exit:
            _wifi_disconnect(method_used, wifi_iface)
        return 1

    if ping_internet and ping_target:
        pi = _ping(wifi_iface, ping_target, count=ping_count, timeout_sec=ping_timeout_sec)
        print(json.dumps({
            "step": "ping-internet",
            "ok": bool(pi.get("ok")),
            "target": ping_target,
            "iface": wifi_iface,
            "rc": pi.get("rc"),
        }, ensure_ascii=False), flush=True)
        if not pi.get("ok"):
            LOOP_FAIL = True
            if disconnect_on_exit:
                _wifi_disconnect(method_used, wifi_iface)
            return 1

    # optional cleanup
    if disconnect_on_exit:
        _wifi_disconnect(method_used, wifi_iface)

    print(json.dumps({
        "result": "OK",
        "ssid": ssid,
        "iface": wifi_iface,
        "method": method_used,
        "ipv4": ip4,
    }, ensure_ascii=False), flush=True)

    return 0
