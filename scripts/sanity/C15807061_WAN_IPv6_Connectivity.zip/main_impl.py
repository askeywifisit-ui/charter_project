#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
C15807061 WAN IPv6 Connectivity
- Step1: Read WAN IPv6 (serial / ssh / auto)
- Precondition (optional): enable SSH via NOC before SSH is used
"""

import json
import os
import re
import ipaddress
import shlex
import socket
import subprocess
import sys
import time
import hashlib
from typing import Any, Dict, List, Optional, Tuple

# Ensure cpe_info is resolvable even when PATH is not set (customer environments).
_DEFAULT_CPE_INFO = "/home/da40/charter/tools/cpe_info"
if 'CPE_INFO_BIN' not in os.environ and os.path.exists(_DEFAULT_CPE_INFO):
    os.environ['CPE_INFO_BIN'] = _DEFAULT_CPE_INFO



# ---------- logging ----------
def _log_line(s: str) -> None:
    print(s, flush=True)

def _log(event: str, **kw) -> None:
    d = {"event": event}
    d.update(kw)
    print(json.dumps(d, ensure_ascii=False), flush=True)


# ---------- SSH precondition cache ----------
# To avoid calling NOC ssh-enable every cycle, we cache the result in-process.
# Control via env:
#   SSH_PRECOND_CACHE_ENABLED (default: 1)
#   SSH_PRECOND_CACHE_TTL_SEC (default: 600)
_SSH_PRECOND_CACHE: dict = {"key": None, "ok": False, "ts": 0.0}

def _precond_cache_key(host: str, ssh_pass: str) -> str:
    # Do not store plaintext password in logs; keep only a short digest in cache key
    h = hashlib.sha256((ssh_pass or "").encode("utf-8")).hexdigest()[:12]
    return f"{host}|{h}"

def _precond_cache_get(host: str, ssh_pass: str) -> bool:
    if not _env_bool("SSH_PRECOND_CACHE_ENABLED", True):
        return False
    ttl = _env_int("SSH_PRECOND_CACHE_TTL_SEC", 600)
    key = _precond_cache_key(host, ssh_pass)
    if _SSH_PRECOND_CACHE.get("key") != key:
        return False
    if not _SSH_PRECOND_CACHE.get("ok"):
        return False
    ts = float(_SSH_PRECOND_CACHE.get("ts") or 0.0)
    if ttl > 0 and (time.time() - ts) > ttl:
        return False
    return True

def _precond_cache_set(host: str, ssh_pass: str, ok: bool) -> None:
    if not _env_bool("SSH_PRECOND_CACHE_ENABLED", True):
        return
    _SSH_PRECOND_CACHE["key"] = _precond_cache_key(host, ssh_pass)
    _SSH_PRECOND_CACHE["ok"] = bool(ok)
    _SSH_PRECOND_CACHE["ts"] = time.time()

# ---------- env helpers ----------
def _env(name: str, default: str = "", required: bool = False) -> str:
    v = os.environ.get(name, default)
    if required and (v is None or str(v).strip() == ""):
        raise RuntimeError(f"Missing required env: {name}")
    return str(v) if v is not None else ""

def _env_int(name: str, default: int) -> int:
    v = _env(name, "")
    if v == "":
        return default
    try:
        return int(v)
    except Exception:
        return default

def _env_float(name: str, default: float) -> float:
    v = _env(name, "")
    if v == "":
        return default
    try:
        return float(v)
    except Exception:
        return default

def _env_bool(name: str, default: bool) -> bool:
    v = _env(name, "")
    if v == "":
        return default
    return v.strip().lower() in ("1", "true", "yes", "y", "on")


# ---------- subprocess helpers ----------
def _run_list(cmd: List[str], timeout: int = 60) -> Tuple[int, str, str, float]:
    t0 = time.time()
    try:
        p = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
        )
        return p.returncode, (p.stdout or ""), (p.stderr or ""), time.time() - t0
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or "") if isinstance(getattr(e, "stdout", ""), str) else ""
        err = (e.stderr or "") if isinstance(getattr(e, "stderr", ""), str) else ""
        if not err:
            err = f"timeout after {timeout}s"
        return 124, out, err, time.time() - t0

def _q(s: str) -> str:
    return shlex.quote(s)

def _run_shell(cmd: str, timeout: float = 8.0) -> Tuple[int, str, float]:
    t0 = time.time()
    p = subprocess.run(
        cmd, shell=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, timeout=timeout,
    )
    return p.returncode, (p.stdout or ""), time.time() - t0


# ---------- IPv6 parsing ----------
def _extract_ipv6(text: str) -> Optional[str]:
    """Best-effort IPv6 extraction from arbitrary CLI output."""
    if not text:
        return None

    # Token-based parse first (most outputs are just an address or 'addr/prefix')
    for tok in re.split(r"[\s\"'\[\]\(\)\{\}<>,;]+", str(text).strip()):
        if ":" not in tok:
            continue
        t = tok.strip().strip(",; ")
        if not t:
            continue
        t = t.split("/")[0]  # drop prefixlen if present
        try:
            ip = ipaddress.IPv6Address(t)
            return str(ip)
        except Exception:
            continue

    # Regex fallback
    for m in re.finditer(r"(?i)\b[0-9a-f]{0,4}:(?:[0-9a-f]{0,4}:){1,6}[0-9a-f]{0,4}\b", str(text)):
        t = m.group(0).split("/")[0]
        try:
            ip = ipaddress.IPv6Address(t)
            return str(ip)
        except Exception:
            pass
    return None


def _is_valid_ipv6(s: str) -> bool:
    if not s:
        return False
    try:
        ip = ipaddress.IPv6Address(str(s).strip())
    except Exception:
        return False
    # Require a global unicast address for WAN connectivity checks
    if ip.is_unspecified or ip.is_loopback or ip.is_multicast:
        return False
    if ip.is_link_local:
        return False
    if not ip.is_global:
        return False
    return True

def _remote_shell(dev: str, baud: str, user: str, shell: str) -> Tuple[int, str, float, str]:
    cpe_console = _env("CPE_CONSOLE", "/home/da40/charter/tools/cpe_console_serial.py")
    cmd = f"{_q(cpe_console)} --device {dev} --baud {baud} --user {user} shell {_q(shell)}"
    rc, out, dur = _run_shell(cmd, timeout=_env_float("SERIAL_SHELL_TIMEOUT_SEC", 15.0))
    return rc, out, dur, cmd

def wait_for_ipv6_serial(dev: str, baud: str, user: str, primary_iface: str, retries: int, wait_ms: int) -> Tuple[Optional[str], Optional[str]]:
    candidates: List[str] = []
    if primary_iface:
        candidates.append(primary_iface)
    if "eth0" not in candidates:
        candidates.append("eth0")

    for attempt in range(1, max(1, retries) + 1):
        for ifname in candidates:
            # NOTE: keep awk expression simple to avoid quoting issues on embedded shells.
            shell = f"ip -6 -o addr show dev {ifname} scope global | awk '{{print $4}}' | cut -d/ -f1 | head -1"
            rc, out, dur, cmd = _remote_shell(dev, baud, user, shell)
            ip = _extract_ipv6((out or "").strip()) or ""
            if _is_valid_ipv6(ip):
                _log_line(f"  ↳ {cmd}  rc={rc}  {dur:0.3f}s")
                _log_line(f"  → ipv6: {ip} (iface={ifname})")
                return ip, ifname
        sleep_s = max(0.05, (wait_ms or 0) / 1000.0) + (0.25 if attempt <= 2 else 0.0)
        time.sleep(sleep_s)
    return None, None



def _global_ipv6_prefixlen_serial(dev: str, baud: str, user: str, iface: str) -> Tuple[Optional[str], Optional[int], Dict[str, Any]]:
    """Read global IPv6 CIDR from interface via serial shell, return (addr, prefixlen, meta)."""
    # NOTE: serial tool output may include extra chatter; we parse IPv6/prefix from the whole stdout.
    shell = f"ip -6 -o addr show dev {iface} scope global | awk '{{print $4}}' | head -1"
    rc, out, dur, cmd = _remote_shell(dev, baud, user, shell)
    raw = (out or "").strip()
    addr = None
    plen = None
    if raw:
        # Prefer explicit CIDR token (addr/prefix)
        m = re.search(r"(?i)\b([0-9a-f:]{2,})/(\d{1,3})\b", raw)
        if m:
            try:
                addr = str(ipaddress.IPv6Address(m.group(1)))
            except Exception:
                addr = None
            try:
                plen = int(m.group(2))
            except Exception:
                plen = None
        else:
            # Fallback: extract a global IPv6 address (prefixlen unknown)
            ip = _extract_ipv6(raw)
            if ip:
                addr = ip
                plen = None

    meta = {
        "rc": rc,
        "sec": round(dur, 3),
        "cmd": cmd,
        "stdout": raw[-400:],
    }
    return addr, plen, meta


def _global_ipv6_prefixlen_ssh(host: str, iface: str, user: str, password: str) -> Tuple[Optional[str], Optional[int], Dict[str, Any]]:
    """Read global IPv6 CIDR from interface via SSH.

    Prefer using tools/cpe_ssh.py --cmd wan-ipv6-detail to avoid parsing shell output.
    Fallback to running `ip -6 ...` via ssh if wan-ipv6-detail is not available.
    """
    timeout = _env_int("SSH_WAN_IPV6_PREFIX_TIMEOUT_SEC", 15)

    # 1) Prefer cpe_ssh.py tool (clean JSON)
    tools_path = _env("TOOLS_PATH", "/home/da40/charter/tools")
    py = _env("TOOLS_PYTHON", "python3")
    cli = os.path.join(tools_path, "cpe_ssh.py")
    tool_cmd = [
        py, cli,
        "--host", host,
        "--cmd", "wan-ipv6-detail",
        "--iface", iface,
        "--user", user,
        "--password", password,
    ]
    masked_tool_cmd = list(tool_cmd)
    try:
        pidx = masked_tool_cmd.index("--password")
        if pidx + 1 < len(masked_tool_cmd):
            masked_tool_cmd[pidx + 1] = "***"
    except Exception:
        pass

    try:
        t0 = time.time()
        cp = subprocess.run(tool_cmd, capture_output=True, text=True, timeout=timeout)
        sec = time.time() - t0
        out = (cp.stdout or "").strip()
        err = (cp.stderr or "").strip()
        if out.startswith("{"):
            try:
                j = json.loads(out)
                addr = j.get("ipv6")
                plen = j.get("prefix_len")
                meta = {"rc": int(j.get("rc", cp.returncode)), "sec": sec, "cmd": " ".join(masked_tool_cmd), "stdout": out, "stderr": err}
                if addr:
                    try:
                        addr = str(ipaddress.IPv6Address(str(addr)))
                    except Exception:
                        pass
                if isinstance(plen, int) and addr:
                    return addr, plen, meta
            except Exception:
                # fall back below
                pass
    except Exception:
        pass

    # 2) Fallback: direct ssh parse
    remote_cmd = f"ip -6 -o addr show dev {iface} scope global | awk '{{print $4}}' | head -1"
    rc, out, err, sec, masked_cmd = _ssh_run(host, user, password, remote_cmd, timeout=timeout)
    raw = (out or "").strip()

    addr: Optional[str] = None
    plen: Optional[int] = None
    if raw:
        m = re.search(r"(?i)\b([0-9a-f:]{2,})/(\d{1,3})\b", raw)
        if m:
            try:
                addr = str(ipaddress.IPv6Address(m.group(1)))
            except Exception:
                addr = None
            try:
                plen = int(m.group(2))
            except Exception:
                plen = None

    meta = {"rc": rc, "sec": sec, "cmd": masked_cmd, "stdout": raw, "stderr": (err or "")}
    return addr, plen, meta
def _wan_ipv6_ssh(host: str, iface: str, user: str, password: str, tools_path: str, py: str) -> Tuple[Optional[str], Dict[str, Any]]:
    cli = os.path.join(tools_path, "cpe_ssh.py")
    cmd = [
        py, cli,
        "--host", host,
        "--cmd", "wan-ipv6",
        "--iface", iface,
        "--user", user,
        "--password", password,
    ]
    # redact password in logs
    cmd_for_log = list(cmd)
    try:
        pidx = cmd_for_log.index("--password")
        if pidx + 1 < len(cmd_for_log):
            cmd_for_log[pidx + 1] = "***"
    except Exception:
        pass
    rc, out, err, sec = _run_list(cmd, timeout=_env_int("SSH_WAN_IPV6_TIMEOUT_SEC", 20))
    raw = (out or "").strip()
    ip = _extract_ipv6(raw or "") or ""
    meta = {"rc": rc, "sec": round(sec, 3), "cmd": " ".join(shlex.quote(x) for x in cmd_for_log), "stdout": raw[-400:], "stderr": (err or "")[-400:]}
    if rc == 0 and _is_valid_ipv6(ip):
        return ip, meta
    # If the CLI prints JSON, try parse it for better meta
    if raw.startswith("{"):
        try:
            j = json.loads(raw)
            meta["json"] = j
            ip2 = (j.get("ipv6") or "") if isinstance(j, dict) else ""
            if _is_valid_ipv6(ip2):
                return ip2, meta
        except Exception:
            pass
    return None, meta


# ---------- NOC SSH enable precondition (copied/adapted from A2435637 pattern) ----------
def _load_noc_profile() -> Tuple[str, str, str]:
    base_env = _env("NOC_BASE", "")
    email_env = _env("NOC_EMAIL", "")
    pass_env = _env("NOC_PASSWORD", "")
    if base_env and email_env and pass_env:
        return base_env, email_env, pass_env

    profiles_path = _env("PROFILES_FILE", "")
    if not profiles_path:
        profiles_path = _env("NOC_PROFILES_PATH", "/home/da40/charter/.secrets/noc_profiles.json", required=True)

    profile_name = _env("NOC_PROFILE", "")
    if not profile_name:
        profile_name = _env("NOC_PROFILE_NAME", "SPECTRUM_INT", required=True)

    with open(profiles_path, "r", encoding="utf-8") as f:
        profiles = json.load(f)

    prof = profiles.get(profile_name)
    if not isinstance(prof, dict):
        raise RuntimeError(f"Profile {profile_name!r} not found in {profiles_path}")
    base = str(prof.get("base") or "")
    email = str(prof.get("email") or "")
    password = str(prof.get("password") or "")
    if not (base and email and password):
        raise RuntimeError(f"Incomplete profile {profile_name!r} in {profiles_path}")
    return base, email, password

def _parse_node_id(s: str) -> str:
    s = (s or "").strip().lower()
    if not s:
        return ""
    m = re.search(r"\b([0-9a-f]{10,})\b", s)
    return (m.group(1) if m else "").lower()

def _serial_node_id(tools_path: str, py: str, dev: str, baud: str, timeout: int = 30) -> Tuple[int, str, str, str]:
    cmd = [
        py,
        os.path.join(tools_path, "cpe_metrics_agent_serial.py"),
        "--device", dev,
        "--baud", baud,
        "--user", "root",
        "--cmd", "node-id",
    ]
    rc, out, err, sec = _run_list(cmd, timeout=timeout)
    nid = _parse_node_id(out) or _parse_node_id(err)
    return rc, out, err, nid

def _wait_serial_node_id(tools_path: str, py: str, dev: str, baud: str) -> Tuple[bool, str]:
    retries = _env_int("SERIAL_NODE_ID_RETRIES", 30)
    interval = _env_int("SERIAL_NODE_ID_INTERVAL_SEC", 5)
    cmd_timeout = _env_int("SERIAL_NODE_ID_TIMEOUT_SEC", 30)

    last_err = ""
    for attempt in range(1, retries + 1):
        rc, out, err, nid = _serial_node_id(tools_path, py, dev, baud, timeout=cmd_timeout)
        if rc == 0 and nid:
            _log("serial_node_id_ok", where="setup", attempt=attempt, node_id=nid)
            return True, nid

        last_err = (err or "").strip() or (out or "").strip()
        _log(
            "serial_node_id_retry",
            where="setup",
            attempt=attempt,
            retries=retries,
            interval_sec=interval,
            timeout_sec=cmd_timeout,
            rc=rc,
            stderr=(err or "")[-300:],
        )
        if attempt < retries:
            time.sleep(interval)

    _log("serial_node_id_fail", where="setup", stderr=last_err[-300:])
    return False, ""


def _node_id_from_cpe_info() -> Tuple[bool, str, int, str]:
    """Fallback node-id source.

    Uses: cpe_info --node-id --value
    Expected format: WAN MAC without ':' and lowercased.

    Returns: (ok, node_id, rc, raw)
    """
    cpe_info = _env("CPE_INFO_BIN", os.environ.get("CPE_INFO_BIN", _DEFAULT_CPE_INFO))
    try:
        p = subprocess.run(
            [cpe_info, "--node-id", "--value"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=_env_int("CPE_INFO_NODEID_TIMEOUT_SEC", 15),
        )
        raw = (p.stdout or "").strip()
        nid = raw.replace(":", "").strip().lower()
        ok = (p.returncode == 0 and bool(nid))
        return ok, nid, p.returncode, raw
    except Exception as e:
        return False, "", 1, str(e)

def _get_location_id(tools_path: str, py: str, base: str, customer_id: str, email: str, password: str, node_id: str) -> Tuple[int, str, str, str]:
    noc_cli = os.path.join(tools_path, "noc_api_cli.py")
    cmd = [
        py, noc_cli,
        "--base", base,
        "--customer-id", customer_id,
        "--email", email,
        "--password", password,
        "get-location",
        "--node-id", node_id,
    ]
    rc, out, err, sec = _run_list(cmd, timeout=_env_int("GET_LOCATION_TIMEOUT_SEC", 60))
    loc = (out or "").strip() if rc == 0 else ""
    return rc, out, err, loc

def _ssh_enable_via_noc(tools_path: str, py: str, base: str, customer_id: str, email: str, password: str, location_id: str, node_id: str, ssh_pass: str) -> Tuple[int, str, str]:
    noc_cli = os.path.join(tools_path, "noc_api_cli.py")
    cmd = [
        py, noc_cli,
        "--base", base,
        "--customer-id", customer_id,
        "--email", email,
        "--password", password,
        "ssh-enable",
        "--location-id", location_id,
        "--node-id", node_id,
        "--ssh-pass", ssh_pass,
    ]
    rc, out, err, sec = _run_list(cmd, timeout=_env_int("SSH_ENABLE_TIMEOUT_SEC", 60))
    return rc, out, err

def _wait_tcp_open(host: str, port: int, timeout_sec: int) -> bool:
    t0 = time.time()
    while True:
        try:
            with socket.create_connection((host, port), timeout=2):
                return True
        except Exception:
            if time.time() - t0 >= timeout_sec:
                return False
            time.sleep(1)

def ensure_ssh_precondition(tools_path: str, py: str, dev: str, baud: str, host: str, ssh_pass: str) -> bool:
    """Enable SSH via NOC, then wait for TCP/22 to open. Returns True if SSH likely enabled."""
    if not _env_bool("ENABLE_SSH_PRECOND", True):
        _log("ssh_precond_skip", reason="ENABLE_SSH_PRECOND_disabled")
        return True

    customer_id = _env("CUSTOMER_ID", "") or _env("NOC_CUSTOMER_ID", "")
    if not customer_id:
        raise RuntimeError("CUSTOMER_ID (or NOC_CUSTOMER_ID) is required")
    base, email, noc_pass = _load_noc_profile()
    # NOTE (DA40 LAB): do NOT use serial/console to obtain node-id.
    # Primary source: cpe_info --node-id --value
    ok2, node_id2, rc2, raw2 = _node_id_from_cpe_info()
    _log("node_id_cpe_info", ok=ok2, rc=rc2, raw=raw2, node_id=node_id2)
    if ok2:
        ok, node_id = True, node_id2
    else:
        _log("ssh_precond_fail", step="node_id_cpe_info", reason="cannot_get_node_id_without_serial")
        _precond_cache_set(host, ssh_pass, False)
        return False

    rc, out, err, loc = _get_location_id(tools_path, py, base, customer_id, email, noc_pass, node_id)
    if rc != 0 or not loc:
        _log("ssh_precond_fail", step="get_location", rc=rc, stderr=(err or "")[-400:], stdout=(out or "")[-200:])
        return False
    _log("location_id_ok", node_id=node_id, location_id=loc)

    rc, out, err = _ssh_enable_via_noc(tools_path, py, base, customer_id, email, noc_pass, loc, node_id, ssh_pass)
    if rc != 0:
        _log("ssh_enable_error", rc=rc, stderr=(err or "")[-400:], stdout=(out or "")[-200:])
        return False
    _log("ssh_enable_ok", raw=(out or "").strip()[:400])

    wait_sec = _env_int("SSH_PORT_WAIT_SEC", 60)
    if not _wait_tcp_open(host, 22, wait_sec):
        _log("ssh_port_not_open", host=host, port=22, waited_sec=wait_sec)
        _precond_cache_set(host, ssh_pass, False)
        # Still return False so caller can decide fallback
        return False
    _log("ssh_port_open", host=host, port=22)
    _precond_cache_set(host, ssh_pass, True)
    return True


# ---------- diagnostics (serial best-effort) ----------
def _serial_diag(dev: str, baud: str, user: str) -> None:
    cmds = [
        "ip -6 -br addr",
        "ip -6 route show default",
        "ip -6 addr show br-wan",
        "ip -6 addr show eth0",
    ]
    _log("wan_ipv6_diag_start")
    for c in cmds:
        rc, out, dur, full = _remote_shell(dev, baud, user, c + " 2>/dev/null || true")
        last = ""
        for ln in (out or "").splitlines():
            if ln.strip():
                last = ln.strip()
        _log("wan_ipv6_diag", cmd=c, rc=rc, sec=round(dur, 3), tail=last[:200])
    _log("wan_ipv6_diag_end")


# ---------- ping ----------
def _ping_once_serial(dev: str, baud: str, user: str, target: str) -> Tuple[bool, int, str, float, str]:
    shell = f"ping -6 -c 1 -W 1 {target} >/dev/null 2>&1; echo $?"
    rc, out, dur, cmd = _remote_shell(dev, baud, user, shell)
    m = re.search(r'(\d+)\s*$', (out or "").strip())
    ok = bool(m and m.group(1) == "0")
    return ok, rc, out, dur, cmd



def _ssh_run(host: str, user: str, password: str, remote_cmd: str, timeout: float = 15.0) -> Tuple[int, str, str, float, str]:
    """Run a command on CPE via SSH (password auth) using sshpass.
    Returns (rc, out, err, sec, masked_cmd_for_log).
    """
    t0 = time.time()
    # Use sh -c (NOT login shell) to avoid banner/MOTD contaminating stdout.
    # Pipes/redirections still work because we pass the full command string.
    wrapped = f"sh -c {_q(remote_cmd)}"
    cmd = [
        "sshpass", "-p", password,
        "ssh",
        "-o", "StrictHostKeyChecking=no",
        "-o", "UserKnownHostsFile=/dev/null",
        "-o", "ConnectTimeout=5",
        "-o", "PreferredAuthentications=password",
        "-o", "PubkeyAuthentication=no",
        f"{user}@{host}",
        wrapped,
    ]
    # Mask password for log
    masked_cmd = " ".join([_q(c) for c in cmd[:2]] + ["'***'"] + [_q(c) for c in cmd[3:]])
    try:
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=timeout)
        return p.returncode, p.stdout or "", p.stderr or "", time.time() - t0, masked_cmd
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or "") if isinstance(getattr(e, "stdout", ""), str) else ""
        err = (e.stderr or "") if isinstance(getattr(e, "stderr", ""), str) else ""
        if not err:
            err = f"timeout after {timeout}s"
        return 124, out, err, time.time() - t0, masked_cmd


def _ping_once_ssh(host: str, target: str, user: str, password: str, tools_path: str, py: str) -> Tuple[bool, Dict[str, Any]]:
    """Ping from CPE via SSH (direct sshpass) and parse latency_ms if possible."""
    timeout = _env_int("SSH_PING_TIMEOUT_SEC", 15)
    rc, out, err, sec, masked_cmd = _ssh_run(host, user, password, f"ping -6 -c 1 -W 1 {target}", timeout=timeout)
    latency_ms = None
    m = re.search(r'time[=<]\s*([0-9.]+)\s*ms', out)
    if m:
        try:
            latency_ms = float(m.group(1))
        except Exception:
            latency_ms = None
    ok = (rc == 0)
    meta = {
        "rc": rc,
        "sec": round(sec, 3),
        "cmd": masked_cmd,
        "stdout": (out or "").strip(),
        "stderr": (err or "").strip(),
        "latency_ms": latency_ms,
    }
    return ok, meta


def _sample_metrics_ssh(
    host: str,
    iface: str,
    user: str,
    password: str,
    latency_ms: float | None = None,
    rate_interval: float = 1.0,
    timeout_sec: float = 30.0,
) -> tuple[bool, dict[str, object]]:
    """Collect basic metrics via the tools module (cpe_ssh.py --cmd metrics).

    This keeps all SSH parsing/collection logic inside the shared tools module.
    """
    tools = "/home/da40/charter/tools/cpe_ssh.py"
    cmd = [
        "python3",
        tools,
        "--host",
        host,
        "--cmd",
        "metrics",
        "--iface",
        iface,
        "--user",
        user,
        "--password",
        password,
        "--rate-interval",
        str(rate_interval),
    ]
    if latency_ms is not None:
        cmd += ["--latency-ms", str(latency_ms)]

    rc, out, err, sec = _run_list(cmd, timeout=timeout_sec + float(rate_interval) + 5.0)

    # mask password in cmd string for logs
    cmd_masked = " ".join(
        shlex.quote(x) if x != password else "'***'"
        for x in cmd
    )

    ok = False
    payload: dict[str, object] = {}
    parse_err = ""
    if out:
        try:
            payload = json.loads(out)
        except Exception as e:
            parse_err = f"{type(e).__name__}: {e}"

    # tool uses rc=0 when ok==true
    ok = (rc == 0) and bool(payload.get("ok", False))

    meta = {
        "ok": ok,
        "rc": rc,
        "sec": round(sec, 3),
        "cmd": cmd_masked,
        "stdout": out.strip(),
        "stderr": err.strip(),
        "parse_error": parse_err,
        "metrics": payload,
    }
    return ok, meta
def run(*, i: int = 1, of: int = 1) -> int:
    name = "C15807061 WAN_IPv6_Connectivity"

    dev = _env("CPE_DEV", "/dev/ttyUSB0")
    baud = _env("CPE_BAUD", "115200")
    serial_user = _env("CPE_USER", "root")
    iface = _env("CPE_IFACE", "br-wan").strip() or "br-wan"

    ping1 = _env("CPE_PING6_1", "8.8.8.8").strip()
    ping2 = _env("CPE_PING6_2", "1.1.1.1").strip()

    retries = _env_int("RETRIES", 3)
    interval = _env_float("INTERVAL_SEC", 1.0)

    api_base = _env("API_BASE", "http://127.0.0.1:8080")

    # Step1 method
    method = _env("WAN_IPV6_METHOD", "serial").strip().lower()
    if method not in ("serial", "ssh", "auto"):
        method = "serial"

    tools_path = _env("TOOLS_PATH", "/home/da40/charter/tools")
    py = _env("TOOLS_PYTHON", "python3")

    host = _env("CPE_HOST", _env("CPE_IP", "192.168.1.1")).strip() or "192.168.1.1"
    ssh_user = _env("CPE_SSH_USER", _env("SSH_USER", "operator"))
    # password preference order
    ssh_pass = _env("CPE_SSH_PASSWORD", _env("SSH_PASSWORD", _env("CPE_PASSWORD", "")))

    # Step2 ping method: serial (default) or ssh.
    # If not set, default to ssh when WAN_IPV6_METHOD=ssh, else serial.
    ping_method = _env("PING_METHOD", "").strip().lower()
    if not ping_method:
        ping_method = "ssh" if method == "ssh" else "serial"
    if ping_method not in ("serial", "ssh"):
        ping_method = "serial"

    # Step3 metrics method: serial (default) or ssh.
    # If not set, default to ssh when WAN_IPV6_METHOD=ssh, else serial.
    metrics_method = _env("METRICS_METHOD", "").strip().lower()
    if not metrics_method:
        metrics_method = "ssh" if method == "ssh" else "serial"
    if metrics_method not in ("serial", "ssh"):
        metrics_method = "serial"

    # header
    _log("runner_start", name=name)
    _log_line(f"[runner] START  {name}")
    _log_line(f"          iface={iface}  ping1={ping1 or '-'} ping2={ping2 or '-'}  retries={retries} interval={int(interval)}s")
    _log(
        "runner_cfg",
        wan_ipv6_method=method,
        ping_method=ping_method,
        metrics_method=metrics_method,
        cpe_host=host,
        ssh_user=ssh_user,
        iface=iface,
        ssh_precond_enabled=_env_bool("ENABLE_SSH_PRECOND", True),
    )

    # ---------- Step 0: optional SSH enable precondition ----------
    # NOTE:
    # - method=ssh  : must enable SSH before Step1
    # - method=auto : we only enable SSH *if* serial Step1 fails and we need to fall back to SSH
    if method == "ssh":
        if not ssh_pass:
            _log("runner_info", msg="SSH password empty; cannot use WAN_IPV6_METHOD=ssh")
            _log("runner_end", passed=False, steps={"wan_ipv4": False, "ping": False, "metrics": False})
            return 1
        try:
            ok_pre = ensure_ssh_precondition(tools_path, py, dev, baud, host, ssh_pass)
        except Exception as e:
            ok_pre = False
            _log("ssh_precond_exception", error=str(e))
        if not ok_pre:
            _log("runner_info", msg="SSH precondition failed; cannot proceed with ssh method")
            # serial diag is best-effort; disabled by default for labs without serial
            if _env_bool("SERIAL_DIAG_ENABLED", False):
                try:
                    _serial_diag(dev, baud, serial_user)
                except Exception as e:
                    _log("serial_diag_exception", error=str(e))
            else:
                _log("serial_diag_skip", reason="SERIAL_DIAG_ENABLED=0")

            _log("runner_end", passed=False, steps={"wan_ipv4": False, "ping": False, "metrics": False})
            return 1

    # ---------- Step 1: Read WAN IPv6 ----------
    _log_line(f"[runner] Step 1 — Read WAN IPv6 (method={method}; expected: {iface} has IPv6; fallback eth0)")
    wan_ipv4_retries = _env_int("WAN_IPV6_RETRIES", _env_int("RETRIES", 5))
    wan_ipv4_wait_ms = _env_int("WAN_IPV6_WAIT_MS", 700)

    ipv6: Optional[str] = None
    used_iface: Optional[str] = None

    if method == "serial":
        ipv6, used_iface = wait_for_ipv6_serial(dev, baud, serial_user, iface, wan_ipv4_retries, wan_ipv4_wait_ms)

    elif method == "ssh":
        ipv6, meta = _wan_ipv6_ssh(host, iface, ssh_user, ssh_pass, tools_path, py)
        _log("wan_ipv6_ssh", ok=bool(ipv6), **meta)
        used_iface = iface if ipv6 else None

    else:  # auto
        ipv6, used_iface = wait_for_ipv6_serial(dev, baud, serial_user, iface, wan_ipv4_retries, wan_ipv4_wait_ms)
    if not ipv6:
            _log("runner_info", msg="serial wan ipv6 not found; will try ssh fallback")
            if not ssh_pass:
                _log("runner_info", msg="SSH password empty; cannot fallback to SSH")
            else:
                # Only now do the NOC ssh-enable precondition (if enabled)
                try:
                    ok_pre = ensure_ssh_precondition(tools_path, py, dev, baud, host, ssh_pass)
                except Exception as e:
                    ok_pre = False
                    _log("ssh_precond_exception", error=str(e))
                if not ok_pre:
                    _log("runner_info", msg="SSH precondition failed; cannot use SSH fallback")
                else:
                    ipv6, meta = _wan_ipv6_ssh(host, iface, ssh_user, ssh_pass, tools_path, py)
                    _log("wan_ipv6_ssh", ok=bool(ipv6), **meta)
                    used_iface = iface if ipv6 else None

    if not ipv6:
        _log_line("[runner] FAIL — WAN IPv6 not found after retries")
        _log("runner_info", msg="WAN IPv6 not found after retries")
        # serial diag is best-effort; disabled by default for labs without serial
        if _env_bool("SERIAL_DIAG_ENABLED", False):
            try:
                _serial_diag(dev, baud, serial_user)
            except Exception as e:
                _log("serial_diag_exception", error=str(e))
        else:
            _log("serial_diag_skip", reason="SERIAL_DIAG_ENABLED=0")

        _log("runner_end", passed=False, steps={"wan_ipv4": False, "ping": False, "metrics": False})
        # If lab/environment has no IPv6, treat as SKIP (N/A) instead of FAIL.
        # Control via env: SKIP_ON_NO_IPV6 (default: 1).
        if _env_bool("SKIP_ON_NO_IPV6", False):
            _log("runner_skip", reason="no_wan_ipv6_in_environment")
            _log_line("[runner] SKIP — environment has no WAN IPv6 (SKIP_ON_NO_IPV6=1)")
            _log("runner_end", passed=False, skipped=True, steps={"wan_ipv6": False, "ping": False, "metrics": False})
            return 0
        return 1

    _log("runner_info", msg=f"WAN IPv6={ipv6} via {used_iface or iface}")

    # ---------- Step 2: Ping Internet (serial or ssh) ----------
    if ping_method == "ssh" and not ssh_pass:
        _log("runner_info", msg="SSH password empty; ping_method=ssh not possible; fallback to serial")
        ping_method = "serial"
    if ping_method == "ssh" and not _precond_cache_get(host, ssh_pass):
        # In case Step1 used serial/auto but Step2 uses SSH
        try:
            ensure_ssh_precondition(tools_path, py, dev, baud, host, ssh_pass)
        except Exception as e:
            _log("ssh_precond_exception", error=str(e))
    
    # Step 1.5 — verify global IPv6 prefix length is /128 (per test plan)
    # Prefer SSH for prefixlen check (serial output may include tool chatter that is hard to parse reliably).
    require_prefix = _env_int("REQUIRE_PREFIXLEN_128", 0)
    prefix_ok = True
    if require_prefix:
        if not ipv6:
            prefix_ok = False
            _log("wan_ipv6_prefix", ok=False, reason="no_ipv6")
        else:
            iface_check = used_iface or iface
            use_ssh_for_prefix = bool(ssh_pass) and (ping_method == "ssh" or method == "ssh" or metrics_method == "ssh")
            if use_ssh_for_prefix:
                addr2, plen, meta_p = _global_ipv6_prefixlen_ssh(host, iface_check, ssh_user, ssh_pass)
                meta_p["method"] = "ssh"
            else:
                addr2, plen, meta_p = _global_ipv6_prefixlen_serial(dev, baud, serial_user, iface_check)
                meta_p["method"] = "serial"

            prefix_ok = (plen == 128)
            _log("wan_ipv6_prefix", ok=prefix_ok, iface=iface_check, addr=(addr2 or ""), prefixlen=plen, **meta_p)
    else:
        _log("wan_ipv6_prefix_skip", ok=True, reason="disabled")

    _log_line(f"[runner] Step 2 — Ping Internet (method={ping_method})")
    ping_ok = False
    last_latency_ms: Optional[float] = None
    for k in range(1, retries + 1):
        ok1 = True
        ok2 = True
        if ping_method == "ssh":
            if ping1:
                ok1, meta1 = _ping_once_ssh(host, ping1, ssh_user, ssh_pass, tools_path, py)
                _log("ping_ssh", target=ping1, ok=bool(ok1), **meta1)
                if ok1 and meta1.get("latency_ms") is not None:
                    last_latency_ms = float(meta1["latency_ms"])
            if ping2:
                ok2, meta2 = _ping_once_ssh(host, ping2, ssh_user, ssh_pass, tools_path, py)
                _log("ping_ssh", target=ping2, ok=bool(ok2), **meta2)
                if ok2 and meta2.get("latency_ms") is not None:
                    last_latency_ms = float(meta2["latency_ms"])
        else:
            if ping1:
                ok1, rc1, out1, dur1, cmd1 = _ping_once_serial(dev, baud, serial_user, ping1)
                _log_line(f"  ↳ {cmd1}  rc={rc1}  {dur1:0.3f}s")
            if ping2:
                ok2, rc2, out2, dur2, cmd2 = _ping_once_serial(dev, baud, serial_user, ping2)
                _log_line(f"  ↳ {cmd2}  rc={rc2}  {dur2:0.3f}s")

        if (ping1 and ping2 and ok1 and ok2) or (ping1 and not ping2 and ok1) or (ping2 and not ping1 and ok2):
            _log_line(f"  ✓ try #{k}: ping ok")
            ping_ok = True
            break
        _log_line(f"  ✗ try #{k}: Not ready yet")
        time.sleep(interval)

    # ---------- Step 3: Sample metrics (serial or ssh) ----------
    metrics_ok = False
    if metrics_method == "ssh":
        if not ssh_pass:
            _log("runner_info", msg="SSH password empty; metrics_method=ssh not possible")
            metrics_ok = False
        else:
            if not _precond_cache_get(host, ssh_pass):
                # In case Step1/Step2 used serial but Step3 uses SSH
                try:
                    ensure_ssh_precondition(tools_path, py, dev, baud, host, ssh_pass)
                except Exception as e:
                    _log("ssh_precond_exception", error=str(e))
            _log_line("[runner] Step 3 — Sample metrics (method=ssh; basic)")
            okm, meta = _sample_metrics_ssh(host, iface, ssh_user, ssh_pass, latency_ms=last_latency_ms, rate_interval=_env_float("SSH_METRICS_RATE_INTERVAL_SEC", 1.0), timeout_sec=_env_float("METRICS_TIMEOUT_SEC", 30.0))
            _log("metrics_ssh", **meta)
            _log_line(f"  ↳ {meta.get('cmd')}  rc={meta.get('rc')}  {meta.get('sec'):0.3f}s")
            _log_line("  ⤷ metrics output:")
            _log_line(f"    {(meta.get('stdout') or '').strip()}")
            metrics_ok = bool(okm)
    else:
        _log_line("[runner] Step 3 — Sample metrics (method=serial)")
        metrics_agent = _env("CPE_METRICS_AGENT", "/home/da40/charter/tools/cpe_metrics_agent_serial.py")
        metrics_cmd = (
            f"{_q(metrics_agent)} --api {api_base} --device {dev} --baud {baud} "
            f"--user {serial_user} --iface {iface} --once --with-wifi"
        )
        mrc, mout, mdur = _run_shell(metrics_cmd, timeout=_env_float("METRICS_TIMEOUT_SEC", 20.0))
        _log_line(f"  ↳ {metrics_cmd}  rc={mrc}  {mdur:0.3f}s")
        _log_line(f"  ℹ metrics agent rc={mrc}")
        _log_line("  ⤷ metrics output:")
        last_line = ""
        for line in (mout or "").splitlines():
            if line.strip():
                last_line = line.strip()
        if last_line:
            _log_line(f"    {last_line}")
        elif (mout or "").strip():
            for ln in mout.splitlines():
                _log_line(f"    {ln}")
        else:
            _log_line("    {}")
        metrics_ok = (mrc == 0)

    passed = bool(ipv6 and prefix_ok and ping_ok and metrics_ok)
    _log("runner_end", passed=passed, steps={"wan_ipv6": True, "ping": ping_ok, "metrics": metrics_ok})
    return 0 if passed else 1


if __name__ == "__main__":
    sys.exit(run())
