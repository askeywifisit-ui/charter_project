#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# shim main that always delegates execution to cycle_wrapper,
# so GUI calling main.py still runs wrapper loops.

def run():
    from cycle_wrapper import run as wrap_run
    rc = wrap_run()
    print("test done", flush=True)
    return rc

if __name__ == "__main__":
    run()
