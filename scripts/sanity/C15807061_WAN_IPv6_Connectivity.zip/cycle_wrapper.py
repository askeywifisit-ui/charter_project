#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os, sys, json, time, pathlib, importlib.util
from typing import Any, Dict, Tuple

try:
    import yaml  # requirements.txt 應已包含 PyYAML
except Exception:
    print("[wrapper] PyYAML not installed", flush=True)
    sys.exit(1)
import subprocess, shlex, re as _re

def _env_bool(name: str, default: bool) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    v = str(v).strip().lower()
    if v in ("1","true","yes","y","on"):
        return True
    if v in ("0","false","no","n","off"):
        return False
    return default

def _env_int(name: str, default: int) -> int:
    v = os.environ.get(name)
    if v is None:
        return default
    try:
        return int(str(v).strip())
    except Exception:
        return default

def _run_cmd(cmd: str, timeout: int) -> tuple[int,str,str]:
    args = shlex.split(cmd)
    p = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    return p.returncode, p.stdout or "", p.stderr or ""

def _parse_cpe_status(text: str) -> tuple[bool,bool]:
    # Example:
    # Internet Status: Connected
    # Cloud Status: Connected
    internet_ok = bool(_re.search(r"Internet\s+Status\s*:\s*Connected", text, _re.IGNORECASE))
    cloud_ok = bool(_re.search(r"Cloud\s+Status\s*:\s*Connected", text, _re.IGNORECASE))
    return internet_ok, cloud_ok

def ensure_cpe_ready_first_cycle() -> int:
    if not _env_bool("CPE_READY_CHECK", True):
        print(json.dumps({"event":"cpe_ready_skip","reason":"CPE_READY_CHECK=0"}), flush=True)
        return 0

    status_cmd = os.environ.get("CPE_INFO_STATUS_CMD", "cpe_info -status")
    max_retries = _env_int("CPE_READY_MAX_RETRIES", 5)
    interval = _env_int("CPE_READY_RETRY_INTERVAL_SEC", 3)
    require_cloud = _env_bool("CPE_READY_REQUIRE_CLOUD", True)

    def _is_ready_once(attempt: int) -> tuple[bool,str]:
        rc, out, err = _run_cmd(status_cmd, timeout=_env_int("PDU_RESET_TIMEOUT_SEC", 600))
        text = (out + "\n" + err).strip()
        internet_ok, cloud_ok = _parse_cpe_status(text)
        ready = internet_ok and (cloud_ok if require_cloud else True)
        print(json.dumps({
            "event":"cpe_ready_check",
            "attempt": attempt,
            "cmd": status_cmd,
            "rc": rc,
            "internet_ok": internet_ok,
            "cloud_ok": cloud_ok,
            "require_cloud": require_cloud,
            "ready": ready
        }), flush=True)
        return ready, text

    # first pass + retries
    for attempt in range(1, max_retries + 1):
        ready, _ = _is_ready_once(attempt)
        if ready:
            return 0
        if attempt < max_retries:
            time.sleep(interval)

    # not ready -> optional PDU reset
    if not _env_bool("PDU_RESET_ON_NOT_READY", True):
        print(json.dumps({"event":"precondition_fail","reason":"cpe_not_ready_no_pdu_reset"}), flush=True)
        return 2

    pdu_script = os.environ.get("PDU_RESET_SCRIPT", "/home/da40/charter/tools/pdu_outlet1.py")
    action = os.environ.get("PDU_RESET_ACTION", "reset")
    python_bin = os.environ.get("TOOLS_PYTHON", "python3")
    pdu_cmd = f"{python_bin} {pdu_script} {action}"
    timeout = _env_int("PDU_RESET_TIMEOUT_SEC", 600)
    print(json.dumps({"event":"pdu_reset_start","cmd":pdu_cmd,"timeout":timeout}), flush=True)
    try:
        rc, out, err = _run_cmd(pdu_cmd, timeout=timeout)
        print(json.dumps({"event":"pdu_reset_done","rc":rc,"stdout":out[-200:],"stderr":err[-200:]}), flush=True)
    except Exception as e:
        print(json.dumps({"event":"pdu_reset_error","error":str(e)}), flush=True)
        return 2

    wait_sec = _env_int("PDU_RESET_WAIT_SEC", 120)
    print(json.dumps({"event":"pdu_reset_wait","secs":wait_sec}), flush=True)
    if wait_sec > 0:
        time.sleep(wait_sec)

    # re-check after reset
    for attempt in range(1, max_retries + 1):
        ready, _ = _is_ready_once(attempt)
        if ready:
            print(json.dumps({"event":"cpe_ready_after_pdu","ready":True}), flush=True)
            return 0
        if attempt < max_retries:
            time.sleep(interval)

    print(json.dumps({"event":"precondition_fail","reason":"cpe_not_ready_after_pdu"}), flush=True)
    return 2

def log(msg: str) -> None:
    print(msg, flush=True)

def _load_manifest() -> Tuple[Dict[str, Any], Dict[str, str], str, int, float]:
    """讀取 manifest.yaml，回傳 (data, env, original_entry, cycles, wait)"""
    here = pathlib.Path(__file__).resolve().parent
    mp = (here / "manifest.yaml")
    if not mp.exists():
        mp = (here / "manifest.yml")

    data: Dict[str, Any] = {}
    if mp.exists():
        data = yaml.safe_load(mp.read_text(encoding="utf-8")) or {}

    menv: Dict[str, str] = {}
    if isinstance(data.get("env"), dict):
        for k, v in data["env"].items():
            menv[str(k)] = "" if v is None else str(v)

    # cycles / wait：env 優先，其次 manifest 項
    def _to_int(x, d): 
        try: return int(str(x))
        except: return d
    def _to_float(x, d):
        try: return float(str(x))
        except: return d

    cycles = _to_int(menv.get("CYCLES", data.get("cycles", 1)), 1)
    wait   = _to_float(menv.get("CYCLE_INTERVAL", data.get("wait", 0.5)), 0.5)

    # ORIGINAL_ENTRY（預設 main_impl.py:run），也支援舊欄位 entrypoint/original_entry
    original_entry = menv.get("ORIGINAL_ENTRY") \
                     or data.get("original_entry") \
                     or data.get("entrypoint") \
                     or "main_impl.py:run"
    return data, menv, original_entry, cycles, wait

def _load_entry_callable(entry: str):
    """支援 'file.py:func' 或 'pkg.module:func'"""
    if ":" not in entry:
        raise ValueError(f"Invalid ORIGINAL_ENTRY: {entry} (expect 'target:func')")
    target, func = entry.split(":", 1)
    here = pathlib.Path(__file__).resolve().parent

    if target.endswith(".py"):
        fpath = (here / target).resolve()
        if not fpath.exists():
            raise FileNotFoundError(f"Entry file not found: {fpath}")
        mod_name = fpath.stem
        spec = importlib.util.spec_from_file_location(mod_name, str(fpath))
        if spec is None or spec.loader is None:
            raise ImportError(f"Cannot load spec from file: {fpath}")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)  # type: ignore
    else:
        mod = importlib.import_module(target)

    if not hasattr(mod, func):
        raise AttributeError(f"Function '{func}' not found in '{target}'")
    fn = getattr(mod, func)

    def _wrapped() -> int:
        rc = fn()
        try:
            return int(rc or 0)
        except Exception:
            return 0
    return _wrapped

def run() -> int:
    #log("[runner] entry: cycle_wrapper run")
    data, menv, original_entry, cycles, wait = _load_manifest()
    print(json.dumps({"event": "wrapper_start", "cycles": cycles, "wait": wait}), flush=True)

    # 將 manifest 的 env 寫入 os.environ（manifest 覆蓋 OS）
    backup: Dict[str, str | None] = {}
    for k, v in menv.items():
        backup[k] = os.environ.get(k)
        os.environ[k] = v

    child = _load_entry_callable(original_entry)

    overall_rc = 0
    for i in range(1, cycles + 1):
        print(json.dumps({"event": "wrapper_iter", "i": i, "of": cycles}), flush=True)
        if i == 1:
            pre_rc = ensure_cpe_ready_first_cycle()
            if pre_rc != 0:
                overall_rc = pre_rc
                break

        try:
            rc = int(child() or 0)
            if rc != 0:
                overall_rc = 1    # 任一圈失敗 → 最終失敗
        except Exception as e:
            overall_rc = 1
            print(json.dumps({"event": "wrapper_error", "i": i, "error": str(e)}), flush=True)
        if i < cycles and wait > 0:
            time.sleep(wait)

    # 還原環境變數
    for k in menv.keys():
        if backup.get(k) is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = backup[k]  # type: ignore
    log("[runner] test done")                               # ← 放在這裡
    print(json.dumps({"event": "wrapper_end", "passed": (overall_rc == 0)}), flush=True)
    log(f"[runner] exit_code={overall_rc}")

    return overall_rc

if __name__ == "__main__":
    sys.exit(run())
