# C15807061_WAN_IPv6_Connectivity

## 1) 目的 / 覆蓋範圍
- 驗證 WAN IPv6 連通性。

## 2) 前置條件 / 環境
- 需環境具備 IPv6（若無 IPv6：可標記不跑，但仍需備份）。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'# 循環次數（整數 >=1）
- CYCLE_INTERVAL：'60'# 每次循環間隔（秒）

## 5) PASS/FAIL 判定
- PASS：IPv6 連通性檢查成功。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807061_WAN_IPv6_Connectivity

## 1) 目的 / 覆蓋範圍
- 驗證 WAN IPv6 連通性（依環境/ISP 是否提供 IPv6）。

## 2) 前置條件 / 環境
- 需要環境具備 IPv6（若環境無 IPv6，此腳本應標記為「不跑但仍備份」）。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'# 循環次數（整數 >=1）
- CYCLE_INTERVAL：'60'# 每次循環間隔（秒）

## 5) PASS/FAIL 判定
- PASS：IPv6 連通性檢查成功。
- FAIL：無 IPv6 或路由/防火牆阻擋等。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807061 WAN IPv6 Connectivity

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'# 循環次數（整數 >=1）
- CYCLE_INTERVAL：'60'# 每次循環間隔（秒）

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807061 WAN IPv6 Connectivity
Entry: cycle_wrapper.py:run

- Parameters are read from manifest.yaml -> env: {"CYCLES","CYCLE_INTERVAL",...}
- Wrapper calls ORIGINAL_ENTRY (defaults to main.py:run) each cycle.

NOTE: This build includes shim main.py delegating to cycle_wrapper.


## Step1 WAN IPv6 method

This script supports `WAN_IPV6_METHOD`:
- `serial` (default): read WAN IPv6 via serial console.
- `ssh`: enable SSH via NOC precondition, then read WAN IPv6 via SSH (`cpe_ssh.py --cmd wan-ipv6`).
- `auto`: try serial first; if not found then try SSH.

When using `ssh/auto`, set `SSH_PASSWORD` (or `CPE_SSH_PASSWORD`) and provide NOC credentials via `CUSTOMER_ID`, `PROFILES_FILE`, and `NOC_PROFILE`.


## SSH WAN IPv6 mode
- Set `WAN_IPV6_METHOD: 'ssh'` to force Step1 via SSH (will run NOC ssh-enable precondition first).
- Set `WAN_IPV6_METHOD: 'auto'` to try serial first; if serial cannot find WAN IPv6 then it will run NOC ssh-enable and retry via SSH.


Backward compatibility: the script also accepts `NOC_CUSTOMER_ID` / `NOC_PROFILES_PATH` / `NOC_PROFILE_NAME` if the new keys are not set.
```

```
```


## 補充（11F LAB 無 IPv6 的行為）
- 當偵測不到 WAN IPv6 時：預設以 **FAIL** 結束（`SKIP_ON_NO_IPV6=0`），避免整體報表被 fail 汙染。
- SSH precondition 取得 node-id：改為 **僅使用 `cpe_info --node-id --value`**（不使用 serial/console）。


## 驗證紀錄（Evidence）
### 客戶環境（有 IPv6）— PASS 範例
- run：#5336（script_id=4363）
- 重點：
  - node_id：a08a0652d506（cpe_info）
  - location_id：693285aaa5dc9d0f5da63310
  - ssh_enable_ok → ssh_port_open(22)
  - WAN IPv6：2001:b030:140:68::680d
  - ping6：2001:4860:4860::8888 OK；2606:4700:4700::1111 OK
- exit_code=0（PASS）
