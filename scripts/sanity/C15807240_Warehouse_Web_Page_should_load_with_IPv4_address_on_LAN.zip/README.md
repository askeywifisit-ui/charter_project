# C15807240_Warehouse_Web_Page_should_load_with_IPv4_address_on_LAN

## 1) 目的 / 覆蓋範圍
- 驗證特定 Web UI page 可在 LAN（IPv4/IPv6 link-local/Domain）載入。

## 2) 前置條件 / 環境
- 需 client 能存取 CPE Web UI（IPv4/IPv6/Domain 視腳本）。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'70'

## 5) PASS/FAIL 判定
- PASS：HTTP/頁面載入成功（依腳本判定）。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807240 - Warehouse Web Page should load with IPv4 address on LAN

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'70'

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15807240 - Warehouse Web Page should load with IPv4 address on LAN

This script automates the "Warehouse Web Page should load with IPv4 address on LAN" test flow using:
- NOC API (factory reset + Wi‑Fi SSID/password change)
- Warehouse page fetch/parse via `cpe_warehouse_info.py` (IPv4 forced)

## What it verifies
1. (Optional) Factory reset via NOC API, then waits for the device to come back.
2. HTTP `http://192.168.1.1/warehouse` redirects to HTTPS (optional check).
3. Warehouse page `https://192.168.1.1/cgi-bin/warehouse.cgi` loads via IPv4 and returns a valid table.
4. Required fields exist, and key values look sane (IPv4 fields contain IPv4, etc.).
5. Default SSID/Password look like Base64 and decode to non-empty strings (optional).
6. (Optional) Change SSID/password via NOC API and verify warehouse page reflects the change.
7. (Optional) Validate MAC fields shown on the warehouse page against `ifconfig -a` on the CPE (via SSH).

## Key envs
See `manifest.yaml` for the full list. Most common:
- `NOC_PROFILE` + `PROFILES_FILE` (recommended)
- `CUSTOMER_ID`
- `METRICS_TOOL` + `CPE_DEV` (for node-id)
- `WAREHOUSE_ID` / `WAREHOUSE_PASSWORD`

### MAC validation via SSH (optional)
- `VALIDATE_MACS=1` to enable.
- `SSH_PASSWORD` is required (and is also used for NOC `ssh_enable` when `SSH_ENABLE_VIA_NOC=1`).
- Interface name candidates can be overridden via:
  - `WAN_IFACES`, `LAN_IFACES`, `WLAN24_IFACES`, `WLAN5_IFACES`, `WLAN6_IFACES`

## Entry
`cycle_wrapper.py:run` (supports CYCLES / STOP_ON_FAIL / CPE_READY precondition / PDU reset)
```

```
