#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""C15807240 - Warehouse Web Page should load with IPv4 address on LAN

Automation outline:
  1) Resolve NOC credentials (profiles.json recommended) and login.
  2) Resolve node-id via serial metrics tool, then resolve location-id.
  3) (Optional) Factory Reset via NOC API.
  4) Verify http://192.168.1.1/warehouse redirects to HTTPS (optional).
  5) Fetch/parse warehouse.cgi via IPv4 (-4) using cpe_warehouse_info.py.
  6) Validate required fields and sanity checks.
  7) (Optional) Change Wi-Fi SSID/Password via NOC API and re-validate warehouse values.

All logs are emitted as one-line JSON to be charter-runner friendly.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple


# -------------------------------------------------
# Load tools (noc_api_cli) from TOOLS_PATH
# -------------------------------------------------
TOOLS_PATH = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
if TOOLS_PATH and TOOLS_PATH not in sys.path:
    sys.path.insert(0, TOOLS_PATH)

try:
    import noc_api_cli as noc  # type: ignore
except Exception as e:
    noc = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "noc_api_cli", "error": str(e)}), flush=True)


LOOP_FAIL = True


# -------------------------------------------------
# helpers
# -------------------------------------------------

def jlog(event: str, **kv: Any) -> None:
    payload = {"event": event}
    payload.update(kv)
    print(json.dumps(payload, ensure_ascii=False), flush=True)


def env_str(key: str, default: str = "") -> str:
    v = os.environ.get(key)
    if v is None:
        return default
    return str(v)


def env_int(key: str, default: int) -> int:
    try:
        return int(str(os.environ.get(key, str(default))).strip())
    except Exception:
        return default


def env_bool(key: str, default: bool = False) -> bool:
    v = os.environ.get(key)
    if v is None:
        return default
    s = str(v).strip().lower()
    if s in ("1", "true", "yes", "y", "on"):
        return True
    if s in ("0", "false", "no", "n", "off"):
        return False
    return default


def _norm_key(s: str) -> str:
    # normalize for fuzzy matching
    return re.sub(r"[^a-z0-9]", "", (s or "").strip().lower())


def _looks_ipv4(s: str) -> bool:
    s = (s or "").strip()
    if not s:
        return False
    m = re.search(r"\b(\d{1,3})(?:\.(\d{1,3})){3}\b", s)
    if not m:
        return False
    parts = m.group(0).split(".")
    try:
        return all(0 <= int(p) <= 255 for p in parts)
    except Exception:
        return False


def _looks_base64(s: str) -> bool:
    s = (s or "").strip()
    if len(s) < 8:
        return False
    if re.fullmatch(r"[A-Za-z0-9+/]+={0,2}", s) is None:
        return False
    # base64 length is usually multiple of 4 (padding may apply)
    return len(s) % 4 == 0


def _b64_decode_safe(s: str) -> str:
    import base64

    try:
        return base64.b64decode((s or "").encode("utf-8"), validate=False).decode("utf-8", "ignore").strip()
    except Exception:
        return ""


def _norm_mac(s: str) -> str:
    """Normalize MAC to upper-case colon format (best-effort)."""
    s = (s or "").strip().upper()
    s = s.replace("-", ":")
    s = re.sub(r"[^0-9A-F:]", "", s)
    # ensure it's like XX:XX:XX:XX:XX:XX when possible
    m = re.search(r"([0-9A-F]{2}(?::[0-9A-F]{2}){5})", s)
    return m.group(1) if m else s


def _strip_ansi(s: str) -> str:
    return re.sub(r"\x1B\[[0-9;?]*[ -/]*[@-~]", "", s or "").replace("\r", "")


def _parse_ifconfig_macs(text: str) -> Dict[str, str]:
    """Parse `ifconfig -a` (BusyBox/Linux) or `ip -o link` output to iface->MAC."""
    text = _strip_ansi(text)
    macs: Dict[str, str] = {}

    # ip -o link format: "2: br-wan: ... link/ether 90:d3:..."
    for line in text.splitlines():
        m = re.search(r"^\s*\d+\s*:\s*([^:]+):.*\blink/(?:ether|loopback)\s+((?:[0-9a-f]{2}:){5}[0-9a-f]{2})\b",
                      line, re.I)
        if m:
            iface = m.group(1).strip()
            macs[iface] = _norm_mac(m.group(2))

    # ifconfig format (first line often includes HWaddr)
    cur_if: Optional[str] = None
    for line in text.splitlines():
        if not line.strip():
            cur_if = None
            continue

        # interface header
        m_hdr = re.match(r"^([\w.-]+)\s+Link\s+encap", line)
        if m_hdr:
            cur_if = m_hdr.group(1)

        # HWaddr in same line
        # - BusyBox ifconfig sometimes prints hyphen-separated and/or extended HWaddr for UNSPEC links:
        #     HWaddr 90-D3-CF-EB-6A-4A-00-00-00-00-...
        #   We capture the first 6 bytes (the only part we care about) and normalize.
        m_hw = re.search(
            r"\bHWaddr\s+((?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}(?:[:-][0-9A-Fa-f]{2}){0,20})",
            line,
        )
        if m_hw and cur_if:
            macs[cur_if] = _norm_mac(m_hw.group(1))

        # some builds show "ether xx:xx..." in ifconfig output
        m_eth = re.search(r"\bether\s+((?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2})\b", line)
        if m_eth and cur_if and cur_if not in macs:
            macs[cur_if] = _norm_mac(m_eth.group(1))

        # header variant like: "br-wan    Link encap:Ethernet  HWaddr ..." already handled

    return macs


def _split_csv_env(key: str, default_csv: str) -> list[str]:
    raw = env_str(key, default_csv).strip()
    items = [x.strip() for x in raw.split(",") if x.strip()]
    return items


def maybe_enable_ssh(creds: 'NocCreds', token: str, location_id: str, node_id: str) -> None:
    """Enable SSH via NOC (optional)."""
    if noc is None:
        raise RuntimeError("noc_api_cli import failed")

    if not env_bool("SSH_ENABLE_VIA_NOC", True):
        jlog("ssh_enable_skip", reason="env_disabled")
        return

    passwd = (env_str("SSH_PASSWORD", "").strip() or env_str("OPERATOR_PASSWORD", "").strip())
    if not passwd:
        jlog("ssh_enable_skip", reason="missing_SSH_PASSWORD")
        return

    timeout_min = env_int("SSH_TIMEOUT_MIN", 30)
    customer_id = env_str("CUSTOMER_ID")
    jlog("ssh_enable_start", customer_id=customer_id, location_id=location_id, node_id=node_id, timeout_min=timeout_min)
    try:
        noc.ssh_enable(
            creds.base,
            customer_id,
            location_id,
            node_id,
            passwd,
            timeout_min,
            token=token,
            bearer=creds.bearer,
            insecure=creds.insecure,
        )
        jlog("ssh_enable_sent", timeout_min=timeout_min)
    except Exception as e:
        jlog("ssh_enable_error", error=str(e))

    wait_s = env_int("SSH_ENABLE_WAIT_SEC", 10)
    if wait_s > 0:
        jlog("ssh_enable_wait", secs=wait_s)
        time.sleep(wait_s)


def validate_macs_against_ifconfig(table: Dict[str, str]) -> Tuple[bool, Dict[str, Any]]:
    """Validate warehouse MAC fields against CPE `ifconfig -a` output via SSH."""
    details: Dict[str, Any] = {}

    host = env_str("SSH_HOST", "192.168.1.1").strip() or "192.168.1.1"
    user = env_str("SSH_USER", "operator").strip() or "operator"
    password = (env_str("SSH_PASSWORD", "").strip() or env_str("OPERATOR_PASSWORD", "").strip())
    bind_src = env_str("SSH_BIND_SRC", "").strip() or None
    timeout = float(env_int("SSH_CMD_TIMEOUT_SEC", 10))
    retries = env_int("SSH_RETRIES", 10)
    interval = float(env_int("SSH_RETRY_INTERVAL_SEC", 3))

    if not password:
        return False, {"reason": "missing_SSH_PASSWORD"}

    try:
        import cpe_ssh  # type: ignore
    except Exception as e:
        return False, {"reason": "import_cpe_ssh_failed", "error": str(e)}

    cmd = "ifconfig -a 2>/dev/null || ifconfig 2>/dev/null || ip -o link 2>/dev/null"
    last = None
    out = ""
    for attempt in range(1, retries + 1):
        rc, o, err, sec = cpe_ssh.ssh_exec(host, user, password, cmd, timeout=timeout, login_shell=True, bind_src=bind_src)
        out = (o or "")
        last = {"attempt": attempt, "rc": rc, "sec": sec, "err_head": (err or "")[:160].strip(), "out_head": _strip_ansi(out)[:200].strip()}
        if rc == 0 and out.strip():
            break
        if attempt < retries:
            time.sleep(max(0.0, interval))

    details["ssh_last"] = last
    if not out.strip():
        details["reason"] = "ssh_no_output"
        return False, details

    macs = _parse_ifconfig_macs(out)
    details["ifaces_found"] = len(macs)
    details["macs_head"] = dict(list(macs.items())[:20])
    if not macs:
        details["reason"] = "parse_no_macs"
        return False, details

    # Candidate iface lists (override via env if needed)
    # Note: Some firmware prints radio macs under wifi0/1/2 (Link encap:UNSPEC) rather than home-ap-*.
    cand = {
        "WAN": _split_csv_env("WAN_IFACES", "br-wan"),
        "LAN": _split_csv_env("LAN_IFACES", "br-home,BR_LAN,br-lan,br0"),
        "WLAN24": _split_csv_env("WLAN24_IFACES", "wifi0,home-ap-24,wlan0"),
        # Some devices swap wifi1/wifi2 between 5G/6G. We include both and (by default) pick by MAC match.
        "WLAN5": _split_csv_env("WLAN5_IFACES", "wifi1,wifi2,home-ap-50,wlan1"),
        "WLAN6": _split_csv_env("WLAN6_IFACES", "wifi2,wifi1,home-ap-60,wlan2"),
    }

    prefer_match = env_bool("MAC_PICK_PREFER_MATCH", True)

    def _existing_iface_name(x: str) -> Optional[str]:
        if x in macs:
            return x
        # fuzzy: normalized key match
        norm = {_norm_key(k): k for k in macs.keys()}
        nk = _norm_key(x)
        return norm.get(nk)

    def pick(role: str, candidates: list[str], expected_mac: str) -> Optional[str]:
        """Pick an iface for a role.

        Strategy:
          1) If prefer_match and expected_mac present: pick the first candidate whose MAC matches expected.
          2) Else pick the first candidate that exists.
        """
        existing: list[str] = []
        for x in candidates:
            real = _existing_iface_name(x)
            if real and real not in existing:
                existing.append(real)

        if prefer_match and expected_mac and existing:
            for iface in existing:
                if _norm_mac(macs.get(iface, "")) == expected_mac:
                    return iface

        return existing[0] if existing else None

    expected_map = {
        "WAN": _norm_mac(table.get("WAN MAC Address", "")),
        "LAN": _norm_mac(table.get("LAN MAC Address", "")),
        "WLAN24": _norm_mac(table.get("WLAN2.4 MAC Address", "")),
        "WLAN5": _norm_mac(table.get("WLAN5.0 MAC Address", "")),
        "WLAN6": _norm_mac(table.get("WLAN6.0 MAC Address", "")),
    }

    mapping = {
        "WAN MAC Address": ("WAN", pick("WAN", cand["WAN"], expected_map["WAN"])),
        "LAN MAC Address": ("LAN", pick("LAN", cand["LAN"], expected_map["LAN"])),
        "WLAN2.4 MAC Address": ("WLAN24", pick("WLAN24", cand["WLAN24"], expected_map["WLAN24"])),
        "WLAN5.0 MAC Address": ("WLAN5", pick("WLAN5", cand["WLAN5"], expected_map["WLAN5"])),
        "WLAN6.0 MAC Address": ("WLAN6", pick("WLAN6", cand["WLAN6"], expected_map["WLAN6"])),
    }

    issues = []
    checks = []
    for wh_key, (role, iface) in mapping.items():
        expected = _norm_mac(table.get(wh_key, ""))
        actual = ""
        if iface:
            actual = _norm_mac(macs.get(iface, ""))

        checks.append({
            "warehouse_key": wh_key,
            "role": role,
            "iface": iface,
            "expected": expected,
            "actual": actual,
        })

        if not expected:
            issues.append({"warehouse_key": wh_key, "reason": "missing_in_warehouse"})
            continue
        if not iface:
            issues.append({"warehouse_key": wh_key, "reason": "iface_not_found", "candidates": cand.get(role, [])})
            continue
        if not actual:
            issues.append({"warehouse_key": wh_key, "reason": "mac_not_found_on_iface", "iface": iface})
            continue
        if expected != actual:
            issues.append({"warehouse_key": wh_key, "reason": "mismatch", "iface": iface, "expected": expected, "actual": actual})

    details["checks"] = checks
    details["issues"] = issues
    return len(issues) == 0, details


@dataclass
class NocCreds:
    base: str
    email: str
    password: str
    bearer: bool
    insecure: bool


def load_noc_creds() -> NocCreds:
    bearer = env_bool("BEARER", False)
    insecure = env_bool("INSECURE", False)

    profile = env_str("NOC_PROFILE", "").strip()
    profiles_file = env_str("PROFILES_FILE", "").strip() or os.path.expanduser("~/.secrets/noc_profiles.json")

    if profile:
        try:
            with open(profiles_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            prof = data.get(profile) or data.get(profile.upper())
            if prof and prof.get("base") and prof.get("email") and prof.get("password"):
                jlog("noc_profile_loaded", profile=profile, profiles_file=profiles_file)
                return NocCreds(
                    base=str(prof["base"]),
                    email=str(prof["email"]),
                    password=str(prof["password"]),
                    bearer=bearer,
                    insecure=insecure,
                )
            jlog("noc_profile_missing", profile=profile, profiles_file=profiles_file)
        except Exception as e:
            jlog("noc_profile_load_error", profile=profile, profiles_file=profiles_file, error=str(e))

    # fallback to direct env
    base = env_str("NOC_BASE", "").strip()
    email = env_str("NOC_EMAIL", "").strip()
    password = env_str("NOC_PASSWORD", "").strip()
    if not (base and email and password):
        raise RuntimeError("Missing NOC credentials: provide NOC_PROFILE/PROFILES_FILE or NOC_BASE/NOC_EMAIL/NOC_PASSWORD")

    jlog("noc_profile_fallback_env", base=base)
    return NocCreds(base=base, email=email, password=password, bearer=bearer, insecure=insecure)


def noc_login(creds: NocCreds) -> str:
    if noc is None:
        raise RuntimeError("noc_api_cli import failed")
    tok = noc.login(creds.base, creds.email, creds.password, bearer=creds.bearer, insecure=creds.insecure)
    jlog("noc_login_ok")
    return tok


def node_id_fallback_via_cpe_info() -> Optional[str]:
    """
    Fallback: use cpe_info to derive node_id from WAN MAC.
    Expected command (tool-style):
      cpe_info --node-id --value
    Returns node_id (12 hex) or None.
    """
    tool = env_str("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info").strip() or "/home/da40/charter/tools/cpe_info"

    # Allow using bundled tool in script directory if present
    if not os.path.exists(tool):
        local_tool = os.path.join(os.path.dirname(__file__), "cpe_info")
        if os.path.exists(local_tool):
            tool = local_tool

    args = [tool, "--node-id", "--value"]

    # If not executable or looks like a .py file, run with python explicitly
    cmd = args
    if (tool.endswith(".py")) or (not os.access(tool, os.X_OK)):
        cmd = [sys.executable] + args

    jlog("node_id_fallback_cmd", cmd=cmd)
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

    out = (p.stdout or "").strip()
    err = (p.stderr or "").strip()
    if p.returncode != 0:
        raise RuntimeError(f"cpe_info rc={p.returncode}: {(err or out)[-400:]}")

    node_id = out.strip().lower()
    if not re.fullmatch(r"[0-9a-f]{12}", node_id):
        raise RuntimeError(f"unexpected node_id from cpe_info: {out!r}")

    return node_id


def resolve_node_id() -> str:
    if noc is None:
        raise RuntimeError("noc_api_cli import failed")

    metrics_tool = env_str("METRICS_TOOL", "").strip()
    dev = env_str("CPE_DEV", "").strip()
    baud = env_int("CPE_BAUD", 115200)
    user = env_str("CPE_USER", "root").strip() or "root"
    password = env_str("CPE_PASSWORD", "").strip()

    max_retries = env_int("NODE_ID_MAX_RETRIES", 5)
    interval = float(env_int("NODE_ID_RETRY_INTERVAL_SEC", 3))

    last_err: Optional[str] = None
    for attempt in range(1, max_retries + 1):
        try:
            node_id = noc.serial_get_node_id(metrics_tool, dev, baud, user, password)
            jlog("node_id_ok", attempt=attempt, node_id=node_id)
            return node_id
        except Exception as e:
            last_err = str(e)
            jlog("node_id_retry", attempt=attempt, max_retries=max_retries, error=last_err)

            # Fallback: use cpe_info to derive node_id (WAN MAC -> node_id)
            if env_bool("NODE_ID_FALLBACK_CPE_INFO", True):
                try:
                    nid = node_id_fallback_via_cpe_info()
                    jlog("node_id_fallback_ok", attempt=attempt, node_id=nid)
                    return nid
                except Exception as fe:
                    jlog("node_id_fallback_fail", attempt=attempt, error=str(fe))

            if attempt < max_retries:
                time.sleep(max(0.0, interval))

    raise RuntimeError(f"node-id resolve failed: {last_err}")


def resolve_location_id(creds: NocCreds, token: str, node_id: str) -> str:
    if noc is None:
        raise RuntimeError("noc_api_cli import failed")
    loc = noc.get_location_id(creds.base, env_str("CUSTOMER_ID"), node_id, token=token, bearer=creds.bearer, insecure=creds.insecure)
    jlog("location_id_ok", location_id=loc)
    return loc


def do_factory_reset(creds: NocCreds, token: str, location_id: str) -> None:
    if noc is None:
        raise RuntimeError("noc_api_cli import failed")

    customer_id = env_str("CUSTOMER_ID")
    jlog("factory_reset_start", customer_id=customer_id, location_id=location_id)
    # options=None => full reset (backwards compatible)
    noc.factory_reset(creds.base, customer_id, location_id, token=token, bearer=creds.bearer, insecure=creds.insecure, options=None)
    jlog("factory_reset_sent")
    # -----------------------------
    # Optional: console mute during reboot window
    #
    # After factory reset, the CPE will reboot. Some environments have background
    # jobs that read/write the serial console; muting the console avoids contention
    # and reduces noisy logs during the reboot window.
    #
    # Compatible with A2435637 naming:
    #   - RESET_MUTE_SECS (preferred)
    #   - RESET_MUTE_WITH_LOCK (0/1)
    #
    # Backward compatible:
    #   - FACTORY_RESET_MUTE_SECS / FR_MUTE_SECS
    #   - FACTORY_RESET_MUTE_WITH_LOCK / FR_MUTE_WITH_LOCK
    # -----------------------------
    mute_raw = (
        env_str('RESET_MUTE_SECS', '').strip()
        or env_str('FACTORY_RESET_MUTE_SECS', '').strip()
        or env_str('FR_MUTE_SECS', '').strip()
    )

    if not mute_raw:
        jlog('factory_reset_mute_console_skip', reason='env_not_set')
    else:
        try:
            mute_secs = int(mute_raw)
        except Exception:
            mute_secs = 0
            jlog('factory_reset_mute_console_invalid', mute_raw=mute_raw)

        if mute_secs <= 0:
            jlog('factory_reset_mute_console_skip', reason='mute_secs<=0', mute_raw=mute_raw)
        else:
            use_lock = (
                env_bool('RESET_MUTE_WITH_LOCK', False)
                or env_bool('FACTORY_RESET_MUTE_WITH_LOCK', False)
                or env_bool('FR_MUTE_WITH_LOCK', False)
            )
            lock_timeout = env_int('CONSOLE_LOCK_TIMEOUT_SEC', env_int('FACTORY_RESET_MUTE_LOCK_TIMEOUT_SEC', 5))
            retry_timeout = env_int('CONSOLE_LOCK_RETRY_TIMEOUT_SEC', 60)
            retry_interval = env_int('CONSOLE_LOCK_RETRY_INTERVAL_SEC', 3)

            # Prefer cpe_ssh helper (it writes /home/da40/charter/var/serial.mute via serial_mute.py)
            until_ts = None
            t0 = time.time()
            attempt = 0
            while True:
                attempt += 1
                try:
                    import cpe_ssh  # type: ignore
                    until_ts = cpe_ssh.set_console_mute(mute_secs, use_lock=use_lock, lock_timeout=lock_timeout)
                    jlog(
                        'factory_reset_mute_console',
                        mute_secs=mute_secs,
                        use_lock=use_lock,
                        lock_timeout=lock_timeout,
                        until_ts=until_ts,
                        attempt=attempt,
                    )
                    break
                except Exception as e:
                    elapsed = time.time() - t0
                    if elapsed >= retry_timeout:
                        jlog(
                            'factory_reset_mute_console_fail',
                            mute_secs=mute_secs,
                            use_lock=use_lock,
                            lock_timeout=lock_timeout,
                            attempts=attempt,
                            retry_timeout=retry_timeout,
                            error=str(e),
                        )
                        break
                    jlog(
                        'factory_reset_mute_console_retry',
                        mute_secs=mute_secs,
                        use_lock=use_lock,
                        lock_timeout=lock_timeout,
                        attempt=attempt,
                        retry_in_sec=retry_interval,
                        elapsed_sec=round(elapsed, 3),
                        error=str(e),
                    )
                    time.sleep(retry_interval)

            # Fallback: call serial_mute.py directly (still updates the same global flag)
            if until_ts is None:
                sm = os.path.join(TOOLS_PATH or '/home/da40/charter/tools', 'serial_mute.py')
                if os.path.exists(sm):
                    cmd = [sys.executable, sm, '--set', str(mute_secs)]
                    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                    jlog(
                        'factory_reset_mute_console_fallback',
                        cmd=cmd,
                        rc=p.returncode,
                        out=(p.stdout or '').strip(),
                        err=(p.stderr or '').strip(),
                    )
    settle = env_int("FR_SETTLE_WAIT_SEC", 120)
    if settle > 0:
        jlog("factory_reset_settle_wait", secs=settle)
        time.sleep(settle)


def check_http_redirect(http_url: str, timeout_sec: int = 5) -> Tuple[bool, Dict[str, str]]:
    # Use curl HEAD to avoid TLS/auth issues; we only check Location.
    cmd = [
        "curl",
        "-4",
        "-sSI",
        "-m",
        str(max(1, timeout_sec)),
        http_url,
    ]
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    out = (p.stdout or "")
    status = ""
    location = ""
    for line in out.splitlines():
        if not status and line.lower().startswith("http/"):
            status = line.strip()
        if line.lower().startswith("location:"):
            location = line.split(":", 1)[1].strip()

    ok = False
    code = None
    m = re.search(r"\s(\d{3})\s", status)
    if m:
        try:
            code = int(m.group(1))
        except Exception:
            code = None

    if code in (301, 302, 303, 307, 308) and location.lower().startswith("https://"):
        ok = True

    info = {"status": status, "location": location, "rc": str(p.returncode)}
    return ok, info


def fetch_warehouse(ip_mode: str = "4") -> Dict[str, str]:
    tool = env_str("WAREHOUSE_TOOL", "/home/da40/charter/tools/cpe_warehouse_info.py").strip()
    url = env_str("WAREHOUSE_HTTPS_URL", "https://192.168.1.1/cgi-bin/warehouse.cgi").strip()

    wid = env_str("WAREHOUSE_ID", "").strip() or env_str("WAREHOUSE_USER", "").strip()
    wpw = env_str("WAREHOUSE_PASSWORD", "").strip() or env_str("WAREHOUSE_PW", "").strip()
    if not wid or not wpw:
        raise RuntimeError("Missing warehouse credentials: set WAREHOUSE_ID + WAREHOUSE_PASSWORD")

    timeout = env_int("WAREHOUSE_TIMEOUT_SEC", 3)
    retries = env_int("WAREHOUSE_RETRIES", 10)
    sleep_s = env_int("WAREHOUSE_SLEEP_SEC", 3)

    cmd = [
        sys.executable,
        tool,
        url,
        "--user",
        wid,
        "--password",
        wpw,
        "--json",
        "--decode-base64",
        "--timeout",
        str(timeout),
        "--retries",
        str(retries),
        "--sleep",
        str(sleep_s),
        "--ipv",
        ip_mode,
    ]

    jlog("warehouse_fetch_cmd", cmd=cmd)
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if p.returncode != 0:
        raise RuntimeError(f"warehouse tool failed rc={p.returncode}: {(p.stderr or p.stdout or '').strip()}")

    txt = (p.stdout or "").strip()
    try:
        data = json.loads(txt)
    except Exception as e:
        raise RuntimeError(f"warehouse json parse failed: {e}; output_head={txt[:200]!r}")

    # ensure str->str
    out: Dict[str, str] = {}
    for k, v in (data or {}).items():
        out[str(k)] = "" if v is None else str(v)

    return out


def validate_required_fields(table: Dict[str, str]) -> Tuple[bool, Dict[str, Any]]:
    required_raw = env_str("REQUIRED_FIELDS", "").strip()
    if not required_raw:
        return True, {"mode": "skip"}

    required = [x.strip() for x in required_raw.split(",") if x.strip()]

    # Some firmware variants use slightly different labels for the same concept.
    # Keep this mapping small and conservative: only for fields that are known
    # to vary across builds while still representing the same value.
    # Keys/values are compared using _norm_key().
    alias_map = {
        "LAN IPv4 Address": [
            # Some builds label the LAN IPv4 field generically.
            "IPv4 Address",
            "LAN IP Address",
            "LAN IP",
            "LAN Address",
            "LAN IPv4",
            "LAN IPv4 addr",
        ],
        "WAN IPv4 Address": [
            "WAN IP Address",
            "WAN IP",
            "WAN IPv4",
            "WAN IPv4 addr",
        ],
    }

    # build normalized lookup
    norm_map = {_norm_key(k): k for k in table.keys()}

    missing = []
    present = []
    for want in required:
        # Candidate keys: exact, normalized, and aliases
        candidates = [want] + alias_map.get(want, [])
        got_key = None
        for cand in candidates:
            if cand in table:
                got_key = cand
                break
            nk = _norm_key(cand)
            if nk in norm_map:
                got_key = norm_map[nk]
                break

        if not got_key:
            missing.append(want)
            continue

        present.append({"want": want, "key": got_key, "value": table.get(got_key, "")})

    ok = len(missing) == 0
    details: Dict[str, Any] = {"missing": missing, "present": present}
    if not ok:
        # help troubleshooting by returning available keys (truncated)
        keys = list(table.keys())
        details["available_keys_head"] = keys[:50]
        if len(keys) > 50:
            details["available_keys_more"] = len(keys) - 50
    return ok, details


def validate_sanity(table: Dict[str, str]) -> Tuple[bool, Dict[str, Any]]:
    details: Dict[str, Any] = {}

    # IPv4 sanity: check any field with "ipv4" in name
    bad_ipv4_fields = []
    for k, v in table.items():
        if "ipv4" in k.lower():
            if v and not _looks_ipv4(v):
                bad_ipv4_fields.append({"field": k, "value": v})
    details["bad_ipv4_fields"] = bad_ipv4_fields

    check_b64 = env_bool("CHECK_DEFAULT_B64", True)
    if check_b64:
        b64_issues = []
        dssid = table.get("Default SSID", "")
        dpw = table.get("Default Password", "")
        dssid_dec = table.get("Default SSID (decoded)", "")
        dpw_dec = table.get("Default Password (decoded)", "")

        if dssid:
            if not _looks_base64(dssid) or not dssid_dec:
                b64_issues.append({"field": "Default SSID", "value": dssid, "decoded": dssid_dec})
        if dpw:
            if not _looks_base64(dpw) or not dpw_dec:
                b64_issues.append({"field": "Default Password", "value": dpw, "decoded": dpw_dec})

        details["default_b64_issues"] = b64_issues

    # "Same as default" check (best-effort)
    if env_bool("EXPECT_SAME_AS_DEFAULT", True):
        same_issues = []
        for fld in ("Current SSID", "Current Password"):
            v = (table.get(fld, "") or "").strip().lower()
            if v and "same" in v and "default" in v:
                continue
            # allow empty (some firmware may not provide)
            if v:
                same_issues.append({"field": fld, "value": table.get(fld, "")})
        details["same_as_default_issues"] = same_issues

    ok = not details.get("bad_ipv4_fields") and not details.get("default_b64_issues") and not details.get("same_as_default_issues")
    return ok, details


def change_wifi(creds: NocCreds, token: str, location_id: str) -> None:
    if noc is None:
        raise RuntimeError("noc_api_cli import failed")

    ssid = env_str("NEW_WIFI_SSID", "").strip()
    pw = env_str("NEW_WIFI_PASSWORD", "").strip()
    if not ssid or not pw:
        raise RuntimeError("CHANGE_WIFI enabled but NEW_WIFI_SSID/NEW_WIFI_PASSWORD missing")

    jlog("wifi_update_start", ssid=ssid)
    noc.wifi_network_update(
        creds.base,
        env_str("CUSTOMER_ID"),
        location_id,
        token=token,
        bearer=creds.bearer,
        insecure=creds.insecure,
        ssid=ssid,
        encryption_key=pw,
    )
    jlog("wifi_update_sent")

    wait_s = env_int("WIFI_APPLY_WAIT_SEC", 60)
    if wait_s > 0:
        jlog("wifi_apply_wait", secs=wait_s)
        time.sleep(wait_s)


def validate_wifi_changed(before: Dict[str, str], after: Dict[str, str]) -> Tuple[bool, Dict[str, Any]]:
    # Best-effort because different firmware may show different strings.
    details: Dict[str, Any] = {}

    b_cur_ssid = before.get("Current SSID", "")
    a_cur_ssid = after.get("Current SSID", "")
    b_cur_pw = before.get("Current Password", "")
    a_cur_pw = after.get("Current Password", "")

    # If warehouse uses "Same as default" before change, after should not.
    issues = []
    if b_cur_ssid and ("same" in b_cur_ssid.lower() and "default" in b_cur_ssid.lower()):
        if a_cur_ssid and ("same" in a_cur_ssid.lower() and "default" in a_cur_ssid.lower()):
            issues.append({"field": "Current SSID", "before": b_cur_ssid, "after": a_cur_ssid})

    if b_cur_pw and ("same" in b_cur_pw.lower() and "default" in b_cur_pw.lower()):
        if a_cur_pw and ("same" in a_cur_pw.lower() and "default" in a_cur_pw.lower()):
            issues.append({"field": "Current Password", "before": b_cur_pw, "after": a_cur_pw})

    # If it shows base64 after change, try decode (optional visibility)
    if a_cur_ssid and _looks_base64(a_cur_ssid):
        details["current_ssid_decoded"] = _b64_decode_safe(a_cur_ssid)
    if a_cur_pw and _looks_base64(a_cur_pw):
        details["current_password_decoded"] = _b64_decode_safe(a_cur_pw)

    details["issues"] = issues
    return len(issues) == 0, details


def run() -> int:
    try:
        creds = load_noc_creds()
        token = noc_login(creds)

        node_id = resolve_node_id()
        location_id = resolve_location_id(creds, token, node_id)

        if env_bool("DO_FACTORY_RESET", True):
            do_factory_reset(creds, token, location_id)

        # Optional: enable SSH via NOC for validations that require remote commands.
        if env_bool("VALIDATE_MACS", False) or env_bool("ENABLE_SSH_PRECOND", False):
            maybe_enable_ssh(creds, token, location_id, node_id)

        if env_bool("CHECK_HTTP_REDIRECT", True):
            http_url = env_str("WAREHOUSE_HTTP_URL", "http://192.168.1.1/warehouse").strip()
            ok, info = check_http_redirect(http_url, timeout_sec=env_int("WAREHOUSE_TIMEOUT_SEC", 3) + 2)
            jlog("http_redirect_check", ok=ok, **info)
            if not ok:
                jlog("fail", reason="http_redirect_not_https")
                return 2

        # Fetch warehouse via IPv4
        before = fetch_warehouse(ip_mode="4")
        jlog("warehouse_fetch_ok", keys=len(before))

        # Validate MACs shown on warehouse page against `ifconfig -a` on CPE.
        if env_bool("VALIDATE_MACS", False):
            ok_macs, mac_detail = validate_macs_against_ifconfig(before)
            jlog("validate_macs", ok=ok_macs, detail=mac_detail)
            if not ok_macs:
                jlog("fail", reason="mac_validation_failed")
                return 7

        ok_req, req_detail = validate_required_fields(before)
        jlog("validate_required_fields", ok=ok_req, detail=req_detail)
        if not ok_req:
            jlog("fail", reason="missing_required_fields")
            return 3

        ok_sanity, sanity_detail = validate_sanity(before)
        jlog("validate_sanity", ok=ok_sanity, detail=sanity_detail)
        if not ok_sanity:
            jlog("fail", reason="sanity_check_failed")
            return 4

        # Optional change Wi-Fi and validate again
        if env_bool("CHANGE_WIFI", True):
            change_wifi(creds, token, location_id)
            after = fetch_warehouse(ip_mode="4")
            jlog("warehouse_fetch_after_wifi_ok", keys=len(after))

            ok_req2, req_detail2 = validate_required_fields(after)
            jlog("validate_required_fields_after", ok=ok_req2, detail=req_detail2)
            if not ok_req2:
                jlog("fail", reason="missing_required_fields_after_wifi")
                return 5

            ok_changed, changed_detail = validate_wifi_changed(before, after)
            jlog("validate_wifi_changed", ok=ok_changed, detail=changed_detail)
            if not ok_changed:
                jlog("fail", reason="wifi_change_not_reflected")
                return 6

        jlog("pass")
        return 0

    except Exception as e:
        jlog("exception", error=str(e))
        return 1


if __name__ == "__main__":
    raise SystemExit(run())
