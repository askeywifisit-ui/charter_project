#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Shared DNS resolve helper using cpe_ssh.py.

This module is intended to be reused by different long-run tests
(DNS-only, WiFi longrun, speedtest longrun, etc.).

It delegates the actual DNS query to cpe_ssh.py, which in turn talks
to the CPE over SSH and returns a JSON object like:

    { "count": N, "ips": ["..."] }

The main entrypoint is `run_dns_check()`.
"""

import os
import time
import json
import subprocess
from typing import Dict, Any, Tuple, List


def _short_list(items: List[str], max_items: int = 3) -> List[str]:
    """Shorten long lists to keep logs under control."""
    if len(items) <= max_items:
        return list(items)
    return list(items[:max_items]) + [f"...(+{len(items) - max_items} more)"]


def _resolve_cpe_ssh_path() -> str:
    """Locate cpe_ssh.py.

    Priority:
      1. $TOOLS_PATH/cpe_ssh.py  (if TOOLS_PATH is set and file exists)
      2. ./cpe_ssh.py            (same directory as the caller, if present)
      3. 'cpe_ssh.py'            (fall back to PATH)
    """
    tools = os.environ.get("TOOLS_PATH")
    if tools:
        candidate = os.path.join(tools, "cpe_ssh.py")
        if os.path.exists(candidate):
            return candidate

    here = os.path.dirname(os.path.abspath(__file__))
    candidate = os.path.join(here, "cpe_ssh.py")
    if os.path.exists(candidate):
        return candidate

    # last resort: rely on PATH
    return "cpe_ssh.py"


def _run_dns_once(
    host: str,
    user: str,
    password: str,
    domain: str,
    family: str,
    timeout: float,
    show_cmd: bool,
) -> Tuple[bool, Dict[str, Any]]:
    """Call a single dns-v4 / dns-v6 via cpe_ssh.py.

    Returns:
        (ok_call, detail)

    ok_call == False means we couldn't even get/parse JSON
    (timeout, bad output, etc.).
    """
    cmd_name = f"dns-{family}"
    cpe_ssh = _resolve_cpe_ssh_path()
    cmd = [
        "python3",
        cpe_ssh,
        "--host",
        host,
        "--user",
        user,
        "--password",
        password,
        "--cmd",
        cmd_name,
        "--domain",
        domain,
    ]

    if show_cmd:
        print(f"[dns_helper] exec: {' '.join(cmd)}", flush=True)

    try:
        p = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired as e:
        return False, {
            "ok": False,
            "error": "timeout",
            "exception": str(e),
            "cmd": cmd,
        }

    stdout = (p.stdout or "").strip()
    stderr = (p.stderr or "").strip()

    # cpe_ssh.py prints a JSON object:
    #   { "count": N, "ips": ["..."] }
    try:
        data = json.loads(stdout or "{}")
    except Exception as e:
        return False, {
            "ok": False,
            "error": "json_decode_failed",
            "exception": str(e),
            "rc": p.returncode,
            "stdout": stdout[-400:],
            "stderr": stderr[-200:],
        }

    ips = data.get("ips") or []
    count = int(data.get("count", len(ips)))

    detail: Dict[str, Any] = {
        "ok": p.returncode == 0 and bool(ips),
        "rc": p.returncode,
        "count": count,
        "ips": ips,
        "raw": data,
        "stdout_tail": stdout[-400:],
        "stderr_tail": stderr[-200:],
    }
    return True, detail


def _check_family_with_retry(
    host: str,
    user: str,
    password: str,
    domain: str,
    family: str,
    expect_min: int,
    retries: int,
    interval: float,
    timeout: float,
    debug: bool,
    show_cmd: bool,
) -> Dict[str, Any]:
    """Check a single family (v4 / v6) with retry.

    Returns a dict like:
        {
          "family": "v4",
          "ok": True/False,
          "tries": n,
          "count": last_count,
          "ips": [...],
          "attempts": [ per-try detail, ... ],
        }
    """
    result: Dict[str, Any] = {
        "family": family,
        "ok": False,
        "tries": 0,
        "count": 0,
        "ips": [],
        "attempts": [],
    }

    if expect_min <= 0:
        # This family is not required; treat as OK without doing any query
        result["ok"] = True
        return result

    for t in range(1, retries + 1):
        ok_call, detail = _run_dns_once(
            host,
            user,
            password,
            domain,
            family,
            timeout,
            show_cmd,
        )
        result["attempts"].append(detail)
        result["tries"] = t

        if not ok_call:
            if debug:
                print(
                    f"[dns_helper] {domain} {family} try#{t}: call_failed detail={detail}",
                    flush=True,
                )
            time.sleep(interval)
            continue

        raw_count = int(detail.get("count", 0))
        ips = detail.get("ips") or []

        # Filter out "invalid" / walled-garden IPs.
        # List is configured via env DNS_INVALID_IPS (逗號分隔)。
        # 預設為空字串 => 不會強制視任何 IP 為「不合法」，完全由每個環境自行設定。
        invalid_env = os.environ.get("DNS_INVALID_IPS", "")
        # 支援在 manifest 中寫「DNS_INVALID_IPS: 172.14.1.1   # comment」
        # 因此先把 # 後面的註解去掉，再用逗號切成清單。
        invalid_env = invalid_env.split("#", 1)[0]
        invalid_ips = [s.strip() for s in invalid_env.split(",") if s.strip()]
        valid_ips = [ip for ip in ips if ip not in invalid_ips]

        count = len(valid_ips)
        result["count"] = count
        # 仍然把原始 ips 一併回傳方便 debug
        result["ips"] = valid_ips
        result["raw_ips"] = ips
        result["invalid_ips"] = invalid_ips

        if debug:
            ips_s = _short_list(ips)
            valid_ips_s = _short_list(valid_ips)
            print(
                f"[dns_helper] {domain} {family} try#{t}: raw_count={raw_count} ips={ips_s} -> valid_count={count} valid_ips={valid_ips_s}",
                flush=True,
            )

        if count >= expect_min:
            result["ok"] = True
            break

        time.sleep(interval)

    return result


def run_dns_check(
    host: str,
    user: str,
    password: str,
    domain: str,
    expect_v4: int,
    expect_v6: int,
    retries: int,
    interval: float,
    timeout: float,
    debug: bool = False,
    show_cmd: bool = False,
) -> Dict[str, Any]:
    """High-level DNS check for one domain.

    Runs IPv4 / IPv6 (depending on expect_v4 / expect_v6) and returns:

        {
          "ok": True/False,
          "reason": "...",
          "target": domain,
          "v4": { ... },
          "v6": { ... },
        }
    """
    v4 = _check_family_with_retry(
        host,
        user,
        password,
        domain,
        "v4",
        expect_v4,
        retries,
        interval,
        timeout,
        debug,
        show_cmd,
    )
    v6 = _check_family_with_retry(
        host,
        user,
        password,
        domain,
        "v6",
        expect_v6,
        retries,
        interval,
        timeout,
        debug,
        show_cmd,
    )

    ok = v4.get("ok", True) and v6.get("ok", True)
    reason = ""
    if not ok:
        parts = []
        if not v4.get("ok", True) and expect_v4 > 0:
            parts.append(f"A answers {v4.get('count', 0)} < {expect_v4}")
        if not v6.get("ok", True) and expect_v6 > 0:
            parts.append(f"AAAA answers {v6.get('count', 0)} < {expect_v6}")
        reason = "; ".join(parts) or "dns_failed"

    return {
        "ok": ok,
        "reason": reason,
        "target": domain,
        "v4": v4,
        "v6": v6,
    }
