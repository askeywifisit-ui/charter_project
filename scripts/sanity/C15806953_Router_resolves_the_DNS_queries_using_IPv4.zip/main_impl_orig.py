#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
C15806953_Router_resolves_the_DNS_queries_using_IPv4 main implementation (NOC+SSH+DNS).

流程：
  1. 使用 NOC_EMAIL / NOC_PASSWORD login 取得 token
  2. 透過 serial (METRICS_TOOL) 取得 node_id
  3. 透過 NOC API 取得 location_id
  4. 跑一輪 NOC API 測試：
     - get-location 一致性確認
     - speedtest-run + speedtest-result (輪詢等待結果)
     - wifi-status / wifi-enable / wifi-disable（最後會還原）
     - lte-status
  5. 根據 SSH_ACTION (enable / disable / both) 做 ssh-enable / ssh-disable

依賴：
  - /home/da40/charter/tools/noc_api_cli.py (用 import noc_api_cli as api)
"""

import os
import sys
import json
import time
import subprocess
import socket
from typing import Dict, Optional
from dns_helper import run_dns_check


import requests  # 用來抓 HTTPError status code
from cpe_health_helper import run_cpe_health_check



# 用來讓 cycle_wrapper 讀取本次 speedtest 的結果
_last_speedtest_metrics: Optional[Dict[str, float]] = None


def get_last_speedtest_metrics() -> Optional[Dict[str, float]]:
    """
    給 cycle_wrapper 用：
    回傳本次 run() 內最後一次 speedtest 的 DL / UL / latency。
    如果這次 run 沒有成功拿到數值，回傳 None。
    """
    return _last_speedtest_metrics


def _first_numeric_key(obj: object, candidates) -> Optional[float]:
    """
    在巢狀 JSON 裡面找第一個符合 key 且是數字的值。
    candidates: 依序嘗試的欄位名稱。
    """
    if isinstance(obj, dict):
        for k in candidates:
            if k in obj and isinstance(obj[k], (int, float)):
                return float(obj[k])
        for v in obj.values():
            val = _first_numeric_key(v, candidates)
            if val is not None:
                return val
    elif isinstance(obj, list):
        for v in obj:
            val = _first_numeric_key(v, candidates)
            if val is not None:
                return val
    return None


def _extract_speedtest_metrics(resp: object) -> Optional[Dict[str, float]]:
    """
    嘗試從 speedtest-result 的 JSON 裡面抽出 download / upload / latency。

    這裡先假設 NOC 回傳的欄位名稱類似：
      - downloadSpeed  (吞吐 / DL)
      - uploadSpeed    (吞吐 / UL)
      - latency        (延遲)

    如果你實際看到的 JSON 不同，只要把下面 KEY 清單換成實際的 key 即可。
    """
    dl = _first_numeric_key(resp, ["downloadSpeed", "download", "downstream", "dlMbps"])
    ul = _first_numeric_key(resp, ["uploadSpeed", "upload", "upstream", "ulMbps"])
    lat = _first_numeric_key(resp, ["latency", "ping", "rtt"])

    if dl is None and ul is None and lat is None:
        return None

    return {
        "downloadSpeed": dl,
        "uploadSpeed": ul,
        "latency": lat,
    }


# -------------------------------------------------
# 載入 tools 目錄底下的 noc_api_cli
# -------------------------------------------------
TOOLS_PATH = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
if TOOLS_PATH and TOOLS_PATH not in sys.path:
    sys.path.insert(0, TOOLS_PATH)

try:
    import noc_api_cli as api  # type: ignore
except Exception as e:  # 在 ChatGPT sandbox 會失敗，在實機應該 OK
    api = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "noc_api_cli", "error": str(e)}))

_CACHE: Dict[str, object] = {}


# -------------------------------------------------
# 小工具
# -------------------------------------------------
def _getenv(name: str, default: str = "") -> str:
    v = os.environ.get(name)
    return default if v is None else str(v)


def _bool_env(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return str(v).strip().lower() in ("1", "true", "yes", "y")


# -------------------------------------------------
# login / node / location
# -------------------------------------------------
def _login(base: str, email: str, password: str, bearer: bool, insecure: bool) -> str:
    if "token" in _CACHE:
        return _CACHE["token"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot login to NOC")

    tok = api.login(base, email, password, bearer=bearer, insecure=insecure)
    _CACHE["token"] = tok
    print(json.dumps({"step": "login", "ok": True}))
    return tok


def _node_id(metrics_tool: str, dev: str, baud: int, user: str, password: str) -> str:
    if "node_id" in _CACHE:
        return _CACHE["node_id"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot query node_id")

    cpe_info_tool = os.environ.get("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")

    # NOTE: cpe_info --node-id is sometimes slow (or briefly unavailable).
    # Add retry here to avoid a single transient timeout causing empty node_id
    # and a later NOC 404.
    try:
        max_tries = int(os.environ.get("NODE_ID_MAX_TRIES", "3"))
    except Exception:
        max_tries = 3
    try:
        interval_sec = float(os.environ.get("NODE_ID_INTERVAL_SEC", "2"))
    except Exception:
        interval_sec = 2.0
    try:
        cmd_timeout = float(os.environ.get("NODE_ID_CMD_TIMEOUT_SEC", "15"))
    except Exception:
        cmd_timeout = 15.0

    nid = ""
    last_err = ""
    for attempt in range(1, max_tries + 1):
        try:
            proc = subprocess.run(
                [cpe_info_tool, "--node-id"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=cmd_timeout,
            )
            if proc.returncode == 0:
                for line in (proc.stdout or "").splitlines():
                    s = line.strip()
                    if s:
                        nid = s
                        break
            ok = bool(nid)
            print(json.dumps({
                "step": "node-id-cpe_info",
                "attempt": attempt,
                "ok": ok,
                "rc": proc.returncode,
                "node_id": nid if ok else "",
            }))
            if ok:
                break
            last_err = (proc.stderr or "").strip()[:200]
        except Exception as e2:
            last_err = str(e2)
            print(json.dumps({
                "step": "node-id-cpe_info-exception",
                "attempt": attempt,
                "error": last_err,
            }))

        if attempt < max_tries:
            time.sleep(interval_sec)

    if not nid:
        # Fallback: use cpe_info --node-id --value (derived from WAN MAC)
        try:
            proc = subprocess.run(
                [cpe_info_tool, "--node-id", "--value"],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=cmd_timeout,
            )
            raw = (proc.stdout or "").strip()
            nid2 = raw.replace(":", "").strip().lower()
            ok = (proc.returncode == 0 and bool(nid2))
            print(json.dumps({
                "step": "node-id-fallback-cpe_info",
                "ok": ok,
                "rc": proc.returncode,
                "raw": raw,
                "node_id": nid2 if ok else "",
            }))
            if ok:
                _CACHE["node_id"] = nid2
                return nid2
        except Exception as e2:
            print(json.dumps({
                "step": "node-id-fallback-cpe_info-exception",
                "error": str(e2),
            }))

        # Still empty -> hard fail (do not proceed to NOC API with empty node_id)
        raise RuntimeError(f"node_id_empty_after_retries: {last_err}")

    _CACHE["node_id"] = nid
    print(json.dumps({"step": "node-id", "node_id": nid}))
    return nid

def _location_id(base: str, customer_id: str, node_id: str,
                 token: str, bearer: bool, insecure: bool) -> str:
    if "location_id" in _CACHE:
        return _CACHE["location_id"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot query location_id")

    loc = api.get_location_id(base, customer_id, node_id,
                              token=token, bearer=bearer, insecure=insecure)
    _CACHE["location_id"] = loc
    print(json.dumps({"step": "location-id", "location_id": loc}))
    return loc


# -------------------------------------------------
# CPE console password fallback
# -------------------------------------------------
def _console_password(cpe_info_tool: str) -> str:
    """
    若 CPE_PASSWORD 未設定或為 null，嘗試透過 cpe_info 撈 console 密碼。
    """
    try:
        proc = subprocess.run(
            [cpe_info_tool, "--password"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=15,
        )
        out = (proc.stdout or "").strip()
        for line in out.splitlines():
            line = line.strip()
            if line:
                return line
    except Exception:
        pass
    return ""


# -------------------------------------------------
# SSH enable / disable
# -------------------------------------------------
def _ssh_enable(base: str, customer_id: str, location_id: str, node_id: str,
                ssh_pass: str, timeout_min: int,
                token: str, bearer: bool, insecure: bool) -> None:
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot enable SSH")

    resp = api.ssh_enable(
        base,
        customer_id,
        location_id,
        node_id,
        ssh_pass,
        timeout_min,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({"step": "ssh-enable", "resp": resp}))


def _ssh_disable(base: str, customer_id: str, location_id: str, node_id: str,
                 token: str, bearer: bool, insecure: bool) -> None:
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot disable SSH")

    resp = api.ssh_disable(
        base,
        customer_id,
        location_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({"step": "ssh-disable", "resp": resp}))


# -------------------------------------------------
# NOC API 測試 helpers
# -------------------------------------------------
def _run_speedtest_tests(base: str, customer_id: str, location_id: str, node_id: str,
                         token: str, bearer: bool, insecure: bool) -> None:
    """
    SpeedTest 測試流程：

      1) POST /speedTest 觸發一次測速 → 拿到 requestId
      2) 先等 SPEEDTEST_WAIT_SEC 秒（預設 60）
      3) 最多重試 SPEEDTEST_MAX_TRIES 次，每次間隔 SPEEDTEST_INTERVAL_SEC 秒
         呼叫 GET /speedTestResults/{requestId} 查單筆結果

    三個參數都用 env 控制：
      SPEEDTEST_WAIT_SEC
      SPEEDTEST_MAX_TRIES
      SPEEDTEST_INTERVAL_SEC
    """
    global _last_speedtest_metrics
    _last_speedtest_metrics = None

    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run speedtest tests")

    # 1) 觸發一次 speed test
    resp_run = api.speedtest_run(
        base,
        customer_id,
        location_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )

    request_id: Optional[str] = None
    if isinstance(resp_run, dict):
        request_id = (
            resp_run.get("requestId")
            or resp_run.get("request_id")
            or resp_run.get("id")
        )

    print(json.dumps({
        "step": "speedtest-run",
        "resp": resp_run,
        "request_id": request_id,
    }))

    if not request_id:
        raise RuntimeError("speedtest-run did not return requestId")

    # 2) 先等一段時間再開始查結果
    wait_sec = int(_getenv("SPEEDTEST_WAIT_SEC", "60"))
    print(json.dumps({
        "step": "speedtest-wait",
        "request_id": request_id,
        "seconds": wait_sec,
    }))
    time.sleep(wait_sec)

    # 3) 開始少量輪詢
    max_tries = int(_getenv("SPEEDTEST_MAX_TRIES", "3"))
    interval_sec = int(_getenv("SPEEDTEST_INTERVAL_SEC", "10"))

    last_error: Optional[str] = None
    resp_one: Optional[object] = None

    for attempt in range(1, max_tries + 1):
        try:
            resp_one = api.speedtest_result_by_id(
                base,
                customer_id,
                location_id,
                node_id,
                request_id,
                token=token,
                bearer=bearer,
                insecure=insecure,
            )
            # 呼叫成功（沒有丟 HTTPError）
            print(json.dumps({
                "step": "speedtest-result",
                "attempt": attempt,
                "request_id": request_id,
                "resp": resp_one,
            }))

            # 解析本次 speedtest 的 throughput / latency，存成全域給 cycle_wrapper 用
            metrics = _extract_speedtest_metrics(resp_one)
            if metrics is not None:
                _last_speedtest_metrics = metrics
                print(json.dumps({
                    "event": "speedtest_metrics",
                    **metrics,
                }))
            else:
                # 沒有找到 DL / UL / latency 欄位
                _last_speedtest_metrics = None
                print(json.dumps({
                    "event": "speedtest_metrics_missing",
                    "reason": "no_dl_ul_latency_found_in_response",
                }))

            break

        except requests.HTTPError as e:
            status = e.response.status_code if e.response is not None else None
            body = e.response.text[:200] if e.response is not None else ""
            last_error = f"HTTP {status}: {body}"

            print(json.dumps({
                "step": "speedtest-result-retry",
                "attempt": attempt,
                "request_id": request_id,
                "status": status,
                "error": last_error,
            }))

            # 如果還有下一次機會，且是 400/404，就睡 interval_sec 秒再試
            if attempt < max_tries and status in (400, 404):
                time.sleep(interval_sec)
                continue

            # 其他情況（沒下一次或不是 400/404），直接丟出去
            raise

    if resp_one is None:
        # 全部嘗試完還失敗，就讓整個腳本 FAIL
        raise RuntimeError(f"speedtest-result failed after {max_tries} tries: {last_error}")


def _wifi_enabled_flag(status: object) -> Optional[bool]:
    """從 wifi-status 回傳的 JSON 抽出 enabled 狀態."""
    if isinstance(status, dict):
        # 1) 先看頂層有沒有 enabled
        if "enabled" in status:
            return bool(status.get("enabled"))

        # 2) 再看 wifiNetwork.enabled
        wn = status.get("wifiNetwork")
        if isinstance(wn, dict) and "enabled" in wn:
            return bool(wn.get("enabled"))

        # 3) 如果是 wifiNetworks 陣列，也處理一下（預留擴充）
        wns = status.get("wifiNetworks")
        if isinstance(wns, list) and wns and isinstance(wns[0], dict) and "enabled" in wns[0]:
            return bool(wns[0].get("enabled"))

    return None


def _run_wifi_tests(base: str, customer_id: str, location_id: str,
                    token: str, bearer: bool, insecure: bool) -> None:
    """wifi-status / wifi-enable / wifi-disable 功能測試，最後會盡量恢復原本狀態。"""
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run wifi tests")

    # 先查目前狀態
    status_before = api.wifi_status(
        base,
        customer_id,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    enabled_before = _wifi_enabled_flag(status_before)
    print(json.dumps({
        "step": "wifi-status-before",
        "enabled": enabled_before,
        "resp": status_before,
    }))

    target_state = not bool(enabled_before) if enabled_before is not None else True

    # 切換一次
    resp_toggle = api.wifi_set_enabled(
        base,
        customer_id,
        location_id,
        target_state,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    status_mid = api.wifi_status(
        base,
        customer_id,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    enabled_mid = _wifi_enabled_flag(status_mid)
    print(json.dumps({
        "step": "wifi-toggle",
        "target": target_state,
        "enabled_mid": enabled_mid,
        "resp_toggle": resp_toggle,
        "status_mid": status_mid,
    }))

    # 盡量恢復原本狀態
    if enabled_before is not None and enabled_before != enabled_mid:
        resp_restore = api.wifi_set_enabled(
            base,
            customer_id,
            location_id,
            enabled_before,
            token=token,
            bearer=bearer,
            insecure=insecure,
        )
        status_after = api.wifi_status(
            base,
            customer_id,
            location_id,
            token=token,
            bearer=bearer,
            insecure=insecure,
        )
        enabled_after = _wifi_enabled_flag(status_after)
        ok = (enabled_after == enabled_before)
        print(json.dumps({
            "step": "wifi-restore",
            "enabled_before": enabled_before,
            "enabled_after": enabled_after,
            "ok": ok,
            "resp_restore": resp_restore,
            "status_after": status_after,
        }))
        if not ok:
            raise RuntimeError("wifi enabled state mismatch after restore")


def _run_lte_test(base: str, location_id: str,
                  token: str, bearer: bool, insecure: bool) -> None:
    """lte-status 測試（僅查詢）。"""
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run LTE tests")

    resp = api.lte_status(
        base,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({
        "step": "lte-status",
        "resp": resp,
    }))


def _run_get_location_test(base: str, customer_id: str, node_id: str,
                           location_id: str,
                           token: str, bearer: bool, insecure: bool) -> None:
    """get-location 功能測試，確認回傳的 locationId 與前面取得的一致。"""
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run get-location test")

    loc2 = api.get_location_id(
        base,
        customer_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    ok = (loc2 == location_id)
    print(json.dumps({
        "step": "get-location-check",
        "location_id": location_id,
        "location_id_refetched": loc2,
        "ok": ok,
    }))
    if not ok:
        raise RuntimeError("location_id from get_location_id() mismatch")


# -------------------------------------------------
# Internet connectivity pre-check using cpe_info --internet
# -------------------------------------------------
def _wait_internet_connected() -> None:
    """在執行 speedtest 之前，透過 cpe_info --internet 確認 Internet Status: Connected。

    預設會重試 10 次，每次間隔 3 秒，可由環境變數覆蓋：
      INTERNET_CHECK_MAX_RETRIES
      INTERNET_CHECK_INTERVAL_SEC
    """
    cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")

    try:
        max_retries = int(_getenv("INTERNET_CHECK_MAX_RETRIES", "10"))
    except Exception:
        max_retries = 10

    try:
        interval_sec = float(_getenv("INTERNET_CHECK_INTERVAL_SEC", "3"))
    except Exception:
        interval_sec = 3.0

    last_output = ""

    for attempt in range(1, max_retries + 1):
        cmd = [cpe_info_tool, "--internet"]
        print(json.dumps({
            "step": "internet-check",
            "attempt": attempt,
            "max_retries": max_retries,
            "cmd": cmd,
        }))

        try:
            proc = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=30,
            )
            out = (proc.stdout or "").strip()
            last_output = out
        except Exception as e:
            print(json.dumps({
                "step": "internet-check-exception",
                "attempt": attempt,
                "error": str(e),
            }))
        else:
            print(json.dumps({
                "step": "internet-check-raw",
                "attempt": attempt,
                "rc": proc.returncode,
                "out": out,
            }))
            # 成功條件：rc == 0 且輸出中有 "Internet Status: Connected"
            if proc.returncode == 0 and "Internet Status: Connected" in out:
                print(json.dumps({
                    "step": "internet-check-ok",
                    "attempt": attempt,
                }))
                return

        # 還沒成功就睡一下再試
        if attempt < max_retries:
            time.sleep(interval_sec)

    # 全部重試完還是沒 Connected → 當成 precondition fail
    print(json.dumps({
        "step": "internet-check-failed",
        "max_retries": max_retries,
        "last_output": last_output[-200:],
    }))
    raise RuntimeError(
        f"internet not connected after {max_retries} checks via cpe_info --internet"
    )


def _run_noc_api_tests(base: str, customer_id: str, node_id: str, location_id: str,
                       token: str, bearer: bool, insecure: bool,
                       ssh_pass: str, ssh_timeout_min: int) -> None:
    """
    統一執行 NOC API 測試，並可透過環境變數決定是否啟用各項測試：

      ENABLE_SPEEDTEST  (預設 1)
      ENABLE_WIFI_TEST  (預設 1)
      ENABLE_LTE_TEST   (預設 1)
    """
    # 讀 env 開關
    enable_speedtest = _bool_env("ENABLE_SPEEDTEST", True)
    enable_wifi = _bool_env("ENABLE_WIFI_TEST", True)
    enable_lte = _bool_env("ENABLE_LTE_TEST", True)

    print(json.dumps({
        "event": "noc-api-tests-start",
        "enable_speedtest": enable_speedtest,
        "enable_wifi": enable_wifi,
        "enable_lte": enable_lte,
    }))

    # 一律先做 get-location 一致性檢查
    _run_get_location_test(base, customer_id, node_id, location_id,
                           token, bearer, insecure)

    # speedtest

    if enable_speedtest:
        _wait_internet_connected()
        _run_speedtest_tests(base, customer_id, location_id, node_id,
                             token, bearer, insecure)
        # 在 health 之前先檢查 SSH port 是否開啟，如未開則透過 NOC API 重新 enable SSH
        host = os.environ.get("CPE_HEALTH_HOST", "192.168.1.1")
        try:
            port = int(os.environ.get("CPE_HEALTH_PORT", "22"))
        except Exception:
            port = 22
        try:
            ssh_port_timeout = float(os.environ.get("SSH_PORT_CHECK_TIMEOUT", "3"))
        except Exception:
            ssh_port_timeout = 3.0
        ssh_open = False
        try:
            with socket.create_connection((host, port), timeout=ssh_port_timeout):
                ssh_open = True
        except Exception:
            ssh_open = False
        print(json.dumps({
            "event": "ssh-port-check",
            "host": host,
            "port": port,
            "open": ssh_open,
        }))
        if not ssh_open:
            # 透過 NOC API 再次 enable SSH（延長 / 重新打開 SSH 視後端實作而定）
            _ssh_enable(base, customer_id, location_id, node_id,
                        ssh_pass, ssh_timeout_min, token, bearer, insecure)
            # 簡單等待一下再給 health 使用
            time.sleep(2.0)
        # CPE health check after speedtest metrics
        health_ok = run_cpe_health_check(TOOLS_PATH, timeout=180)
        if not health_ok:
            raise RuntimeError("CPE health check failed after speedtest")
    else:
        print(json.dumps({
            "event": "speedtest-skip",
            "reason": "env_disabled",
        }))



    # wifi
    if enable_wifi:
        _run_wifi_tests(base, customer_id, location_id,
                        token, bearer, insecure)
    else:
        print(json.dumps({
            "event": "wifi-skip",
            "reason": "env_disabled",
        }))

    # lte
    if enable_lte:
        _run_lte_test(base, location_id,
                      token, bearer, insecure)
    else:
        print(json.dumps({
            "event": "lte-skip",
            "reason": "env_disabled",
        }))

    print(json.dumps({"event": "noc-api-tests-done"}))


# -------------------------------------------------
# main entrypoint for cycle_wrapper
# -------------------------------------------------
# -------------------------------------------------
# main entrypoint for cycle_wrapper
# -------------------------------------------------
def _run_noc_api_tests(base: str, customer_id: str, node_id: str, location_id: str,
                       token: str, bearer: bool, insecure: bool,
                       ssh_pass: str, ssh_timeout_min: int) -> None:
    """NOC API tests + SSH/health + DNS (speedtest & WiFi/LTE optional).

    Env toggles:
      ENABLE_SPEEDTEST   (default 0 for this DNS product)
      ENABLE_WIFI_TEST   (default 0)
      ENABLE_LTE_TEST    (default 0)
      ENABLE_DNS_CHECK   (default 1)
    """
    # read env toggles
    enable_speedtest = _bool_env("ENABLE_SPEEDTEST", False)
    enable_wifi = _bool_env("ENABLE_WIFI_TEST", False)
    enable_lte = _bool_env("ENABLE_LTE_TEST", False)
    enable_health = _bool_env("ENABLE_HEALTH_CHECK", True)
    # 對 DNS 開關特別寬鬆處理：只有明確 0/false/no/off 才視為關閉
    _raw_dns_flag = os.environ.get("ENABLE_DNS_CHECK", "1")
    enable_dns = str(_raw_dns_flag).strip().lower() not in ("0", "false", "no", "off")

    print(json.dumps({
        "event": "noc-api-tests-start",
        "enable_speedtest": enable_speedtest,
        "enable_wifi": enable_wifi,
        "enable_lte": enable_lte,
        "enable_dns": enable_dns,
        "enable_health": enable_health,
    }))

    # always do get-location consistency check
    _run_get_location_test(base, customer_id, node_id, location_id,
                           token, bearer, insecure)

    # optional speedtest
    if enable_speedtest:
        _run_speedtest_tests(base, customer_id, location_id, node_id,
                             token, bearer, insecure)
    else:
        print(json.dumps({
            "event": "speedtest-skip",
            "reason": "env_disabled_or_default_off",
        }))

    # unified SSH port check + health (always)
    host = os.environ.get("CPE_HEALTH_HOST", "192.168.1.1")
    try:
        port = int(os.environ.get("CPE_HEALTH_PORT", "22"))
    except Exception:
        port = 22
    try:
        ssh_port_timeout = float(os.environ.get("SSH_PORT_CHECK_TIMEOUT", "3"))
    except Exception:
        ssh_port_timeout = 3.0

    try:
        import socket
        with socket.create_connection((host, port), timeout=ssh_port_timeout):
            ssh_open = True
    except Exception:
        ssh_open = False

    print(json.dumps({
        "event": "ssh-port-check",
        "host": host,
        "port": port,
        "open": ssh_open,
    }))

    if not ssh_open:
        # re-enable SSH via NOC API
        _ssh_enable(base, customer_id, location_id, node_id,
                    ssh_pass, ssh_timeout_min, token, bearer, insecure)
        # give the CPE a moment before health / DNS use SSH
        time.sleep(2.0)

    # health check (optional)
    if enable_health:
        health_ok = run_cpe_health_check(TOOLS_PATH, timeout=180)
        if not health_ok:
            raise RuntimeError("CPE health check failed before DNS / WiFi / LTE")
    else:
        print(json.dumps({
            "event": "health-skip",
            "reason": "env_disabled",
        }))

    # DNS checks (v4/v6) via cpe_ssh.py
    if enable_dns:
        ssh_host = os.environ.get("SSH_HOST_LAN", "192.168.1.1")
        ssh_user = os.environ.get("SSH_USER", "operator")
        ssh_password = os.environ.get("SSH_PASSWORD", "")

        target = (os.environ.get("TARGET", "www.google.com") or "").split("#", 1)[0].strip()
        second = (os.environ.get("SECOND", "") or "").split("#", 1)[0].strip()

        # NOTE: platform may inject env values from manifest.yaml "as-is".
        # Avoid inline comments like: EXPECT_AAAA_MIN: 1  # comment
        # by stripping anything after '#'.
        def _int_env(name: str, default: int) -> int:
            raw = os.environ.get(name)
            if raw is None:
                return default
            s = str(raw).split("#", 1)[0].strip()
            if not s:
                return default
            try:
                return int(s)
            except Exception:
                return default

        expect_v4 = _int_env("EXPECT_A_MIN", 1)
        expect_v6 = _int_env("EXPECT_AAAA_MIN", 1)
        try:
            retries = int(os.environ.get("RETRIES", "3"))
        except Exception:
            retries = 3
        try:
            interval = float(os.environ.get("INTERVAL_SEC", "3"))
        except Exception:
            interval = 3.0
        try:
            dns_timeout = float(os.environ.get("DNS_SSH_TIMEOUT_SEC", "30"))
        except Exception:
            dns_timeout = 30.0

        debug_dns = _bool_env("DEBUG_DNS", False)
        debug_show_cmd = _bool_env("DEBUG_SHOW_CMD", False)

        # Persist DNS check results to a local JSON file in the run directory.
        # Some runners truncate stdout, which can make it look like the second domain/family
        # was never checked even when it was.
        save_dns_results = _bool_env("SAVE_DNS_RESULTS", True)
        dns_results_file = os.environ.get("DNS_RESULTS_FILE", "dns_results.json")
        dns_results = {
            "event": "dns-results",
            "target": target,
            "second": second,
            "expect_v4": expect_v4,
            "expect_v6": expect_v6,
            "retries": retries,
            "interval": interval,
            "dns_timeout": dns_timeout,
            "results": [],
        }

        print(json.dumps({
            "event": "dns-check-params",
            "target": target,
            "second": second,
            "expect_v4": expect_v4,
            "expect_v6": expect_v6,
            "expect_aaaa_min_raw": os.environ.get("EXPECT_AAAA_MIN"),
            "retries": retries,
            "interval": interval,
            "dns_timeout": dns_timeout,
            "ssh_host": ssh_host,
            "ssh_user": ssh_user,
        }))

        if not target:
            raise RuntimeError("DNS_TARGET_not_set")

        # Build domain list (TARGET is required; SECOND is optional)
        domains = [("TARGET", target)]
        if second:
            domains.append(("SECOND", second))
        else:
            print(json.dumps({
                "event": "dns-second-skip",
                "reason": "SECOND_empty",
                "second_raw": os.environ.get("SECOND"),
            }))

        print(json.dumps({
            "event": "dns-check-list",
            "domains": [{"which": w, "domain": d} for (w, d) in domains],
        }))

        dns_results = {
            "node_id": node_id,
            "location_id": location_id,
            "ssh_host": ssh_host,
            "expect_v4": expect_v4,
            "expect_v6": expect_v6,
            "retries": retries,
            "interval": interval,
            "timeout": dns_timeout,
            "results": [],
        }

        try:
            for which, domain in domains:
                print(json.dumps({
                    "event": "dns-check-start",
                    "which": which,
                    "domain": domain,
                }), flush=True)

                res = run_dns_check(
                    host=ssh_host,
                    user=ssh_user,
                    password=ssh_password,
                    domain=domain,
                    expect_v4=expect_v4,
                    expect_v6=expect_v6,
                    retries=retries,
                    interval=interval,
                    timeout=dns_timeout,
                    debug=debug_dns,
                    show_cmd=debug_show_cmd,
                )

                result_event = {
                    "event": "dns-check-result",
                    "which": which,
                    "domain": domain,
                    "ok": res.get("ok", False),
                    "reason": res.get("reason"),
                    "summary": {
                        "v4_ok": res.get("v4", {}).get("ok"),
                        "v4_count": res.get("v4", {}).get("count"),
                        "v6_ok": res.get("v6", {}).get("ok"),
                        "v6_count": res.get("v6", {}).get("count"),
                    },
                }
                print(json.dumps(result_event), flush=True)
                dns_results["results"].append({"which": which, "domain": domain, **res})

                if not res.get("ok", False):
                    raise RuntimeError(f"DNS check failed for {which}={domain}: {res.get('reason')}")
        finally:
            if save_dns_results:
                try:
                    with open(dns_results_file, "w", encoding="utf-8") as f:
                        json.dump(dns_results, f, indent=2, ensure_ascii=False)
                    print(json.dumps({
                        "event": "dns-results-saved",
                        "file": dns_results_file,
                        "count": len(dns_results.get("results", [])),
                    }), flush=True)
                except Exception as e:
                    print(json.dumps({
                        "event": "dns-results-save-failed",
                        "file": dns_results_file,
                        "error": str(e),
                    }), flush=True)
    else:
        print(json.dumps({
            "event": "dns-skip",
            "reason": "env_disabled",
        }))

    # wifi tests (optional)
    if enable_wifi:
        _run_wifi_tests(base, customer_id, location_id,
                        token, bearer, insecure)
    else:
        print(json.dumps({
            "event": "wifi-skip",
            "reason": "env_disabled_or_default_off",
        }))

    # LTE tests (optional)
    if enable_lte:
        _run_lte_test(base, customer_id, location_id,
                      token, bearer, insecure)
    else:
        print(json.dumps({
            "event": "lte-skip",
            "reason": "env_disabled_or_default_off",
        }))


def run() -> int:
    """
    entrypoint: ORIGINAL_ENTRY = main_impl_orig.py:run
    """
    # --- NOC 相關 ---
    base = _getenv("NOC_BASE", "https://piranha-int.tau.dev-charter.net")
    email = _getenv("NOC_EMAIL")
    password = _getenv("NOC_PASSWORD")
    bearer = _bool_env("BEARER", False)
    insecure = _bool_env("INSECURE", False)
    customer_id = _getenv("CUSTOMER_ID")

    if not email or not password:
        print(json.dumps({
            "event": "missing_credentials",
            "email": bool(email),
            "password": bool(password),
        }))
        return 2

    # --- CPE / Serial ---
    metrics_tool = _getenv("METRICS_TOOL", "/home/da40/charter/tools/cpe_metrics_agent_serial.py")
    dev = _getenv("CPE_DEV", "/dev/ttyUSB0")
    baud = int(_getenv("CPE_BAUD", "115200"))
    cpe_user = _getenv("CPE_USER", "root")
    cpe_password = _getenv("CPE_PASSWORD", "")
    if str(cpe_password).strip().lower() in ("none", "null", "nil"):
        cpe_password = ""

    cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
    if not cpe_password:
        cpe_password = _console_password(cpe_info_tool)
        print(json.dumps({"step": "console-password-fallback", "len": len(cpe_password)}))

    # --- SSH 動作 ---
    ssh_user = _getenv("SSH_USER", "operator")
    ssh_pass = _getenv("SSH_PASSWORD", "")
    ssh_timeout_min = int(_getenv("SSH_TIMEOUT_MIN", "120"))
    ssh_action = _getenv("SSH_ACTION", "enable").strip().lower()

    # SSH flow 開關（預設啟用）
    enable_ssh_flow = _bool_env("ENABLE_SSH_FLOW", True)

    if ssh_action not in ("enable", "disable", "both"):
        print(json.dumps({"event": "bad_ssh_action", "ssh_action": ssh_action}))
        return 1

    print(json.dumps({
        "event": "params",
        "base": base,
        "customer_id": customer_id,
        "ssh_action": ssh_action,
        "ssh_user": ssh_user,
        "enable_ssh_flow": enable_ssh_flow,
    }))

    try:
        # 1) login + node/location
        token = _login(base, email, password, bearer, insecure)
        node_id = _node_id(metrics_tool, dev, baud, cpe_user, cpe_password)
        location_id = _location_id(base, customer_id, node_id, token, bearer, insecure)

        # 2) NOC API 測試（內部再依 env 判斷 speedtest / wifi / lte）

        _run_noc_api_tests(base, customer_id, node_id, location_id,
                           token, bearer, insecure, ssh_pass, ssh_timeout_min)
        # 3) SSH enable / disable（可整個關掉）
        if enable_ssh_flow:
            if ssh_action in ("enable", "both"):
                _ssh_enable(base, customer_id, location_id, node_id,
                            ssh_pass, ssh_timeout_min, token, bearer, insecure)
            if ssh_action in ("disable", "both"):
                _ssh_disable(base, customer_id, location_id, node_id,
                             token, bearer, insecure)
        else:
            print(json.dumps({
                "event": "ssh-flow-skip",
                "reason": "env_disabled",
            }))

        return 0

    except Exception as e:
        print(json.dumps({"event": "exception", "error": str(e)}))
        return 1

if __name__ == "__main__":
    sys.exit(run())
