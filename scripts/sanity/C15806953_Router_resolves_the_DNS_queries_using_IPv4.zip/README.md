# C15806953_Router_resolves_the_DNS_queries_using_IPv4

## 1) 目的 / 覆蓋範圍
- 驗證 DNS resolve 行為（IPv4/IPv6 視腳本設定）。

## 2) 前置條件 / 環境
- 需可從指定介面/host 進行 DNS 查詢。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：1
- CYCLE_INTERVAL：70

## 5) PASS/FAIL 判定
- PASS：resolve 結果符合期望。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15806953_Router_resolves_the_DNS_queries_using_IPv4

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`sanity`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：1
- CYCLE_INTERVAL：70

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C15806953_Router_resolves_the_DNS_queries_using_IPv4

## 目的 / Purpose

這支腳本用來做 **DNS IPv4/IPv6 解析檢查**，重點是確認：

- 從 CPE LAN 端（經由 `cpe_ssh.py` 登入 CPE）對指定網域進行 DNS 查詢。
- 檢查 IPv4 (A) / IPv6 (AAAA) 回應數量是否達到預期。
- 支援重試機制與第二個備用網域。
- 可選擇同時執行 NOC API 測試 / SSH flow / health check，但在這個 PRD 中主要關注 DNS 行為。

每一個 cycle 的行為由 `cycle_wrapper.py` 控制（`CYCLES`, `CYCLE_INTERVAL`, `STOP_ON_FAIL`），
但此腳本預設 `CYCLES=1`，以方便在 lab 上 debug。

---

## 檔案架構

- `manifest.yaml`
  - 實際執行時會被平台讀取的設定檔。
  - DNS 測試相關的參數（TARGET / EXPECT_A_MIN / EXPECT_AAAA_MIN / RETRIES …）皆從這裡的 `env` 取得。
- `cycle_wrapper.py`
  - 通用 cycle 控制器：
    - 讀取 `manifest.yaml` → env
    - 依 `CYCLES / CYCLE_INTERVAL / STOP_ON_FAIL` 跑多輪
    - 每輪呼叫 `ORIGINAL_ENTRY` 指定的 entry（這顆是 `main_impl_orig.py:run`）。
- `main_impl_orig.py`
  - 單一 cycle 的主要流程實作，包含：
    - NOC login / node-id / locationId（若有需要）
    - DNS resolve 測試（呼叫 `dns_helper.run_dns_check()`）
    - （可選）其它 NOC API 測試、SSH flow、health check 等。
- `dns_helper.py`
  - 共用 DNS helper：
    - 透過 `cpe_ssh.py` 在 CPE 上跑 DNS 查詢。
    - 實作 retry / timeout / IPv4/IPv6 分別檢查。
- `cpe_health_helper.py`
  - 包一層 `cpe_ssh.py --cmd health`，可選擇做 CPE health 檢查。
- `main.py`
  - 方便在 lab 直接執行，載入 `manifest.yaml` 後呼叫 `cycle_wrapper.run()`。

---

## DNS 測試流程（對應 `main_impl_orig.py` 中的 DNS 區段）

本腳本的 DNS 測試是透過 `dns_helper.run_dns_check()` 完成，整體流程如下：

1. **讀取 DNS 相關環境變數**

   - `ENABLE_DNS_CHECK`
     - `1`：會執行 DNS 測試（這顆預設 `1`）。
     - `0`：完全跳過 DNS 檢查，只印出 `event=dns-skip`。
   - `TARGET`
     - 第一個主要檢查的網域，例如：`www.google.com`。
   - `SECOND`
     - 第二個備用網域；可以為空（`null` 或空字串），代表不做第二個 domain 檢查。
   - `EXPECT_A_MIN`
     - A record（IPv4）預期最少要有幾個回應才算 PASS。
   - `EXPECT_AAAA_MIN`
     - AAAA record（IPv6）預期最少要有幾個回應才算 PASS；
     - 若要關掉 IPv6 判斷，可設 `0`。
   - `RETRIES`
     - DNS 失敗時的重試次數。
   - `INTERVAL_SEC`
     - 每次重試之間的間隔秒數。
   - `DNS_SSH_TIMEOUT_SEC`
     - 每次透過 `cpe_ssh.py` 執行 DNS 查詢的 timeout（秒）。
   - `DEBUG_DNS`
     - `'1'`：開啟較 verbose 的 DNS log。
   - `DEBUG_SHOW_CMD`
     - `'1'`：在 log 中顯示實際執行的 `cpe_ssh.py` 命令。

   與 SSH 相關的 env：

   - `SSH_HOST_LAN`
     - 從哪個 IP 登入 CPE（預設 `192.168.1.1`）。
   - `SSH_USER`
     - SSH 使用者帳號（預設 `operator`）。
   - `SSH_PASSWORD`
     - SSH 密碼。

2. **log 出 DNS 參數**

   在執行前會印出一筆 JSON log，例如：

   ```json
   {
     "event": "dns-check-params",
     "target": "...",
     "second": "...",
     "expect_v4": 1,
     "expect_v6": 1,
     "retries": 3,
     "interval": 3,
```
