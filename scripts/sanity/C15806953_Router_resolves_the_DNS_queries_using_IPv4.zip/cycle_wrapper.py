#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Sanity cycle wrapper (stability-style precondition + per-cycle SSH readiness).

Goals (aligned with stability suite):
  1) node_id MUST be obtained only via `cpe_info --node-id` (no serial/console for node-id)
  2) precondition() runs only once (cycle #1):
      - cpe_info --cloud retry; if still fail -> PDU reset once -> retry again
      - scan TCP port 22; if closed -> NOC ssh-enable (attempt 2) -> wait -> re-scan
      - SSH uptime probe (cpe_ssh.py --cmd uptime)
  3) Before each cycle starts: scan port 22; if closed -> NOC ssh-enable (attempt 2)

Entrypoint:
  - manifest.yaml uses: entrypoint: cycle_wrapper.py:run (or rg_cycle_wrapper.py:run)

Key env (compatible with older sanity manifests):
  - CYCLES / CYCLE_TOTAL
  - CYCLE_INTERVAL / CYCLE_INTERVAL_SEC
  - STOP_ON_FAIL
  - ORIGINAL_ENTRY: "main_impl_orig.py:run" (module.py:func)

Tools:
  - /home/da40/charter/tools/cpe_info
  - /home/da40/charter/tools/cpe_ssh.py
  - /home/da40/charter/tools/noc_api_cli.py (python module)

This wrapper is self-contained and does NOT call module-provided cpe_ready_check() hooks,
to guarantee consistent behavior across sanity scripts.
"""

from __future__ import annotations

import importlib
import json
import os
import socket
import subprocess
import sys
import time
from typing import Any, Dict, Tuple, Callable


def _emit(event: str, **fields: Any) -> None:
    obj = {"event": event}
    obj.update(fields)
    print(json.dumps(obj, ensure_ascii=False), flush=True)


def _env_bool(name: str, default: bool = False) -> bool:
    v = str(os.environ.get(name, "")).strip().lower()
    if not v:
        return default
    return v in ("1", "true", "yes", "y", "on")


def _env_int(name: str, default: int) -> int:
    try:
        return int(str(os.environ.get(name, str(default))).strip())
    except Exception:
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return float(str(os.environ.get(name, str(default))).strip())
    except Exception:
        return default


def _tools_path() -> str:
    return os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")


def _cpe_info_tool() -> str:
    return os.environ.get("CPE_INFO_TOOL", os.path.join(_tools_path(), "cpe_info"))


def _cpe_ssh_tool() -> str:
    return os.environ.get("CPE_SSH_TOOL", os.path.join(_tools_path(), "cpe_ssh.py"))


def _pybin() -> str:
    return os.environ.get("PYTHON", "python3")


def _cpe_host() -> str:
    return os.environ.get("CPE_HOST", os.environ.get("CPE_GATEWAY", "192.168.1.1"))


def _cpe_ssh_user() -> str:
    return os.environ.get("CPE_SSH_USER", os.environ.get("SSH_USER", "operator"))


def _cpe_ssh_password() -> str:
    # For NOC ssh-enable, passwd must match operator password
    return os.environ.get("SSH_PASSWORD", os.environ.get("CPE_SSH_PASSWORD", os.environ.get("CPE_PASSWORD", "")))


def _run(argv: list[str], timeout: float = 60.0) -> Tuple[int, str]:
    t0 = time.time()
    try:
        p = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)
        out = p.stdout or ""
        sec = round(time.time() - t0, 3)
        sample = out.strip().splitlines()[-2:]
        _emit("cmd", ok=(p.returncode == 0), rc=p.returncode, sec=sec, argv=argv, sample=sample)
        return p.returncode, out
    except subprocess.TimeoutExpired as e:
        sec = round(time.time() - t0, 3)
        _emit("cmd", ok=False, rc=124, sec=sec, argv=argv, error="timeout")
        return 124, (e.stdout or "") + "\n(timeout)"


def _cloud_connected(out: str) -> bool:
    for line in (out or "").splitlines():
        s = line.strip()
        if not s:
            continue
        if "cloud status" in s.lower():
            return "connected" in s.lower()
        if s.lower() == "connected":
            return True
    return False


def _wait_cpe_cloud(tag: str, max_retries: int, sleep_sec: int) -> bool:
    tool = _cpe_info_tool()
    _emit("step_start", name="cpe_ready", phase="initial", max_retries=max_retries, sleep_sec=sleep_sec, tool=tool, tag=tag)
    for attempt in range(1, max_retries + 1):
        rc, out = _run([tool, "--cloud"], timeout=30.0)
        ok = (rc == 0 and _cloud_connected(out))
        _emit("step_progress", name="cpe_ready", phase="initial", try_no=attempt, ok=ok, sample=out.strip().splitlines()[-2:], tag=tag)
        if ok:
            _emit("step_end", name="cpe_ready", phase="initial", ok=True, tag=tag)
            return True
        if attempt < max_retries and sleep_sec > 0:
            time.sleep(sleep_sec)
    _emit("step_end", name="cpe_ready", phase="initial", ok=False, tag=tag)
    return False


def _pdu_reset(tag: str) -> None:
    # Compatibility: prefer PDU_RESET_SCRIPT; else PDU_SCRIPT.
    script = os.environ.get("PDU_RESET_SCRIPT", os.environ.get("PDU_SCRIPT", "/home/da40/charter/tools/pdu_outlet1.py"))
    action = os.environ.get("PDU_RESET_ACTION", os.environ.get("PDU_ACTION", "reset"))
    timeout_sec = _env_int("PDU_RESET_TIMEOUT_SEC", 600)
    wait_sec = _env_int("PDU_RESET_WAIT_SEC", 120)

    _emit("pdu_reset_start", script=script, action=action, tag=tag)
    rc, out = _run([_pybin(), script, action], timeout=float(timeout_sec))
    _emit("pdu_reset_end", rc=rc, output_tail=(out or "")[-2000:], tag=tag)

    if wait_sec > 0:
        _emit("pdu_reset_wait", seconds=wait_sec, tag=tag)
        time.sleep(wait_sec)


def _get_node_id(tag: str, retries: int = 3, sleep_sec: float = 2.0, cmd_timeout_sec: float = 15.0) -> str:
    """Fetch node_id via cpe_info with retry.

    This protects us from transient cpe_info timeouts which otherwise
    can lead to empty node_id and 404 on the NOC nodes endpoint.
    """
    tool = _cpe_info_tool()

    nid = ""
    last_err = ""
    for attempt in range(1, int(retries) + 1):
        try:
            rc, out = _run([tool, "--node-id"], timeout=float(cmd_timeout_sec))
            if rc == 0:
                for line in (out or "").splitlines():
                    s = line.strip()
                    if s:
                        nid = s
                        break
        except subprocess.TimeoutExpired:
            rc = -1
            out = ""
            last_err = "timeout"

        _emit("node-id-cpe_info", attempt=attempt, ok=bool(nid), rc=rc, node_id=nid, error=last_err, tag=tag)
        if nid:
            break
        if attempt < int(retries):
            time.sleep(float(sleep_sec))

    if nid:
        _emit("node_id", ok=True, node_id=nid, tag=tag)
    return nid


def _tcp_wait(host: str, port: int, timeout_sec: int, interval_sec: float) -> bool:
    deadline = time.time() + max(1, int(timeout_sec))
    while time.time() < deadline:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(2.0)
        try:
            s.connect((host, port))
            s.close()
            return True
        except Exception:
            try:
                s.close()
            except Exception:
                pass
            time.sleep(max(0.2, interval_sec))
    return False


def _load_noc_profile(tag: str) -> Dict[str, Any]:
    """Load NOC creds from PROFILES_FILE+NOC_PROFILE if present; fallback to env."""
    applied = []
    prof_name = os.environ.get("NOC_PROFILE", "")
    prof_file = os.environ.get("PROFILES_FILE", "")
    # expected keys in profile
    keys = ["NOC_BASE", "NOC_EMAIL", "NOC_PASSWORD", "CUSTOMER_ID", "BEARER", "INSECURE"]
    if prof_name and prof_file:
        try:
            with open(prof_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            prof = data.get(prof_name, {}) if isinstance(data, dict) else {}
            if isinstance(prof, dict):
                for k in keys:
                    if k in prof and not os.environ.get(k):
                        os.environ[k] = str(prof[k])
                        applied.append(k)
            _emit("noc_profile_loaded", profile=prof_name, applied=applied, tag=tag)
        except Exception as e:
            _emit("noc_profile_load_failed", profile=prof_name, error=str(e), tag=tag)
    else:
        _emit("noc_profile_skipped", reason="missing NOC_PROFILE/PROFILES_FILE", tag=tag)

    return {
        "base": os.environ.get("NOC_BASE", ""),
        "email": os.environ.get("NOC_EMAIL", ""),
        "password": os.environ.get("NOC_PASSWORD", ""),
        "customer_id": os.environ.get("CUSTOMER_ID", os.environ.get("NOC_CUSTOMER_ID", "")),
        "bearer": _env_bool("BEARER", False),
        "insecure": _env_bool("INSECURE", False),
    }


def _import_noc_api():
    tp = _tools_path()
    if tp and tp not in sys.path:
        sys.path.insert(0, tp)
    import noc_api_cli as api  # type: ignore
    return api


def _enable_ssh_via_noc(node_id: str, ssh_password: str, tag: str) -> bool:
    meta = _load_noc_profile(tag)
    base = meta.get("base") or ""
    email = meta.get("email") or ""
    password = meta.get("password") or ""
    customer_id = meta.get("customer_id") or ""
    bearer = bool(meta.get("bearer"))
    insecure = bool(meta.get("insecure"))

    if not (base and email and password and customer_id and node_id and ssh_password):
        _emit("ssh_enable_end", ok=False, error="missing noc credentials / node_id / ssh_password", tag=tag)
        return False

    try:
        api = _import_noc_api()
        tok = api.login(base, email, password, bearer=bearer, insecure=insecure)
        location_id = api.get_location_id(base, customer_id, node_id, token=tok, bearer=bearer, insecure=insecure)
        timeout_min = _env_int("SSH_TIMEOUT_MIN", _env_int("SSH_ENABLE_TIMEOUT_MIN", 120))

        _emit("ssh_enable_start", node_id=node_id, location_id=location_id, customer_id=customer_id, timeout_min=timeout_min, tag=tag)
        resp = api.ssh_enable(base, customer_id, location_id, node_id, ssh_password, timeout_min, token=tok, bearer=bearer, insecure=insecure)
        _emit("ssh_enable_end", ok=True, resp=resp, tag=tag)
        return True
    except Exception as e:
        _emit("ssh_enable_end", ok=False, error=str(e), tag=tag)
        return False


def _ssh_probe(host: str, user: str, passwd: str, tag: str) -> bool:
    tool = _cpe_ssh_tool()
    timeout = _env_float("CPE_SSH_TIMEOUT_SEC", 30.0)
    argv = [
        _pybin(),
        tool,
        "--host", host,
        "--user", user,
        "--password", passwd,
        "--timeout", str(timeout),
        "--cmd", "uptime",
    ]
    t0 = time.time()
    rc, out = _run(argv, timeout=timeout + 10.0)
    sec = round(time.time() - t0, 3)
    sample = (out or "").strip().splitlines()[-2:]
    ok = (rc == 0)
    _emit("ssh_probe", ok=ok, rc=rc, sec=sec, sample=sample, tag=tag)
    return ok


def ensure_ssh_ready(tag: str) -> bool:
    host = _cpe_host()
    port = _env_int("CPE_SSH_PORT", 22)
    scan_timeout = _env_int("SSH_SCAN_TIMEOUT_SEC", 30)
    scan_interval = _env_float("SSH_SCAN_INTERVAL_SEC", 2.0)

    enable_retries = _env_int("SSH_ENABLE_RETRIES", 2)
    wait_after_enable = _env_int("WAIT_AFTER_SSH_ENABLE_SEC", 60)
    auto_enable = _env_bool("AUTO_SSH_ENABLE", True) and _env_bool("SSH_ENABLE_VIA_NOC", True)

    user = _cpe_ssh_user()
    passwd = _cpe_ssh_password()
    node_id_retries = _env_int("NODE_ID_MAX_TRIES", _env_int("NODE_ID_RETRIES", 3))
    node_id_sleep = _env_float("NODE_ID_INTERVAL_SEC", _env_float("NODE_ID_RETRY_SLEEP_SEC", 2.0))
    node_id_timeout = _env_float("NODE_ID_CMD_TIMEOUT_SEC", 15.0)
    node_id = _get_node_id(tag, retries=node_id_retries, sleep_sec=node_id_sleep, cmd_timeout_sec=node_id_timeout)

    _emit("step_start", name="ssh_ready", host=host, port=port, scan_timeout_sec=scan_timeout, scan_interval_sec=scan_interval, user=user, have_password=bool(passwd), node_id=node_id, tag=tag)

    for attempt in range(1, enable_retries + 1):
        # 1) Check port/probe (pre-enable)
        port_ok = _tcp_wait(host, port, timeout_sec=scan_timeout, interval_sec=scan_interval)
        _emit("ssh_port", ok=port_ok, attempt=attempt, phase="pre_enable", tag=tag)

        if port_ok and passwd and _ssh_probe(host, user, passwd, tag):
            _emit("step_end", name="ssh_ready", ok=True, tag=tag)
            return True

        # 2) Enable via NOC (optional)
        if not auto_enable:
            _emit("ssh_enable_skipped", ok=False, error="AUTO_SSH_ENABLE/SSH_ENABLE_VIA_NOC disabled", tag=tag)
            break
        if not passwd:
            _emit("ssh_enable_skip", ok=False, error="ssh_password not available", tag=tag)
            break
        if not node_id:
            _emit("ssh_enable_skip", ok=False, error="node_id not available", tag=tag)
            break

        ok = _enable_ssh_via_noc(node_id=node_id, ssh_password=passwd, tag=tag)
        if not ok:
            _emit("ssh_enable_attempt_failed", attempt=attempt, tag=tag)
            continue

        if wait_after_enable > 0:
            _emit("ssh_enable_wait", seconds=wait_after_enable, tag=tag)
            time.sleep(wait_after_enable)

        # 3) Re-check after enable within the same attempt (fixes last-attempt edge case)
        port_ok2 = _tcp_wait(host, port, timeout_sec=scan_timeout, interval_sec=scan_interval)
        _emit("ssh_port", ok=port_ok2, attempt=attempt, phase="post_enable", tag=tag)
        if port_ok2 and passwd and _ssh_probe(host, user, passwd, tag):
            _emit("step_end", name="ssh_ready", ok=True, tag=tag)
            return True

    _emit("step_end", name="ssh_ready", ok=False, tag=tag)
    return False


def _resolve_entry(entry: str) -> Callable[[], int]:
    if ":" not in entry:
        raise ValueError(f"Bad ORIGINAL_ENTRY format: {entry!r}")
    mod_name, func_name = entry.split(":", 1)
    if mod_name.endswith(".py"):
        mod_name = mod_name[:-3]
    mod = importlib.import_module(mod_name)
    fn = getattr(mod, func_name, None)
    if not callable(fn):
        raise AttributeError(f"entry function not found: {entry!r}")
    return fn  # type: ignore[return-value]


def _get_cycles() -> int:
    # compatibility: CYCLES or CYCLE_TOTAL
    return _env_int("CYCLES", _env_int("CYCLE_TOTAL", 1))


def _get_interval() -> float:
    return float(_env_int("CYCLE_INTERVAL", _env_int("CYCLE_INTERVAL_SEC", 30)))


def run() -> int:
    cycles = _get_cycles()
    interval = _get_interval()
    stop_on_fail = _env_bool("STOP_ON_FAIL", True)
    entry = os.environ.get("ORIGINAL_ENTRY", os.environ.get("ORIGINAL_ENTRYPOINT", "main_impl_orig.py:run"))

    try:
        func = _resolve_entry(entry)
    except Exception as e:
        _emit("entry_resolve_error", entry=entry, error=str(e))
        return 1

    _emit("runner_start", name=os.environ.get("TEST_NAME", os.environ.get("name", "")) or "sanity_cycle", cycles=cycles, interval=interval, stop_on_fail=stop_on_fail, original_entry=entry)

    # === precondition (cycle #1 only) ===
    precond_ok = True
    if cycles >= 1:
        tag = "precondition"
        # load profile (log only; also applies missing env)
        _load_noc_profile(tag)

        ready = _wait_cpe_cloud(tag, max_retries=_env_int("CPE_READY_MAX_RETRIES", 10), sleep_sec=_env_int("CPE_READY_RETRY_INTERVAL_SEC", 30))
        if not ready and _env_bool("PDU_RESET_ON_NOT_READY", True):
            _pdu_reset(tag)
            ready = _wait_cpe_cloud(tag, max_retries=_env_int("CPE_READY_MAX_RETRIES", 10), sleep_sec=_env_int("CPE_READY_RETRY_INTERVAL_SEC", 30))
        if not ready:
            _emit("precondition_fail", rc=2, reason="cpe_not_ready", tag=tag)
            precond_ok = False

        if precond_ok:
            if not ensure_ssh_ready(tag):
                _emit("precondition_fail", rc=2, reason="ssh_not_ready", tag=tag)
                precond_ok = False

        _emit("precondition_ok", ok=precond_ok, tag=tag)

    if not precond_ok:
        return 2

    overall_rc = 0
    for i in range(cycles):
        cycle_no = i + 1
        _emit("cycle_start", i=cycle_no, cycle=cycle_no, total=cycles)

        # per-cycle ssh readiness (as requested)
        if not ensure_ssh_ready(f"cycle_{cycle_no}"):
            overall_rc = 2
            if stop_on_fail:
                break

        try:
            rc = int(func() or 0)
        except SystemExit as se:
            rc = int(se.code or 0)
        except Exception as e:
            _emit("cycle_exception", cycle=cycle_no, error=str(e))
            rc = 1

        _emit("cycle_end", cycle=cycle_no, rc=rc)
        if rc != 0:
            overall_rc = rc
            if stop_on_fail:
                break

        if cycle_no < cycles and interval > 0:
            time.sleep(interval)

    _emit("all_cycles_done", rc=overall_rc)
    return overall_rc


if __name__ == "__main__":
    sys.exit(run())
