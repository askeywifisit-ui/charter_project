#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""A2435637_Continuously_executing_FactoryReset — v7-style precondition + per-cycle SSH ensure

要求：
- Precondition（cycle #1 一次）：cpe_ready retry -> fail 則 PDU reset 1 次 -> 再 retry；且 ssh port:22 scan fail 則 NOC ssh-enable
- 每一個 cycle：在執行原本測試流程前，再做一次 ssh port:22 scan，若關閉則 NOC ssh-enable（同 A2435638 v7 行為）

Note:
- 本檔只負責「前置條件 / SSH ready」與呼叫原本的 main_impl_orig.py:run()
- 原本腳本邏輯保留在 main_impl_orig.py
"""

from __future__ import annotations

import importlib.util
import json
import os
import pathlib
import socket
import subprocess
import sys
import time
from typing import Any, Optional, Tuple

# ---------- logging ----------
def _emit(event: str, **k: Any) -> None:
    d = {"event": event}
    d.update(k)
    print(json.dumps(d, ensure_ascii=False), flush=True)

def _log(msg: str) -> None:
    print(msg, flush=True)


def _redact_argv(argv):
    # return a redacted shallow copy of argv list (mask secrets after specific flags)
    try:
        a = list(argv)
    except Exception:
        return argv
    secret_flags = {"--password", "--passphrase", "--ssh-pass", "--token", "--bearer-token", "--auth", "--authorization"}
    i = 0
    while i < len(a) - 1:
        if str(a[i]) in secret_flags:
            a[i+1] = "***"
            i += 2
            continue
        i += 1
    return a

def _redact_obj(obj):
    # recursively redact known secret keys
    secret_keys = {"password","passphrase","sshpass","ssh_pass","ssh-pass","sshpassword","ssh_password","token","bearer","authorization",
                   "sshAuthPasswd","ssh_passwd","sshAuthPassword"}
    if isinstance(obj, dict):
        out={}
        for k,v in obj.items():
            if str(k) in secret_keys:
                out[k]="***"
            else:
                out[k]=_redact_obj(v)
        return out
    if isinstance(obj, list):
        return [_redact_obj(x) for x in obj]
    return obj

# ---------- env ----------
def _g(name: str, default: str = "") -> str:
    v = os.environ.get(name)
    return str(default) if v is None else str(v)

def _gi(name: str, default: int) -> int:
    try:
        return int(str(os.environ.get(name, str(default))).strip())
    except Exception:
        return int(default)

def _gf(name: str, default: float) -> float:
    try:
        return float(str(os.environ.get(name, str(default))).strip())
    except Exception:
        return float(default)

def _gb(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    s = str(v).strip().lower()
    if s in ("1","true","yes","on","y"):
        return True
    if s in ("0","false","no","off","n"):
        return False
    return default

# ---------- tools / profile ----------
def _tools_path() -> str:
    return _g("TOOLS_PATH", "/home/da40/charter/tools").strip() or "/home/da40/charter/tools"

def _cpe_info() -> str:
    return _g("CPE_INFO_TOOL", str(pathlib.Path(_tools_path()) / "cpe_info"))

def _load_profile_into_env() -> None:
    profile = _g("NOC_PROFILE","").strip()
    if not profile:
        return
    path = _g("PROFILES_FILE", "/home/da40/charter/.secrets/noc_profiles.json").strip()
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        _emit("noc_profile_load_error", profile=profile, path=path, error=str(e))
        return
    prof = data.get(profile) or data.get(profile.upper()) or {}
    if not prof:
        _emit("noc_profile_not_found", profile=profile, path=path)
        return
    mapping = {
        "NOC_BASE": "base",
        "NOC_EMAIL": "email",
        "NOC_PASSWORD": "password",
        "CUSTOMER_ID": "customer_id",
        "LOCATION_ID": "location_id",
        "NOC_TOKEN": "token",
        "BEARER": "bearer",
        "INSECURE": "insecure",
    }
    applied=[]
    for ek,jk in mapping.items():
        if os.environ.get(ek) and str(os.environ.get(ek)).strip() != "":
            continue
        if jk in prof and prof[jk] is not None:
            os.environ[ek] = str(prof[jk])
            applied.append(ek)
    _emit("noc_profile_loaded", profile=profile, applied=applied)

def _import_noc_api_cli():
    tp=_tools_path()
    if tp and tp not in sys.path:
        sys.path.insert(0,tp)
    import noc_api_cli  # type: ignore
    return noc_api_cli

# ---------- cmd helpers ----------
def _run(argv, timeout: float=30.0) -> Tuple[bool,int,float,str]:
    t0=time.time()
    try:
        p=subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)
        out=(p.stdout or "").strip()
        sec=round(time.time()-t0,3)
        _emit("cmd", ok=(p.returncode==0), rc=p.returncode, sec=sec, argv=_redact_argv(argv), sample=out.splitlines()[:3])
        return p.returncode==0, p.returncode, sec, out
    except subprocess.TimeoutExpired:
        sec=round(time.time()-t0,3)
        _emit("cmd", ok=False, rc=124, timeout=True, sec=sec, argv=_redact_argv(argv))
        return False, 124, sec, ""

def _tcp_open(host: str, port: int, per_try_timeout: float=2.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=per_try_timeout):
            return True
    except Exception:
        return False

# ---------- cpe ready ----------
def ensure_cpe_ready_with_pdu_once(tag: str) -> bool:
    tool=_cpe_info()
    max_retries=_gi("CPE_READY_MAX_RETRIES", 10)
    sleep_sec=_gi("CPE_READY_RETRY_SLEEP_SEC", 30)
    timeout=_gf("CPE_INFO_TIMEOUT_SEC", 30.0)

    def _probe(phase: str) -> bool:
        _emit("step_start", name="cpe_ready", phase=phase, max_retries=max_retries, sleep_sec=sleep_sec, tool=tool, tag=tag)
        for i in range(1, max_retries+1):
            ok,rc,sec,out=_run([tool,"--cloud"], timeout=timeout)
            ready = ok and ("Cloud Status: Connected" in out)
            _emit("step_progress", name="cpe_ready", phase=phase, try_no=i, ok=ready, sample=out.splitlines()[:2], tag=tag)
            if ready:
                _emit("step_end", name="cpe_ready", phase=phase, ok=True, tag=tag)
                return True
            time.sleep(sleep_sec)
        _emit("step_end", name="cpe_ready", phase=phase, ok=False, tag=tag)
        return False

    if _probe("initial"):
        return True

    if not _gb("PDU_RESET_ON_NOT_READY", True):
        return False

    # one-time PDU reset
    pdu_script=_g("PDU_SCRIPT", "/home/da40/charter/tools/pdu_outlet1.py").strip()
    outlet_id=_g("PDU_OUTLET_ID","1").strip()
    pdu_timeout=_gi("PDU_RESET_TIMEOUT_SEC", 600)
    wait_sec=_gi("PDU_RESET_WAIT_SEC", 120)
    args_style=_g("PDU_SCRIPT_ARGS_STYLE","").strip().lower()

    _emit("step_start", name="pdu_reset", script=pdu_script, outlet_id=outlet_id, timeout_sec=pdu_timeout, tag=tag)
    argv=["python3", pdu_script, "reset"]
    if args_style in ("with_outlet_id","need_outlet_id","outlet_id"):
        argv.append(str(outlet_id))
    _run(argv, timeout=float(pdu_timeout))
    _emit("step_end", name="pdu_reset", ok=True, argv=argv, tag=tag)

    if wait_sec>0:
        _emit("sleep", name="after_pdu_reset", seconds=wait_sec, tag=tag)
        _log(f"[runner] wait {wait_sec}s")
        time.sleep(wait_sec)

    return _probe("after_pdu")

def get_node_id() -> str:
    ok,rc,sec,out=_run([_cpe_info(),"--node-id"], timeout=15)
    if not ok:
        return ""
    for line in out.splitlines():
        s=line.strip()
        if s:
            return s
    return ""

# ---------- ssh ensure ----------
def enable_ssh_via_noc(node_id: str) -> bool:
    noc=_import_noc_api_cli()
    base=_g("NOC_BASE","").strip() or "https://piranha-int.tau.dev-charter.net"
    customer_id=_g("CUSTOMER_ID","").strip()
    email=_g("NOC_EMAIL","").strip()
    password=_g("NOC_PASSWORD","").strip()
    bearer=_gb("BEARER", False)
    insecure=_gb("INSECURE", False)

    ssh_password = _g("SSH_PASSWORD","").strip() or _g("SSH_PASSWORD_DEFAULT","123456789").strip() or "123456789"
    timeout_min=_gi("SSH_ENABLE_TIMEOUT_MIN", 120)

    if not customer_id:
        _emit("ssh_enable_end", ok=False, error="CUSTOMER_ID not set")
        return False
    if not email or not password:
        _emit("ssh_enable_end", ok=False, error="NOC_EMAIL/NOC_PASSWORD not set")
        return False

    _emit("ssh_enable_start", node_id=node_id, location_id=_g("LOCATION_ID","").strip() or None,
          customer_id=customer_id, timeout_min=timeout_min, base=base)

    try:
        token = noc.login(base, email, password, bearer=bearer, insecure=insecure)
        location_id = _g("LOCATION_ID","").strip() or noc.get_location_id(base, customer_id, node_id, token=token, bearer=bearer, insecure=insecure)
        resp = noc.ssh_enable(base, customer_id, location_id, node_id,
                              ssh_password, timeout_min,
                              token=token, bearer=bearer, insecure=insecure)
        _emit("ssh_enable_end", ok=True, resp=_redact_obj(resp))
        os.environ["LOCATION_ID"]=str(location_id)
        return True
    except Exception as e:
        _emit("ssh_enable_end", ok=False, error=str(e))
        return False

def ensure_ssh_ready(node_id: str, tag: str) -> bool:
    host=_g("CPE_HOST","192.168.1.1").strip() or "192.168.1.1"
    port=_gi("CPE_SSH_PORT", 22)
    scan_timeout=_gi("SSH_SCAN_TIMEOUT_SEC", 60)
    scan_interval=_gf("SSH_SCAN_INTERVAL_SEC", 2.0)
    user=_g("SSH_USER","operator").strip() or "operator"
    ssh_password=_g("SSH_PASSWORD","").strip() or _g("SSH_PASSWORD_DEFAULT","123456789").strip() or "123456789"
    have_password=bool(ssh_password)

    pybin=_g("PYTHON_BIN","python3").strip() or "python3"
    cpe_ssh=_g("CPE_SSH_TOOL", str(pathlib.Path(_tools_path())/"cpe_ssh.py")).strip()

    _emit("step_start", name="ssh_ready", host=host, port=port, scan_timeout_sec=scan_timeout,
          scan_interval_sec=scan_interval, user=user, have_password=have_password, node_id=node_id, tag=tag)

    def _scan_port() -> bool:
        t0=time.time()
        attempt=0
        while time.time()-t0 < scan_timeout:
            attempt += 1
            if _tcp_open(host, port, per_try_timeout=min(2.0, scan_interval)):
                _emit("ssh_port", ok=True, attempt=attempt, tag=tag)
                return True
            time.sleep(scan_interval)
        _emit("ssh_port", ok=False, attempt=1, tag=tag)
        return False

    def _probe() -> bool:
        ok,rc,sec,out=_run([pybin, cpe_ssh, "--host", host, "--user", user, "--password", ssh_password,
                            "--timeout", "30.0", "--cmd", "uptime"], timeout=40.0)
        _emit("ssh_probe", ok=ok, rc=rc, sec=sec, sample=out.splitlines()[:2], tag=tag)
        return ok

    if _scan_port() and _probe():
        _emit("step_end", name="ssh_ready", ok=True, tag=tag)
        return True

    retries=_gi("SSH_ENABLE_RETRIES", 2)
    wait_after=_gi("WAIT_AFTER_SSH_ENABLE_SEC", 60)

    for _ in range(1, retries+1):
        if not enable_ssh_via_noc(node_id):
            continue
        _emit("ssh_enable_wait", seconds=wait_after, tag=tag)
        time.sleep(max(0,wait_after))

        t0=time.time()
        attempt=1
        while time.time()-t0 < scan_timeout:
            attempt += 1
            if _tcp_open(host, port, per_try_timeout=min(2.0, scan_interval)):
                _emit("ssh_port", ok=True, attempt=attempt, tag=tag)
                if _probe():
                    _emit("step_end", name="ssh_ready", ok=True, tag=tag)
                    return True
            time.sleep(scan_interval)
        _emit("ssh_port", ok=False, attempt=attempt, tag=tag)

    _emit("step_end", name="ssh_ready", ok=False, tag=tag)
    return False

# ---------- call original ----------
def _call_orig() -> int:
    here = pathlib.Path(__file__).resolve().parent
    orig_path = here / "main_impl_orig.py"
    spec = importlib.util.spec_from_file_location("orig_impl", orig_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load orig module: {orig_path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)  # type: ignore
    fn = getattr(mod, "run", None)
    if not callable(fn):
        raise RuntimeError("orig module missing run()")
    rc = fn()
    return int(rc) if isinstance(rc, int) else 0

# ---------- entrypoints ----------
def precondition() -> int:
    _load_profile_into_env()
    if not ensure_cpe_ready_with_pdu_once("precondition"):
        _emit("precondition_ok", ok=False, reason="cpe_not_ready")
        return 2
    node_id = get_node_id()
    if not node_id:
        _emit("precondition_ok", ok=False, reason="node_id_missing")
        return 3
    if not ensure_ssh_ready(node_id, "precondition"):
        _emit("precondition_ok", ok=False, reason="ssh_not_ready")
        return 4
    _emit("precondition_ok", ok=True)
    return 0

def run() -> int:
    _load_profile_into_env()
    cycle = _gi("CYCLE_INDEX", 1)
    if not ensure_cpe_ready_with_pdu_once(f"cycle_{cycle}"):
        return 2
    node_id = get_node_id()
    if not node_id:
        return 3
    if not ensure_ssh_ready(node_id, f"cycle_{cycle}"):
        return 4
    return _call_orig()

if __name__ == "__main__":
    raise SystemExit(run())
