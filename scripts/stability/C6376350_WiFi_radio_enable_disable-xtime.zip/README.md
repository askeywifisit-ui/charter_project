# C6376350_WiFi_radio_enable_disable-xtime

## 1) 目的 / 覆蓋範圍
- 驗證 Wi‑Fi SSID 廣播、client 連線或 radio toggle 行為。

## 2) 前置條件 / 環境
- 需有可用 WLAN client，且腳本指定的 SSID/頻段在環境中存在。

## 3) 如何執行
- 平台：UI `/scripts` 點 Run 或 API：`POST /api/scripts/{id}/run`

## 4) 重要設定（manifest 摘要）
- suite（資料夾）：`stability`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'90'

## 5) PASS/FAIL 判定
- PASS：SSID/連線/radio 狀態符合預期。

## 6) 常見失敗 / Root cause / 建議
- （待補：由 failed run log 補上 root cause 與修正建議）

## 7) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 8) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
# C6376350_WiFi_radio_enable_disable-xtime

## 1) 目的 / 覆蓋範圍
- （請補：此腳本驗證的功能點/場景；若為穩定性/長跑請說明）

## 2) 如何執行
- 平台：在 UI /scripts 選 Run，或 API：`POST /api/scripts/{id}/run`

## 3) 重要設定（manifest 摘要）
- suite（資料夾）：`stability`
- entrypoint：`cycle_wrapper.py:run`
- CYCLES：'1'
- CYCLE_INTERVAL：'90'

## 4) PASS/FAIL 判定
- 以 run status（passed/failed/error）為準；細節見 `/api/runs/{run_id}/log`

## 5) 常見失敗 / Root cause / 建議
- （待補：從 failed log 摘要 root cause 與修正建議）

## 6) 安全與憑證
- README/zip 內避免放真實 credentials；建議使用 `.secrets`/`PROFILES_FILE` 或以 `<REDACTED>`/`<placeholder>` 表示。

---

## 7) Legacy notes（保留原 README 摘要，已做敏感資訊遮罩）
```text
> Professional update: remove hard-coded/empty NOC credentials and avoid serial node-id; use NOC_PROFILE+PROFILES_FILE and cpe_info --node-id.

# C6376350_WiFi_radio_enable_disable-xtime

## 目的 / Purpose

這支腳本用來做 **WiFi radio enable/disable 長時間測試**（long-run）：

- 每一個 cycle 會透過 **NOC API** 針對指定 CPE 做：
  1. login & 取得 `node_id` / `location_id`
  2. 執行一輪 NOC API 測試（以 **WiFi radio 開關** 為主）：
     - `wifi-status`
     - `wifi-enable` / `wifi-disable`（反轉一次）
     - 再次 `wifi-status` 並恢復成原本狀態
  3. 依設定決定是否執行 SSH enable flow
  4. 檢查 SSH port 是否開啟，不開時會透過 NOC API 重新 enable SSH
  5. 執行一次 CPE health check（`cpe_ssh.py --cmd health`）

- 由 `cycle_wrapper.py` 控制 `CYCLES`、`CYCLE_INTERVAL`，可以做長時間 WiFi radio 穩定度測試
  （例如每幾分鐘反轉一次 WiFi 開關，觀察是否有 crash / 異常）。

在這顆腳本的 `manifest.yaml` 預設中：

- `ENABLE_WIFI_TEST = 1` → **只跑 WiFi 測試**
- `ENABLE_SPEEDTEST = 0`
- `ENABLE_LTE_TEST = 0`
- `ENABLE_DNS_CHECK = 0`

---

## 檔案架構

- `manifest.yaml`
  - 所有環境變數集中設定（cycle 次數、NOC 帳密、WiFi 測試開關、SSH 帳號密碼…）。
- `cycle_wrapper.py`
  - 讀取 `manifest.yaml` 的 `env`，依 `CYCLES / CYCLE_INTERVAL / STOP_ON_FAIL` 做外層迴圈。
  - 每一輪呼叫 `ORIGINAL_ENTRY` 指定的 entry function（這顆是 `main_impl_orig.py:run`）。
- `main_impl.py`
  - shim：載入 `main_impl_orig.run()`，並把回傳碼 / 例外轉成 cycle_wrapper 期待的 rc。
- `main_impl_orig.py`
  - 主要邏輯實作：
    - NOC login、node-id、location-id
    - NOC API 測試（WiFi 為主，可選 speedtest / LTE）
    - SSH enable/disable flow
    - CPE health check
- `cpe_health_helper.py`
  - 包一層 `cpe_ssh.py --cmd health`，做 CPE 自身 health 檢查。
- `main.py`
  - 方便在 lab 直接執行，會載入 `manifest.yaml` 然後呼叫 `cycle_wrapper.run()`。

---

## 單一 cycle 流程（對應 `main_impl_orig.run()`）

1. **讀取環境變數**

   - NOC 相關：
     - `NOC_BASE`, `NOC_EMAIL`, `NOC_PASSWORD`, `CUSTOMER_ID`, `BEARER`, `INSECURE`
   - Serial / tools：
     - `CPE_DEV`, `CPE_BAUD`, `CPE_USER`, `CPE_PASSWORD`
     - `TOOLS_PATH`, `METRICS_TOOL`, `CPE_INFO_TOOL`
   - NOC API 測試開關：
     - `ENABLE_NOC_API_TESTS`
     - `ENABLE_SPEEDTEST`
     - `ENABLE_WIFI_TEST`
     - `ENABLE_LTE_TEST`
   - SSH / health：
     - `SSH_USER`, `SSH_PASSWORD`, `SSH_HOST_LAN`
     - `SSH_TIMEOUT_MIN`, `SSH_ACTION`, `ENABLE_SSH_FLOW`
     - `CPE_HEALTH_WAIT_SEC`
     - `CPE_HEALTH_HOST`, `CPE_HEALTH_PORT`, `SSH_PORT_CHECK_TIMEOUT`（如果有設定）

2. **NOC login + node-id + location-id**

   - 呼叫 `noc_api_cli` 登入 NOC，取得 access token。
   - 使用 `cpe_info --node-id` 取得 `node_id`（不走 serial/console）：
     - 內部會依 `NODE_ID_MAX_RETRIES` / `NODE_ID_RETRY_INTERVAL_SEC` 做多次重試，避免 console 一時 lock 住。
   - 透過 NOC API 以 `CUSTOMER_ID + node_id` 查詢 `location_id`。

3. **NOC API 測試：WiFi radio 為主**

   - `_run_noc_api_tests()` 根據 env 決定要跑哪些子測試：
     - `ENABLE_SPEEDTEST = 0` → speedtest 會被跳過（log: `event="speedtest-skip"`）。
     - `ENABLE_WIFI_TEST = 1` → 會呼叫 `_run_wifi_tests()`。
     - `ENABLE_LTE_TEST = 0` → LTE 測試跳過（log: `event="lte-skip"`）。

   - `_run_wifi_tests()` 詳細流程：
     1. 呼叫 `wifi-status` 取得目前 WiFi 狀態，解析是否 `enabled`。
     2. **step 1：反轉 WiFi 狀態**
        - 如果目前 `enabled=True`，就呼叫 `wifi-disable`；
        - 如果目前 `enabled=False`，就呼叫 `wifi-enable`。
        - 再次呼叫 `wifi-status` 檢查狀態是否成功反轉。
        - log: `step="wifi-step-1-toggle"`, `ok=True/False`。
```
