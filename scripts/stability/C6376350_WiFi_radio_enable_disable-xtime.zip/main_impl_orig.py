#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
C001_SSH_api_test main implementation.

流程：
  1. 使用 NOC_EMAIL / NOC_PASSWORD login 取得 token
  2. 透過 serial (METRICS_TOOL) 取得 node_id
  3. 透過 NOC API 取得 location_id
  4. 跑一輪 NOC API 測試：
     - get-location 一致性確認
     - speedtest-run + speedtest-result (輪詢等待結果)
     - wifi-status / wifi-enable / wifi-disable（最後會還原）
     - lte-status
  5. 根據 SSH_ACTION (enable / disable / both) 做 ssh-enable / ssh-disable

依賴：
  - /home/da40/charter/tools/noc_api_cli.py (用 import noc_api_cli as api)
"""

import os
import sys
import json
import time
import subprocess
import socket
from typing import Dict, Optional

import requests  # 用來抓 HTTPError status code
from cpe_health_helper import run_cpe_health_check

# ---------- serial.mute stale cleanup (auto-added) ----------
import time as _time
import json as _json

_SERIAL_MUTE_PATH = "/home/da40/charter/var/serial.mute"

def _serial_mute_clear(reason: str) -> dict:
    """
    Clear stale/bad serial.mute only.
    - If file missing: noop
    - If until_ts <= now: unlink
    - If parse error / empty: unlink
    - If still active (left>0): skip (do NOT clear)
    Never raises.
    """
    now = int(_time.time())
    path = _SERIAL_MUTE_PATH
    try:
        if not os.path.exists(path):
            d = {"event":"serial_mute_clear","ok":True,"via":"noop","reason":reason,"path":path}
            print(_json.dumps(d, ensure_ascii=False), flush=True)
            return d
        try:
            raw = open(path, "r", encoding="utf-8", errors="ignore").read().strip()
        except Exception:
            raw = ""
        try:
            until = int(float(raw)) if raw else 0
        except Exception:
            until = 0
        left = max(0, until - now)
        if left > 0:
            d = {"event":"serial_mute_clear","ok":True,"via":"skip_active","reason":reason,"path":path,"left":left,"until_ts":until}
            print(_json.dumps(d, ensure_ascii=False), flush=True)
            return d
        # stale / bad / empty
        try:
            os.remove(path)
            d = {"event":"serial_mute_clear","ok":True,"via":"unlink_stale","reason":reason,"path":path,"until_ts":until}
            print(_json.dumps(d, ensure_ascii=False), flush=True)
            return d
        except FileNotFoundError:
            d = {"event":"serial_mute_clear","ok":True,"via":"noop","reason":reason,"path":path}
            print(_json.dumps(d, ensure_ascii=False), flush=True)
            return d
        except Exception as e:
            d = {"event":"serial_mute_clear","ok":False,"via":"error","reason":reason,"path":path,"error":str(e)}
            print(_json.dumps(d, ensure_ascii=False), flush=True)
            return d
    except Exception as e:
        d = {"event":"serial_mute_clear","ok":False,"via":"error_outer","reason":reason,"path":path,"error":str(e)}
        try:
            print(_json.dumps(d, ensure_ascii=False), flush=True)
        except Exception:
            pass
        return d
# ---------------------------------------------------------



# -------------------------------------------------
# 載入 tools 目錄底下的 noc_api_cli
# -------------------------------------------------
TOOLS_PATH = os.environ.get("TOOLS_PATH", "/home/da40/charter/tools")
if TOOLS_PATH and TOOLS_PATH not in sys.path:
    sys.path.insert(0, TOOLS_PATH)

try:
    import noc_api_cli as api  # type: ignore
except Exception as e:  # 在 ChatGPT sandbox 會失敗，在實機應該 OK
    api = None  # type: ignore
    print(json.dumps({"event": "import_warning", "module": "noc_api_cli", "error": str(e)}))

_CACHE: Dict[str, object] = {}


# -------------------------------------------------
# 小工具
# -------------------------------------------------
def _getenv(name: str, default: str = "") -> str:
    v = os.environ.get(name)
    return default if v is None else str(v)


def _bool_env(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return str(v).strip().lower() in ("1", "true", "yes", "y")


# -------------------------------------------------
# NOC profile helper (optional)
# - If NOC_PROFILE + PROFILES_FILE are provided, we can load base/email/password
#   from JSON (so manifest.yaml does not need to hardcode credentials)
# -------------------------------------------------

def _is_placeholder(v: str) -> bool:
    vv = (v or "").strip().lower()
    if not vv:
        return True
    return ("<" in vv and ">" in vv) or ("your-" in vv) or ("example" in vv)


def _load_noc_profile(profile: str, profiles_file: str) -> Optional[Dict[str, str]]:
    profile = (profile or "").strip()
    profiles_file = (profiles_file or "").strip()
    if not profile or not profiles_file:
        return None
    try:
        raw = open(profiles_file, "r", encoding="utf-8").read()
        data = json.loads(raw)
        obj = data.get(profile)
        if not isinstance(obj, dict):
            print(json.dumps({
                "event": "noc_profile_missing",
                "profile": profile,
                "profiles_file": profiles_file,
                "ok": False,
            }))
            return None
        base = str(obj.get("base", "")).strip()
        email = str(obj.get("email", "")).strip()
        password = str(obj.get("password", "")).strip()
        return {"base": base, "email": email, "password": password}
    except Exception as e:
        print(json.dumps({
            "event": "noc_profile_load_error",
            "profile": profile,
            "profiles_file": profiles_file,
            "ok": False,
            "error": str(e),
        }))
        return None

# -------------------------------------------------
# login / node / location
# -------------------------------------------------
def _login(base: str, email: str, password: str, bearer: bool, insecure: bool) -> str:
    if "token" in _CACHE:
        return _CACHE["token"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot login to NOC")

    tok = api.login(base, email, password, bearer=bearer, insecure=insecure)
    _CACHE["token"] = tok
    print(json.dumps({"step": "login", "ok": True}))
    return tok


def _node_id(metrics_tool: str, dev: str, baud: int, user: str, password: str) -> str:
    """Resolve node_id via `cpe_info --node-id` only (no console/serial)."""
    if "node_id" in _CACHE:
        try:
            print(json.dumps({"step": "node-id", "cached": True, "node_id": _CACHE["node_id"]}))
        except Exception:
            pass
        return _CACHE["node_id"]  # type: ignore[return-value]

    try:
        max_retries = int(os.environ.get("NODE_ID_MAX_RETRIES", "3"))
    except Exception:
        max_retries = 3
    try:
        retry_interval = float(os.environ.get("NODE_ID_RETRY_INTERVAL_SEC", "2"))
    except Exception:
        retry_interval = 2.0

    def _norm_node_id(raw: str) -> str:
        s = (raw or "").strip()
        if not s:
            return ""
        for ln in s.splitlines():
            ln = ln.strip()
            if ln:
                s = ln
                break
        s = s.replace(":", "").strip().lower()
        if len(s) == 12 and all(c in "0123456789abcdef" for c in s):
            return s
        return ""

    cpe_info_tool = os.environ.get("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
    last_raw = ""

    for attempt in range(1, max_retries + 1):
        for extra_args in (["--node-id"], ["--node-id", "--value"]):
            cmd = ([cpe_info_tool] if os.path.exists(cpe_info_tool) else ["cpe_info"]) + extra_args
            try:
                proc = subprocess.run(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    timeout=20,
                )
                last_raw = (proc.stdout or "").strip()
            except Exception as e:
                last_raw = str(e)
                print(json.dumps({
                    "step": "node-id-cpe_info-exception",
                    "attempt": attempt,
                    "cmd": cmd,
                    "error": str(e),
                }))
                continue

            nid = _norm_node_id(last_raw)
            ok = (proc.returncode == 0 and bool(nid))
            print(json.dumps({
                "step": "node-id-cpe_info",
                "attempt": attempt,
                "cmd": cmd,
                "rc": proc.returncode,
                "raw": last_raw,
                "node_id": nid if ok else "",
                "ok": ok,
            }))
            if ok:
                _CACHE["node_id"] = nid
                return nid

        if attempt < max_retries:
            print(json.dumps({
                "step": "node-id-retry",
                "attempt": attempt,
                "next_wait_sec": retry_interval,
            }))
            time.sleep(retry_interval)

    raise RuntimeError(f"cpe_info --node-id failed after {max_retries} retries; last_output={last_raw!r}")


def _location_id(base: str, customer_id: str, node_id: str,
                 token: str, bearer: bool, insecure: bool) -> str:
    if "location_id" in _CACHE:
        return _CACHE["location_id"]  # type: ignore[return-value]
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot query location_id")

    loc = api.get_location_id(base, customer_id, node_id,
                              token=token, bearer=bearer, insecure=insecure)
    _CACHE["location_id"] = loc
    print(json.dumps({"step": "location-id", "location_id": loc}))
    return loc


# -------------------------------------------------
# CPE console password fallback
# -------------------------------------------------
def _console_password(cpe_info_tool: str) -> str:
    """
    若 CPE_PASSWORD 未設定或為 null，嘗試透過 cpe_info 撈 console 密碼。
    """
    try:
        proc = subprocess.run(
            [cpe_info_tool, "--password"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=15,
        )
        out = (proc.stdout or "").strip()
        for line in out.splitlines():
            line = line.strip()
            if line:
                return line
    except Exception:
        pass
    return ""


# -------------------------------------------------
# SSH enable / disable
# -------------------------------------------------
def _ssh_enable(base: str, customer_id: str, location_id: str, node_id: str,
                ssh_pass: str, timeout_min: int,
                token: str, bearer: bool, insecure: bool) -> None:
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot enable SSH")

    resp = api.ssh_enable(
        base,
        customer_id,
        location_id,
        node_id,
        ssh_pass,
        timeout_min,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({"step": "ssh-enable", "resp": resp}))


def _ssh_disable(base: str, customer_id: str, location_id: str, node_id: str,
                 token: str, bearer: bool, insecure: bool) -> None:
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot disable SSH")

    resp = api.ssh_disable(
        base,
        customer_id,
        location_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({"step": "ssh-disable", "resp": resp}))




# -------------------------------------------------
# Precondition: cache token/node_id/location_id (A2435637-style)
# -------------------------------------------------

def _ensure_noc_context(base: str, email: str, password: str, bearer: bool, insecure: bool,
                        metrics_tool: str, dev: str, baud: int, cpe_user: str, cpe_password: str,
                        customer_id: str) -> Dict[str, str]:
    """Ensure token/node_id/location_id are available in _CACHE.

    Called early so later recovery paths can reuse cached node_id/location_id without
    re-touching serial. Emits a single precondition event.
    """
    pre = {
        "token_cached": "token" in _CACHE,
        "node_id_cached": "node_id" in _CACHE,
        "location_id_cached": "location_id" in _CACHE,
    }

    token = _login(base, email, password, bearer, insecure)
    node_id = _node_id(metrics_tool, dev, baud, cpe_user, cpe_password)
    location_id = _location_id(base, customer_id, node_id, token, bearer, insecure)

    try:
        print(json.dumps({
            "event": "precondition_noc_ctx",
            **pre,
            "node_id": node_id,
            "location_id": location_id,
        }))
    except Exception:
        pass

    return {"token": token, "node_id": node_id, "location_id": location_id}


def _http_status_from_exc(e: Exception) -> Optional[int]:
    # requests.HTTPError has response.status_code
    try:
        if isinstance(e, requests.HTTPError) and getattr(e, 'response', None) is not None:
            return int(e.response.status_code)  # type: ignore
    except Exception:
        pass
    # some libs attach .response
    resp = getattr(e, 'response', None)
    try:
        code = getattr(resp, 'status_code', None)
        return int(code) if code is not None else None
    except Exception:
        return None


def _cloud_ssh_enable_try(base: str, customer_id: str, location_id: str, node_id: str,
                          ssh_pass: str, timeout_min: int,
                          email: str, noc_password: str, bearer: bool, insecure: bool,
                          reason: str = "") -> bool:
    """Best-effort enable SSH via NOC.

    Uses cached token/node_id/location_id.
    If token is stale (401/403), clears token and re-logins once.
    """
    if api is None:
        print(json.dumps({"event": "cloud_ssh_enable_skip", "reason": "noc_api_cli_missing"}))
        return False

    print(json.dumps({
        "event": "cloud_ssh_enable_try",
        "base": base,
        "customer_id": customer_id,
        "location_id": location_id,
        "node_id": node_id,
        "reason": reason,
    }))

    def _do_enable(tok: str) -> None:
        _ssh_enable(base, customer_id, location_id, node_id,
                    ssh_pass, timeout_min,
                    token=tok, bearer=bearer, insecure=insecure)

    tok = str(_CACHE.get('token') or "")
    if not tok:
        tok = _login(base, email, noc_password, bearer, insecure)

    try:
        _do_enable(tok)
        print(json.dumps({"event": "cloud_ssh_enable_ok", "reason": reason}))
        return True
    except Exception as e:
        st = _http_status_from_exc(e)
        print(json.dumps({
            "event": "cloud_ssh_enable_error",
            "reason": reason,
            "status": st,
            "error": str(e),
        }))
        if st in (401, 403):
            try:
                _CACHE.pop('token', None)
            except Exception:
                pass
            try:
                tok2 = _login(base, email, noc_password, bearer, insecure)
                _do_enable(tok2)
                print(json.dumps({"event": "cloud_ssh_enable_ok", "reason": reason, "relogin": True}))
                return True
            except Exception as e2:
                st2 = _http_status_from_exc(e2)
                print(json.dumps({
                    "event": "cloud_ssh_enable_error",
                    "reason": reason,
                    "status": st2,
                    "error": str(e2),
                    "relogin": True,
                }))
        return False


def _ssh_port_is_open(host: str, port: int, timeout: float) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except Exception:
        return False


def _wait_ssh_port_open(host: str, port: int) -> bool:
    try:
        max_retries = int(os.environ.get('SSH_PORT_WAIT_MAX_RETRIES', '20'))
    except Exception:
        max_retries = 20
    try:
        timeout = float(os.environ.get('SSH_PORT_CHECK_TIMEOUT', '3'))
    except Exception:
        timeout = 3.0
    try:
        interval = float(os.environ.get('SSH_PORT_WAIT_INTERVAL_SEC', '3'))
    except Exception:
        interval = 3.0

    for attempt in range(1, max_retries + 1):
        ok = _ssh_port_is_open(host, port, timeout)
        print(json.dumps({
            "event": "ssh-port-wait",
            "host": host,
            "port": port,
            "attempt": attempt,
            "max_retries": max_retries,
            "timeout": timeout,
            "open": ok,
        }))
        if ok:
            print(json.dumps({
                "event": "ssh-port-wait-ok",
                "host": host,
                "port": port,
                "attempt": attempt,
            }))
            return True
        if attempt < max_retries:
            time.sleep(interval)
    return False


def _health_check_with_recover(tools_path: str, host: str, port: int,
                               base: str, customer_id: str, location_id: str, node_id: str,
                               email: str, noc_password: str, bearer: bool, insecure: bool,
                               ssh_pass: str, ssh_timeout_min: int) -> bool:
    """Run health check; if fail/timeout, immediately try NOC ssh-enable and retry once."""
    try:
        health_timeout = int(os.environ.get('CPE_HEALTH_TIMEOUT_SEC', os.environ.get('HEALTH_TIMEOUT_SEC', '180')))
    except Exception:
        health_timeout = 180

    ok = run_cpe_health_check(tools_path, host=host, timeout=health_timeout)
    if ok:
        return True

    if not _bool_env('SSH_RECOVER_ON_FAIL', True):
        return False

    _cloud_ssh_enable_try(
        base, customer_id, location_id, node_id,
        ssh_pass, ssh_timeout_min,
        email, noc_password, bearer, insecure,
        reason='health_fail_or_timeout',
    )

    try:
        wait_sec = float(os.environ.get('SSH_RECOVER_WAIT_SEC', '2'))
    except Exception:
        wait_sec = 2.0
    if wait_sec > 0:
        time.sleep(wait_sec)

    _wait_ssh_port_open(host, port)

    ok2 = run_cpe_health_check(tools_path, host=host, timeout=health_timeout)

    if not ok2:
        _cloud_ssh_enable_try(
            base, customer_id, location_id, node_id,
            ssh_pass, ssh_timeout_min,
            email, noc_password, bearer, insecure,
            reason='health_retry_failed_keep_ssh',
        )
        try:
            grace = float(os.environ.get('SSH_RECOVER_GRACE_SEC', '5'))
        except Exception:
            grace = 5.0
        if grace > 0:
            time.sleep(grace)

    return ok2

# -------------------------------------------------
# NOC API 測試 helpers
# -------------------------------------------------
def _run_speedtest_tests(base: str, customer_id: str, location_id: str, node_id: str,
                         token: str, bearer: bool, insecure: bool) -> None:
    """
    SpeedTest 測試流程：

      1) POST /speedTest 觸發一次測速 → 拿到 requestId
      2) 先等 SPEEDTEST_WAIT_SEC 秒（預設 60）
      3) 最多重試 SPEEDTEST_MAX_TRIES 次，每次間隔 SPEEDTEST_INTERVAL_SEC 秒
         呼叫 GET /speedTestResults/{requestId} 查單筆結果

    三個參數都用 env 控制：
      SPEEDTEST_WAIT_SEC
      SPEEDTEST_MAX_TRIES
      SPEEDTEST_INTERVAL_SEC
    """
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run speedtest tests")

    # 1) 觸發一次 speed test
    resp_run = api.speedtest_run(
        base,
        customer_id,
        location_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )

    request_id: Optional[str] = None
    if isinstance(resp_run, dict):
        request_id = (
            resp_run.get("requestId")
            or resp_run.get("request_id")
            or resp_run.get("id")
        )

    print(json.dumps({
        "step": "speedtest-run",
        "resp": resp_run,
        "request_id": request_id,
    }))

    if not request_id:
        raise RuntimeError("speedtest-run did not return requestId")

    # 2) 先等一段時間再開始查結果
    wait_sec = int(_getenv("SPEEDTEST_WAIT_SEC", "60"))
    print(json.dumps({
        "step": "speedtest-wait",
        "request_id": request_id,
        "seconds": wait_sec,
    }))
    time.sleep(wait_sec)

    # 3) 開始少量輪詢
    max_tries = int(_getenv("SPEEDTEST_MAX_TRIES", "3"))
    interval_sec = int(_getenv("SPEEDTEST_INTERVAL_SEC", "10"))

    last_error: Optional[str] = None
    resp_one: Optional[object] = None

    for attempt in range(1, max_tries + 1):
        try:
            resp_one = api.speedtest_result_by_id(
                base,
                customer_id,
                location_id,
                node_id,
                request_id,
                token=token,
                bearer=bearer,
                insecure=insecure,
            )
            # 呼叫成功（沒有丟 HTTPError）
            print(json.dumps({
                "step": "speedtest-result",
                "attempt": attempt,
                "request_id": request_id,
                "resp": resp_one,
            }))
            break

        except requests.HTTPError as e:
            status = e.response.status_code if e.response is not None else None
            body = e.response.text[:200] if e.response is not None else ""
            last_error = f"HTTP {status}: {body}"

            print(json.dumps({
                "step": "speedtest-result-retry",
                "attempt": attempt,
                "request_id": request_id,
                "status": status,
                "error": last_error,
            }))

            # 如果還有下一次機會，且是 400/404，就睡 interval_sec 秒再試
            if attempt < max_tries and status in (400, 404):
                time.sleep(interval_sec)
                continue

            # 其他情況（沒下一次或不是 400/404），直接丟出去
            raise

    if resp_one is None:
        # 全部嘗試完還失敗，就讓整個腳本 FAIL
        raise RuntimeError(f"speedtest-result failed after {max_tries} tries: {last_error}")


def _wifi_enabled_flag(status: object) -> Optional[bool]:
    """從 wifi-status 回傳的 JSON 抽出 enabled 狀態."""
    if isinstance(status, dict):
        # 1) 先看頂層有沒有 enabled
        if "enabled" in status:
            return bool(status.get("enabled"))

        # 2) 再看 wifiNetwork.enabled
        wn = status.get("wifiNetwork")
        if isinstance(wn, dict) and "enabled" in wn:
            return bool(wn.get("enabled"))

        # 3) 如果是 wifiNetworks 陣列，也處理一下（預留擴充）
        wns = status.get("wifiNetworks")
        if isinstance(wns, list) and wns and isinstance(wns[0], dict) and "enabled" in wns[0]:
            return bool(wns[0].get("enabled"))

    return None


def _run_wifi_tests(base: str, customer_id: str, location_id: str,
                    token: str, bearer: bool, insecure: bool) -> None:
    """wifi-status / wifi-enable / wifi-disable 功能測試，最後會盡量恢復原本狀態。

    這裡把重點步驟標示成三步：
      step 1: disable / enable WiFi（反轉目前狀態一次）
      step 2: restore WiFi（切回原本狀態）
      step 3: check no crash（先當 placeholder，實際判斷用 ok 欄位即可）
    """
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run wifi tests")

    # 先查目前狀態
    status_before = api.wifi_status(
        base,
        customer_id,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    enabled_before = _wifi_enabled_flag(status_before)
    print(json.dumps({
        "step": "wifi-status-before",
        "enabled": enabled_before,
        "resp": status_before,
    }))

    # 目標狀態：如果原本有值，就反轉；如果拿不到原始值，就先嘗試 enable 一次
    target_state = not bool(enabled_before) if enabled_before is not None else True
    action1 = "disable" if target_state is False else "enable"

    # step 1: 切換一次（disable 或 enable）
    resp_toggle = api.wifi_set_enabled(
        base,
        customer_id,
        location_id,
        target_state,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    status_mid = api.wifi_status(
        base,
        customer_id,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    enabled_mid = _wifi_enabled_flag(status_mid)
    print(json.dumps({
        "step": "wifi-step-1-toggle",
        "action": action1,
        "target": target_state,
        "enabled_mid": enabled_mid,
        "resp_toggle": resp_toggle,
        "status_mid": status_mid,
    }))

    # Optional hold time between toggle and restore
    hold_sec = int(os.environ.get("WIFI_TOGGLE_HOLD_SEC", "0"))
    if hold_sec > 0:
        print(json.dumps({
            "step": "wifi-wait-before-restore",
            "sec": hold_sec,
        }))
        time.sleep(hold_sec)

    # step 2 + step 3: 盡量恢復原本狀態，並檢查沒有 crash
    if enabled_before is not None and enabled_before != enabled_mid:
        resp_restore = api.wifi_set_enabled(
            base,
            customer_id,
            location_id,
            enabled_before,
            token=token,
            bearer=bearer,
            insecure=insecure,
        )
        status_after = api.wifi_status(
            base,
            customer_id,
            location_id,
            token=token,
            bearer=bearer,
            insecure=insecure,
        )
        enabled_after = _wifi_enabled_flag(status_after)
        ok = (enabled_after == enabled_before)
        action2 = "enable" if enabled_before else "disable"
        print(json.dumps({
            "step": "wifi-step-2-restore",
            "action": action2,
            "enabled_before": enabled_before,
            "enabled_after": enabled_after,
            "ok": ok,
            "resp_restore": resp_restore,
            "status_after": status_after,
        }))
        # step 3: check no crash（placeholder，實際上 ok==True 代表沒問題）
        print(json.dumps({
            "step": "wifi-step-3-check-no-crash",
            "ok": ok,
            "note": "placeholder; treat ok==True as no-crash",
        }))
        if not ok:
            raise RuntimeError("wifi enabled state mismatch after restore")
def _run_lte_test(base: str, location_id: str,
                  token: str, bearer: bool, insecure: bool) -> None:
    """lte-status 測試（僅查詢）。"""
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run LTE tests")

    resp = api.lte_status(
        base,
        location_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    print(json.dumps({
        "step": "lte-status",
        "resp": resp,
    }))


def _run_get_location_test(base: str, customer_id: str, node_id: str,
                           location_id: str,
                           token: str, bearer: bool, insecure: bool) -> None:
    """get-location 功能測試，確認回傳的 locationId 與前面取得的一致。"""
    if api is None:
        raise RuntimeError("noc_api_cli not available; cannot run get-location test")

    loc2 = api.get_location_id(
        base,
        customer_id,
        node_id,
        token=token,
        bearer=bearer,
        insecure=insecure,
    )
    ok = (loc2 == location_id)
    print(json.dumps({
        "step": "get-location-check",
        "location_id": location_id,
        "location_id_refetched": loc2,
        "ok": ok,
    }))
    if not ok:
        raise RuntimeError("location_id from get_location_id() mismatch")



# -------------------------------------------------
# Internet connectivity pre-check using cpe_info --internet
# -------------------------------------------------
def _wait_internet_connected() -> None:
    """在執行 speedtest 之前，透過 cpe_info --internet 確認 Internet Status: Connected。

    預設會重試 10 次，每次間隔 3 秒，可由環境變數覆蓋：
      INTERNET_CHECK_MAX_RETRIES
      INTERNET_CHECK_INTERVAL_SEC
    """
    cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")

    try:
        max_retries = int(_getenv("INTERNET_CHECK_MAX_RETRIES", "10"))
    except Exception:
        max_retries = 10

    try:
        interval_sec = float(_getenv("INTERNET_CHECK_INTERVAL_SEC", "3"))
    except Exception:
        interval_sec = 3.0

    last_output = ""

    for attempt in range(1, max_retries + 1):
        cmd = [cpe_info_tool, "--internet"]
        print(json.dumps({
            "step": "internet-check",
            "attempt": attempt,
            "max_retries": max_retries,
            "cmd": cmd,
        }))

        try:
            proc = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=30,
            )
            out = (proc.stdout or "").strip()
            last_output = out
        except Exception as e:
            print(json.dumps({
                "step": "internet-check-exception",
                "attempt": attempt,
                "error": str(e),
            }))
        else:
            print(json.dumps({
                "step": "internet-check-raw",
                "attempt": attempt,
                "rc": proc.returncode,
                "out": out,
            }))
            # 成功條件：rc == 0 且輸出中有 "Internet Status: Connected"
            if proc.returncode == 0 and "Internet Status: Connected" in out:
                print(json.dumps({
                    "step": "internet-check-ok",
                    "attempt": attempt,
                }))
                return

        # 還沒成功就睡一下再試
        if attempt < max_retries:
            time.sleep(interval_sec)

    # 全部重試完還是沒 Connected → 當成 precondition fail
    print(json.dumps({
        "step": "internet-check-failed",
        "max_retries": max_retries,
        "last_output": last_output[-200:],
    }))
    raise RuntimeError(
        f"internet not connected after {max_retries} checks via cpe_info --internet"
    )


def _run_noc_api_tests(base: str, customer_id: str, node_id: str, location_id: str,
                       token: str, bearer: bool, insecure: bool) -> None:
    """
    統一執行 NOC API 測試，並可透過環境變數決定是否啟用各項測試：

      ENABLE_SPEEDTEST  (預設 1)
      ENABLE_WIFI_TEST  (預設 1)
      ENABLE_LTE_TEST   (預設 1)
    """
    # 讀 env 開關
    enable_speedtest = _bool_env("ENABLE_SPEEDTEST", True)
    enable_wifi = _bool_env("ENABLE_WIFI_TEST", True)
    enable_lte = _bool_env("ENABLE_LTE_TEST", True)

    print(json.dumps({
        "event": "noc-api-tests-start",
        "enable_speedtest": enable_speedtest,
        "enable_wifi": enable_wifi,
        "enable_lte": enable_lte,
    }))

    # 一律先做 get-location 一致性檢查
    # WiFi long-run：只在第一次執行時檢查，後續 cycles 直接略過，避免因 NOC 偶發 timeout 中斷測試
    if not _CACHE.get("location_checked"):
        _run_get_location_test(base, customer_id, node_id, location_id,
                               token, bearer, insecure)
        _CACHE["location_checked"] = True
    else:
        print(json.dumps({
            "event": "get-location-skip",
            "reason": "already_checked",
        }))

    # speedtest
    if enable_speedtest:
        _wait_internet_connected()
        _run_speedtest_tests(base, customer_id, location_id, node_id,
                             token, bearer, insecure)
    else:
        print(json.dumps({
            "event": "speedtest-skip",
            "reason": "env_disabled",
        }))

    # wifi
    if enable_wifi:
        _run_wifi_tests(base, customer_id, location_id,
                        token, bearer, insecure)
    else:
        print(json.dumps({
            "event": "wifi-skip",
            "reason": "env_disabled",
        }))

    # lte
    if enable_lte:
        _run_lte_test(base, location_id,
                      token, bearer, insecure)
    else:
        print(json.dumps({
            "event": "lte-skip",
            "reason": "env_disabled",
        }))

    print(json.dumps({"event": "noc-api-tests-done"}))


# -------------------------------------------------
# main entrypoint for cycle_wrapper
# -------------------------------------------------
# -------------------------------------------------
# main entrypoint for cycle_wrapper
# -------------------------------------------------

def _noc_node_status_snapshot(base: str, node_id: str, location_id: str,
                              token: str, bearer: bool, insecure: bool) -> None:
    """
    呼叫 noc_api_cli node-status，印出精簡的雲端狀態資訊。
    """
    import subprocess

    cli_path = os.path.join(TOOLS_PATH or "/home/da40/charter/tools", "noc_api_cli.py")
    if not os.path.exists(cli_path):
        print(json.dumps({
            "event": "noc-node-status-skip",
            "reason": "missing_cli",
            "path": cli_path,
        }))
        return

    cmd = [sys.executable, cli_path]
    if bearer:
        cmd.append("--bearer")
    cmd.extend([
        "--token", token,
        "node-status",
        "--node-id", node_id,
        "--location-id", location_id,
    ])

    env = os.environ.copy()
    env.setdefault("NOC_BASE", base)

    try:
        proc = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=float(os.environ.get("NOC_NODE_STATUS_TIMEOUT", "10")),
            env=env,
        )
    except Exception as e:
        print(json.dumps({
            "event": "noc-node-status-error",
            "error": str(e),
        }))
        return

    if proc.returncode != 0:
        print(json.dumps({
            "event": "noc-node-status-error",
            "rc": proc.returncode,
            "stderr": (proc.stderr or "").strip()[-200:],
        }))
        return

    raw = (proc.stdout or "").strip()
    try:
        data = json.loads(raw) if raw else {}
    except Exception as e:
        print(json.dumps({
            "event": "noc-node-status-parse-error",
            "error": str(e),
            "raw_tail": raw[-200:],
        }))
        return

    summary = {
        "id": data.get("id"),
        "connectionState": data.get("connectionState"),
        "bootAt": data.get("bootAt"),
        "connectionStateChangeAt": data.get("connectionStateChangeAt"),
        "health": data.get("health"),
        "connectedDeviceCount": data.get("connectedDeviceCount"),
    }

    print(json.dumps({
        "event": "noc-node-status",
        "node_id": node_id,
        "location_id": location_id,
        "summary": summary,
    }))


def _cpe_uptime_snapshot(host: str) -> None:
    """
    透過 cpe_ssh.py --cmd uptime 抓 CPE uptime，印出 JSON event。
    需要環境變數 CPE_SSH_TOOL / SSH_USER / SSH_PASSWORD 已設定。
    """
    import subprocess

    tool = os.environ.get("CPE_SSH_TOOL", "/home/da40/charter/tools/cpe_ssh.py")
    user = os.environ.get("SSH_USER", "operator")
    password = os.environ.get("SSH_PASSWORD", "")

    if not os.path.exists(tool):
        print(json.dumps({
            "event": "cpe-uptime-skip",
            "reason": "missing_cpe_ssh",
            "path": tool,
        }))
        return

    cmd = [
        sys.executable, tool,
        "--host", host,
        "--user", user,
        "--password", password,
        "--cmd", "uptime",
    ]
    try:
        proc = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=float(os.environ.get("CPE_UPTIME_TIMEOUT", "10")),
        )
    except Exception as e:
        print(json.dumps({
            "event": "cpe-uptime-error",
            "error": str(e),
        }))
        return

    value = (proc.stdout or "").strip()
    print(json.dumps({
        "event": "cpe-uptime",
        "host": host,
        "rc": proc.returncode,
        "value": value,
        "stderr_tail": (proc.stderr or "").strip()[-120:],
    }))


def run() -> int:
    _serial_mute_clear("precondition")
    try:
        """
        entrypoint: ORIGINAL_ENTRY = main_impl_orig.py:run
        """
        # --- NOC 相關 ---
        base = _getenv("NOC_BASE", "https://piranha-int.tau.dev-charter.net")
        email = _getenv("NOC_EMAIL")
        password = _getenv("NOC_PASSWORD")
        bearer = _bool_env("BEARER", False)
        insecure = _bool_env("INSECURE", False)
        customer_id = _getenv("CUSTOMER_ID")


        # --- Optional: load NOC base/email/password from profiles JSON ---
        noc_profile = _getenv("NOC_PROFILE").strip()
        profiles_file = _getenv("PROFILES_FILE") or _getenv("NOC_PROFILES_PATH")
        prof = _load_noc_profile(noc_profile, profiles_file) if noc_profile and profiles_file else None
        if prof:
            used = {"base": False, "email": False, "password": False}
            if _is_placeholder(base):
                base = prof.get("base") or base
                used["base"] = True
            if _is_placeholder(email):
                email = prof.get("email") or email
                used["email"] = True
            if _is_placeholder(password):
                password = prof.get("password") or password
                used["password"] = True

            # Keep env in sync for downstream tools (do NOT print password)
            if used["base"]:
                os.environ["NOC_BASE"] = base
            if used["email"]:
                os.environ["NOC_EMAIL"] = email
            if used["password"]:
                os.environ["NOC_PASSWORD"] = password

            print(json.dumps({
                "event": "noc_profile_applied",
                "profile": noc_profile,
                "profiles_file": profiles_file,
                "base": base,
                "used": used,
                "email_set": bool(email),
                "password_set": bool(password),
            }))

        if not email or not password:
            print(json.dumps({
                "event": "missing_credentials",
                "email": bool(email),
                "password": bool(password),
            }))
            return 2

        # --- CPE / Serial ---
        metrics_tool = _getenv("METRICS_TOOL", "/home/da40/charter/tools/cpe_metrics_agent_serial.py")
        dev = _getenv("CPE_DEV", "/dev/ttyUSB0")
        baud = int(_getenv("CPE_BAUD", "115200"))
        cpe_user = _getenv("CPE_USER", "root")
        cpe_password = _getenv("CPE_PASSWORD", "")
        if str(cpe_password).strip().lower() in ("none", "null", "nil"):
            cpe_password = ""

        cpe_info_tool = _getenv("CPE_INFO_TOOL", "/home/da40/charter/tools/cpe_info")
        if not cpe_password:
            cpe_password = _console_password(cpe_info_tool)
            print(json.dumps({"step": "console-password-fallback", "len": len(cpe_password)}))

        # --- SSH 動作 ---
        ssh_user = _getenv("SSH_USER", "operator")
        ssh_pass = _getenv("SSH_PASSWORD", "")
        ssh_timeout_min = int(_getenv("SSH_TIMEOUT_MIN", "120"))
        ssh_action = _getenv("SSH_ACTION", "enable").strip().lower()

        # SSH flow 開關（預設啟用）
        enable_ssh_flow = _bool_env("ENABLE_SSH_FLOW", True)

        if ssh_action not in ("enable", "disable", "both"):
            print(json.dumps({"event": "bad_ssh_action", "ssh_action": ssh_action}))
            return 1

        print(json.dumps({
            "event": "params",
            "base": base,
            "customer_id": customer_id,
            "ssh_action": ssh_action,
            "ssh_user": ssh_user,
            "enable_ssh_flow": enable_ssh_flow,
        }))

        try:
            # 1) login + node/location
            # 1) Precondition: cache token/node_id/location_id (so recovery can reuse)
            ctx = _ensure_noc_context(
                base, email, password, bearer, insecure,
                metrics_tool, dev, baud, cpe_user, cpe_password,
                customer_id,
            )
            token = ctx["token"]
            node_id = ctx["node_id"]
            location_id = ctx["location_id"]

            # 2) NOC API tests (optional)
            if _bool_env("ENABLE_NOC_API_TESTS", True):
                _run_noc_api_tests(base, customer_id, node_id, location_id,
                                   token, bearer, insecure)
            else:
                print(json.dumps({
                    "event": "noc-api-tests-skip",
                    "reason": "env_disabled",
                }))

            # 3) SSH enable / disable（可整個關掉）
            if enable_ssh_flow:
                if ssh_action in ("enable", "both"):
                    _ssh_enable(base, customer_id, location_id, node_id,
                                ssh_pass, ssh_timeout_min, token, bearer, insecure)
                if ssh_action in ("disable", "both"):
                    _ssh_disable(base, customer_id, location_id, node_id,
                                 token, bearer, insecure)
            else:
                print(json.dumps({
                    "event": "ssh-flow-skip",
                    "reason": "env_disabled",
                }))

            # 4) Ensure SSH is reachable before health check (and recover if needed)
            host = os.environ.get("CPE_HEALTH_HOST", "192.168.1.1")
            try:
                port = int(os.environ.get("CPE_HEALTH_PORT", "22"))
            except Exception:
                port = 22
            try:
                ssh_port_timeout = float(os.environ.get("SSH_PORT_CHECK_TIMEOUT", "3"))
            except Exception:
                ssh_port_timeout = 3.0

            ssh_open = _ssh_port_is_open(host, port, ssh_port_timeout)
            print(json.dumps({
                "event": "ssh-port-check",
                "host": host,
                "port": port,
                "open": ssh_open,
            }))

            # If SSH is required and not open, immediately re-enable via NOC then wait
            if (not ssh_open) and enable_ssh_flow and ssh_action in ("enable", "both") and _bool_env('SSH_RECOVER_ON_FAIL', True):
                _cloud_ssh_enable_try(
                    base, customer_id, location_id, node_id,
                    ssh_pass, ssh_timeout_min,
                    email, password, bearer, insecure,
                    reason='pre_health_ssh_port_closed',
                )
                _wait_ssh_port_open(host, port)

            # 5) CPE health check — with immediate NOC SSH recover on fail/timeout
            health_ok = _health_check_with_recover(
                TOOLS_PATH, host, port,
                base, customer_id, location_id, node_id,
                email, password, bearer, insecure,
                ssh_pass, ssh_timeout_min,
            )

            # Evidence snapshots (best-effort)
            try:
                token2 = str(_CACHE.get('token') or token)
                _noc_node_status_snapshot(base, node_id, location_id, token2, bearer, insecure)
            except Exception as _e:
                print(json.dumps({'event': 'noc-node-status-snapshot-error', 'error': str(_e)}))
            try:
                _cpe_uptime_snapshot(host)
            except Exception as _e:
                print(json.dumps({'event': 'cpe-uptime-snapshot-error', 'error': str(_e)}))

            return 0 if health_ok else 1

        except Exception as e:
            print(json.dumps({"event": "exception", "error": str(e)}))
            return 1

    finally:
        _serial_mute_clear("postcondition")
if __name__ == "__main__":
    sys.exit(run())
